from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterable

from core.models import (
    CandidateType,
    EvidenceStatus,
    ParameterValue,
    SourceReference,
    ViewEvidence,
)


@dataclass(frozen=True)
class ExtractedMeasurement:
    """
    Medición o token técnico encontrado en evidencia documental.

    candidate_type clasifica la naturaleza técnica del valor:
    - MEASUREMENT: dimensión física (ancho, espesor, cota, etc.)
    - STATION: progresiva / kilometraje (eje lineal, NO activo físico)
    - ELEVATION: cota altimétrica sobre el nivel de referencia
    - ANGLE: orientación, rumbo, azimut o ángulo
    - IDENTIFIER: código o número de identificación
    - COUNT: cantidad entera de elementos
    - UNKNOWN_NUMERIC: valor numérico no contextualizado
    """

    raw_text: str
    value: float
    unit: str | None
    source: SourceReference
    candidate_type: CandidateType = CandidateType.UNKNOWN_NUMERIC

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_type": self.candidate_type.value,
            "raw_text": self.raw_text,
            "value": self.value,
            "unit": self.unit,
            "source": self.source.to_dict() if hasattr(self.source, "to_dict") else self.source,
        }


class ParameterExtractor:
    """
    Extractor conservador de valores y cotas documentales.

    PRINCIPIO:

    detectar un número no significa conocer automáticamente
    su significado técnico.

    Este módulo extrae candidatos clasificados.
    La asociación:

    valor -> dimensión -> objeto

    debe resolverse posteriormente.
    """

    STATION_PATTERN = re.compile(
        r"""
        (?P<full_station>
            (?:PK|KM)?\s*
            (?P<km>\d+)\s*\+\s*
            (?P<meters>\d+(?:[.,]\d+)?)
        )
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    ELEVATION_PATTERN = re.compile(
        r"""
        (?:COTA|ELEV|EL|Z)\s*[=:]?\s*
        (?P<value>[-+]?\d+(?:[.,]\d+)?)\s*
        (?P<unit>m|mm|cm)?
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    ANGLE_PATTERN = re.compile(
        r"""
        (?P<value>[-+]?\d+(?:[.,]\d+)?)\s*
        (?P<unit>°|deg|gon|rad)
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    DIMENSION_EXPRESSION_PATTERN = re.compile(
        r"""
        (?P<label>[A-ZÁÉÍÓÚÑ_]+)\s*=\s*
        (?P<value>[-+]?\d+(?:[.,]\d+)?)\s*
        (?P<unit>mm|cm|km|m)?
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    NUMBER_UNIT_PATTERN = re.compile(
        r"""
        (?<![\w.])
        (?P<value>
            [-+]?
            (?:\d+(?:[.,]\d+)?)
        )
        \s*
        (?P<unit>
            mm|cm|km|m
        )?
        (?![\w+])
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    def extract_measurements(
        self,
        view: ViewEvidence,
    ) -> list[ExtractedMeasurement]:
        """
        Extrae candidatos numéricos de los textos asociados a una vista,
        clasificándolos según su tipo técnico y evitando duplicaciones.
        """

        measurements: list[ExtractedMeasurement] = []

        for text in view.texts:
            consumed_spans: list[tuple[int, int]] = []

            # 1. Progresivas / Stations (PK 12+345.67, KM 12+345.67, 12+345.67)
            for match in self.STATION_PATTERN.finditer(text):
                km = float(self._parse_number(match.group("km")))
                meters = float(self._parse_number(match.group("meters")))
                station_m = km * 1000.0 + meters
                consumed_spans.append(match.span())

                measurements.append(
                    ExtractedMeasurement(
                        raw_text=match.group("full_station").strip(),
                        value=station_m,
                        unit="m",
                        source=view.source,
                        candidate_type=CandidateType.STATION,
                    )
                )

            # 2. Expresiones dimensionales explícitas (ANCHO = 7.30 m, ESPESOR = 0.20 m)
            for match in self.DIMENSION_EXPRESSION_PATTERN.finditer(text):
                # Verificar si se solapa con algo ya consumido
                span = match.span()
                if any(start <= span[0] and span[1] <= end for start, end in consumed_spans):
                    continue

                consumed_spans.append(span)
                val = self._parse_number(match.group("value"))
                unit = match.group("unit").lower() if match.group("unit") else None

                measurements.append(
                    ExtractedMeasurement(
                        raw_text=match.group(0).strip(),
                        value=val,
                        unit=unit,
                        source=view.source,
                        candidate_type=CandidateType.MEASUREMENT,
                    )
                )

            # 3. Elevaciones (COTA = 125.40 m)
            for match in self.ELEVATION_PATTERN.finditer(text):
                span = match.span()
                if any(start <= span[0] and span[1] <= end for start, end in consumed_spans):
                    continue

                consumed_spans.append(span)
                val = self._parse_number(match.group("value"))
                unit = match.group("unit").lower() if match.group("unit") else "m"

                measurements.append(
                    ExtractedMeasurement(
                        raw_text=match.group(0).strip(),
                        value=val,
                        unit=unit,
                        source=view.source,
                        candidate_type=CandidateType.ELEVATION,
                    )
                )

            # 4. Ángulos
            for match in self.ANGLE_PATTERN.finditer(text):
                span = match.span()
                if any(start <= span[0] and span[1] <= end for start, end in consumed_spans):
                    continue

                consumed_spans.append(span)
                val = self._parse_number(match.group("value"))
                unit = match.group("unit").lower()

                measurements.append(
                    ExtractedMeasurement(
                        raw_text=match.group(0).strip(),
                        value=val,
                        unit=unit,
                        source=view.source,
                        candidate_type=CandidateType.ANGLE,
                    )
                )

            # 5. Mediciones generales / números restantes
            for match in self.NUMBER_UNIT_PATTERN.finditer(text):
                span = match.span()
                # Omitir si este fragmento fue parte de una estación, elevación o dimensión ya procesada
                if any(not (span[1] <= start or span[0] >= end) for start, end in consumed_spans):
                    continue

                raw_value = match.group("value")
                value = self._parse_number(raw_value)
                unit = match.group("unit").lower() if match.group("unit") else None

                cand_type = (
                    CandidateType.MEASUREMENT
                    if unit in {"mm", "cm", "m", "km"}
                    else CandidateType.UNKNOWN_NUMERIC
                )

                measurements.append(
                    ExtractedMeasurement(
                        raw_text=match.group(0).strip(),
                        value=value,
                        unit=unit,
                        source=view.source,
                        candidate_type=cand_type,
                    )
                )

        return measurements

    def extract_station_values(
        self,
        texts: Iterable[str],
    ) -> list[float]:
        """
        Convierte progresivas tipo:

        PK 12+345.67

        a metros acumulados:

        12345.67

        IMPORTANTE:
        una progresiva es una posición sobre un eje.
        NO representa un objeto físico.
        """

        stations: list[
            float
        ] = []

        for text in texts:

            for pattern in (
                self.STATION_PATTERNS
            ):

                for match in (
                    pattern.finditer(
                        text
                    )
                ):

                    km = float(
                        self._parse_number(
                            match.group(1)
                        )
                    )

                    meters = float(
                        self._parse_number(
                            match.group(2)
                        )
                    )

                    stations.append(
                        km * 1000.0
                        + meters
                    )

        return stations

    def parameter_from_documented_value(
        self,
        name: str,
        value: float | str,
        unit: str | None,
        source: SourceReference,
        notes: str | None = None,
    ) -> ParameterValue:
        """
        Helper para crear explícitamente un parámetro
        documentado cuando la asociación semántica ya
        fue resuelta por otra etapa.
        """

        return ParameterValue(
            name=name,
            value=value,
            unit=unit,
            status=(
                EvidenceStatus.DOCUMENTED
            ),
            sources=[
                source
            ],
            notes=notes,
        )

    @staticmethod
    def normalize_length(
        value: float,
        unit: str | None,
    ) -> tuple[
        float,
        str | None,
    ]:
        """
        Normaliza longitudes conocidas a metros.

        Si la unidad es desconocida, NO se asume.
        """

        if unit is None:
            return (
                value,
                None,
            )

        normalized = (
            unit.lower()
        )

        factors = {
            "mm": 0.001,
            "cm": 0.01,
            "m": 1.0,
            "km": 1000.0,
        }

        if normalized not in factors:
            return (
                value,
                unit,
            )

        return (
            value
            * factors[
                normalized
            ],
            "m",
        )

    @staticmethod
    def _parse_number(
        value: str,
    ) -> float:
        """
        Soporta separador decimal coma o punto.
        """

        normalized = (
            value.strip()
            .replace(
                ",",
                ".",
            )
        )

        return float(
            normalized
        )
