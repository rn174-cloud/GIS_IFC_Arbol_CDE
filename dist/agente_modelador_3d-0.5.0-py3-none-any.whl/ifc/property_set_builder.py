from __future__ import annotations

from typing import Any
import ifcopenshell
import ifcopenshell.api.pset
from core.models import (
    ParametricGeometry,
    ReconstructedObject,
)


class IFCPropertySetBuilder:
    """
    Genera los Property Sets obligatorios de calidad, trazabilidad y parámetros:
    1. Pset_SourceTraceability
    2. Pset_ReconstructedParameters
    3. Pset_ReconstructionQuality
    """

    @staticmethod
    def build_traceability_pset(
        model: ifcopenshell.file,
        product: Any,
        obj: ReconstructedObject,
    ) -> Any:
        pset = ifcopenshell.api.pset.add_pset(
            model,
            product=product,
            name="Pset_SourceTraceability",
        )

        sources = "; ".join(sorted(set(obj.source_documents))) if obj.source_documents else "UNDOCUMENTED"
        sp = obj.spatial_reference or {}

        props = {
            "SourceId": obj.object_id,
            "SourceFiles": sources,
            "DocumentedFamily": str(obj.family or ""),
            "DocumentedType": str(obj.object_type or ""),
            "Station": float(sp.get("station", 0.0)) if sp.get("station") is not None else 0.0,
            "Offset": float(sp.get("offset", 0.0)) if sp.get("offset") is not None else 0.0,
            "Elevation": float(sp.get("elevation", 0.0)) if sp.get("elevation") is not None else 0.0,
        }

        ifcopenshell.api.pset.edit_pset(model, pset=pset, properties=props)
        return pset

    @staticmethod
    def build_reconstructed_parameters_pset(
        model: ifcopenshell.file,
        product: Any,
        obj: ReconstructedObject,
    ) -> Any:
        pset = ifcopenshell.api.pset.add_pset(
            model,
            product=product,
            name="Pset_ReconstructedParameters",
        )

        props: dict[str, Any] = {}
        for p_name, param in obj.parameters.items():
            if isinstance(param.value, (str, int, float, bool)):
                props[p_name] = param.value
                props[f"{p_name}_Status"] = param.status.value
                if param.unit:
                    props[f"{p_name}_Unit"] = param.unit

        if props:
            ifcopenshell.api.pset.edit_pset(model, pset=pset, properties=props)
        return pset

    @staticmethod
    def build_quality_pset(
        model: ifcopenshell.file,
        product: Any,
        obj: ReconstructedObject,
        geom: ParametricGeometry,
    ) -> Any:
        pset = ifcopenshell.api.pset.add_pset(
            model,
            product=product,
            name="Pset_ReconstructionQuality",
        )

        cb = obj.confidence_breakdown

        props = {
            "IdentityConfidence": cb.identity_confidence.value,
            "SemanticConfidence": cb.semantic_confidence.value,
            "ParameterConfidence": cb.parameter_confidence.value,
            "GeometryConfidence": geom.geometry_confidence.value,
            "GeometryRecipeId": geom.recipe_id,
            "GeometryValidationStatus": "VERIFIED" if geom.geometry_confidence.value == "VERIFIED" else "UNVERIFIED",
            "DataGapCount": len(obj.data_gaps) + len(geom.data_gaps),
            "ConflictCount": len(obj.conflicts) + len(geom.conflicts),
            "InferenceCount": len([p for p in obj.parameters.values() if p.status.value == "INFERRED"]),
            "ProvisionalCount": len([p for p in obj.parameters.values() if p.status.value == "PROVISIONAL"]),
        }

        ifcopenshell.api.pset.edit_pset(model, pset=pset, properties=props)
        return pset
