"""
Motor de reconstrucción documental y geométrica.

Esta capa transforma evidencia extraída de las fuentes en:

- vistas;
- parámetros;
- relaciones;
- objetos reconstruidos;
- definiciones geométricas.

Regla fundamental:

2D -> SIGNIFICADO -> OBJETO -> PARAMETROS
-> RELACIONES -> 3D -> IFC 4.3

Nunca:

LINEA 2D -> SOLIDO ARBITRARIO
"""

from reconstruction.view_classifier import ViewClassifier
from reconstruction.view_segmenter import ViewSegmenter
from reconstruction.parameter_extractor import ParameterExtractor
from reconstruction.semantic_signal_extractor import SemanticSignalExtractor
from reconstruction.object_candidate_detector import (
    ObjectCandidateDetector,
    compute_candidate_confidence,
)
from reconstruction.reference_resolver import ReferenceResolver
from reconstruction.multiview_matcher import MultiViewMatcher
from reconstruction.object_hypothesis_resolver import ObjectHypothesisResolver
from reconstruction.multiview_solver import MultiViewSolver
from reconstruction.object_reconstructor import ObjectReconstructor

from reconstruction.asset_context_resolver import AssetContextResolver
from reconstruction.visual_context_resolver import VisualContextResolver
from reconstruction.document_role_resolver import DocumentRoleResolver
from reconstruction.asset_assembly_resolver import AssetAssemblyResolver
from reconstruction.source_question_planner import SourceQuestionPlanner
from reconstruction.relationship_reasoner import RelationshipReasoner
from reconstruction.parametric_recipe_library import ParametricRecipeLibrary, GenericRecipePattern
from reconstruction.alignment_generator import AlignmentAwareGenerator, AlignmentFrame
from reconstruction.conflict_detector import ConflictDetector
from reconstruction.provisional_model_manager import ProvisionalModelManager
from reconstruction.directed_evidence_searcher import DirectedEvidenceSearcher

__all__ = [
    "ViewClassifier",
    "ViewSegmenter",
    "ParameterExtractor",
    "SemanticSignalExtractor",
    "ObjectCandidateDetector",
    "compute_candidate_confidence",
    "ReferenceResolver",
    "MultiViewMatcher",
    "ObjectHypothesisResolver",
    "MultiViewSolver",
    "ObjectReconstructor",
    "AssetContextResolver",
    "VisualContextResolver",
    "DocumentRoleResolver",
    "AssetAssemblyResolver",
    "SourceQuestionPlanner",
    "RelationshipReasoner",
    "ParametricRecipeLibrary",
    "GenericRecipePattern",
    "AlignmentAwareGenerator",
    "AlignmentFrame",
    "ConflictDetector",
    "ProvisionalModelManager",
    "DirectedEvidenceSearcher",
]


