from __future__ import annotations

from typing import Any
from core.models import (
    DocumentConflict,
    EvidenceStatus,
    ParameterEligibilityStatus,
    ParameterValue,
)


class GeometryParameterResolver:
    """
    Motor de elegibilidad de parámetros para reconstrucción geométrica 3D.
    
    Responsabilidad:
    Decidir si un parámetro posee solidez documental suficiente para ser empleado
    en la formulación de sólidos paramétricos 3D.
    
    Políticas:
    - Modo ESTRICTO / VERIFIED:
        Admite: DOCUMENTED, DERIVED, INTERPOLATED.
        Rechaza: INFERRED, PROVISIONAL, UNKNOWN, CONFLICT.
    - Modo PRELIMINARY:
        Admite: DOCUMENTED, DERIVED, INTERPOLATED, INFERRED, PROVISIONAL.
        Rechaza: UNKNOWN, CONFLICT.
        (La geometría construida en modo preliminar NO puede obtener estado VERIFIED).
    """

    def __init__(self, mode: str = "STRICT") -> None:
        self.mode = mode.upper()

    def evaluate_parameter(
        self,
        parameter: ParameterValue,
        conflicts: list[DocumentConflict] | None = None,
    ) -> ParameterEligibilityStatus:
        """
        Evalúa un parámetro individual y determina su elegibilidad.
        """
        # Verificar si el parámetro está afectado por un conflicto documental no resuelto
        if conflicts:
            for conf in conflicts:
                if conf.parameter == parameter.name and conf.resolution != "RESOLVED":
                    return ParameterEligibilityStatus.REJECTED_CONFLICT

        status = parameter.status

        if status == EvidenceStatus.DOCUMENTED:
            return ParameterEligibilityStatus.ACCEPTED_DOCUMENTED
        elif status == EvidenceStatus.DERIVED:
            return ParameterEligibilityStatus.ACCEPTED_DERIVED
        elif status == EvidenceStatus.INTERPOLATED:
            return ParameterEligibilityStatus.ACCEPTED_INTERPOLATED
        elif status == EvidenceStatus.INFERRED:
            if self.mode == "PRELIMINARY":
                return ParameterEligibilityStatus.REJECTED_INFERRED  # clasificado, pero aceptado condicionalmente por filter
            return ParameterEligibilityStatus.REJECTED_INFERRED
        elif status == EvidenceStatus.PROVISIONAL:
            return ParameterEligibilityStatus.REJECTED_PROVISIONAL
        elif status == EvidenceStatus.UNKNOWN:
            return ParameterEligibilityStatus.REJECTED_UNKNOWN
        else:
            return ParameterEligibilityStatus.REJECTED_UNKNOWN

    def filter_eligible_parameters(
        self,
        parameters: dict[str, ParameterValue],
        conflicts: list[DocumentConflict] | None = None,
    ) -> tuple[dict[str, ParameterValue], dict[str, ParameterEligibilityStatus]]:
        """
        Filtra los parámetros elegibles y devuelve el mapa de elegibles junto con el diagnóstico de cada uno.
        """
        eligible: dict[str, ParameterValue] = {}
        evaluations: dict[str, ParameterEligibilityStatus] = {}

        for name, param in parameters.items():
            status = self.evaluate_parameter(param, conflicts=conflicts)
            evaluations[name] = status

            if self.mode == "PRELIMINARY":
                if status in {
                    ParameterEligibilityStatus.ACCEPTED_DOCUMENTED,
                    ParameterEligibilityStatus.ACCEPTED_DERIVED,
                    ParameterEligibilityStatus.ACCEPTED_INTERPOLATED,
                } or param.status in {EvidenceStatus.INFERRED, EvidenceStatus.PROVISIONAL}:
                    eligible[name] = param
            else:
                # STRICT
                if status in {
                    ParameterEligibilityStatus.ACCEPTED_DOCUMENTED,
                    ParameterEligibilityStatus.ACCEPTED_DERIVED,
                    ParameterEligibilityStatus.ACCEPTED_INTERPOLATED,
                }:
                    eligible[name] = param

        return eligible, evaluations
