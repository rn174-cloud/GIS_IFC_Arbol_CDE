from __future__ import annotations

import hashlib
import re
from typing import Any, Optional

from core.models import (
    ConsolidatedParameter,
    DocumentConflict,
    EvidenceOrigin,
    EvidenceStatus,
    ObjectCandidate,
    ObjectHypothesis,
    ParameterBindingCandidate,
    ParameterReadiness,
    SourceDocument,
    SourceReference,
    UnitResolutionStatus,
)
from reconstruction.unit_resolver import UnitResolver


class MultidocumentSynthesizer:
    """
    Sintetizador multidocumental de parámetros y compuerta estricta de identidad (Identity Gate) v0.5.3.

    PRINCIPIOS:
    1. MULTIDOCUMENT IDENTITY GATE:
       Prohibido fusionar parámetros entre documentos distintos por mera similitud de tipo,
       geometría, disciplina o proximidad nominal.
       Exige decisión auditable SAME_OBJECT o POSSIBLE_SAME_OBJECT basada en:
       - Tag o identificador explícito;
       - Referencia a detalle o sección (callout);
       - Estación/progresiva coincidente o coordenadas en tolerancia;
       - Referencia cruzada documental (ej. RVA_... en notas/referencias);
       - Relación gobernada CDE.
    2. TRATAMIENTO DE DUPLICADOS (EVIDENCE ORIGIN GROUP):
       DWG y PDF del mismo plano pertenecen al mismo grupo de origen. No cuentan como dos
       evidencias independientes ni inflan artificialmente la confianza.
    3. PROHIBICIÓN DE VALOR TÍPICO:
       Prohibido incorporar 'espesor típico' o valores habituales sin vínculo documental gobernado.
    4. CONSOLIDACIÓN Y DETECCIÓN DE CONFLICTOS REALES:
       Solo crear DOCUMENT_CONFLICT cuando coincidan: mismo parámetro físico + misma identidad +
       misma base de unidad + valores incompatibles fuera de tolerancia sin regla de precedencia.
    """

    CALLOUT_PATTERN = re.compile(
        r"(?:VER|S/|SEG[UÚ]N|REF\.?)\s*(?:PLANO|DETALLE|CORTE)?\s*([A-Z0-9_\-]+)",
        re.IGNORECASE,
    )
    DRAWING_REF_PATTERN = re.compile(
        r"\b(?:RVA|DWG|PLANO)[\-_A-Z0-9]+\b",
        re.IGNORECASE,
    )

    def __init__(self, unit_resolver: Optional[UnitResolver] = None) -> None:
        self.unit_resolver = unit_resolver or UnitResolver()

    def evaluate_multidocument_identity_gate(
        self,
        candidate_a: ObjectCandidate,
        candidate_b: ObjectCandidate,
        doc_a: Optional[SourceDocument] = None,
        doc_b: Optional[SourceDocument] = None,
    ) -> tuple[bool, str, float, list[dict[str, Any]]]:
        """
        Evalúa si dos candidatos provenientes de documentos diferentes corresponden
        al MISMO objeto físico con evidencia suficiente.
        """
        evidence_records: list[dict[str, Any]] = []
        confidence = 0.0

        # Si provienen del mismo documento, es correspondencia intra-documental
        src_a = candidate_a.source_ids[0] if candidate_a.source_ids else "src_a"
        src_b = candidate_b.source_ids[0] if candidate_b.source_ids else "src_b"

        # 1. Verificar si son duplicados DWG + PDF del mismo plano (mismo file root)
        clean_name_a = src_a.split("#")[0].replace(".dwg", "").replace(".pdf", "").strip()
        clean_name_b = src_b.split("#")[0].replace(".dwg", "").replace(".pdf", "").strip()
        if clean_name_a == clean_name_b:
            evidence_records.append({
                "type": "SAME_DOCUMENT_REPRESENTATION",
                "detail": f"Formatos complementarios DWG/PDF del mismo plano {clean_name_a}",
                "origin_group": clean_name_a,
            })
            return True, "SAME_OBJECT", 0.90, evidence_records

        # 2. Identificador unívoco explícito coincidente
        ids_a = set(candidate_a.labels or [])
        ids_b = set(candidate_b.labels or [])
        common_ids = ids_a.intersection(ids_b)
        # Filtrar identificadores genéricos
        specific_common = {i for i in common_ids if not i.startswith("MOTIF_") and len(i) > 2}
        if specific_common:
            evidence_records.append({
                "type": "MATCHING_EXPLICIT_IDENTIFIER",
                "detail": f"Identificadores compartidos: {sorted(specific_common)}",
                "identifiers": sorted(specific_common),
            })
            confidence += 0.85

        # 3. Referencias cruzadas documentales (ej. plano A cita a plano B en notas)
        texts_a = candidate_a.related_texts or []
        texts_b = candidate_b.related_texts or []
        for t_a in texts_a:
            for ref in self.DRAWING_REF_PATTERN.findall(t_a):
                if ref.lower() in src_b.lower() or (doc_b and ref.lower() in str(doc_b.path).lower()):
                    evidence_records.append({
                        "type": "DOCUMENTED_CROSS_REFERENCE",
                        "detail": f"Plano A cita referencia {ref} correspondiente al Plano B",
                        "reference": ref,
                    })
                    confidence += 0.40

        # 4. Progresiva / Estación LRS coincidente en tolerancia
        if candidate_a.station is not None and candidate_b.station is not None:
            st_diff = abs(candidate_a.station - candidate_b.station)
            if st_diff <= 0.50:  # Dentro de 50 cm
                evidence_records.append({
                    "type": "LRS_STATION_MATCH",
                    "detail": f"Estaciones compatibles: PK {candidate_a.station:.3f} vs {candidate_b.station:.3f} (diff={st_diff:.3f}m)",
                })
                confidence += 0.50

        # 5. Compatibilidad semántica y de vistas complementarias (PLANTA + CORTE)
        if (
            candidate_a.probable_family == candidate_b.probable_family
            and candidate_a.probable_family.value != "UNKNOWN"
            and candidate_a.probable_type == candidate_b.probable_type
        ):
            views_a = set(candidate_a.view_ids or [])
            views_b = set(candidate_b.view_ids or [])
            # Si uno es planta y el otro es elevación/corte
            has_complementary_views = any("PLAN" in va for va in views_a) and any(
                "ELEV" in vb or "SEC" in vb or "CORTE" in vb for vb in views_b
            )
            if has_complementary_views and confidence >= 0.40:
                evidence_records.append({
                    "type": "COMPLEMENTARY_VIEWS_ALIGNED",
                    "detail": "Vista en planta combinada con vista en corte/elevación bajo misma identidad",
                })
                confidence += 0.30

        # Decisión auditable del Gate según evidencia independiente cualificada (Ajuste obligatorio 1)
        # Prohibido usar regla arbitraria confidence >= 0.80 -> SAME_OBJECT
        ev_types = {e["type"] for e in evidence_records}
        has_same_doc = "SAME_DOCUMENT_REPRESENTATION" in ev_types
        has_explicit_id = "MATCHING_EXPLICIT_IDENTIFIER" in ev_types
        has_cross_ref = "DOCUMENTED_CROSS_REFERENCE" in ev_types
        has_station_and_views = ("LRS_STATION_MATCH" in ev_types and "COMPLEMENTARY_VIEWS_ALIGNED" in ev_types)

        confidence = min(confidence, 1.0)
        if has_same_doc or has_explicit_id or has_cross_ref or has_station_and_views:
            return True, "SAME_OBJECT", confidence, evidence_records
        elif evidence_records:
            # Evidencia parcial o débil: POSSIBLE_SAME_OBJECT
            # NO autoriza síntesis crítica para BUILT (authorized=False)
            return False, "POSSIBLE_SAME_OBJECT", confidence, evidence_records
        else:
            return False, "MULTIDOCUMENT_SYNTHESIS_NOT_AUTHORIZED", confidence, evidence_records

    def synthesize_parameters_for_hypothesis(
        self,
        hypothesis: ObjectHypothesis,
        binding_candidates: list[ParameterBindingCandidate],
        source_documents: Optional[list[SourceDocument]] = None,
    ) -> tuple[dict[str, ConsolidatedParameter], list[DocumentConflict], ParameterReadiness]:
        """
        Consolida parámetros físicos agrupados por nombre para una hipótesis de objeto.
        Detecta conflictos reales y calcula la preparación paramétrica (Readiness).
        """
        # Si la hipótesis involucra múltiples documentos pero no tiene autorización SAME_OBJECT:
        # Rechazar mediciones de documentos secundarios para no fusionar sin identidad física suficiente.
        primary_source = hypothesis.source_ids[0] if hypothesis.source_ids else None
        rejected_sources: set[str] = set()
        filtered_bindings: list[ParameterBindingCandidate] = []

        is_same_object = (hypothesis.identity_gate_status == "SAME_OBJECT")
        distinct_sources = {s.split("#")[0] for s in hypothesis.source_ids if s}

        if not is_same_object and len(distinct_sources) > 1:
            for b in binding_candidates:
                if b.source_id and primary_source and b.source_id.split("#")[0] != primary_source.split("#")[0]:
                    rejected_sources.add(b.source_id)
                else:
                    filtered_bindings.append(b)
        else:
            filtered_bindings = binding_candidates

        by_param: dict[str, list[ParameterBindingCandidate]] = {}
        for b in filtered_bindings:
            if b.parameter_name != "DIMENSION_UNRESOLVED":
                by_param.setdefault(b.parameter_name, []).append(b)

        consolidated: dict[str, ConsolidatedParameter] = {}
        conflicts: list[DocumentConflict] = []

        for p_name, b_list in by_param.items():
            # 1. Agrupar por EvidenceOriginGroup para no duplicar DWG/PDF
            origin_groups: set[str] = set()
            sources_set: list[SourceReference] = []
            for b in b_list:
                src_path = b.source_id or "unknown"
                clean_origin = src_path.split("#")[0].replace(".dwg", "").replace(".pdf", "").strip()
                origin_groups.add(clean_origin)
                sources_set.append(
                    SourceReference(source_file=b.source_id, entity_id=b.dimension_handle, view=b.view_id)
                )

            # 2. Analizar valores numéricos
            valid_b = [b for b in b_list if b.raw_value is not None]
            if not valid_b:
                continue

            # Si hay un solo valor o todos provienen del mismo grupo de origen idéntico
            if len(valid_b) == 1:
                b0 = valid_b[0]
                is_unit_resolved = (
                    b0.unit_resolution_status in {UnitResolutionStatus.UNIT_DOCUMENTED, UnitResolutionStatus.UNIT_DERIVED}
                    and b0.resolved_value is not None
                    and b0.raw_unit != "CAD_UNIT"
                )

                if is_unit_resolved:
                    status = EvidenceStatus.DOCUMENTED
                    canon_val = b0.resolved_value
                    res_val = b0.resolved_value
                    res_unit = b0.resolved_unit or "m"
                    factor = b0.conversion_factor
                    u_status = b0.unit_resolution_status
                else:
                    # CAD_UNIT NO ES METRE: unidad no resuelta -> no se infiere metro ni se aplica conversion_factor
                    status = EvidenceStatus.UNKNOWN
                    canon_val = None
                    res_val = None
                    res_unit = None
                    factor = None
                    u_status = UnitResolutionStatus.UNIT_UNRESOLVED

                cp = ConsolidatedParameter(
                    parameter_name=p_name,
                    canonical_value=canon_val,
                    canonical_unit="m",
                    raw_value=b0.raw_value,
                    raw_unit=b0.raw_unit,
                    resolved_value=res_val,
                    resolved_unit=res_unit,
                    conversion_factor=factor,
                    status=status,
                    confidence=b0.confidence if is_unit_resolved else 0.10,
                    sources=sources_set,
                    evidence_origin_groups=sorted(origin_groups),
                    binding_methods=[b0.binding_method],
                    document_conflicts=[],
                    unit_resolution_status=u_status,
                    identity_decision=hypothesis.identity_gate_status,
                    identity_evidence=hypothesis.identity_evidence,
                    identity_confidence=hypothesis.confidence,
                    notes=(
                        f"Parámetro {p_name} consolidado desde {b0.binding_method}"
                        if is_unit_resolved
                        else f"Parámetro {p_name} con unidad física no resuelta (raw_unit={b0.raw_unit})"
                    ),
                )
                consolidated[p_name] = cp

            else:
                # Múltiples mediciones para el MISMO parámetro físico
                # Evaluar si todas tienen unidad resuelta
                any_unresolved = any(
                    b.unit_resolution_status in {UnitResolutionStatus.UNIT_UNRESOLVED, UnitResolutionStatus.UNIT_SCALE_HYPOTHESIS}
                    or b.resolved_value is None
                    or b.raw_unit == "CAD_UNIT"
                    for b in valid_b
                )

                if any_unresolved:
                    # No fusionar si hay unidades sin resolver documentalmente
                    cp = ConsolidatedParameter(
                        parameter_name=p_name,
                        canonical_value=None,
                        canonical_unit="m",
                        raw_value=valid_b[0].raw_value,
                        raw_unit=valid_b[0].raw_unit,
                        resolved_value=None,
                        resolved_unit=None,
                        conversion_factor=None,
                        status=EvidenceStatus.UNKNOWN,
                        confidence=0.10,
                        sources=sources_set,
                        evidence_origin_groups=sorted(origin_groups),
                        binding_methods=list({b.binding_method for b in valid_b}),
                        document_conflicts=[],
                        unit_resolution_status=UnitResolutionStatus.UNIT_UNRESOLVED,
                        identity_decision=hypothesis.identity_gate_status,
                        identity_evidence=hypothesis.identity_evidence,
                        identity_confidence=hypothesis.confidence,
                        notes=f"Parámetro {p_name} bloqueado por unidades físicas no resueltas en una o más fuentes.",
                    )
                    consolidated[p_name] = cp
                    continue

                canonical_values = [b.resolved_value for b in valid_b if b.resolved_value is not None]
                val_min, val_max = min(canonical_values), max(canonical_values)
                diff = abs(val_max - val_min)

                # Tolerancia admisible (5 cm o 2% del valor)
                tol = max(0.05, 0.02 * val_max)

                if diff <= tol:
                    mean_val = round(sum(canonical_values) / len(canonical_values), 4)
                    cp = ConsolidatedParameter(
                        parameter_name=p_name,
                        canonical_value=mean_val,
                        canonical_unit="m",
                        raw_value=valid_b[0].raw_value,
                        raw_unit=valid_b[0].raw_unit,
                        resolved_value=mean_val,
                        resolved_unit="m",
                        conversion_factor=valid_b[0].conversion_factor,
                        status=EvidenceStatus.DOCUMENTED,
                        confidence=0.92,
                        sources=sources_set,
                        evidence_origin_groups=sorted(origin_groups),
                        binding_methods=list({b.binding_method for b in valid_b}),
                        document_conflicts=[],
                        unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED,
                        identity_decision=hypothesis.identity_gate_status,
                        identity_evidence=hypothesis.identity_evidence,
                        identity_confidence=hypothesis.confidence,
                        notes="Fuentes múltiples compatibles consolidadas sin discrepancia.",
                    )
                    consolidated[p_name] = cp

                else:
                    # CONFLICTO REAL DOCUMENTADO (mismo parámetro físico, valores incompatibles)
                    src_a = SourceReference(source_file=valid_b[0].source_id, entity_id=valid_b[0].dimension_handle)
                    src_b = SourceReference(source_file=valid_b[1].source_id, entity_id=valid_b[1].dimension_handle)
                    conflict = DocumentConflict(
                        object_id=hypothesis.hypothesis_id,
                        parameter=p_name,
                        source_a=src_a,
                        value_a=canonical_values[0],
                        source_b=src_b,
                        value_b=canonical_values[1],
                        impact=f"Valores discrepantes para el parámetro físico {p_name} ({canonical_values[0]} vs {canonical_values[1]})",
                        resolution="UNRESOLVED",
                    )
                    conflicts.append(conflict)

                    cp = ConsolidatedParameter(
                        parameter_name=p_name,
                        canonical_value=None,
                        canonical_unit="m",
                        raw_value=valid_b[0].raw_value,
                        raw_unit=valid_b[0].raw_unit,
                        status=EvidenceStatus.UNKNOWN,
                        confidence=0.20,
                        sources=sources_set,
                        evidence_origin_groups=sorted(origin_groups),
                        binding_methods=list({b.binding_method for b in valid_b}),
                        document_conflicts=[conflict],
                        unit_resolution_status=valid_b[0].unit_resolution_status,
                        identity_decision=hypothesis.identity_gate_status,
                        identity_evidence=hypothesis.identity_evidence,
                        identity_confidence=hypothesis.confidence,
                        notes="Bloqueado por DOCUMENT_CONFLICT_UNRESOLVED.",
                    )
                    consolidated[p_name] = cp

        # 3. Calcular ParameterReadiness
        fam_str = hypothesis.probable_family.value.upper()
        type_str = hypothesis.probable_type.upper()

        if any(k in type_str or k in fam_str for k in ["COLUMN", "COLUMNA", "PILOTE", "PILA"]):
            required = ["DIAMETRO", "ALTURA"]
        elif any(k in type_str or k in fam_str for k in ["SLAB", "LOSA", "PAVEMENT", "CALZADA"]):
            required = ["ANCHO", "LONGITUD", "ESPESOR"]
        elif any(k in type_str or k in fam_str for k in ["BEAM", "VIGA", "BARRIER", "DEFENSA"]):
            required = ["ANCHO", "ALTURA", "LONGITUD"]
        else:
            required = ["ANCHO", "LONGITUD"]

        # Evaluar parámetros requeridos que están resueltos documentalmente
        resolved_req = []
        unresolved_req = []
        for req in required:
            # Aceptar RADIO como alternativa de DIAMETRO
            if req == "DIAMETRO" and "RADIO" in consolidated:
                r_cp = consolidated["RADIO"]
                if (
                    r_cp.canonical_value is not None
                    and r_cp.status in {EvidenceStatus.DOCUMENTED, EvidenceStatus.DERIVED}
                    and r_cp.unit_resolution_status in {UnitResolutionStatus.UNIT_DOCUMENTED, UnitResolutionStatus.UNIT_DERIVED}
                ):
                    resolved_req.append("DIAMETRO")
                else:
                    unresolved_req.append("DIAMETRO")
            elif (
                req in consolidated
                and consolidated[req].canonical_value is not None
                and consolidated[req].status in {EvidenceStatus.DOCUMENTED, EvidenceStatus.DERIVED}
                and consolidated[req].unit_resolution_status in {UnitResolutionStatus.UNIT_DOCUMENTED, UnitResolutionStatus.UNIT_DERIVED}
            ):
                resolved_req.append(req)
            else:
                unresolved_req.append(req)

        score = len(resolved_req) / len(required) if required else 0.0
        is_ready = (len(unresolved_req) == 0 and len(conflicts) == 0)

        readiness = ParameterReadiness(
            object_id=hypothesis.hypothesis_id,
            required_parameters=required,
            resolved_required_parameters=resolved_req,
            unresolved_required_parameters=unresolved_req,
            parameter_readiness=round(score, 3),
            is_ready_for_built=is_ready,
            notes=f"Readiness {score*100:.1f}% ({len(resolved_req)}/{len(required)}) - Ready: {is_ready}",
        )

        return consolidated, conflicts, readiness
