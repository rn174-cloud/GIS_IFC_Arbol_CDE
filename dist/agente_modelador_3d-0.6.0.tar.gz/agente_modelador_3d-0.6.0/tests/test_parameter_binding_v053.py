"""
tests/test_parameter_binding_v053.py
Batería de 12 tests funcionales específicos para v0.5.3:
Parameter Binding, Unit Resolution y Multidocument Synthesis.
"""
from __future__ import annotations

from pathlib import Path
import pytest

from core.geometry_kernel import LocalFrame, Point3D, Vector3D
from core.models import (
    CandidateStatus,
    CandidateType,
    ConsolidatedParameter,
    EvidenceOrigin,
    EvidenceStatus,
    GeometryRecipe,
    ObjectCandidate,
    ObjectHypothesis,
    ParameterBindingCandidate,
    ParameterReadiness,
    ParameterValue,
    QualityConfidenceLevel,
    RecipeType,
    ReconstructedObject,
    SemanticFamily,
    SourceDocument,
    SourceReference,
    UnitResolutionStatus,
)
from reconstruction.multidocument_synthesizer import MultidocumentSynthesizer
from reconstruction.parameter_binding_resolver import ParameterBindingResolver
from reconstruction.parametric_geometry_builder import ParametricGeometryBuilder
from reconstruction.unit_resolver import UnitResolver


def test_two_orthogonal_dimensions_bind_to_different_parameters():
    """1. Two orthogonal dimensions bind to different parameters (e.g. LONGITUD vs ANCHO)."""
    resolver = ParameterBindingResolver()

    # Cota 1: Horizontal en X en vista PLAN
    meas_x = {
        "value": 12.0,
        "raw_text": "12.00",
        "dimension_type": "LINEAR",
        "definition_points": [[0.0, 0.0, 0.0], [12.0, 0.0, 0.0]],
        "view_id": "v_plan",
    }
    # Cota 2: Ortogonal en Y en vista PLAN
    meas_y = {
        "value": 3.5,
        "raw_text": "3.50",
        "dimension_type": "LINEAR",
        "definition_points": [[0.0, 0.0, 0.0], [0.0, 3.5, 0.0]],
        "view_id": "v_plan",
    }

    bind_x = resolver.bind_measurement_to_candidate(meas_x, view_type="PLAN")
    bind_y = resolver.bind_measurement_to_candidate(meas_y, view_type="PLAN")

    assert bind_x.parameter_name == "LONGITUD"
    assert bind_y.parameter_name == "ANCHO"
    assert bind_x.parameter_name != bind_y.parameter_name


def test_same_parameter_with_documented_units_normalizes_without_conflict():
    """2. Same parameter with documented m/mm units normalizes without conflict."""
    unit_res = UnitResolver()
    synthesizer = MultidocumentSynthesizer(unit_resolver=unit_res)

    doc_ev_mm = {"dominant_unit": "mm", "primary_evidence": ["DRAWING_NOTE: DIMENSIONES EN MILIMETROS"]}
    doc_ev_m = {"dominant_unit": "m", "primary_evidence": ["DOCUMENT_METADATA: m"]}

    meas_mm = {
        "value": 4000.0,
        "raw_text": "4000",
        "source": {"source_file": "doc_a.dwg"},
        "view_id": "v1",
    }
    meas_m = {
        "value": 4.0,
        "raw_text": "4.0 m",
        "source": {"source_file": "doc_b.dwg"},
        "view_id": "v2",
    }

    b_mm = ParameterBindingResolver(unit_resolver=unit_res).bind_measurement_to_candidate(
        meas_mm, document_unit_evidence=doc_ev_mm
    )
    b_m = ParameterBindingResolver(unit_resolver=unit_res).bind_measurement_to_candidate(
        meas_m, document_unit_evidence=doc_ev_m
    )

    # Ambos deben estar documentados y normalizados a 4.0 m
    assert b_mm.unit_resolution_status == UnitResolutionStatus.UNIT_DOCUMENTED
    assert b_mm.resolved_value == 4.0
    assert b_m.unit_resolution_status == UnitResolutionStatus.UNIT_DOCUMENTED
    assert b_m.resolved_value == 4.0

    # Sintetizar para el mismo parámetro
    b_mm.parameter_name = "ALTURA"
    b_m.parameter_name = "ALTURA"

    hyp = ObjectHypothesis(hypothesis_id="hyp_01")
    consolidated, conflicts, readiness = synthesizer.synthesize_parameters_for_hypothesis(
        hypothesis=hyp,
        binding_candidates=[b_mm, b_m],
    )

    assert len(conflicts) == 0
    assert "ALTURA" in consolidated
    assert consolidated["ALTURA"].canonical_value == 4.0
    assert consolidated["ALTURA"].status == EvidenceStatus.DOCUMENTED


def test_ratio_1000_without_unit_evidence_remains_unresolved():
    """3. Ratio 1000 without unit evidence remains in UNIT_SCALE_HYPOTHESIS / unresolved."""
    unit_res = UnitResolver()
    rec = unit_res.resolve_measurement_unit(
        raw_value=4000.0,
        comparison_value=4.0,
        # Sin evidencia documental primaria
        doc_evidence={"dominant_unit": None, "primary_evidence": [], "secondary_evidence": ["ESC 1:50"]},
    )

    # Regla: La escala gráfica 1:50 es secundaria; ratio 1000 sin primaria genera escala hipotética
    assert rec.unit_resolution_status == UnitResolutionStatus.UNIT_SCALE_HYPOTHESIS
    assert rec.resolved_value is None


def test_different_physical_parameters_do_not_create_document_conflict():
    """4. Different physical parameters do not create document conflict (e.g. 1.0 vs 10.0)."""
    synthesizer = MultidocumentSynthesizer()
    hyp = ObjectHypothesis(hypothesis_id="hyp_col")

    # 1.0 es DIAMETRO, 10.0 es ALTURA
    b_diam = ParameterBindingCandidate(
        parameter_name="DIAMETRO",
        binding_method="EXPLICIT_TEXT_DIAMETER_SYMBOL",
        raw_value=1.0,
        resolved_value=1.0,
        resolved_unit="m",
        unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED,
    )
    b_alt = ParameterBindingCandidate(
        parameter_name="ALTURA",
        binding_method="EXPLICIT_TEXT_HEIGHT_KEYWORD",
        raw_value=10.0,
        resolved_value=10.0,
        resolved_unit="m",
        unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED,
    )

    consolidated, conflicts, readiness = synthesizer.synthesize_parameters_for_hypothesis(
        hypothesis=hyp,
        binding_candidates=[b_diam, b_alt],
    )

    assert len(conflicts) == 0
    assert "DIAMETRO" in consolidated
    assert "ALTURA" in consolidated
    assert consolidated["DIAMETRO"].canonical_value == 1.0
    assert consolidated["ALTURA"].canonical_value == 10.0


def test_same_physical_parameter_with_incompatible_documented_values_creates_conflict():
    """5. Same physical parameter with incompatible documented values creates conflict."""
    synthesizer = MultidocumentSynthesizer()
    hyp = ObjectHypothesis(hypothesis_id="hyp_conflict")

    # Dos fuentes documentan DIAMETRO con valores incompatibles (1.0 vs 2.0)
    b1 = ParameterBindingCandidate(
        parameter_name="DIAMETRO",
        binding_method="EXPLICIT_TEXT_DIAMETER_SYMBOL",
        source_id="doc_a.dwg",
        raw_value=1.0,
        resolved_value=1.0,
        unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED,
    )
    b2 = ParameterBindingCandidate(
        parameter_name="DIAMETRO",
        binding_method="EXPLICIT_TEXT_DIAMETER_SYMBOL",
        source_id="doc_b.dwg",
        raw_value=2.0,
        resolved_value=2.0,
        unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED,
    )

    consolidated, conflicts, readiness = synthesizer.synthesize_parameters_for_hypothesis(
        hypothesis=hyp,
        binding_candidates=[b1, b2],
    )

    assert len(conflicts) == 1
    assert conflicts[0].parameter == "DIAMETRO"
    assert conflicts[0].value_a == 1.0
    assert conflicts[0].value_b == 2.0


def test_regional_text_does_not_control_binding():
    """6. Regional text far away does not control binding."""
    resolver = ParameterBindingResolver()

    # Cota geométrica local con bbox en (10, 10) a (12, 12)
    bbox = {"minx": 10.0, "miny": 10.0, "maxx": 12.0, "maxy": 12.0}
    meas = {
        "value": 2.0,
        "raw_text": "",
        "dimension_type": "LINEAR",
        "definition_points": [[10.0, 10.0, 0.0], [12.0, 10.0, 0.0]],
        "view_id": "v_plan",
    }
    # Texto regional a 500 metros de distancia
    far_texts = [
        {"text": "ESPESOR DE LOSA = 0.22", "insert_point": [500.0, 500.0]}
    ]

    binding = resolver.bind_measurement_to_candidate(
        measurement=meas,
        candidate_bbox=bbox,
        view_type="PLAN",
        nearby_texts=far_texts,
    )

    # No debe tomar ESPESOR del texto regional lejano; debe vincular por geometría local horizontal en planta (LONGITUD)
    assert binding.parameter_name == "LONGITUD"
    assert "NEARBY_TEXT" not in str(binding.evidence_groups)


def test_local_explicit_diameter_text_binds_diameter():
    """7. Local explicit diameter text binds diameter."""
    resolver = ParameterBindingResolver()

    meas_symbol = {
        "value": 140.0,
        "raw_text": "%%C140",
        "dimension_type": "LINEAR",
        "definition_points": [[0.0, 0.0, 0.0], [0.14, 0.0, 0.0]],
    }
    meas_unicode = {
        "value": 10.0,
        "raw_text": "4 Ø 10",
        "dimension_type": "LINEAR",
        "definition_points": [[0.0, 0.0, 0.0], [0.01, 0.0, 0.0]],
    }

    b1 = resolver.bind_measurement_to_candidate(meas_symbol)
    b2 = resolver.bind_measurement_to_candidate(meas_unicode)

    assert b1.parameter_name == "DIAMETRO"
    assert b2.parameter_name == "DIAMETRO"
    assert b1.binding_method == "EXPLICIT_TEXT_DIAMETER_SYMBOL"


def test_section_and_plan_can_complete_same_object_parameters():
    """8. Section and plan can complete same object parameters under matching identity."""
    synthesizer = MultidocumentSynthesizer()

    # Candidato A (Planta) -> ANCHO y LONGITUD
    cand_a = ObjectCandidate(
        candidate_id="c_plan",
        source_ids=["planta.dwg"],
        probable_family=SemanticFamily.PAVEMENT,
        probable_type="SLAB",
        labels=["LOSA_01"],
        view_ids=["v_plan"],
    )
    # Candidato B (Corte) -> ESPESOR
    cand_b = ObjectCandidate(
        candidate_id="c_sec",
        source_ids=["corte.dwg"],
        probable_family=SemanticFamily.PAVEMENT,
        probable_type="SLAB",
        labels=["LOSA_01"],
        view_ids=["v_sec"],
    )

    ok, dec, conf, ev = synthesizer.evaluate_multidocument_identity_gate(cand_a, cand_b)
    assert ok is True
    assert dec == "SAME_OBJECT"

    hyp = ObjectHypothesis(
        hypothesis_id="hyp_slab",
        probable_family=SemanticFamily.PAVEMENT,
        probable_type="SLAB",
    )
    bindings = [
        ParameterBindingCandidate(parameter_name="ANCHO", raw_value=3.5, resolved_value=3.5, unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED),
        ParameterBindingCandidate(parameter_name="LONGITUD", raw_value=5.0, resolved_value=5.0, unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED),
        ParameterBindingCandidate(parameter_name="ESPESOR", raw_value=0.22, resolved_value=0.22, unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED),
    ]

    consolidated, conflicts, readiness = synthesizer.synthesize_parameters_for_hypothesis(hyp, bindings)

    assert readiness.is_ready_for_built is True
    assert readiness.parameter_readiness == 1.0
    assert len(readiness.unresolved_required_parameters) == 0


def test_duplicate_dwg_pdf_evidence_is_not_double_counted():
    """9. Duplicate DWG/PDF evidence is not double-counted."""
    synthesizer = MultidocumentSynthesizer()
    hyp = ObjectHypothesis(hypothesis_id="hyp_dup")

    # Mismo plano exportado en DWG y PDF
    b_dwg = ParameterBindingCandidate(
        parameter_name="ANCHO",
        source_id="PLANO_01.dwg#ENT1",
        raw_value=4.0,
        resolved_value=4.0,
        unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED,
    )
    b_pdf = ParameterBindingCandidate(
        parameter_name="ANCHO",
        source_id="PLANO_01.pdf#TXT1",
        raw_value=4.0,
        resolved_value=4.0,
        unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED,
    )

    consolidated, conflicts, readiness = synthesizer.synthesize_parameters_for_hypothesis(hyp, [b_dwg, b_pdf])

    param = consolidated["ANCHO"]
    # Los dos archivos pertenecen al mismo EvidenceOriginGroup "PLANO_01"
    assert len(param.evidence_origin_groups) == 1
    assert param.evidence_origin_groups[0] == "PLANO_01"


def test_typical_value_without_governed_link_cannot_complete_critical_parameter():
    """10. Typical value without governed link cannot complete critical parameter."""
    hyp = ObjectHypothesis(
        hypothesis_id="hyp_slab",
        probable_family=SemanticFamily.PAVEMENT,
        probable_type="SLAB",
    )
    # Losa con ancho y longitud, pero sin espesor documentado
    bindings = [
        ParameterBindingCandidate(parameter_name="ANCHO", raw_value=3.5, resolved_value=3.5, unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED),
        ParameterBindingCandidate(parameter_name="LONGITUD", raw_value=5.0, resolved_value=5.0, unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED),
    ]

    synthesizer = MultidocumentSynthesizer()
    consolidated, conflicts, readiness = synthesizer.synthesize_parameters_for_hypothesis(hyp, bindings)

    # No se debe inventar un espesor típico
    assert "ESPESOR" not in consolidated
    assert "ESPESOR" in readiness.unresolved_required_parameters
    assert readiness.is_ready_for_built is False


def test_multidocument_synthesis_preserves_source_traceability():
    """11. Multidocument synthesis preserves source traceability."""
    synthesizer = MultidocumentSynthesizer()
    hyp = ObjectHypothesis(hypothesis_id="hyp_trace")

    b_a = ParameterBindingCandidate(
        parameter_name="ALTURA",
        source_id="source_a.dwg",
        dimension_handle="HDL_A",
        raw_value=12.0,
        resolved_value=12.0,
        unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED,
    )
    b_b = ParameterBindingCandidate(
        parameter_name="ALTURA",
        source_id="source_b.dwg",
        dimension_handle="HDL_B",
        raw_value=12.0,
        resolved_value=12.0,
        unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED,
    )

    consolidated, conflicts, readiness = synthesizer.synthesize_parameters_for_hypothesis(hyp, [b_a, b_b])

    param = consolidated["ALTURA"]
    src_files = [s.source_file for s in param.sources]
    assert "source_a.dwg" in src_files
    assert "source_b.dwg" in src_files
    assert len(param.evidence_origin_groups) == 2


def test_unresolved_unit_blocks_built_for_critical_parameter():
    """12. Unresolved unit blocks BUILT for critical parameter."""
    builder = ParametricGeometryBuilder()

    obj = ReconstructedObject(
        object_id="obj_col",
        parameters={
            "DIAMETRO": ParameterValue(
                name="DIAMETRO",
                value=1.0,
                unit=None,  # Unidad no resuelta
                status=EvidenceStatus.UNKNOWN,
            ),
            "ALTURA": ParameterValue(
                name="ALTURA",
                value=10.0,
                unit="m",
                status=EvidenceStatus.DOCUMENTED,
            ),
        }
    )

    recipe = GeometryRecipe(
        recipe_id="rec_01",
        object_id="obj_col",
        recipe_type=RecipeType.CIRCULAR_EXTRUSION,
        required_parameters=["RADIO", "ALTURA"],
        source_parameters={"ALTURA": 10.0},
        unresolved_parameters=["RADIO"],  # Falta radio resuelto
    )

    geom = builder.build_geometry(obj=obj, recipe=recipe)

    assert geom.is_built is False
    assert "MISSING_REQUIRED_PARAMETERS" in (geom.build_failure_reason or "")
