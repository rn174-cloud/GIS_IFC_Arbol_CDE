from __future__ import annotations

from collections import defaultdict
from typing import Iterable

from core.models import (
    SourceReference,
    ViewEvidence,
)


class MultiViewSolver:
    """
    Agrupa evidencias de distintas vistas que podrían
    corresponder al mismo objeto o conjunto de objetos.

    Este solver NO fuerza correspondencias.

    Su responsabilidad es producir grupos candidatos
    de evidencia multivista para análisis posterior.

    Ejemplos de relaciones esperables:

    PLANTA
    + PERFIL
    + SECCION
    + DETALLE

    o

    GIS
    + INVENTARIO
    + PLANO
    + FOTOGRAFIA
    """

    def group_by_candidate_object(
        self,
        views: Iterable[ViewEvidence],
    ) -> dict[str, list[ViewEvidence]]:
        """
        Agrupa vistas por candidate_object_ids explícitos.

        Una vista puede pertenecer a más de un candidato.
        """

        groups: dict[
            str,
            list[ViewEvidence]
        ] = defaultdict(list)

        for view in views:

            for object_id in (
                view.candidate_object_ids
            ):
                groups[
                    object_id
                ].append(
                    view
                )

        return dict(
            groups
        )

    def group_by_source(
        self,
        views: Iterable[ViewEvidence],
    ) -> dict[str, list[ViewEvidence]]:
        """
        Agrupa vistas por archivo fuente.
        """

        groups: dict[
            str,
            list[ViewEvidence]
        ] = defaultdict(list)

        for view in views:

            source_file = (
                view.source.source_file
                or "UNKNOWN_SOURCE"
            )

            groups[
                source_file
            ].append(
                view
            )

        return dict(
            groups
        )

    def find_complementary_views(
        self,
        views: Iterable[ViewEvidence],
    ) -> list[
        tuple[
            ViewEvidence,
            ViewEvidence,
        ]
    ]:
        """
        Busca pares de vistas potencialmente complementarias.

        Este método usa únicamente señales básicas.
        No declara que dos vistas correspondan al mismo objeto.

        Las relaciones propuestas deben considerarse
        candidatos para una etapa semántica superior.
        """

        views_list = list(
            views
        )

        complementary_pairs = {
            ("PLAN", "PROFILE"),
            ("PLAN", "SECTION"),
            ("PLAN", "ELEVATION"),
            ("PROFILE", "SECTION"),
            ("ELEVATION", "SECTION"),
            ("DETAIL", "PLAN"),
            ("DETAIL", "PROFILE"),
            ("DETAIL", "SECTION"),
            ("DETAIL", "ELEVATION"),
        }

        result: list[
            tuple[
                ViewEvidence,
                ViewEvidence,
            ]
        ] = []

        for index, view_a in enumerate(
            views_list
        ):

            for view_b in (
                views_list[
                    index + 1:
                ]
            ):

                pair = (
                    view_a.view_type,
                    view_b.view_type,
                )

                reverse_pair = (
                    view_b.view_type,
                    view_a.view_type,
                )

                if (
                    pair
                    in complementary_pairs
                    or reverse_pair
                    in complementary_pairs
                ):
                    result.append(
                        (
                            view_a,
                            view_b,
                        )
                    )

        return result

    def source_similarity(
        self,
        source_a: SourceReference,
        source_b: SourceReference,
    ) -> float:
        """
        Calcula una similitud documental básica.

        NO representa certeza geométrica.

        Señales:
        - mismo archivo;
        - mismo plano;
        - misma hoja;
        - misma revisión.
        """

        score = 0.0
        weight = 0.0

        def compare(
            value_a: str | None,
            value_b: str | None,
            local_weight: float,
        ) -> None:
            nonlocal score, weight

            if (
                value_a is None
                or value_b is None
            ):
                return

            weight += (
                local_weight
            )

            if (
                str(value_a).strip().lower()
                ==
                str(value_b).strip().lower()
            ):
                score += (
                    local_weight
                )

        compare(
            source_a.source_file,
            source_b.source_file,
            0.35,
        )

        compare(
            source_a.drawing_number,
            source_b.drawing_number,
            0.30,
        )

        compare(
            source_a.sheet,
            source_b.sheet,
            0.20,
        )

        compare(
            source_a.revision,
            source_b.revision,
            0.15,
        )

        if weight == 0.0:
            return 0.0

        return (
            score / weight
        )
