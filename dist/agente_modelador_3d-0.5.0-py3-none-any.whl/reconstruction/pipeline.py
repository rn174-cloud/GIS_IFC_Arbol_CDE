from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Iterable

from core.config import AgentConfig
from core.models import (
    SourceDocument,
    ViewEvidence,
)
from core.traceability import BuildLog
from readers.registry import (
    ReaderRegistry,
    build_default_registry,
)
from reconstruction.geometric_recipe_resolver import (
    GeometricRecipeResolver,
)
from reconstruction.geometry_parameter_resolver import (
    GeometryParameterResolver,
)
from reconstruction.geometry_validator import (
    GeometryValidator,
)
from reconstruction.local_frame_resolver import (
    LocalFrameResolver,
)
from reconstruction.multiview_matcher import (
    MultiViewMatcher,
)
from reconstruction.object_candidate_detector import (
    ObjectCandidateDetector,
)
from reconstruction.object_hypothesis_resolver import (
    ObjectHypothesisResolver,
)
from reconstruction.parameter_extractor import (
    ParameterExtractor,
)
from reconstruction.parametric_geometry_builder import (
    ParametricGeometryBuilder,
)
from reconstruction.reference_resolver import (
    ReferenceResolver,
)
from reconstruction.semantic_signal_extractor import (
    SemanticSignalExtractor,
)
from reconstruction.view_classifier import (
    ViewClassifier,
)
from reconstruction.view_segmenter import (
    ViewSegmenter,
)


LOGGER = logging.getLogger(
    "agente_modelador_3d.pipeline"
)


class ReconstructionPipeline:
    """
    Pipeline principal del Agente Modelador 3D.

    En esta versión v0.2B el pipeline realiza:

    1. inventario;
    2. selección de reader;
    3. extracción documental;
    4. clasificación inicial de vistas;
    5. segmentación espacial de regiones;
    6. extracción de candidatos de medición;
    7. extracción de señales semánticas (SemanticSignal);
    8. descubrimiento de candidatos a objeto (ObjectCandidate);
    9. correspondencia multivista (EvidenceMatch);
    10. consolidación de hipótesis de objeto (ObjectHypothesis);
    11. generación de borradores de objeto (ReconstructedObject) con geometry_definition VACÍA;
    12. emisión de salidas en output/semantic/.

    NO crea objetos físicos IFC automáticamente
    a partir de líneas, puntos o mediciones aisladas.
    """

    VALID_MODES = {
        "AUDIT",
        "EXTRACT",
        "MODEL",
        "VALIDATE",
        "UPDATE",
        "REBUILD",
    }

    def __init__(
        self,
        config: AgentConfig,
        project_name: str,
        mode: str = "AUDIT",
        crs: str | None = None,
        registry: ReaderRegistry | None = None,
    ) -> None:

        normalized_mode = (
            mode.upper()
        )

        if (
            normalized_mode
            not in self.VALID_MODES
        ):
            raise ValueError(
                f"Modo no soportado: {mode!r}"
            )

        self.config = config
        self.project_name = (
            project_name
        )
        self.mode = (
            normalized_mode
        )
        self.crs = (
            crs
        )

        self.registry = (
            registry
            or build_default_registry()
        )

        self.view_classifier = (
            ViewClassifier()
        )

        self.view_segmenter = (
            ViewSegmenter()
        )

        self.parameter_extractor = (
            ParameterExtractor()
        )

        self.signal_extractor = (
            SemanticSignalExtractor()
        )

        self.candidate_detector = (
            ObjectCandidateDetector()
        )

        self.reference_resolver = (
            ReferenceResolver()
        )

        self.multiview_matcher = (
            MultiViewMatcher()
        )

        self.hypothesis_resolver = (
            ObjectHypothesisResolver()
        )

        self.param_eligibility_resolver = (
            GeometryParameterResolver(mode="STRICT")
        )

        self.recipe_resolver = (
            GeometricRecipeResolver(param_resolver=self.param_eligibility_resolver)
        )

        self.geometry_builder = (
            ParametricGeometryBuilder()
        )

        self.geometry_validator = (
            GeometryValidator()
        )

        self.build_log = BuildLog(
            project_name=project_name,
            mode=self.mode,
        )

    def run(
        self,
        source_paths: Iterable[
            str | Path
        ],
    ) -> dict[str, Any]:
        """
        Ejecuta la ingesta documental y la reconstrucción semántica inicial.

        En MODEL/UPDATE/REBUILD esta versión aún NO
        genera IFC de forma autónoma.

        Esa decisión se mantiene explícita:
        primero debe existir reconstrucción semántica
        suficiente.
        """

        documents: list[
            SourceDocument
        ] = []

        views: list[
            ViewEvidence
        ] = []

        measurement_candidates: list[
            dict[str, Any]
        ] = []

        unsupported_sources: list[
            dict[str, str]
        ] = []

        for raw_path in source_paths:

            source_path = Path(
                raw_path
            ).expanduser().resolve()

            LOGGER.info(
                "Procesando fuente: %s",
                source_path,
            )

            if not self.registry.supports(
                source_path
            ):
                message = (
                    "No existe reader para "
                    f"{source_path.suffix!r}"
                )

                LOGGER.warning(
                    "%s: %s",
                    message,
                    source_path,
                )

                unsupported_sources.append(
                    {
                        "path": str(
                            source_path
                        ),
                        "reason": message,
                    }
                )

                self.build_log.add_warning(
                    f"{source_path}: {message}"
                )

                continue

            try:
                reader = (
                    self.registry
                    .create_reader_for(
                        source_path
                    )
                )

                document = reader.read(
                    source_path
                )

            except Exception as exc:

                message = (
                    f"Falló la lectura de "
                    f"{source_path}: {exc}"
                )

                LOGGER.exception(
                    "%s",
                    message,
                )

                self.build_log.add_error(
                    message
                )

                continue

            if (
                self.crs
                and not document.crs
            ):
                document.warnings.append(
                    "Se recibió un CRS por configuración "
                    "del pipeline, pero la fuente no lo "
                    "declara internamente. Debe verificarse "
                    "antes de considerarlo documentado."
                )

            documents.append(
                document
            )

            self.build_log.add_source(
                {
                    "path": str(
                        document.path
                    ),
                    "file_type": (
                        document.file_type
                    ),
                    "units": (
                        document.units
                    ),
                    "crs": (
                        document.crs
                    ),
                    "warnings": list(
                        document.warnings
                    ),
                }
            )

            for warning in (
                document.warnings
            ):
                self.build_log.add_warning(
                    f"{document.path.name}: "
                    f"{warning}"
                )

            # 1. Clasificación léxica preliminar
            document_views = (
                self.view_classifier
                .classify_document(
                    document
                )
            )

            # 2. Segmentación espacial de vistas
            segmented_views = (
                self.view_segmenter
                .segment_document(
                    document=document,
                    lexical_views=document_views,
                )
            )

            views.extend(
                segmented_views
            )

            for view in (
                segmented_views
            ):

                measurements = (
                    self.parameter_extractor
                    .extract_measurements(
                        view
                    )
                )

                for measurement in measurements:

                    measurement_candidates.append(
                        {
                            "candidate_type": (
                                measurement.candidate_type.value
                            ),
                            "raw_text": (
                                measurement.raw_text
                            ),
                            "value": (
                                measurement.value
                            ),
                            "unit": (
                                measurement.unit
                            ),
                            "view_id": (
                                view.view_id
                            ),
                            "view_type": (
                                view.view_type
                            ),
                            "source": (
                                measurement
                                .source
                                .to_dict()
                            ),
                            "semantic_binding": (
                                "UNRESOLVED"
                            ),
                        }
                    )

        # 3. Descubrimiento de candidatos a objeto y señales semánticas
        object_candidates, semantic_signals, candidate_relations = (
            self.candidate_detector.detect_candidates(
                documents=documents,
                views=views,
                classified_measurements=measurement_candidates,
            )
        )

        # 4. Detección de llamadas cruzadas (callouts) entre vistas
        view_callouts = self.reference_resolver.find_view_callout_matches(views)

        # 5. Comparación y resolución multivista (EvidenceMatch)
        views_dict = {v.view_id: v for v in views}
        evidence_matches = []
        for i in range(len(object_candidates)):
            cand_i = object_candidates[i]
            for j in range(i + 1, len(object_candidates)):
                cand_j = object_candidates[j]
                # Comparar pares
                match_res = self.multiview_matcher.compare_candidates(
                    cand_a=cand_i,
                    cand_b=cand_j,
                    views_dict=views_dict,
                    view_callouts=view_callouts,
                )
                evidence_matches.append(match_res)

        # 6. Consolidación de hipótesis de objeto y generación de borradores ReconstructedObject
        object_hypotheses, reconstructed_objects = (
            self.hypothesis_resolver.resolve_hypotheses_and_drafts(
                candidates=object_candidates,
                matches=evidence_matches,
                views_dict=views_dict,
            )
        )

        # 7. RECONSTRUCCIÓN PARAMÉTRICA 3D (v0.3)
        # Transformar ReconstructedObjects en geometría 3D trazable con recetas y validaciones
        geometric_recipes = []
        parametric_geometries = []
        geometry_validations = []
        all_geometry_data_gaps = []

        for obj in reconstructed_objects:
            recipe, r_gaps = self.recipe_resolver.resolve_recipe(obj)
            geometric_recipes.append(recipe)
            all_geometry_data_gaps.extend(r_gaps)

            # Construir sólido paramétrico
            geom = self.geometry_builder.build_geometry(obj=obj, recipe=recipe, gaps=r_gaps)

            # Validar contra documentación fuente
            val_results, final_conf = self.geometry_validator.validate_geometry(obj=obj, geom=geom)
            geom.validation_results = val_results
            geom.geometry_confidence = final_conf
            parametric_geometries.append(geom)
            geometry_validations.extend(val_results)

            # Actualizar desglose en el objeto reconstruido
            obj.confidence_breakdown.geometry_confidence = final_conf
            if geom.is_built:
                obj.geometry_definition = geom.to_dict()

        if (
            self.mode
            in {
                "MODEL",
                "UPDATE",
                "REBUILD",
            }
        ):
            self.build_log.add_warning(
                "El modo solicitado requiere modelado: se generaron sólidos paramétricos trazables v0.3, "
                "pero este kernel no crea entidades IFC automáticamente hasta que la geometría supere sus validaciones."
            )

        self.build_log.finish()

        # Separar evidencia pesada en output_dir/evidence/<source_id>.json
        evidence_dir = self.config.output_dir / "evidence"
        evidence_dir.mkdir(parents=True, exist_ok=True)

        import json
        from cli import serialize_result

        lightweight_docs: list[dict[str, Any]] = []
        for document in documents:
            source_id = document.source_id or "src_unknown"
            evidence_path = evidence_dir / f"{source_id}.json"

            # Guardar datos pesados en archivo de evidencia individual
            with evidence_path.open("w", encoding="utf-8") as ef:
                json.dump(
                    serialize_result({
                        "source_id": source_id,
                        "sha256": document.sha256,
                        "path": str(document.path),
                        "file_type": document.file_type,
                        "extracted_data": document.extracted_data,
                    }),
                    ef,
                    ensure_ascii=False,
                    indent=2,
                )

            # Documento liviano para source_inventory.json
            lightweight_docs.append({
                "source_id": document.source_id,
                "sha256": document.sha256,
                "file_size": document.file_size,
                "path": str(document.path),
                "file_type": document.file_type,
                "drawing_number": document.drawing_number,
                "drawing_title": document.drawing_title,
                "discipline": document.discipline,
                "revision": document.revision,
                "date": document.date,
                "scale": document.scale,
                "units": document.units,
                "crs": document.crs,
                "document_role": document.document_role,
                "metadata": document.metadata,
                "warnings": document.warnings,
                "evidence_file": str(evidence_path.relative_to(self.config.output_dir)),
            })

        # Generar archivos en output/semantic/
        semantic_dir = self.config.output_dir / "semantic"
        semantic_dir.mkdir(parents=True, exist_ok=True)

        with (semantic_dir / "object_candidates.json").open("w", encoding="utf-8") as f:
            json.dump(
                serialize_result([c.to_dict() for c in object_candidates]),
                f,
                ensure_ascii=False,
                indent=2,
            )

        with (semantic_dir / "semantic_signals.json").open("w", encoding="utf-8") as f:
            json.dump(
                serialize_result([s.to_dict() for s in semantic_signals]),
                f,
                ensure_ascii=False,
                indent=2,
            )

        with (semantic_dir / "candidate_relations.json").open("w", encoding="utf-8") as f:
            json.dump(
                serialize_result([r.to_dict() for r in candidate_relations]),
                f,
                ensure_ascii=False,
                indent=2,
            )

        with (semantic_dir / "evidence_matches.json").open("w", encoding="utf-8") as f:
            json.dump(
                serialize_result([m.to_dict() for m in evidence_matches]),
                f,
                ensure_ascii=False,
                indent=2,
            )

        with (semantic_dir / "object_hypotheses.json").open("w", encoding="utf-8") as f:
            json.dump(
                serialize_result([h.to_dict() for h in object_hypotheses]),
                f,
                ensure_ascii=False,
                indent=2,
            )

        with (semantic_dir / "reconstructed_objects.json").open("w", encoding="utf-8") as f:
            json.dump(
                serialize_result([obj.to_dict() for obj in reconstructed_objects]),
                f,
                ensure_ascii=False,
                indent=2,
            )

        # Generar archivos en output/geometry/ (v0.3)
        geom_dir = self.config.output_dir / "geometry"
        geom_dir.mkdir(parents=True, exist_ok=True)

        with (geom_dir / "geometric_recipes.json").open("w", encoding="utf-8") as f:
            json.dump(
                serialize_result([r.to_dict() for r in geometric_recipes]),
                f,
                ensure_ascii=False,
                indent=2,
            )

        with (geom_dir / "parametric_geometry.json").open("w", encoding="utf-8") as f:
            json.dump(
                serialize_result([g.to_dict() for g in parametric_geometries]),
                f,
                ensure_ascii=False,
                indent=2,
            )

        with (geom_dir / "geometry_validation.json").open("w", encoding="utf-8") as f:
            json.dump(
                serialize_result(geometry_validations),
                f,
                ensure_ascii=False,
                indent=2,
            )

        with (geom_dir / "data_gaps.json").open("w", encoding="utf-8") as f:
            json.dump(
                serialize_result([g.to_dict() for g in all_geometry_data_gaps]),
                f,
                ensure_ascii=False,
                indent=2,
            )

        # Generar previsualización inspeccionable 3D (OBJ) en output/geometry_preview/
        preview_dir = self.config.output_dir / "geometry_preview"
        preview_dir.mkdir(parents=True, exist_ok=True)

        built_geoms = [g for g in parametric_geometries if g.is_built]
        for g in built_geoms:
            obj_preview_file = preview_dir / f"{g.object_id}.obj"
            with obj_preview_file.open("w", encoding="utf-8") as f:
                f.write(f"# Parametric Preview for {g.object_id}\n")
                f.write(f"# Recipe: {g.recipe_id} ({g.geometry_type.value})\n")
                for v in g.vertices:
                    f.write(f"v {v[0]:.4f} {v[1]:.4f} {v[2]:.4f}\n")
                for face in g.faces:
                    # OBJ es 1-indexed
                    f.write("f " + " ".join(str(idx + 1) for idx in face) + "\n")

        built_count = len(built_geoms)
        not_built_count = len([g for g in parametric_geometries if not g.is_built])

        return {
            "project_name": (
                self.project_name
            ),
            "mode": self.mode,
            "requested_crs": (
                self.crs
            ),
            "documents": lightweight_docs,
            "views": [
                view.to_dict()
                for view
                in views
            ],
            "measurement_candidates": (
                measurement_candidates
            ),
            "object_candidates_summary": {
                "total_candidates": len(object_candidates),
                "families": {
                    fam.value: len([c for c in object_candidates if c.probable_family == fam])
                    for fam in set(c.probable_family for c in object_candidates)
                },
                "unresolved_count": len([c for c in object_candidates if c.status.value == "UNRESOLVED"]),
                "partially_resolved_count": len([c for c in object_candidates if c.status.value == "PARTIALLY_RESOLVED"]),
                "resolved_count": len([c for c in object_candidates if c.status.value == "RESOLVED"]),
            },
            "multiview_resolution_summary": {
                "total_matches": len(evidence_matches),
                "decisions": {
                    dec.value: len([m for m in evidence_matches if m.decision == dec])
                    for dec in set(m.decision for m in evidence_matches)
                },
                "total_hypotheses": len(object_hypotheses),
                "reconstructed_drafts": len(reconstructed_objects),
            },
            "geometry_summary": {
                "built_count": built_count,
                "not_built_count": not_built_count,
                "total_recipes": len(geometric_recipes),
                "verified_geometries": len([g for g in parametric_geometries if g.geometry_confidence.value == "VERIFIED"]),
            },
            "semantic_files": {
                "object_candidates": str((semantic_dir / "object_candidates.json").relative_to(self.config.output_dir)),
                "semantic_signals": str((semantic_dir / "semantic_signals.json").relative_to(self.config.output_dir)),
                "candidate_relations": str((semantic_dir / "candidate_relations.json").relative_to(self.config.output_dir)),
                "evidence_matches": str((semantic_dir / "evidence_matches.json").relative_to(self.config.output_dir)),
                "object_hypotheses": str((semantic_dir / "object_hypotheses.json").relative_to(self.config.output_dir)),
                "reconstructed_objects": str((semantic_dir / "reconstructed_objects.json").relative_to(self.config.output_dir)),
            },
            "geometry_files": {
                "geometric_recipes": str((geom_dir / "geometric_recipes.json").relative_to(self.config.output_dir)),
                "parametric_geometry": str((geom_dir / "parametric_geometry.json").relative_to(self.config.output_dir)),
                "geometry_validation": str((geom_dir / "geometry_validation.json").relative_to(self.config.output_dir)),
                "data_gaps": str((geom_dir / "data_gaps.json").relative_to(self.config.output_dir)),
            },
            "unsupported_sources": (
                unsupported_sources
            ),
            "reader_registry": {
                "readers": (
                    self.registry
                    .registered_readers()
                ),
                "extensions": (
                    self.registry
                    .supported_extensions()
                ),
            },
            "model_generation": {
                "performed": False,
                "reason": (
                    "El kernel v0.3 genera sólidos paramétricos trazables validados (OBJ/JSON). "
                    "No genera entidades IFC 4.3 hasta la fase siguiente de IFC Authoring."
                ),
            },
            "build_log": (
                self.build_log.to_dict()
            ),
        }

