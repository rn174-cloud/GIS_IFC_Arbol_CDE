from __future__ import annotations

from typing import Any, Optional
import ifcopenshell


class IFCGeoreferencingBuilder:
    """
    Construye entidades de georreferenciación en IFC 4.3 (IfcProjectedCRS, IfcMapConversion).
    
    REGLA:
    Si el CRS no está documentado, NO inventar EPSG ni coordenadas proyectadas.
    El modelo permanece limpiamente en coordenadas de proyecto local.
    """

    @staticmethod
    def apply_georeferencing(
        model: ifcopenshell.file,
        context_model: Any,
        crs_info: Optional[dict[str, Any]],
    ) -> Optional[Any]:
        """
        Aplica IfcMapConversion e IfcProjectedCRS si existe CRS documentado.
        """
        if not crs_info or not crs_info.get("crs_name"):
            return None

        crs_name = str(crs_info.get("crs_name"))
        epsg = crs_info.get("epsg")
        eastings = float(crs_info.get("eastings", 0.0))
        northings = float(crs_info.get("northings", 0.0))
        height = float(crs_info.get("orthogonal_height", 0.0))
        scale = float(crs_info.get("scale", 1.0))

        # Crear IfcProjectedCRS
        projected_crs = model.create_entity(
            "IfcProjectedCRS",
            Name=crs_name,
            Description=f"Projected CRS EPSG:{epsg}" if epsg else "Projected CRS",
            GeodeticDatum="WGS84" if "WGS" in crs_name.upper() else "POSGAR07",
            VerticalDatum="EGM96" if height != 0.0 else None,
            MapProjection="TRANSVERSE_MERCATOR",
            MapZone=str(crs_info.get("zone", "")),
        )

        # Crear IfcMapConversion vinculando context_model con projected_crs
        map_conversion = model.create_entity(
            "IfcMapConversion",
            SourceCRS=context_model,
            TargetCRS=projected_crs,
            Eastings=eastings,
            Northings=northings,
            OrthogonalHeight=height,
            Scale=scale,
        )

        return map_conversion
