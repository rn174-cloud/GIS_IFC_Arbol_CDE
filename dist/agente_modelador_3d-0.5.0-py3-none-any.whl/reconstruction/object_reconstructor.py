from __future__ import annotations

from typing import Iterable

from core.models import (
    DataGap,
    EvidenceStatus,
    ParameterValue,
    ReconstructedObject,
)
from core.validators import (
    ValidationReport,
    validate_before_verified_modeling,
)


class ObjectReconstructor:
    """
    Motor conservador de reconstrucción de objetos.

    Este módulo NO debe inventar dimensiones.

    Su función es decidir si existe evidencia suficiente
    para generar una definición geométrica paramétrica.

    La creación física IFC ocurre después.
    """

    VERIFIED_STATUSES = {
        EvidenceStatus.DOCUMENTED,
        EvidenceStatus.DERIVED,
        EvidenceStatus.INTERPOLATED,
    }

    def can_build_verified_geometry(
        self,
        obj: ReconstructedObject,
        required_parameters: Iterable[str],
    ) -> ValidationReport:
        """
        Verifica si puede construirse geometría
        considerada documentalmente verificable.
        """

        return validate_before_verified_modeling(
            obj,
            required_parameters,
        )

    def require_parameters(
        self,
        obj: ReconstructedObject,
        required_parameters: Iterable[str],
        expected_source: str | None = None,
    ) -> bool:
        """
        Registra DATA_GAP por cada parámetro faltante.

        Retorna True solamente si todos existen.
        """

        all_present = True

        existing_gap_keys = {
            (
                gap.parameter,
                gap.description,
            )
            for gap in obj.data_gaps
        }

        for name in required_parameters:

            parameter = (
                obj.get_parameter(
                    name
                )
            )

            if (
                parameter is None
                or parameter.value is None
            ):
                all_present = False

                description = (
                    f"Falta el parámetro crítico "
                    f"{name!r} para reconstruir "
                    "la geometría."
                )

                gap_key = (
                    name,
                    description,
                )

                if (
                    gap_key
                    not in existing_gap_keys
                ):
                    obj.data_gaps.append(
                        DataGap(
                            object_id=(
                                obj.object_id
                            ),
                            parameter=name,
                            description=(
                                description
                            ),
                            criticality="HIGH",
                            expected_source=(
                                expected_source
                            ),
                            impact=(
                                "Impide construir "
                                "geometría verificada."
                            ),
                        )
                    )

                    existing_gap_keys.add(
                        gap_key
                    )

        obj.update_confidence_level()

        return all_present

    def build_rectangular_extrusion_definition(
        self,
        obj: ReconstructedObject,
        width_parameter: str,
        height_parameter: str,
        depth_parameter: str,
    ) -> dict[str, object] | None:
        """
        Genera una definición paramétrica abstracta
        de extrusión rectangular.

        NO genera IFC todavía.

        Todos los parámetros deben poseer evidencia
        suficiente para geometría verificada.
        """

        required = [
            width_parameter,
            height_parameter,
            depth_parameter,
        ]

        report = (
            self.can_build_verified_geometry(
                obj,
                required,
            )
        )

        if report.has_errors:
            return None

        width = obj.require_parameter(
            width_parameter
        )

        height = obj.require_parameter(
            height_parameter
        )

        depth = obj.require_parameter(
            depth_parameter
        )

        geometry = {
            "type": (
                "RECTANGULAR_EXTRUSION"
            ),
            "parameters": {
                "width": (
                    self._parameter_payload(
                        width
                    )
                ),
                "height": (
                    self._parameter_payload(
                        height
                    )
                ),
                "depth": (
                    self._parameter_payload(
                        depth
                    )
                ),
            },
        }

        obj.geometry_definition = (
            geometry
        )

        obj.update_confidence_level()

        return geometry

    def build_circular_extrusion_definition(
        self,
        obj: ReconstructedObject,
        diameter_parameter: str,
        depth_parameter: str,
    ) -> dict[str, object] | None:
        """
        Genera una definición abstracta de
        extrusión circular.
        """

        required = [
            diameter_parameter,
            depth_parameter,
        ]

        report = (
            self.can_build_verified_geometry(
                obj,
                required,
            )
        )

        if report.has_errors:
            return None

        diameter = obj.require_parameter(
            diameter_parameter
        )

        depth = obj.require_parameter(
            depth_parameter
        )

        diameter_value = float(
            diameter.value
        )

        if diameter_value <= 0.0:
            raise ValueError(
                f"El diámetro del objeto "
                f"{obj.object_id!r} debe ser positivo."
            )

        geometry = {
            "type": (
                "CIRCULAR_EXTRUSION"
            ),
            "parameters": {
                "diameter": (
                    self._parameter_payload(
                        diameter
                    )
                ),
                "radius": {
                    "value": (
                        diameter_value
                        / 2.0
                    ),
                    "unit": (
                        diameter.unit
                    ),
                    "status": (
                        EvidenceStatus.DERIVED.value
                    ),
                    "derived_from": (
                        diameter_parameter
                    ),
                },
                "depth": (
                    self._parameter_payload(
                        depth
                    )
                ),
            },
        }

        obj.geometry_definition = (
            geometry
        )

        obj.update_confidence_level()

        return geometry

    def mark_parameter_as_inferred(
        self,
        obj: ReconstructedObject,
        name: str,
        value: object,
        unit: str | None = None,
        notes: str | None = None,
    ) -> ParameterValue:
        """
        Crea explícitamente un parámetro inferido.

        La inferencia nunca debe disfrazarse de dato
        documentado.
        """

        parameter = ParameterValue(
            name=name,
            value=value,
            unit=unit,
            status=(
                EvidenceStatus.INFERRED
            ),
            notes=notes,
        )

        obj.add_parameter(
            parameter
        )

        obj.update_confidence_level()

        return parameter

    def mark_parameter_as_provisional(
        self,
        obj: ReconstructedObject,
        name: str,
        value: object,
        unit: str | None = None,
        notes: str | None = None,
    ) -> ParameterValue:
        """
        Crea explícitamente un parámetro provisional.
        """

        parameter = ParameterValue(
            name=name,
            value=value,
            unit=unit,
            status=(
                EvidenceStatus.PROVISIONAL
            ),
            notes=notes,
        )

        obj.add_parameter(
            parameter
        )

        obj.update_confidence_level()

        return parameter

    @staticmethod
    def _parameter_payload(
        parameter: ParameterValue,
    ) -> dict[str, object]:
        """
        Serialización mínima para definición geométrica.
        """

        return {
            "value": parameter.value,
            "unit": parameter.unit,
            "status": (
                parameter.status.value
            ),
            "sources": [
                source.to_dict()
                for source
                in parameter.sources
            ],
        }
