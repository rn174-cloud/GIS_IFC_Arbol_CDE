"""
reconstruction/visual_context_resolver.py
Capa genérica de contexto visual multimodal para v0.6.0.
Registra evidencias visuales y construye VisualContextAssessment.
REGLA ESTRICTA: La evidencia visual NUNCA se convierte automáticamente en DOCUMENTED geometry.
"""
from __future__ import annotations

from typing import Any, Optional

from core.models import (
    AssetVisualEvidence,
    AssetVisualEvidenceSet,
    EvidenceStatus,
    VisualContextAssessment,
)


class VisualContextResolver:
    """
    Evalúa conjuntos de evidencia visual multimodal (fotos, ortofotos, Street View, drones)
    para guiar la hipótesis macro del activo y formular preguntas documentales dirigidas.
    """

    def assess_visual_set(
        self,
        visual_set: AssetVisualEvidenceSet,
        context_facility_type: Optional[str] = None,
    ) -> VisualContextAssessment:
        """
        Analiza el conjunto de imágenes disponibles para el activo y sintetiza
        características visibles, sistemas plausibles, regiones ocluidas y consultas documentales.
        """
        if not visual_set.images:
            return VisualContextAssessment(
                visible_features=[],
                possible_systems=[],
                possible_components=[],
                occluded_regions=["ALL_REGIONS_UNOBSERVED"],
                unresolved_questions=["NO_VISUAL_EVIDENCE_SUPPLIED"],
                recommended_document_queries=["SEARCH_GENERAL_ARRANGEMENT_DRAWINGS"],
                confidence=0.0,
            )

        visible_features: set[str] = set()
        possible_systems: set[str] = set()
        possible_components: set[str] = set()
        occluded_regions: set[str] = set()
        unresolved_questions: list[str] = []
        document_queries: list[str] = []

        viewpoints = {img.viewpoint_type.lower() for img in visual_set.images}

        # Analizar cobertura según puntos de vista disponibles
        has_lateral = any("lateral" in vp or "elevation" in vp for vp in viewpoints)
        has_aerial = any("aerial" in vp or "drone" in vp or "ortofoto" in vp or "satellite" in vp for vp in viewpoints)
        has_street = any("street" in vp or "frontal" in vp for vp in viewpoints)
        has_underneath = any("inferior" in vp or "under" in vp or "sofit" in vp for vp in viewpoints)

        if has_lateral:
            visible_features.add("LONGITUDINAL_ELEVATION_PROFILE")
            visible_features.add("VERTICAL_CLEARANCE_AND_SUPPORTS")
            possible_systems.add("SUPERSTRUCTURE")
            possible_systems.add("SUBSTRUCTURE")
        else:
            occluded_regions.add("SUBSTRUCTURE_ELEVATION_OCUSED")
            unresolved_questions.append("Is substructure pier or column supported?")
            document_queries.append("QUERY_ELEVATION_AND_SECTION_DRAWINGS")

        if has_aerial:
            visible_features.add("PLANAR_FOOTPRINT_AND_ALIGNMENT")
            visible_features.add("LANE_OR_TRACK_CONFIGURATION")
            possible_systems.add("ROADWAY_AND_PAVEMENT")
        else:
            occluded_regions.add("TOP_SURFACE_PLAN_OCCLUDED")
            unresolved_questions.append("What is overall horizontal layout and lane count?")
            document_queries.append("QUERY_GENERAL_ARRANGEMENT_PLAN")

        if has_underneath:
            visible_features.add("UNDERSIDE_FRAMING_AND_BEARINGS")
            possible_components.add("BEAMS_OR_BOX_GIRDER")
        else:
            occluded_regions.add("FOUNDATION_AND_UNDERCARRIAGE_OCCLUDED")
            unresolved_questions.append("What foundation type and underside structural system exists?")
            document_queries.append("QUERY_FOUNDATION_AND_STRUCTURAL_SECTIONS")

        if has_street:
            visible_features.add("SURFACE_EQUIPMENT_AND_SAFETY_BARRIERS")
            possible_systems.add("EQUIPMENT_AND_LIGHTING")

        # Agregar limitaciones explícitas de cada imagen
        for img in visual_set.images:
            # Forzar explícitamente que la evidencia visual mantenga status no documental
            if img.evidence_status == EvidenceStatus.DOCUMENTED:
                # Regla v0.6.0: visual evidence CANNOT be DOCUMENTED by itself
                img.evidence_status = EvidenceStatus.INFERRED

            for lim in img.visibility_limitations:
                occluded_regions.add(lim)

        # Preguntas sobre tipología y métrica
        unresolved_questions.append("What exact metric dimensions govern the visible structural spans?")
        unresolved_questions.append("What specific fabrication details govern the joint connections?")
        document_queries.append("QUERY_FABRICATION_DETAILS_AND_SCHEDULES")

        # Confianza visual agregada (máximo 0.70 sin soporte métrico documental)
        coverage_factor = min(len(viewpoints) * 0.18, 0.65)
        avg_img_conf = sum(img.confidence for img in visual_set.images) / len(visual_set.images)
        overall_confidence = round(min(coverage_factor * avg_img_conf, 0.68), 3)

        return VisualContextAssessment(
            visible_features=sorted(list(visible_features)),
            possible_systems=sorted(list(possible_systems)),
            possible_components=sorted(list(possible_components)),
            occluded_regions=sorted(list(occluded_regions)),
            unresolved_questions=unresolved_questions,
            recommended_document_queries=document_queries,
            confidence=overall_confidence,
        )
