from __future__ import annotations

from pathlib import Path
from typing import Any

try:
    import pymupdf as fitz
except ImportError:
    import fitz

from core.models import SourceDocument
from readers.base import BaseReader


class PDFVectorReader(BaseReader):
    """
    Reader para PDF con extracción de:

    - texto;
    - palabras con posición;
    - bloques;
    - líneas y curvas vectoriales;
    - dimensiones de página;
    - metadatos básicos.

    PRINCIPIO:
    un PDF puede contener evidencia documental útil,
    pero sus primitivas gráficas no deben convertirse
    directamente en objetos físicos.

    Este reader NO realiza OCR de manera automática.
    Si una página es raster y no contiene texto/vector
    suficiente, debe registrarse esa condición.
    """

    supported_extensions = (
        ".pdf",
    )

    def read(
        self,
        path: str | Path,
    ) -> SourceDocument:

        source_path = self.validate_path(
            path
        )

        try:
            pdf = fitz.open(
                str(source_path)
            )

        except Exception as exc:
            raise RuntimeError(
                f"No fue posible abrir PDF: {source_path}"
            ) from exc

        pages: list[dict[str, Any]] = []
        warnings: list[str] = []

        total_text_chars = 0
        total_drawings = 0
        raster_suspected_pages: list[int] = []

        try:
            for page_index in range(
                pdf.page_count
            ):
                page = pdf.load_page(
                    page_index
                )

                page_record = (
                    self._extract_page(
                        page=page,
                        page_index=page_index,
                    )
                )

                pages.append(
                    page_record
                )

                total_text_chars += len(
                    page_record.get(
                        "text",
                        "",
                    )
                )

                total_drawings += len(
                    page_record.get(
                        "drawings",
                        [],
                    )
                )

                if page_record.get(
                    "raster_suspected"
                ):
                    raster_suspected_pages.append(
                        page_index + 1
                    )

        finally:
            metadata = dict(
                pdf.metadata or {}
            )

            page_count = pdf.page_count

            pdf.close()

        if raster_suspected_pages:
            warnings.append(
                "Se detectaron páginas con escasa o nula "
                "información textual/vectorial. Podrían ser "
                "páginas raster y requerir análisis visual "
                "u OCR controlado: "
                + ", ".join(
                    str(page_number)
                    for page_number
                    in raster_suspected_pages
                )
            )

        source_id, sha256, file_size = self.compute_file_metadata(source_path)

        return SourceDocument(
            path=source_path,
            file_type="PDF",
            source_id=source_id,
            sha256=sha256,
            file_size=file_size,
            metadata={
                "page_count": page_count,
                "pdf_metadata": metadata,
                "total_text_chars": total_text_chars,
                "total_vector_drawings": (
                    total_drawings
                ),
                "raster_suspected_pages": (
                    raster_suspected_pages
                ),
            },
            extracted_data={
                "pages": pages,
            },
            warnings=warnings,
        )

    def _extract_page(
        self,
        page: Any,
        page_index: int,
    ) -> dict[str, Any]:
        """
        Extrae evidencia estructurada de una página.
        """

        rect = page.rect

        text = page.get_text(
            "text"
        )

        words_raw = page.get_text(
            "words"
        )

        words = [
            {
                "x0": float(word[0]),
                "y0": float(word[1]),
                "x1": float(word[2]),
                "y1": float(word[3]),
                "text": str(word[4]),
                "block_no": int(word[5]),
                "line_no": int(word[6]),
                "word_no": int(word[7]),
            }
            for word in words_raw
        ]

        blocks_raw = page.get_text(
            "blocks"
        )

        blocks: list[
            dict[str, Any]
        ] = []

        for block in blocks_raw:
            blocks.append(
                {
                    "x0": float(
                        block[0]
                    ),
                    "y0": float(
                        block[1]
                    ),
                    "x1": float(
                        block[2]
                    ),
                    "y1": float(
                        block[3]
                    ),
                    "text": str(
                        block[4]
                    ),
                    "block_no": int(
                        block[5]
                    ),
                    "block_type": int(
                        block[6]
                    )
                    if len(block) > 6
                    else None,
                }
            )

        drawings = self._extract_drawings(
            page
        )

        image_count = len(
            page.get_images(
                full=True
            )
        )

        raster_suspected = (
            len(text.strip()) < 10
            and len(drawings) == 0
            and image_count > 0
        )

        return {
            "page_number": (
                page_index + 1
            ),
            "width": float(
                rect.width
            ),
            "height": float(
                rect.height
            ),
            "rotation": int(
                page.rotation
            ),
            "text": text,
            "words": words,
            "blocks": blocks,
            "drawings": drawings,
            "image_count": (
                image_count
            ),
            "raster_suspected": (
                raster_suspected
            ),
        }

    def _extract_drawings(
        self,
        page: Any,
    ) -> list[dict[str, Any]]:
        """
        Extrae primitivas vectoriales disponibles
        mediante PyMuPDF.

        No asigna significado técnico.
        """

        drawings_raw = (
            page.get_drawings()
        )

        drawings: list[
            dict[str, Any]
        ] = []

        for drawing_index, drawing in enumerate(
            drawings_raw
        ):

            items = []

            for item in drawing.get(
                "items",
                []
            ):
                items.append(
                    self._serialize_drawing_item(
                        item
                    )
                )

            rect = drawing.get(
                "rect"
            )

            drawings.append(
                {
                    "drawing_index": (
                        drawing_index
                    ),
                    "type": drawing.get(
                        "type"
                    ),
                    "rect": (
                        self._rect_to_dict(
                            rect
                        )
                        if rect is not None
                        else None
                    ),
                    "width": drawing.get(
                        "width"
                    ),
                    "close_path": (
                        drawing.get(
                            "closePath"
                        )
                    ),
                    "fill_opacity": (
                        drawing.get(
                            "fill_opacity"
                        )
                    ),
                    "stroke_opacity": (
                        drawing.get(
                            "stroke_opacity"
                        )
                    ),
                    "items": items,
                }
            )

        return drawings

    def _serialize_drawing_item(
        self,
        item: Any,
    ) -> dict[str, Any]:
        """
        Convierte una primitiva gráfica de PyMuPDF
        a una estructura JSON serializable.
        """

        if not item:
            return {
                "type": "UNKNOWN"
            }

        item_type = str(
            item[0]
        )

        serialized: dict[
            str,
            Any
        ] = {
            "type": item_type
        }

        values = []

        for value in item[1:]:
            values.append(
                self._serialize_geometry_value(
                    value
                )
            )

        serialized[
            "values"
        ] = values

        return serialized

    def _serialize_geometry_value(
        self,
        value: Any,
    ) -> Any:

        if isinstance(
            value,
            fitz.Point,
        ):
            return {
                "x": float(
                    value.x
                ),
                "y": float(
                    value.y
                ),
            }

        if isinstance(
            value,
            fitz.Rect,
        ):
            return self._rect_to_dict(
                value
            )

        if isinstance(
            value,
            fitz.Quad,
        ):
            return {
                "ul": {
                    "x": float(
                        value.ul.x
                    ),
                    "y": float(
                        value.ul.y
                    ),
                },
                "ur": {
                    "x": float(
                        value.ur.x
                    ),
                    "y": float(
                        value.ur.y
                    ),
                },
                "ll": {
                    "x": float(
                        value.ll.x
                    ),
                    "y": float(
                        value.ll.y
                    ),
                },
                "lr": {
                    "x": float(
                        value.lr.x
                    ),
                    "y": float(
                        value.lr.y
                    ),
                },
            }

        if isinstance(
            value,
            (
                str,
                int,
                float,
                bool,
            ),
        ):
            return value

        if value is None:
            return None

        return str(
            value
        )

    @staticmethod
    def _rect_to_dict(
        rect: Any,
    ) -> dict[str, float]:

        return {
            "x0": float(
                rect.x0
            ),
            "y0": float(
                rect.y0
            ),
            "x1": float(
                rect.x1
            ),
            "y1": float(
                rect.y1
            ),
        }
