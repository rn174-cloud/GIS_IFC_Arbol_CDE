from __future__ import annotations

import math
from typing import Any

from core.models import (
    SourceDocument,
    SourceReference,
    ViewEvidence,
)


class ViewSegmenter:
    """
    Segmentador espacial de vistas dentro de un plano CAD o PDF.

    Responsabilidad:
    Detectar regiones gráficas discretas dentro del plano para evitar que
    todas las entidades del archivo se asignen indiscriminadamente a todas las vistas.

    Principios:
    1. Proximidad espacial entre textos, cotas y geometría.
    2. Agrupamiento por bounding boxes y distancia.
    3. Títulos de vista próximos a una región gráfica.
    4. Conservar referencias a entidades en lugar de duplicar geometría pesada.
    5. Si no puede segmentarse de manera fiable: view_type=UNKNOWN, detection_method=UNRESOLVED.
    """

    def segment_document(
        self,
        document: SourceDocument,
        lexical_views: list[ViewEvidence],
    ) -> list[ViewEvidence]:
        """
        Segmenta espacialmente el documento combinando evidencia léxica y geométrica.
        """
        if document.file_type in {"DXF", "DWG"}:
            return self._segment_cad(document, lexical_views)

        if document.file_type == "PDF":
            return self._segment_pdf(document, lexical_views)

        return lexical_views

    def _compute_adaptive_threshold(
        self,
        boxes: list[dict[str, float]],
    ) -> tuple[float, str, dict[str, Any]]:
        """
        Calcula un umbral de agrupación espacial adaptativo e intrínseco al documento.

        Criterios:
        - drawing extent (diagonal del espacio ocupado);
        - median bbox size / diagonal;
        - distribución de distancias al vecino más próximo (nearest-neighbour distances);
        - percentiles de distancia (p75, p90, p95).

        NUNCA utiliza un valor fijo o hardcodeado.
        """
        if not boxes:
            return 10.0, "FALLBACK_EMPTY", {}

        n = len(boxes)
        min_x = min(b["minx"] for b in boxes)
        max_x = max(b["maxx"] for b in boxes)
        min_y = min(b["miny"] for b in boxes)
        max_y = max(b["maxy"] for b in boxes)
        drawing_extent = math.hypot(max_x - min_x, max_y - min_y)

        # Diagonales de cada entidad
        diags = [
            math.hypot(b["maxx"] - b["minx"], b["maxy"] - b["miny"])
            for b in boxes
        ]
        diags.sort()
        median_diag = diags[n // 2]
        p75_diag = diags[int(n * 0.75)] if n > 3 else median_diag

        # Distancias al vecino más próximo (boundary-to-boundary)
        nn_dists: list[float] = []
        # Para eficiencia en dibujos muy densos, evaluamos sobre una muestra uniforme si n > 600
        stride = max(1, n // 300)
        eval_indices = list(range(0, n, stride))

        for i in eval_indices:
            b_i = boxes[i]
            min_d = float("inf")
            for j in range(n):
                if i == j:
                    continue
                d = self._box_distance(b_i, boxes[j])
                if d < min_d:
                    min_d = d
                    if min_d == 0.0:
                        break
            nn_dists.append(min_d)

        nn_dists.sort()
        m_nn = len(nn_dists)
        p50_nn = nn_dists[m_nn // 2]
        p90_nn = nn_dists[int(m_nn * 0.90)] if m_nn > 9 else p50_nn
        p95_nn = nn_dists[int(m_nn * 0.95)] if m_nn > 19 else p90_nn
        max_nn = nn_dists[-1] if nn_dists else 0.0

        # Heurística adaptativa multi-factor:
        # 1. Al menos 2.5 veces la distancia máxima observada al vecino más próximo en elementos locales
        # 2. O 2.0 veces el tamaño percentil 75 de las geometrías típicas
        # 3. Pero nunca exceder el 15% de la extensión total del dibujo (para no unificar vistas distantes)
        base_threshold = max(2.5 * max_nn, 2.0 * p75_diag, 3.0 * p50_nn)
        max_permitted = max(1.0, 0.15 * drawing_extent)
        adaptive_threshold = min(base_threshold, max_permitted)
        adaptive_threshold = max(adaptive_threshold, 0.5)

        stats = {
            "entity_count": n,
            "drawing_extent": round(drawing_extent, 3),
            "median_diag": round(median_diag, 4),
            "p75_diag": round(p75_diag, 4),
            "p50_nn_dist": round(p50_nn, 4),
            "p90_nn_dist": round(p90_nn, 4),
            "max_nn_dist": round(max_nn, 4),
            "adaptive_threshold": round(adaptive_threshold, 4),
        }
        return adaptive_threshold, "ADAPTIVE_NEAREST_NEIGHBOUR_EXTENT", stats

    def _box_distance(self, b1: dict[str, float], b2: dict[str, float]) -> float:
        dx = max(0.0, max(b1["minx"] - b2["maxx"], b2["minx"] - b1["maxx"]))
        dy = max(0.0, max(b1["miny"] - b2["maxy"], b2["miny"] - b1["maxy"]))
        return math.hypot(dx, dy)

    def _segment_cad(
        self,
        document: SourceDocument,
        lexical_views: list[ViewEvidence],
    ) -> list[ViewEvidence]:
        """
        Segmenta un archivo CAD agrupando entidades por cercanía espacial o por título.
        Separa MODELSPACE de PAPERSPACE / BLOCK_DEFINITION.
        """
        entities = document.extracted_data.get("entities", [])
        canonical_texts = document.extracted_data.get("texts", [])
        canonical_dims = document.extracted_data.get("dimensions", [])

        if not entities:
            return lexical_views

        # 1. Separar entidades de MODELSPACE de definiciones de bloque o formato de lámina
        modelspace_entities = [
            e for e in entities
            if e.get("space", "MODELSPACE") == "MODELSPACE"
        ]
        # Si no hay clasificación de espacio explícita, considerar todas
        target_entities = modelspace_entities if modelspace_entities else entities

        entity_boxes: list[tuple[dict[str, Any], dict[str, float]]] = []
        for entity in target_entities:
            box = self._compute_cad_entity_bbox(entity)
            if box:
                entity_boxes.append((entity, box))

        if not entity_boxes:
            return lexical_views

        # 2. Calcular threshold adaptativo a partir de la distribución espacial de las entidades
        adaptive_th, th_method, th_stats = self._compute_adaptive_threshold(
            [b for _, b in entity_boxes]
        )

        # 3. Agrupar mediante single-linkage con threshold adaptativo
        clusters = self._cluster_bboxes(
            [b for _, b in entity_boxes],
            max_gap=adaptive_th,
        )

        # Si no se separaron clusters o solo hay 1:
        if len(clusters) <= 1:
            global_box = self._merge_bboxes([b for _, b in entity_boxes])
            segmented_views: list[ViewEvidence] = []
            all_handles = [str(e.get("handle")) for e in target_entities if e.get("handle")]

            # Textos asociados
            doc_texts = [str(t.get("text")) for t in canonical_texts if isinstance(t, dict) and t.get("text")]
            if not doc_texts:
                doc_texts = [str(e.get("text")) for e in entities if e.get("entity_type") in {"TEXT", "MTEXT"} and e.get("text")]

            for v in lexical_views:
                v.bounding_box = global_box
                v.detection_method = "GLOBAL_CAD_BOUNDS"
                v.entity_references = all_handles
                v.texts = doc_texts
                v.dimensions = canonical_dims
                v.geometry = {
                    "bbox": global_box,
                    "entity_count": len(target_entities),
                    "threshold_method": th_method,
                    "adaptive_threshold": adaptive_th,
                    "clustering_stats": th_stats,
                }
                segmented_views.append(v)
            return segmented_views

        # 4. Múltiples regiones detectadas:
        segmented_views = []
        for cluster_idx, cluster_box in enumerate(clusters):
            contained_entities = []
            contained_handles = []

            for ent, box in entity_boxes:
                if self._box_inside_or_intersects(box, cluster_box, tol=adaptive_th * 0.2):
                    contained_entities.append(ent)
                    if ent.get("handle"):
                        contained_handles.append(str(ent["handle"]))

            # Asignar textos canónicos dentro de esta región espacial
            contained_texts: list[str] = []
            for t in canonical_texts:
                if not isinstance(t, dict):
                    continue
                pos = t.get("insertion_point") or t.get("insert")
                t_str = t.get("text", "")
                if not t_str:
                    continue
                if pos is not None:
                    if isinstance(pos, dict):
                        tx = float(pos.get("x", 0.0))
                        ty = float(pos.get("y", 0.0))
                    elif isinstance(pos, (list, tuple)) and len(pos) >= 2:
                        tx, ty = float(pos[0]), float(pos[1])
                    else:
                        continue
                    if (cluster_box["minx"] - 2.0 <= tx <= cluster_box["maxx"] + 2.0 and
                            cluster_box["miny"] - 2.0 <= ty <= cluster_box["maxy"] + 2.0):
                        contained_texts.append(str(t_str))

            # Asignar cotas canónicas cuyos puntos caen en esta región
            contained_dims: list[dict[str, Any]] = []
            for d in canonical_dims:
                pts = d.get("definition_points", [])
                if pts:
                    def _pt_in_region(pt: Any) -> bool:
                        if isinstance(pt, dict):
                            px, py = float(pt.get("x", 0.0)), float(pt.get("y", 0.0))
                        elif isinstance(pt, (list, tuple)) and len(pt) >= 2:
                            px, py = float(pt[0]), float(pt[1])
                        else:
                            return False
                        return (cluster_box["minx"] - 2.0 <= px <= cluster_box["maxx"] + 2.0 and
                                cluster_box["miny"] - 2.0 <= py <= cluster_box["maxy"] + 2.0)

                    if any(_pt_in_region(p) for p in pts):
                        contained_dims.append(d)

            # Clasificación local de vista: solo a partir de textos contenidos en la región
            cluster_text_str = " ".join(contained_texts).upper()
            assigned_type = "UNKNOWN"
            conf = 0.35

            if any(k in cluster_text_str for k in ["PLANTA", "PLAN"]):
                assigned_type = "PLAN"
                conf = 0.70
            elif any(k in cluster_text_str for k in ["SECCION", "SECCIÓN", "CORTE", "SECTION"]):
                assigned_type = "SECTION"
                conf = 0.70
            elif any(k in cluster_text_str for k in ["PERFIL", "PROFILE"]):
                assigned_type = "PROFILE"
                conf = 0.70
            elif any(k in cluster_text_str for k in ["DETALLE", "DETAIL"]):
                assigned_type = "DETAIL"
                conf = 0.70

            view_id = f"{document.path.name}:region:{cluster_idx}:{assigned_type}"

            view = ViewEvidence(
                view_id=view_id,
                view_type=assigned_type,
                source=SourceReference(
                    source_file=str(document.path),
                    source_type=document.file_type,
                    view=assigned_type,
                ),
                bounding_box=cluster_box,
                detection_method="SPATIAL_CLUSTER_ADAPTIVE",
                geometry={
                    "bbox": cluster_box,
                    "entity_count": len(contained_entities),
                    "text_count": len(contained_texts),
                    "dimension_count": len(contained_dims),
                    "threshold_method": th_method,
                    "adaptive_threshold": adaptive_th,
                    "clustering_stats": th_stats,
                },
                entity_references=contained_handles,
                texts=contained_texts,
                dimensions=contained_dims,
                confidence=conf,
                notes=f"REGION_CANDIDATE cluster_{cluster_idx} (entities={len(contained_entities)}, texts={len(contained_texts)}, dims={len(contained_dims)})",
            )
            segmented_views.append(view)

        return segmented_views

    def _segment_pdf(
        self,
        document: SourceDocument,
        lexical_views: list[ViewEvidence],
    ) -> list[ViewEvidence]:
        """
        Segmenta páginas PDF asociando bounding boxes de página y regiones vectoriales.
        """
        pages = document.extracted_data.get("pages", [])
        if not pages:
            return lexical_views

        segmented_views: list[ViewEvidence] = []

        for page in pages:
            pn = page.get("page_number", 1)
            pw = page.get("width", 0.0)
            ph = page.get("height", 0.0)
            page_bbox = {"minx": 0.0, "miny": 0.0, "maxx": float(pw), "maxy": float(ph)}

            # Buscar la vista léxica correspondiente a esta página si existe
            matching_lex = [
                v for v in lexical_views
                if v.source.sheet == str(pn)
            ]

            v_type = matching_lex[0].view_type if matching_lex else "UNKNOWN"
            conf = matching_lex[0].confidence if matching_lex else 0.20

            # Guardar referencia liviana (evitar clonar 4500 primitivas en cada vista)
            drawings_count = len(page.get("drawings", []))

            view_id = f"{document.path.name}:page:{pn}:{v_type}"
            view = ViewEvidence(
                view_id=view_id,
                view_type=v_type,
                source=SourceReference(
                    source_file=str(document.path),
                    source_type="PDF",
                    sheet=str(pn),
                    view=v_type,
                ),
                bounding_box=page_bbox,
                detection_method="PAGE_BOUNDS_AND_VECTORS",
                geometry={
                    "page_number": pn,
                    "page_width": pw,
                    "page_height": ph,
                    "drawings_count": drawings_count,
                },
                texts=[
                    w.get("text", "")
                    for w in page.get("words", [])
                    if w.get("text")
                ],
                confidence=conf,
            )
            segmented_views.append(view)

        return segmented_views

    def _compute_cad_entity_bbox(self, entity: dict[str, Any]) -> dict[str, float] | None:
        """Calcula bounding box 2D de una entidad CAD."""
        etype = entity.get("entity_type")

        if etype == "LINE":
            s, e = entity.get("start", {}), entity.get("end", {})
            return {
                "minx": min(s.get("x", 0.0), e.get("x", 0.0)),
                "miny": min(s.get("y", 0.0), e.get("y", 0.0)),
                "maxx": max(s.get("x", 0.0), e.get("x", 0.0)),
                "maxy": max(s.get("y", 0.0), e.get("y", 0.0)),
            }

        if etype in {"LWPOLYLINE", "POLYLINE"}:
            pts = entity.get("points", [])
            if not pts:
                return None
            xs = [p.get("x", 0.0) for p in pts]
            ys = [p.get("y", 0.0) for p in pts]
            return {
                "minx": min(xs),
                "miny": min(ys),
                "maxx": max(xs),
                "maxy": max(ys),
            }

        if etype in {"CIRCLE", "ARC"}:
            c = entity.get("center", {})
            r = entity.get("radius", 0.0)
            cx, cy = c.get("x", 0.0), c.get("y", 0.0)
            return {
                "minx": cx - r,
                "miny": cy - r,
                "maxx": cx + r,
                "maxy": cy + r,
            }

        if etype in {"TEXT", "MTEXT", "INSERT", "POINT"}:
            loc = entity.get("insert") or entity.get("location") or {}
            x, y = loc.get("x", 0.0), loc.get("y", 0.0)
            return {
                "minx": x,
                "miny": y,
                "maxx": x,
                "maxy": y,
            }

        return None

    def _merge_bboxes(self, boxes: list[dict[str, float]]) -> dict[str, float]:
        if not boxes:
            return {"minx": 0.0, "miny": 0.0, "maxx": 0.0, "maxy": 0.0}
        return {
            "minx": min(b["minx"] for b in boxes),
            "miny": min(b["miny"] for b in boxes),
            "maxx": max(b["maxx"] for b in boxes),
            "maxy": max(b["maxy"] for b in boxes),
        }

    def _cluster_bboxes(
        self,
        boxes: list[dict[str, float]],
        max_gap: float = 150.0,
    ) -> list[dict[str, float]]:
        """
        Agrupa cajas que estén a una distancia menor a max_gap.
        """
        if not boxes:
            return []

        clusters: list[list[dict[str, float]]] = []

        for b in boxes:
            assigned = False
            for c in clusters:
                merged = self._merge_bboxes(c)
                # Distancia entre merged y b
                dx = max(0.0, max(merged["minx"] - b["maxx"], b["minx"] - merged["maxx"]))
                dy = max(0.0, max(merged["miny"] - b["maxy"], b["miny"] - merged["maxy"]))
                dist = math.sqrt(dx * dx + dy * dy)
                if dist <= max_gap:
                    c.append(b)
                    assigned = True
                    break
            if not assigned:
                clusters.append([b])

        return [self._merge_bboxes(c) for c in clusters]

    def _box_inside_or_intersects(
        self,
        inner: dict[str, float],
        outer: dict[str, float],
        tol: float = 1.0,
    ) -> bool:
        return not (
            inner["maxx"] < outer["minx"] - tol
            or inner["minx"] > outer["maxx"] + tol
            or inner["maxy"] < outer["miny"] - tol
            or inner["miny"] > outer["maxy"] + tol
        )
