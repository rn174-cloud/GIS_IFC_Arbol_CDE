from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from core.canonical_cad import CanonicalCADDocument


class CapabilityStatus(str, Enum):
    SUPPORTED = "SUPPORTED"
    PARTIAL = "PARTIAL"
    UNSUPPORTED = "UNSUPPORTED"
    UNKNOWN = "UNKNOWN"


@dataclass
class ProviderCapabilities:
    native_dwg: CapabilityStatus = CapabilityStatus.SUPPORTED
    layers: CapabilityStatus = CapabilityStatus.SUPPORTED
    blocks: CapabilityStatus = CapabilityStatus.SUPPORTED
    nested_blocks: CapabilityStatus = CapabilityStatus.PARTIAL
    dimensions: CapabilityStatus = CapabilityStatus.PARTIAL
    layouts: CapabilityStatus = CapabilityStatus.SUPPORTED
    paperspace: CapabilityStatus = CapabilityStatus.SUPPORTED
    modelspace: CapabilityStatus = CapabilityStatus.SUPPORTED
    xrefs: CapabilityStatus = CapabilityStatus.PARTIAL
    xdata: CapabilityStatus = CapabilityStatus.PARTIAL
    dynamic_blocks: CapabilityStatus = CapabilityStatus.UNSUPPORTED
    splines: CapabilityStatus = CapabilityStatus.SUPPORTED
    hatches: CapabilityStatus = CapabilityStatus.SUPPORTED
    texts: CapabilityStatus = CapabilityStatus.SUPPORTED
    mtext: CapabilityStatus = CapabilityStatus.SUPPORTED

    def to_dict(self) -> dict[str, str]:
        return {
            "native_dwg": self.native_dwg.value,
            "layers": self.layers.value,
            "blocks": self.blocks.value,
            "nested_blocks": self.nested_blocks.value,
            "dimensions": self.dimensions.value,
            "layouts": self.layouts.value,
            "paperspace": self.paperspace.value,
            "modelspace": self.modelspace.value,
            "xrefs": self.xrefs.value,
            "xdata": self.xdata.value,
            "dynamic_blocks": self.dynamic_blocks.value,
            "splines": self.splines.value,
            "hatches": self.hatches.value,
            "texts": self.texts.value,
            "mtext": self.mtext.value,
        }


@dataclass
class ProviderHealth:
    is_operational: bool
    provider_name: str
    version: Optional[str] = None
    executable_path: Optional[str] = None
    library_path: Optional[str] = None
    notes: Optional[str] = None
    diagnostics: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "is_operational": self.is_operational,
            "provider_name": self.provider_name,
            "version": self.version,
            "executable_path": self.executable_path,
            "library_path": self.library_path,
            "notes": self.notes,
            "diagnostics": self.diagnostics,
        }


class DWGProvider(ABC):
    """
    Contrato abstracto para proveedores de ingesta DWG.

    El pipeline de reconstrucción NUNCA conoce qué biblioteca o herramienta
    externa procesa el DWG (LibreDWG, ODA, Autodesk Core Console, etc.).
    Solo consume el CanonicalCADDocument neutral.
    """

    provider_id: str = "GENERIC_DWG"
    display_name: str = "Generic DWG Provider"

    @abstractmethod
    def probe(self) -> bool:
        """Verifica de forma no bloqueante si el proveedor está disponible en el entorno."""
        raise NotImplementedError

    @abstractmethod
    def is_available(self) -> bool:
        """Retorna True si el proveedor puede procesar archivos en este momento."""
        raise NotImplementedError

    @abstractmethod
    def version(self) -> Optional[str]:
        """Retorna la versión del motor de lectura DWG."""
        raise NotImplementedError

    @abstractmethod
    def supported_dwg_versions(self) -> list[str]:
        """Lista las versiones DWG soportadas (ej. AC1015, AC1018, AC1027, AC1032, etc.)."""
        raise NotImplementedError

    @abstractmethod
    def get_capabilities(self) -> ProviderCapabilities:
        """Retorna la matriz de capacidades declaradas del proveedor."""
        raise NotImplementedError

    @abstractmethod
    def inspect(self, dwg_path: Path) -> dict[str, Any]:
        """Extrae metadatos rápidos sin parsear todo el modelo si es posible."""
        raise NotImplementedError

    @abstractmethod
    def read(self, dwg_path: Path) -> CanonicalCADDocument:
        """
        Lee el archivo DWG y retorna la representación canónica neutral.
        Si la fuente primaria es un DWG, CanonicalCADDocument conserva
        su identidad y hash original inmutables.
        """
        raise NotImplementedError

    @abstractmethod
    def health_check(self) -> ProviderHealth:
        """Realiza un diagnóstico de salud del proveedor."""
        raise NotImplementedError
