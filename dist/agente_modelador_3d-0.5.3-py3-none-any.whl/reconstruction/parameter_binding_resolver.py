from __future__ import annotations

import math
import re
from typing import Any, Optional

from core.geometry_kernel import LocalFrame, Point3D, Vector3D
from core.models import (
    CandidateType,
    EvidenceOrigin,
    EvidenceStatus,
    ParameterBindingCandidate,
    SourceReference,
    UnitResolutionStatus,
    ViewEvidence,
)
from reconstruction.unit_resolver import UnitResolver


class ParameterBindingResolver:
    """
    Motor de vinculación de parámetros físicos (Parameter Binding) por geometría local,
    orientación vectorial, proximidad léxica y vistas complementarias v0.5.3.

    PRINCIPIOS:
    1. ELIMINAR DIMENSION_GENERAL como colapso semántico. No consolidar cotas diferentes
       en el mismo parámetro.
    2. Parámetros físicos admisibles:
       LONGITUD, ANCHO, ALTURA, ESPESOR, DIAMETRO, RADIO, OFFSET, ELEVACION,
       SEPARACION, OTRO_PARAMETRO_DOCUMENTADO, DIMENSION_UNRESOLVED.
    3. Análisis vectorial:
       Relación angular entre el vector de medición de la cota y los ejes locales
       (LOCAL_X, LOCAL_Y, LOCAL_Z) del candidato u objeto.
    4. Text-aware:
       Palabras clave locales próximas (ANCHO, ESPESOR, DIAMETRO, ALTURA, Ø, %%C, H=, e=, etc.).
       Texto regional general NO actúa como evidencia determinante.
    5. View-aware:
       Evidencia complementaria (PLAN -> longitud/ancho; ELEVATION -> longitud/altura;
       SECTION -> ancho/altura/espesor/diámetro).
    6. Conflicto Real:
       Dos valores diferentes NO crean DOCUMENT_CONFLICT si son parámetros físicos distintos.
    """

    # Patrones léxicos de alta prioridad
    DIAMETER_PATTERN = re.compile(r"(?:%%[Cc]|Ø|ø|\bDI[AÁ]METRO\b|\bDIAM\b|\bøi\b)", re.IGNORECASE)
    RADIUS_PATTERN = re.compile(r"(?:\bRADIO\b|\bRAD\b|\bR\s*=\s*|\bR(?=\d))", re.IGNORECASE)
    THICKNESS_PATTERN = re.compile(r"(?:\bESPESOR\b|\bESP\b|\be\s*=\s*|\be(?=\d))", re.IGNORECASE)
    HEIGHT_PATTERN = re.compile(r"(?:\bALTURA\b|\bALTO\b|\bH\s*=\s*|\bH(?=\d)|\bPROFUNDIDAD\b)", re.IGNORECASE)
    WIDTH_PATTERN = re.compile(r"(?:\bANCHO\b|\bBASE\b|\bB\s*=\s*|\bB(?=\d))", re.IGNORECASE)
    LENGTH_PATTERN = re.compile(r"(?:\bLONGITUD\b|\bLARGO\b|\bL\s*=\s*|\bL(?=\d))", re.IGNORECASE)
    ELEVATION_PATTERN = re.compile(r"(?:\bCOTA\b|\bNIVEL\b|\bELEVACI[OÓ]N\b|\bEL\b|\bZ\b)", re.IGNORECASE)

    def __init__(self, unit_resolver: Optional[UnitResolver] = None) -> None:
        self.unit_resolver = unit_resolver or UnitResolver()

    def bind_measurement_to_candidate(
        self,
        measurement: dict[str, Any],
        candidate_bbox: Optional[dict[str, float]] = None,
        candidate_type: Optional[str] = None,
        view_type: Optional[str] = None,
        local_frame: Optional[LocalFrame] = None,
        nearby_texts: Optional[list[dict[str, Any]]] = None,
        document_unit_evidence: Optional[dict[str, Any]] = None,
    ) -> ParameterBindingCandidate:
        """
        Determina a qué parámetro físico corresponde una cota o medición técnica.
        """
        raw_text = measurement.get("raw_text") or ""
        override = measurement.get("text_override") or ""
        dim_type = measurement.get("dimension_type") or "LINEAR"
        def_pts = measurement.get("definition_points") or []
        handle = measurement.get("dimension_handle") or measurement.get("handle")
        source_id = measurement.get("source", {}).get("source_file") if isinstance(measurement.get("source"), dict) else None
        view_id = measurement.get("view_id")

        raw_val = float(measurement.get("value", 0.0))
        text_full = f"{raw_text} {override}".strip()

        evidence_groups: list[str] = []
        confidence = 0.50
        param_name = "DIMENSION_UNRESOLVED"
        binding_method = "UNRESOLVED"
        geom_axis: Optional[str] = None

        # -------------------------------------------------------------
        # 1. EVALUAR EVIDENCIA LÉXICA EXPLÍCITA DIRECTA EN LA COTA
        # -------------------------------------------------------------
        if self.DIAMETER_PATTERN.search(text_full):
            param_name = "DIAMETRO"
            binding_method = "EXPLICIT_TEXT_DIAMETER_SYMBOL"
            confidence = 0.95
            evidence_groups.append("TEXTUAL_EXPLICIT_SYMBOL")

        elif self.RADIUS_PATTERN.search(text_full):
            param_name = "RADIO"
            binding_method = "EXPLICIT_TEXT_RADIUS_KEYWORD"
            confidence = 0.95
            evidence_groups.append("TEXTUAL_EXPLICIT_KEYWORD")

        elif self.THICKNESS_PATTERN.search(text_full):
            param_name = "ESPESOR"
            binding_method = "EXPLICIT_TEXT_THICKNESS_KEYWORD"
            confidence = 0.90
            evidence_groups.append("TEXTUAL_EXPLICIT_KEYWORD")

        elif self.HEIGHT_PATTERN.search(text_full):
            param_name = "ALTURA"
            binding_method = "EXPLICIT_TEXT_HEIGHT_KEYWORD"
            confidence = 0.90
            evidence_groups.append("TEXTUAL_EXPLICIT_KEYWORD")

        elif self.WIDTH_PATTERN.search(text_full):
            param_name = "ANCHO"
            binding_method = "EXPLICIT_TEXT_WIDTH_KEYWORD"
            confidence = 0.85
            evidence_groups.append("TEXTUAL_EXPLICIT_KEYWORD")

        elif self.LENGTH_PATTERN.search(text_full):
            param_name = "LONGITUD"
            binding_method = "EXPLICIT_TEXT_LENGTH_KEYWORD"
            confidence = 0.85
            evidence_groups.append("TEXTUAL_EXPLICIT_KEYWORD")

        elif self.ELEVATION_PATTERN.search(text_full) or measurement.get("candidate_type") == CandidateType.ELEVATION.value:
            param_name = "ELEVACION"
            binding_method = "EXPLICIT_TEXT_ELEVATION_KEYWORD"
            confidence = 0.90
            evidence_groups.append("TEXTUAL_EXPLICIT_KEYWORD")

        elif measurement.get("candidate_type") == CandidateType.STATION.value:
            param_name = "PROGRESIVA_EJE"
            binding_method = "LINEAR_REFERENCING_STATION"
            confidence = 0.95
            evidence_groups.append("LRS_STATION")

        # -------------------------------------------------------------
        # 2. EVALUAR ORIENTACIÓN VECTORIAL Y GEOMETRÍA LOCAL
        # -------------------------------------------------------------
        vector = self._compute_dimension_vector(def_pts)
        if vector:
            geom_axis = self._classify_vector_axis(vector, local_frame)
            evidence_groups.append(f"GEOMETRY_AXIS:{geom_axis}")

            # Si no hubo texto explícito, resolver por orientación vectorial + contexto de vista
            if param_name == "DIMENSION_UNRESOLVED":
                param_name, binding_method, conf_geom = self._bind_by_axis_and_view(
                    geom_axis=geom_axis,
                    view_type=view_type,
                    candidate_type=candidate_type,
                    candidate_bbox=candidate_bbox,
                    raw_value=raw_val,
                )
                confidence = max(confidence, conf_geom)
                if binding_method != "UNRESOLVED":
                    evidence_groups.append("VECTOR_ORIENTATION")

        # -------------------------------------------------------------
        # 3. EVALUAR TEXTOS PRÓXIMOS AL OBJETO (TEXT-AWARE LOCAL)
        # -------------------------------------------------------------
        if nearby_texts and param_name == "DIMENSION_UNRESOLVED":
            closest_param, text_dist, t_raw = self._find_nearby_text_binding(nearby_texts, candidate_bbox)
            if closest_param:
                param_name = closest_param
                binding_method = "NEARBY_TEXT_PROXIMITY"
                confidence = 0.75
                evidence_groups.append(f"NEARBY_TEXT:{t_raw[:30]}")

        # -------------------------------------------------------------
        # 4. RESOLUCIÓN DE UNIDADES
        # -------------------------------------------------------------
        unit_rec = self.unit_resolver.resolve_measurement_unit(
            raw_value=raw_val,
            declared_unit=measurement.get("unit"),
            raw_text=text_full,
            doc_evidence=document_unit_evidence,
        )

        return ParameterBindingCandidate(
            parameter_name=param_name,
            binding_method=binding_method,
            geometry_axis=geom_axis,
            dimension_handle=handle,
            source_id=source_id,
            view_id=view_id,
            confidence=round(confidence, 3),
            evidence_groups=evidence_groups,
            raw_text=text_full if text_full else None,
            raw_value=raw_val,
            raw_unit=unit_rec.raw_unit,
            resolved_value=unit_rec.resolved_value,
            resolved_unit=unit_rec.resolved_unit,
            conversion_factor=unit_rec.conversion_factor,
            unit_resolution_status=unit_rec.unit_resolution_status,
            notes=f"Binding {param_name} via {binding_method} (axis={geom_axis})",
        )

    def _compute_dimension_vector(self, def_pts: list[list[float]]) -> Optional[Vector3D]:
        """
        Calcula el vector de dirección entre puntos de definición de la cota.
        """
        if len(def_pts) < 2:
            return None
        p0, p1 = def_pts[0], def_pts[1]
        dx = float(p1[0]) - float(p0[0])
        dy = float(p1[1]) - float(p0[1])
        dz = float(p1[2]) - float(p0[2]) if len(p1) > 2 and len(p0) > 2 else 0.0

        length = math.sqrt(dx * dx + dy * dy + dz * dz)
        if length < 1e-6:
            # Puntos colapsados: si hay un tercer punto de línea de cota
            if len(def_pts) >= 3:
                p2 = def_pts[2]
                dx = float(p2[0]) - float(p0[0])
                dy = float(p2[1]) - float(p0[1])
                length = math.sqrt(dx * dx + dy * dy)
                if length < 1e-6:
                    return None
            else:
                return None
        return Vector3D(dx / length, dy / length, dz / length)

    def _classify_vector_axis(self, vector: Vector3D, local_frame: Optional[LocalFrame] = None) -> str:
        """
        Clasifica el vector respecto al frame local o los ejes ortogonales principales.
        """
        if local_frame is not None:
            # Proyectar sobre los ejes locales ortonormales
            dot_x = abs(vector.x * local_frame.longitudinal.x + vector.y * local_frame.longitudinal.y + vector.z * local_frame.longitudinal.z)
            dot_y = abs(vector.x * local_frame.transverse.x + vector.y * local_frame.transverse.y + vector.z * local_frame.transverse.z)
            dot_z = abs(vector.x * local_frame.vertical.x + vector.y * local_frame.vertical.y + vector.z * local_frame.vertical.z)
            if dot_z > 0.707:
                return "LOCAL_Z"
            elif dot_x >= dot_y:
                return "LOCAL_X"
            else:
                return "LOCAL_Y"
        else:
            # Sistema cartesiano neutral
            ax, ay, az = abs(vector.x), abs(vector.y), abs(vector.z)
            if az > 0.707 or (az >= ax and az >= ay and az > 0.5):
                return "LOCAL_Z"
            elif ax >= ay:
                return "LOCAL_X"
            else:
                return "LOCAL_Y"

    def _bind_by_axis_and_view(
        self,
        geom_axis: str,
        view_type: Optional[str] = None,
        candidate_type: Optional[str] = None,
        candidate_bbox: Optional[dict[str, float]] = None,
        raw_value: float = 0.0,
    ) -> tuple[str, str, float]:
        """
        Deduce el parámetro físico combinando eje vectorial y tipo de vista.
        """
        v_type = (view_type or "UNKNOWN").upper()

        if v_type == "PLAN":
            # En vista en planta, las dimensiones están en el plano horizontal
            if geom_axis == "LOCAL_X":
                return "LONGITUD", "VECTOR_AXIS_PLAN_X", 0.80
            elif geom_axis == "LOCAL_Y":
                return "ANCHO", "VECTOR_AXIS_PLAN_Y", 0.80
            elif geom_axis == "LOCAL_Z":
                return "ALTURA", "VECTOR_AXIS_PLAN_Z", 0.70

        elif v_type in {"ELEVATION", "SECTION", "CORTE"}:
            # En vistas verticales / elevación
            if geom_axis in {"LOCAL_Z", "LOCAL_Y"}:
                # El eje vertical en vista de corte representa altura o espesor
                if candidate_type and any(k in candidate_type for k in ["SLAB", "LOSA", "PAVEMENT"]):
                    return "ESPESOR", "VECTOR_AXIS_VERTICAL_SLAB", 0.85
                else:
                    return "ALTURA", "VECTOR_AXIS_VERTICAL_ELEVATION", 0.85
            elif geom_axis == "LOCAL_X":
                return "ANCHO", "VECTOR_AXIS_HORIZONTAL_SECTION", 0.80

        elif v_type in {"DETAIL", "DETALLE"}:
            if geom_axis == "LOCAL_Z":
                return "ALTURA", "VECTOR_AXIS_DETAIL_Z", 0.75
            elif geom_axis == "LOCAL_Y":
                return "ESPESOR", "VECTOR_AXIS_DETAIL_Y", 0.75
            elif geom_axis == "LOCAL_X":
                return "ANCHO", "VECTOR_AXIS_DETAIL_X", 0.75

        # Asignación conservadora por eje cartesiano
        if geom_axis == "LOCAL_X":
            return "LONGITUD", "LOCAL_X_AXIS_DEFAULT", 0.65
        elif geom_axis == "LOCAL_Y":
            return "ANCHO", "LOCAL_Y_AXIS_DEFAULT", 0.65
        elif geom_axis == "LOCAL_Z":
            return "ALTURA", "LOCAL_Z_AXIS_DEFAULT", 0.65

        return "DIMENSION_UNRESOLVED", "UNRESOLVED", 0.20

    def _find_nearby_text_binding(
        self,
        texts: list[dict[str, Any]],
        bbox: Optional[dict[str, float]],
    ) -> tuple[Optional[str], Optional[float], str]:
        """
        Busca textos con palabras clave dentro de un radio de influencia del candidato.
        Excluye textos regionales lejanos.
        """
        if not bbox:
            return None, None, ""

        cx = (bbox.get("minx", 0.0) + bbox.get("maxx", 0.0)) / 2.0
        cy = (bbox.get("miny", 0.0) + bbox.get("maxy", 0.0)) / 2.0
        max_dist = max(bbox.get("maxx", 0.0) - bbox.get("minx", 0.0), bbox.get("maxy", 0.0) - bbox.get("miny", 0.0), 2.0) * 1.5

        closest_param = None
        min_dist = float("inf")
        matched_text = ""

        for t in texts:
            txt = t.get("text", "")
            pt = t.get("insert_point") or t.get("position")
            if not pt or len(pt) < 2:
                continue
            tx, ty = float(pt[0]), float(pt[1])
            dist = math.sqrt((tx - cx) ** 2 + (ty - cy) ** 2)

            if dist <= max_dist and dist < min_dist:
                if self.DIAMETER_PATTERN.search(txt):
                    closest_param = "DIAMETRO"
                    min_dist = dist
                    matched_text = txt
                elif self.THICKNESS_PATTERN.search(txt):
                    closest_param = "ESPESOR"
                    min_dist = dist
                    matched_text = txt
                elif self.HEIGHT_PATTERN.search(txt):
                    closest_param = "ALTURA"
                    min_dist = dist
                    matched_text = txt
                elif self.WIDTH_PATTERN.search(txt):
                    closest_param = "ANCHO"
                    min_dist = dist
                    matched_text = txt

        if closest_param:
            return closest_param, round(min_dist, 3), matched_text
        return None, None, ""
