"""
Core package del Agente Modelador 3D.

Contiene las capacidades fundamentales y neutrales al proyecto:

- configuración;
- modelos de datos;
- geometría;
- georreferenciación;
- creación IFC 4.3;
- trazabilidad;
- validación.

Los módulos de `core` no deben contener dimensiones, progresivas,
nombres de activos ni reglas específicas de un proyecto concreto.
"""

from core.config import AgentConfig
from core.models import (
    CandidateType,
    ConfidenceLevel,
    EvidenceStatus,
    SourceReference,
    ParameterValue,
    ReconstructedObject,
)

__all__ = [
    "AgentConfig",
    "CandidateType",
    "ConfidenceLevel",
    "EvidenceStatus",
    "SourceReference",
    "ParameterValue",
    "ReconstructedObject",
]
