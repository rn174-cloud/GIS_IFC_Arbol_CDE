from __future__ import annotations

import re
from typing import Any

from core.models import SourceDocument, ViewEvidence


class ReferenceResolver:
    """
    Detector de referencias explícitas de corte, sección y detalle entre vistas técnicas.

    Responsabilidad:
    Detectar llamadas cruzadas como:
    - SECCION A-A / CORTE A-A / A-A / B-B
    - DETALLE 1 / DETALLE 3 / DETAIL C
    - VER PLANO X / SEE DETAIL

    Principio:
    Una referencia documental explícita aporta mayor certeza de relación
    que la mera proximidad espacial entre entidades.
    """

    SECTION_CUT_PATTERNS = [
        # CORTE A-A, SECCION B-B, SECCIÓN 1-1
        re.compile(r"(?:SECCI[OÓ]N|CORTE|SECTION)\s+([A-Z0-9]+)\s*[-–]\s*([A-Z0-9]+)", re.IGNORECASE),
        # A - A o B - B aislado
        re.compile(r"\b([A-Z])\s*[-–]\s*([A-Z])\b"),
    ]

    DETAIL_CALLOUT_PATTERNS = [
        re.compile(r"(?:DETALLE|DETAIL)\s+([A-Z0-9]+)", re.IGNORECASE),
        re.compile(r"(?:VER\s+PLANO|VER\s+DETALLE|SEE\s+DETAIL)\s+([A-Z0-9\-_/]+)", re.IGNORECASE),
    ]

    def extract_references_from_text(self, text: str) -> list[dict[str, Any]]:
        """
        Extrae referencias documentales normalizadas encontradas en un texto.
        """
        refs: list[dict[str, Any]] = []

        # 1. Cortes y Secciones
        for pat in self.SECTION_CUT_PATTERNS:
            for match in pat.finditer(text):
                g1, g2 = match.group(1).upper(), match.group(2).upper()
                if g1 == g2:  # Ejemplo A-A, B-B, 1-1
                    ref_tag = f"SECTION_{g1}-{g2}"
                    refs.append({
                        "ref_type": "SECTION_CALLOUT",
                        "tag": ref_tag,
                        "raw_text": match.group(0),
                        "identifier": g1,
                    })

        # 2. Detalles
        for pat in self.DETAIL_CALLOUT_PATTERNS:
            for match in pat.finditer(text):
                tag_id = match.group(1).upper()
                refs.append({
                    "ref_type": "DETAIL_CALLOUT",
                    "tag": f"DETAIL_{tag_id}",
                    "raw_text": match.group(0),
                    "identifier": tag_id,
                })

        return refs

    def find_view_callout_matches(
        self,
        views: list[ViewEvidence],
    ) -> list[dict[str, Any]]:
        """
        Encuentra enlaces documentales explícitos entre vistas a partir de sus textos.
        """
        view_refs: dict[str, list[dict[str, Any]]] = {}

        for v in views:
            combined_text = " ".join(v.texts)
            refs = self.extract_references_from_text(combined_text)
            if refs:
                view_refs[v.view_id] = refs

        matches: list[dict[str, Any]] = []
        view_ids = list(view_refs.keys())

        for i in range(len(view_ids)):
            v_a = view_ids[i]
            refs_a = {r["tag"] for r in view_refs[v_a]}
            for j in range(i + 1, len(view_ids)):
                v_b = view_ids[j]
                refs_b = {r["tag"] for r in view_refs[v_b]}

                common = refs_a.intersection(refs_b)
                if common:
                    for tag in common:
                        matches.append({
                            "view_a": v_a,
                            "view_b": v_b,
                            "tag": tag,
                            "score_boost": 0.35,  # Impulso significativo por concordancia explícita
                            "notes": f"Llamada documental coincidente: {tag}",
                        })

        return matches
