import pytest
from core.models import (
    CandidateStatus,
    EvidenceOrigin,
    ProximityLevel,
    SemanticFamily,
    SemanticSignal,
)
from reconstruction.object_candidate_detector import (
    ObjectCandidateDetector,
    compute_candidate_confidence,
)
from reconstruction.semantic_signal_extractor import SemanticSignalExtractor


def test_far_text_does_not_generate_nearby_signal():
    """
    Test 1: Mismo plano pero texto lejano (> 200 m) != TEXT_NEARBY.
    """
    extractor = SemanticSignalExtractor()

    # Entidad situada en (0, 0)
    entity = {
        "entity_type": "CIRCLE",
        "handle": "C_ORIGIN",
        "layer": "SUBESTRUCTURA_PILOTES",
        "center": {"x": 0.0, "y": 0.0, "z": 0.0},
        "radius": 1.0,
    }

    # Texto situado en (500, 500) -> distancia ~707 metros (FAR)
    text_ent = {
        "entity_type": "TEXT",
        "handle": "TXT_FAR",
        "layer": "TEXTOS",
        "text": "PILOTE P1",
        "insert": {"x": 500.0, "y": 500.0, "z": 0.0},
        "height": 2.5,
    }

    signals = extractor.extract_signals_for_entity(
        entity=entity,
        source_id="src_test",
        candidate_text_entities=[text_ent],
    )

    # No debe generar TEXT_NEARBY ni TEXT_VERY_NEAR ni TEXT_SAME_REGION
    text_signals = [s for s in signals if s.signal_group == EvidenceOrigin.TEXTUAL]
    assert len(text_signals) == 0


def test_short_distance_generates_text_nearby_with_exact_distance():
    """
    Test 2: Distancia corta sí genera TEXT_NEARBY / TEXT_VERY_NEAR con distancia real.
    """
    extractor = SemanticSignalExtractor()

    # Entidad círculo en (100, 100), radio 1.0 -> bbox [99, 99, 101, 101]
    entity = {
        "entity_type": "CIRCLE",
        "handle": "C_PILA",
        "layer": "SUBESTRUCTURA_PILOTES",
        "center": {"x": 100.0, "y": 100.0, "z": 0.0},
        "radius": 1.0,
    }

    # Texto en (105, 100) -> distancia real ~4 metros (VERY_NEAR <= 15m)
    text_ent = {
        "entity_type": "TEXT",
        "handle": "TXT_CLOSE",
        "layer": "TEXTOS",
        "text": "PILA P3",
        "insert": {"x": 105.0, "y": 100.0, "z": 0.0},
        "height": 2.5,
    }

    signals = extractor.extract_signals_for_entity(
        entity=entity,
        source_id="src_test",
        candidate_text_entities=[text_ent],
    )

    text_signals = [s for s in signals if s.signal_group == EvidenceOrigin.TEXTUAL]
    assert len(text_signals) == 1
    s = text_signals[0]
    assert s.signal_type == "TEXT_VERY_NEAR"
    assert s.proximity_level == ProximityLevel.VERY_NEAR
    assert s.real_distance is not None
    assert 3.5 <= s.real_distance <= 4.5
    assert s.distance_method == "EUCLIDEAN_BBOX_MIN_DISTANCE"


def test_layer_and_family_hint_do_not_double_count():
    """
    Test 3: layer + family hint no cuentan como dos fuentes independientes.
    """
    signals = [
        SemanticSignal(
            signal_type="LAYER_NAME",
            value="SUBESTRUCTURA_PILOTES",
            source_id="src_1",
            confidence=0.30,
            weight=0.20,
            signal_group=EvidenceOrigin.CAD_LAYER,
        ),
        SemanticSignal(
            signal_type="LAYER_FAMILY_HINT",
            value="STRUCTURAL",
            source_id="src_1",
            confidence=0.50,
            weight=0.20,
            signal_group=EvidenceOrigin.CAD_LAYER,
        ),
    ]

    # Ambas señales tienen signal_group = CAD_LAYER
    raw_s, w_s, norm_f, pen, bst, final_c, scored_sigs = compute_candidate_confidence(
        signals=signals,
        ent_type="CIRCLE",
        layer="SUBESTRUCTURA_PILOTES",
    )

    # Debe tomar la mejor señal del grupo (weight=0.20, conf=0.50)
    # y norm_factor debe ser exactamente 0.20, NO 0.40
    assert norm_f == 0.20
    assert raw_s == 0.50
    # Al ser un solo grupo independiente, boost = 0.0
    assert bst == 0.0
    assert final_c == 0.50


def test_single_layer_does_not_produce_partially_resolved():
    """
    Test 4: Un solo layer no produce PARTIALLY_RESOLVED.
    """
    detector = ObjectCandidateDetector()

    # Círculo sin textos ni geometría adicional analizable más que su layer
    entity = {
        "entity_type": "CIRCLE",
        "handle": "C_LONE",
        "layer": "SUBESTRUCTURA_PILOTES",
        "center": {"x": 0.0, "y": 0.0, "z": 0.0},
        "radius": 1.0,
    }

    # Solo señales de CAD_LAYER
    signals = [
        SemanticSignal(
            signal_type="LAYER_NAME",
            value="SUBESTRUCTURA_PILOTES",
            source_id="src_1",
            confidence=0.30,
            weight=0.20,
            signal_group=EvidenceOrigin.CAD_LAYER,
        )
    ]

    (
        family,
        prob_type,
        rule_id,
        type_ev,
        status,
        raw_score,
        w_score,
        norm_factor,
        penalties,
        boosts,
        final_conf,
        scored_signals,
    ) = detector._classify_and_score(ent=entity, signals=signals)

    assert status == CandidateStatus.UNRESOLVED


def test_single_geometry_does_not_produce_partially_resolved():
    """
    Test 5: Una sola geometría no produce PARTIALLY_RESOLVED.
    """
    detector = ObjectCandidateDetector()

    entity = {
        "entity_type": "CIRCLE",
        "handle": "C_GEOM",
        "layer": "0",  # layer neutro sin hint
        "center": {"x": 0.0, "y": 0.0, "z": 0.0},
        "radius": 1.0,
    }

    signals = [
        SemanticSignal(
            signal_type="CIRCULAR_GEOMETRY",
            value={"radius": 1.0},
            source_id="src_1",
            confidence=0.40,
            weight=0.15,
            signal_group=EvidenceOrigin.GEOMETRIC,
        )
    ]

    (
        family,
        prob_type,
        rule_id,
        type_ev,
        status,
        raw_score,
        w_score,
        norm_factor,
        penalties,
        boosts,
        final_conf,
        scored_signals,
    ) = detector._classify_and_score(ent=entity, signals=signals)

    assert status == CandidateStatus.UNRESOLVED
    assert prob_type == "UNKNOWN_CIRCULAR_FEATURE"


def test_independent_signals_elevate_confidence_and_state():
    """
    Test 6: Señales independientes (CAD_LAYER + GEOMETRIC + TEXTUAL) sí elevan confianza y permiten PARTIALLY_RESOLVED.
    """
    detector = ObjectCandidateDetector()

    entity = {
        "entity_type": "CIRCLE",
        "handle": "C_FULL",
        "layer": "SUBESTRUCTURA_PILOTES",
        "center": {"x": 10.0, "y": 10.0, "z": 0.0},
        "radius": 1.2,
    }

    signals = [
        SemanticSignal(
            signal_type="LAYER_FAMILY_HINT",
            value="STRUCTURAL",
            source_id="src_1",
            confidence=0.50,
            weight=0.20,
            signal_group=EvidenceOrigin.CAD_LAYER,
        ),
        SemanticSignal(
            signal_type="CIRCULAR_GEOMETRY",
            value={"radius": 1.2},
            source_id="src_1",
            confidence=0.40,
            weight=0.15,
            signal_group=EvidenceOrigin.GEOMETRIC,
        ),
        SemanticSignal(
            signal_type="TEXT_VERY_NEAR",
            value="PILA P3",
            source_id="src_1",
            confidence=0.80,
            weight=0.30,
            signal_group=EvidenceOrigin.TEXTUAL,
            proximity_level=ProximityLevel.VERY_NEAR,
            real_distance=3.5,
        ),
    ]

    (
        family,
        prob_type,
        rule_id,
        type_ev,
        status,
        raw_score,
        w_score,
        norm_factor,
        penalties,
        boosts,
        final_conf,
        scored_signals,
    ) = detector._classify_and_score(ent=entity, signals=signals)

    # 3 grupos independientes -> boost multi-origen = 0.15
    assert status == CandidateStatus.PARTIALLY_RESOLVED
    assert boosts == 0.15
    assert final_conf > 0.70
    assert prob_type == "POSSIBLE_FOUNDATION_MEMBER"


def test_negative_evidence_reduces_confidence():
    """
    Test 7: Evidencia negativa reduce confianza y degrada a UNRESOLVED.
    """
    signals = [
        SemanticSignal(
            signal_type="LAYER_FAMILY_HINT",
            value="STRUCTURAL",
            source_id="src_1",
            confidence=0.50,
            weight=0.20,
            signal_group=EvidenceOrigin.CAD_LAYER,
        ),
        SemanticSignal(
            signal_type="CIRCULAR_GEOMETRY",
            value={"radius": 1.2},
            source_id="src_1",
            confidence=0.40,
            weight=0.15,
            signal_group=EvidenceOrigin.GEOMETRIC,
        ),
        # Señal negativa contradictoria
        SemanticSignal(
            signal_type="TEXT_CONTRADICTS_TYPE",
            value="PERFIL LONGITUDINAL TERRENO",
            source_id="src_1",
            confidence=0.80,
            weight=0.25,
            signal_group=EvidenceOrigin.NEGATIVE,
            is_negative=True,
        ),
    ]

    raw_s, w_s, norm_f, pen, bst, final_c, scored_sigs = compute_candidate_confidence(
        signals=signals,
        ent_type="CIRCLE",
        layer="SUBESTRUCTURA_PILOTES",
    )

    # Debe registrar penalización = weight * conf = 0.25 * 0.80 = 0.20
    assert pen == 0.20
    # La confianza final debe ser menor que el raw_signal_score
    assert final_c < raw_s


def test_confidence_mathematically_exact():
    """
    Test 8: Confidence final se reproduce exactamente desde sus componentes.
    """
    signals = [
        SemanticSignal(
            signal_type="SIG_A",
            value="valA",
            source_id="src_1",
            confidence=0.60,
            weight=0.20,
            signal_group=EvidenceOrigin.CAD_LAYER,
        ),
        SemanticSignal(
            signal_type="SIG_B",
            value="valB",
            source_id="src_1",
            confidence=0.80,
            weight=0.30,
            signal_group=EvidenceOrigin.TEXTUAL,
        ),
    ]

    raw_s, w_s, norm_f, pen, bst, final_c, scored_sigs = compute_candidate_confidence(
        signals=signals,
        ent_type="GENERIC",
        layer="ANY",
    )

    # w_s = 0.20*0.60 + 0.30*0.80 = 0.12 + 0.24 = 0.36
    # norm_f = 0.20 + 0.30 = 0.50
    # raw_s = 0.36 / 0.50 = 0.72
    # 2 grupos independientes -> boost = 0.08
    # final_c = 0.72 + 0.08 = 0.80
    assert raw_s == 0.72
    assert w_s == 0.36
    assert norm_f == 0.50
    assert bst == 0.08
    assert pen == 0.0
    assert final_c == 0.80
    assert round(raw_s + bst - pen, 4) == final_c


def test_probable_type_conserves_type_rule_id():
    """
    Test 9: probable_type conserva type_rule_id y type_evidence.
    """
    detector = ObjectCandidateDetector()

    entity = {
        "entity_type": "LINE",
        "handle": "L_ALIGN",
        "layer": "EJE_CALZADA",
        "start": {"x": 0.0, "y": 0.0, "z": 0.0},
        "end": {"x": 50.0, "y": 0.0, "z": 0.0},
    }

    signals = [
        SemanticSignal(
            signal_type="LAYER_FAMILY_HINT",
            value="ALIGNMENT",
            source_id="src_1",
            confidence=0.60,
            weight=0.20,
            signal_group=EvidenceOrigin.CAD_LAYER,
        ),
        SemanticSignal(
            signal_type="LINEAR_GEOMETRY",
            value="SEGMENT",
            source_id="src_1",
            confidence=0.30,
            weight=0.10,
            signal_group=EvidenceOrigin.GEOMETRIC,
        ),
    ]

    (
        family,
        prob_type,
        rule_id,
        type_ev,
        status,
        raw_score,
        w_score,
        norm_factor,
        penalties,
        boosts,
        final_conf,
        scored_signals,
    ) = detector._classify_and_score(ent=entity, signals=signals)

    assert rule_id == "RULE_LINE_ALIGNMENT_LAYER"
    assert "LAYER_ALIGNMENT" in type_ev
    assert prob_type == "POSSIBLE_ALIGNMENT_FEATURE"
    assert "Ifc" not in prob_type
