"""
Readers del Agente Modelador 3D.

Responsabilidad:
convertir fuentes documentales y técnicas en datos estructurados
sin interpretar todavía su significado geométrico final.

Los readers deben:
- preservar metadatos;
- preservar coordenadas;
- preservar unidades cuando estén disponibles;
- preservar layers, entidades, textos y referencias;
- registrar warnings;
- no inventar objetos físicos.

Formatos principales:
- DWG
- DXF
- PDF
- GIS
"""

from readers.base import BaseReader
from readers.registry import ReaderRegistry

__all__ = [
    "BaseReader",
    "ReaderRegistry",
]
