from __future__ import annotations

from pathlib import Path
from typing import Any

from core.models import SourceDocument
from readers.base import BaseReader


class GISReader(BaseReader):
    """
    Reader genérico para fuentes GIS vectoriales.

    Formatos inicialmente contemplados:

    - GeoJSON
    - GeoPackage
    - Shapefile

    Requiere GeoPandas para la lectura efectiva.

    PRINCIPIO:
    una feature GIS puede representar geometría,
    localización o inventario, pero no se debe asumir
    automáticamente que cada vértice o feature equivale
    a un objeto físico BIM.
    """

    supported_extensions = (
        ".geojson",
        ".json",
        ".gpkg",
        ".shp",
    )

    def read(
        self,
        path: str | Path,
    ) -> SourceDocument:

        source_path = self.validate_path(
            path
        )

        try:
            import geopandas as gpd

        except ImportError as exc:
            raise RuntimeError(
                "Se requiere GeoPandas para procesar "
                "fuentes GIS. Instale las dependencias "
                "opcionales del grupo 'gis'."
            ) from exc

        try:
            gdf = gpd.read_file(
                source_path
            )

        except Exception as exc:
            raise RuntimeError(
                "No fue posible leer la fuente GIS: "
                f"{source_path}"
            ) from exc

        crs = (
            str(gdf.crs)
            if gdf.crs is not None
            else None
        )

        features: list[
            dict[str, Any]
        ] = []

        warnings: list[str] = []

        for index, row in gdf.iterrows():

            geometry = row.geometry

            properties = {}

            for column in gdf.columns:

                if column == (
                    gdf.geometry.name
                ):
                    continue

                value = row[column]

                properties[
                    str(column)
                ] = self._serialize_value(
                    value
                )

            feature = {
                "index": (
                    self._serialize_value(
                        index
                    )
                ),
                "geometry_type": (
                    geometry.geom_type
                    if geometry is not None
                    else None
                ),
                "geometry": (
                    geometry.__geo_interface__
                    if geometry is not None
                    else None
                ),
                "properties": properties,
            }

            features.append(
                feature
            )

        bounds = None

        if not gdf.empty:

            try:
                minx, miny, maxx, maxy = (
                    gdf.total_bounds
                )

                bounds = {
                    "minx": float(
                        minx
                    ),
                    "miny": float(
                        miny
                    ),
                    "maxx": float(
                        maxx
                    ),
                    "maxy": float(
                        maxy
                    ),
                }

            except Exception as exc:
                warnings.append(
                    "No fue posible calcular "
                    f"el bounding box GIS: {exc}"
                )

        return SourceDocument(
            path=source_path,
            file_type="GIS",
            crs=crs,
            metadata={
                "driver_source_extension": (
                    source_path.suffix.lower()
                ),
                "feature_count": len(
                    features
                ),
                "columns": [
                    str(column)
                    for column
                    in gdf.columns
                ],
                "geometry_column": (
                    gdf.geometry.name
                ),
                "bounds": bounds,
            },
            extracted_data={
                "features": features,
            },
            warnings=warnings,
        )

    @staticmethod
    def _serialize_value(
        value: Any,
    ) -> Any:
        """
        Convierte valores de pandas/numpy a tipos
        simples cuando sea posible.
        """

        if value is None:
            return None

        if hasattr(
            value,
            "item",
        ):
            try:
                return value.item()

            except Exception:
                pass

        if isinstance(
            value,
            (
                str,
                int,
                float,
                bool,
            ),
        ):
            return value

        try:
            if value != value:
                return None

        except Exception:
            pass

        return str(
            value
        )
