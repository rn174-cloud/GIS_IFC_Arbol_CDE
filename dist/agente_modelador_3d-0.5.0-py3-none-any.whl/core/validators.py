from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Optional

from core.models import (
    EvidenceStatus,
    ReconstructedObject,
)


@dataclass
class ValidationIssue:
    """
    Hallazgo individual producido durante una validación.
    """

    severity: str
    code: str
    message: str

    object_id: Optional[str] = None
    parameter: Optional[str] = None

    metadata: dict[str, Any] = field(
        default_factory=dict
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "severity": self.severity,
            "code": self.code,
            "message": self.message,
            "object_id": self.object_id,
            "parameter": self.parameter,
            "metadata": self.metadata,
        }


@dataclass
class ValidationReport:
    """
    Resultado acumulado de una validación.

    Severidades utilizadas:

    INFO
    WARNING
    ERROR
    CRITICAL
    """

    issues: list[ValidationIssue] = field(
        default_factory=list
    )

    def add(
        self,
        severity: str,
        code: str,
        message: str,
        object_id: Optional[str] = None,
        parameter: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> None:

        self.issues.append(
            ValidationIssue(
                severity=severity.upper(),
                code=code,
                message=message,
                object_id=object_id,
                parameter=parameter,
                metadata=metadata or {},
            )
        )

    @property
    def has_errors(self) -> bool:
        return any(
            issue.severity
            in {
                "ERROR",
                "CRITICAL",
            }
            for issue in self.issues
        )

    @property
    def has_critical_errors(self) -> bool:
        return any(
            issue.severity == "CRITICAL"
            for issue in self.issues
        )

    def by_severity(
        self,
        severity: str,
    ) -> list[ValidationIssue]:

        severity = severity.upper()

        return [
            issue
            for issue in self.issues
            if issue.severity == severity
        ]

    def to_dict(self) -> dict[str, Any]:
        return {
            "valid": not self.has_errors,
            "critical": self.has_critical_errors,
            "issue_count": len(self.issues),
            "issues": [
                issue.to_dict()
                for issue in self.issues
            ],
        }


class ObjectValidator:
    """
    Valida objetos reconstruidos antes de convertirlos
    en geometría IFC.

    El objetivo principal es impedir que información
    insuficiente o inconsistente se convierta silenciosamente
    en geometría aparentemente válida.
    """

    def validate(
        self,
        reconstructed_object: ReconstructedObject,
    ) -> ValidationReport:

        report = ValidationReport()

        self._validate_identity(
            reconstructed_object,
            report,
        )

        self._validate_ifc_semantics(
            reconstructed_object,
            report,
        )

        self._validate_parameters(
            reconstructed_object,
            report,
        )

        self._validate_data_gaps(
            reconstructed_object,
            report,
        )

        self._validate_conflicts(
            reconstructed_object,
            report,
        )

        self._validate_geometry_definition(
            reconstructed_object,
            report,
        )

        return report

    def _validate_identity(
        self,
        obj: ReconstructedObject,
        report: ValidationReport,
    ) -> None:

        if not obj.object_id:
            report.add(
                severity="CRITICAL",
                code="OBJECT_ID_MISSING",
                message=(
                    "El objeto reconstruido no posee object_id."
                ),
            )

    def _validate_ifc_semantics(
        self,
        obj: ReconstructedObject,
        report: ValidationReport,
    ) -> None:

        if not obj.ifc_class:
            report.add(
                severity="WARNING",
                code="IFC_CLASS_UNRESOLVED",
                message=(
                    "Todavía no se determinó una clase IFC "
                    "para el objeto."
                ),
                object_id=obj.object_id,
            )
            return

        if not obj.ifc_class.startswith("Ifc"):
            report.add(
                severity="ERROR",
                code="IFC_CLASS_INVALID_FORMAT",
                message=(
                    f"La clase IFC {obj.ifc_class!r} "
                    "no utiliza el formato esperado."
                ),
                object_id=obj.object_id,
            )

    def _validate_parameters(
        self,
        obj: ReconstructedObject,
        report: ValidationReport,
    ) -> None:

        for name, parameter in obj.parameters.items():

            if parameter.value is None:
                severity = (
                    "ERROR"
                    if parameter.status
                    != EvidenceStatus.UNKNOWN
                    else "WARNING"
                )

                report.add(
                    severity=severity,
                    code="PARAMETER_VALUE_MISSING",
                    message=(
                        f"El parámetro {name!r} "
                        "no posee valor."
                    ),
                    object_id=obj.object_id,
                    parameter=name,
                )

            if (
                parameter.status
                == EvidenceStatus.UNKNOWN
            ):
                report.add(
                    severity="WARNING",
                    code="PARAMETER_UNKNOWN",
                    message=(
                        f"El parámetro {name!r} "
                        "está clasificado como UNKNOWN."
                    ),
                    object_id=obj.object_id,
                    parameter=name,
                )

            elif (
                parameter.status
                == EvidenceStatus.PROVISIONAL
            ):
                report.add(
                    severity="WARNING",
                    code="PARAMETER_PROVISIONAL",
                    message=(
                        f"El parámetro {name!r} "
                        "es provisional."
                    ),
                    object_id=obj.object_id,
                    parameter=name,
                )

            elif (
                parameter.status
                == EvidenceStatus.INFERRED
            ):
                report.add(
                    severity="INFO",
                    code="PARAMETER_INFERRED",
                    message=(
                        f"El parámetro {name!r} "
                        "fue inferido."
                    ),
                    object_id=obj.object_id,
                    parameter=name,
                )

            if (
                parameter.status
                == EvidenceStatus.DOCUMENTED
                and not parameter.sources
            ):
                report.add(
                    severity="WARNING",
                    code="DOCUMENTED_WITHOUT_SOURCE",
                    message=(
                        f"El parámetro {name!r} "
                        "está marcado DOCUMENTED pero "
                        "no posee una referencia de fuente."
                    ),
                    object_id=obj.object_id,
                    parameter=name,
                )

    def _validate_data_gaps(
        self,
        obj: ReconstructedObject,
        report: ValidationReport,
    ) -> None:

        for gap in obj.data_gaps:

            criticality = (
                gap.criticality or "MEDIUM"
            ).upper()

            severity = {
                "LOW": "INFO",
                "MEDIUM": "WARNING",
                "HIGH": "ERROR",
                "CRITICAL": "CRITICAL",
            }.get(
                criticality,
                "WARNING",
            )

            report.add(
                severity=severity,
                code="DATA_GAP",
                message=gap.description,
                object_id=obj.object_id,
                parameter=gap.parameter,
                metadata={
                    "criticality": criticality,
                    "expected_source": (
                        gap.expected_source
                    ),
                    "impact": gap.impact,
                },
            )

    def _validate_conflicts(
        self,
        obj: ReconstructedObject,
        report: ValidationReport,
    ) -> None:

        for conflict in obj.conflicts:
            report.add(
                severity="ERROR",
                code="DOCUMENT_CONFLICT",
                message=(
                    "Existen valores documentales "
                    f"contradictorios para "
                    f"{conflict.parameter!r}: "
                    f"{conflict.value_a!r} vs "
                    f"{conflict.value_b!r}."
                ),
                object_id=obj.object_id,
                parameter=conflict.parameter,
                metadata={
                    "source_a": (
                        conflict.source_a.to_dict()
                    ),
                    "source_b": (
                        conflict.source_b.to_dict()
                    ),
                    "impact": conflict.impact,
                    "resolution": (
                        conflict.resolution
                    ),
                },
            )

    def _validate_geometry_definition(
        self,
        obj: ReconstructedObject,
        report: ValidationReport,
    ) -> None:

        if not obj.geometry_definition:
            report.add(
                severity="INFO",
                code="GEOMETRY_NOT_DEFINED",
                message=(
                    "El objeto todavía no posee una "
                    "definición geométrica reconstruida."
                ),
                object_id=obj.object_id,
            )


class ObjectCollectionValidator:
    """
    Controles de coherencia entre múltiples objetos.
    """

    def validate(
        self,
        objects: Iterable[ReconstructedObject],
    ) -> ValidationReport:

        report = ValidationReport()

        objects_list = list(objects)

        self._validate_duplicate_ids(
            objects_list,
            report,
        )

        self._validate_duplicate_global_ids(
            objects_list,
            report,
        )

        return report

    def _validate_duplicate_ids(
        self,
        objects: list[ReconstructedObject],
        report: ValidationReport,
    ) -> None:

        seen: set[str] = set()

        for obj in objects:

            if obj.object_id in seen:
                report.add(
                    severity="CRITICAL",
                    code="DUPLICATE_OBJECT_ID",
                    message=(
                        "Se detectó un object_id "
                        f"duplicado: {obj.object_id!r}."
                    ),
                    object_id=obj.object_id,
                )

            seen.add(
                obj.object_id
            )

    def _validate_duplicate_global_ids(
        self,
        objects: list[ReconstructedObject],
        report: ValidationReport,
    ) -> None:

        seen: set[str] = set()

        for obj in objects:

            if not obj.global_id:
                continue

            if obj.global_id in seen:
                report.add(
                    severity="CRITICAL",
                    code="DUPLICATE_GLOBAL_ID",
                    message=(
                        "Se detectó un IFC GlobalId "
                        f"duplicado: {obj.global_id!r}."
                    ),
                    object_id=obj.object_id,
                )

            seen.add(
                obj.global_id
            )


class IFCValidator:
    """
    Validaciones básicas del archivo IFC generado.

    No sustituye un validador IFC formal ni IDS.
    Actúa como barrera interna antes de entregar el modelo.
    """

    def validate_model(
        self,
        model: Any,
    ) -> ValidationReport:

        report = ValidationReport()

        self._validate_schema(
            model,
            report,
        )

        self._validate_project(
            model,
            report,
        )

        self._validate_site(
            model,
            report,
        )

        self._validate_products(
            model,
            report,
        )

        self._validate_global_ids(
            model,
            report,
        )

        return report

    def validate_file(
        self,
        file_path: str | Path,
    ) -> ValidationReport:

        path = Path(
            file_path
        ).expanduser().resolve()

        report = ValidationReport()

        if not path.exists():
            report.add(
                severity="CRITICAL",
                code="IFC_FILE_NOT_FOUND",
                message=(
                    f"No existe el archivo IFC: {path}"
                ),
            )
            return report

        try:
            import ifcopenshell

            model = ifcopenshell.open(
                str(path)
            )

        except Exception as exc:
            report.add(
                severity="CRITICAL",
                code="IFC_OPEN_FAILED",
                message=(
                    "No fue posible abrir el archivo IFC."
                ),
                metadata={
                    "path": str(path),
                    "error": str(exc),
                },
            )
            return report

        internal_report = self.validate_model(
            model
        )

        report.issues.extend(
            internal_report.issues
        )

        return report

    def _validate_schema(
        self,
        model: Any,
        report: ValidationReport,
    ) -> None:

        schema = getattr(
            model,
            "schema",
            None,
        )

        if callable(schema):
            schema = schema()

        normalized = (
            str(schema).upper()
            if schema
            else ""
        )

        if not normalized.startswith("IFC4X3"):
            report.add(
                severity="CRITICAL",
                code="IFC_SCHEMA_NOT_4X3",
                message=(
                    "El modelo no utiliza IFC 4.3. "
                    f"Schema detectado: {schema!r}"
                ),
            )

    def _validate_project(
        self,
        model: Any,
        report: ValidationReport,
    ) -> None:

        projects = model.by_type(
            "IfcProject"
        )

        if len(projects) != 1:
            report.add(
                severity="CRITICAL",
                code="IFC_PROJECT_COUNT",
                message=(
                    "Se esperaba exactamente un "
                    "IfcProject y se encontraron "
                    f"{len(projects)}."
                ),
            )

    def _validate_site(
        self,
        model: Any,
        report: ValidationReport,
    ) -> None:

        sites = model.by_type(
            "IfcSite"
        )

        if not sites:
            report.add(
                severity="ERROR",
                code="IFC_SITE_MISSING",
                message=(
                    "El modelo IFC no contiene IfcSite."
                ),
            )

    def _validate_products(
        self,
        model: Any,
        report: ValidationReport,
    ) -> None:

        products = model.by_type(
            "IfcProduct"
        )

        if not products:
            report.add(
                severity="ERROR",
                code="IFC_PRODUCTS_MISSING",
                message=(
                    "El modelo IFC no contiene productos."
                ),
            )
            return

        products_without_representation = [
            product
            for product in products
            if (
                hasattr(
                    product,
                    "Representation",
                )
                and product.Representation is None
            )
        ]

        if products_without_representation:
            report.add(
                severity="INFO",
                code="IFC_PRODUCTS_WITHOUT_GEOMETRY",
                message=(
                    f"{len(products_without_representation)} "
                    "productos no poseen representación "
                    "geométrica."
                ),
                metadata={
                    "count": len(
                        products_without_representation
                    ),
                },
            )

    def _validate_global_ids(
        self,
        model: Any,
        report: ValidationReport,
    ) -> None:

        roots = model.by_type(
            "IfcRoot"
        )

        seen: set[str] = set()

        for root in roots:

            global_id = getattr(
                root,
                "GlobalId",
                None,
            )

            if not global_id:
                report.add(
                    severity="ERROR",
                    code="IFC_GLOBAL_ID_MISSING",
                    message=(
                        f"Entidad {root.is_a()} "
                        "sin GlobalId."
                    ),
                )
                continue

            if global_id in seen:
                report.add(
                    severity="CRITICAL",
                    code="IFC_GLOBAL_ID_DUPLICATE",
                    message=(
                        "GlobalId duplicado detectado: "
                        f"{global_id}"
                    ),
                )

            seen.add(
                global_id
            )


def validate_before_verified_modeling(
    obj: ReconstructedObject,
    required_parameters: Iterable[str],
) -> ValidationReport:
    """
    Control específico antes de crear geometría
    considerada VERIFICADA.

    Un parámetro requerido solo es aceptado cuando su
    evidencia es:

    DOCUMENTED
    DERIVED
    INTERPOLATED

    INFERRED, PROVISIONAL y UNKNOWN impiden declarar
    esa geometría como verificada.
    """

    report = ValidationReport()

    for name in required_parameters:

        parameter = obj.get_parameter(
            name
        )

        if parameter is None:
            report.add(
                severity="ERROR",
                code="REQUIRED_PARAMETER_MISSING",
                message=(
                    f"Falta el parámetro requerido "
                    f"{name!r}."
                ),
                object_id=obj.object_id,
                parameter=name,
            )
            continue

        if not parameter.is_usable_for_verified_geometry():
            report.add(
                severity="ERROR",
                code="REQUIRED_PARAMETER_LOW_EVIDENCE",
                message=(
                    f"El parámetro requerido {name!r} "
                    "no posee evidencia suficiente para "
                    "generar geometría verificada. "
                    f"Estado: {parameter.status.value}."
                ),
                object_id=obj.object_id,
                parameter=name,
            )

    return report
