from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class AgentConfig:
    """
    Configuración general del Agente Modelador 3D.

    Este módulo debe permanecer neutral al proyecto.
    No contiene:
    - credenciales hardcodeadas;
    - rutas locales específicas;
    - nombres de proyectos;
    - CRS obligatorios;
    - progresivas;
    - dimensiones geométricas específicas.

    Toda configuración sensible o dependiente del entorno
    debe provenir de variables de entorno o argumentos externos.
    """

    # Directorios
    output_dir: Path

    # Base de datos opcional
    db_host: Optional[str] = None
    db_port: Optional[int] = None
    db_name: Optional[str] = None
    db_user: Optional[str] = None
    db_password: Optional[str] = None

    # Conversión DWG -> DXF
    dwg_to_dxf_command: Optional[str] = None

    # Georreferenciación
    default_crs: Optional[str] = None

    # Origen local IFC opcional
    local_origin_x: Optional[float] = None
    local_origin_y: Optional[float] = None
    local_origin_z: Optional[float] = None

    # Logging
    log_level: str = "INFO"

    @classmethod
    def from_environment(cls) -> "AgentConfig":
        """
        Construye la configuración a partir de variables de entorno.

        Ninguna variable es obligatoria salvo que una capacidad concreta
        del agente la necesite.

        Ejemplo:
        - no se necesita DB_HOST para procesar un DXF local;
        - no se necesita DEFAULT_CRS para un plano sin georreferenciación;
        - DWG_TO_DXF_COMMAND solo es necesario al procesar DWG.
        """

        output_dir = Path(
            os.getenv("OUTPUT_DIR", "output")
        ).expanduser().resolve()

        return cls(
            output_dir=output_dir,

            db_host=_optional_string("DB_HOST"),
            db_port=_optional_int("DB_PORT"),
            db_name=_optional_string("DB_NAME"),
            db_user=_optional_string("DB_USER"),
            db_password=_optional_string("DB_PASSWORD"),

            dwg_to_dxf_command=_optional_string(
                "DWG_TO_DXF_COMMAND"
            ),

            default_crs=_optional_string("DEFAULT_CRS"),

            local_origin_x=_optional_float(
                "LOCAL_ORIGIN_X"
            ),
            local_origin_y=_optional_float(
                "LOCAL_ORIGIN_Y"
            ),
            local_origin_z=_optional_float(
                "LOCAL_ORIGIN_Z"
            ),

            log_level=os.getenv(
                "LOG_LEVEL",
                "INFO"
            ).strip().upper(),
        )

    @property
    def has_database_config(self) -> bool:
        """
        Indica si existe una configuración mínima de conexión a DB.

        No intenta conectarse.
        """
        return all(
            [
                self.db_host,
                self.db_name,
                self.db_user,
                self.db_password,
            ]
        )

    @property
    def has_local_origin(self) -> bool:
        """
        Retorna True únicamente cuando X, Y y Z del origen local
        fueron definidos explícitamente.
        """
        return (
            self.local_origin_x is not None
            and self.local_origin_y is not None
            and self.local_origin_z is not None
        )

    @property
    def local_origin(self) -> Optional[tuple[float, float, float]]:
        """
        Retorna el origen local IFC como tupla (X, Y, Z)
        o None si no fue definido completamente.
        """
        if not self.has_local_origin:
            return None

        return (
            float(self.local_origin_x),
            float(self.local_origin_y),
            float(self.local_origin_z),
        )


def _optional_string(name: str) -> Optional[str]:
    """
    Obtiene una variable de entorno como string opcional.
    """
    value = os.getenv(name)

    if value is None:
        return None

    value = value.strip()

    return value if value else None


def _optional_int(name: str) -> Optional[int]:
    """
    Obtiene una variable de entorno como entero opcional.
    """
    value = _optional_string(name)

    if value is None:
        return None

    try:
        return int(value)
    except ValueError as exc:
        raise ValueError(
            f"La variable de entorno {name} debe ser un entero. "
            f"Valor recibido: {value!r}"
        ) from exc


def _optional_float(name: str) -> Optional[float]:
    """
    Obtiene una variable de entorno como float opcional.
    """
    value = _optional_string(name)

    if value is None:
        return None

    try:
        return float(value)
    except ValueError as exc:
        raise ValueError(
            f"La variable de entorno {name} debe ser numérica. "
            f"Valor recibido: {value!r}"
        ) from exc
