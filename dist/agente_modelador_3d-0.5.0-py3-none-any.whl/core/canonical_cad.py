from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional


class CanonicalSpaceType(str, Enum):
    MODELSPACE = "MODELSPACE"
    PAPERSPACE = "PAPERSPACE"
    LAYOUT = "LAYOUT"
    BLOCK_DEFINITION = "BLOCK_DEFINITION"
    UNKNOWN = "UNKNOWN"


class CanonicalUnitStatus(str, Enum):
    DOCUMENTED = "DOCUMENTED"
    DERIVED = "DERIVED"
    UNKNOWN = "UNKNOWN"


class CanonicalXRefStatus(str, Enum):
    RESOLVED = "RESOLVED"
    MISSING = "MISSING"
    UNAVAILABLE = "UNAVAILABLE"
    CIRCULAR = "CIRCULAR"
    UNSUPPORTED = "UNSUPPORTED"


class CanonicalIngestionStrategy(str, Enum):
    NATIVE_DIRECT = "NATIVE_DIRECT"
    LIBREDWG_DIRECT = "LIBREDWG_DIRECT"
    LIBREDWG_DXF_FALLBACK = "LIBREDWG_DXF_FALLBACK"
    EZDXF_DIRECT = "EZDXF_DIRECT"
    EXTERNAL_CLI = "EXTERNAL_CLI"
    UNKNOWN = "UNKNOWN"


@dataclass
class CanonicalCADLayer:
    name: str
    is_visible: bool = True
    is_frozen: bool = False
    is_locked: bool = False
    color_index: Optional[int] = None
    color_rgb: Optional[tuple[int, int, int]] = None
    lineweight: Optional[float] = None
    linetype: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "is_visible": self.is_visible,
            "is_frozen": self.is_frozen,
            "is_locked": self.is_locked,
            "color_index": self.color_index,
            "color_rgb": self.color_rgb,
            "lineweight": self.lineweight,
            "linetype": self.linetype,
            "metadata": self.metadata,
        }


@dataclass
class CanonicalCADText:
    text: str
    insertion_point: tuple[float, float, float]
    height: Optional[float] = None
    rotation: Optional[float] = None
    style: Optional[str] = None
    layer: Optional[str] = None
    handle: Optional[str] = None
    is_mtext: bool = False
    attachment_point: Optional[str] = None
    bounding_box: Optional[dict[str, float]] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "text": self.text,
            "insertion_point": self.insertion_point,
            "height": self.height,
            "rotation": self.rotation,
            "style": self.style,
            "layer": self.layer,
            "handle": self.handle,
            "is_mtext": self.is_mtext,
            "attachment_point": self.attachment_point,
            "bounding_box": self.bounding_box,
        }


@dataclass
class CanonicalCADDimension:
    handle: Optional[str] = None
    layer: Optional[str] = None
    dimension_type: str = "ALIGNED"
    measurement: Optional[float] = None
    text_override: Optional[str] = None
    definition_points: list[tuple[float, float, float]] = field(default_factory=list)
    style: Optional[str] = None
    unit_context: Optional[str] = None
    associated_handles: list[str] = field(default_factory=list)
    status: str = "SUPPORTED"

    def to_dict(self) -> dict[str, Any]:
        return {
            "handle": self.handle,
            "layer": self.layer,
            "dimension_type": self.dimension_type,
            "measurement": self.measurement,
            "text_override": self.text_override,
            "definition_points": self.definition_points,
            "style": self.style,
            "unit_context": self.unit_context,
            "associated_handles": self.associated_handles,
            "status": self.status,
        }


@dataclass
class CanonicalCADBlockReference:
    insert_id: str
    block_name: str
    handle: Optional[str] = None
    layer: Optional[str] = None
    space: CanonicalSpaceType = CanonicalSpaceType.MODELSPACE
    insertion_point: tuple[float, float, float] = (0.0, 0.0, 0.0)
    scale: tuple[float, float, float] = (1.0, 1.0, 1.0)
    rotation: float = 0.0
    attributes: dict[str, str] = field(default_factory=dict)
    owner_handle: Optional[str] = None
    bounding_box: Optional[dict[str, float]] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "insert_id": self.insert_id,
            "block_name": self.block_name,
            "handle": self.handle,
            "layer": self.layer,
            "space": self.space.value,
            "insertion_point": self.insertion_point,
            "scale": self.scale,
            "rotation": self.rotation,
            "attributes": self.attributes,
            "owner_handle": self.owner_handle,
            "bounding_box": self.bounding_box,
        }


@dataclass
class CanonicalCADBlock:
    name: str
    handle: Optional[str] = None
    base_point: tuple[float, float, float] = (0.0, 0.0, 0.0)
    description: Optional[str] = None
    entities: list["CanonicalCADEntity"] = field(default_factory=list)
    is_anonymous: bool = False
    is_xref: bool = False
    xref_path: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "handle": self.handle,
            "base_point": self.base_point,
            "description": self.description,
            "entity_count": len(self.entities),
            "is_anonymous": self.is_anonymous,
            "is_xref": self.is_xref,
            "xref_path": self.xref_path,
        }


@dataclass
class CanonicalCADViewport:
    handle: Optional[str] = None
    layout_name: str = ""
    center_point: tuple[float, float, float] = (0.0, 0.0, 0.0)
    width: float = 0.0
    height: float = 0.0
    scale: Optional[float] = None
    view_direction: tuple[float, float, float] = (0.0, 0.0, 1.0)
    target_point: tuple[float, float, float] = (0.0, 0.0, 0.0)
    status: str = "ACTIVE"

    def to_dict(self) -> dict[str, Any]:
        return {
            "handle": self.handle,
            "layout_name": self.layout_name,
            "center_point": self.center_point,
            "width": self.width,
            "height": self.height,
            "scale": self.scale,
            "view_direction": self.view_direction,
            "target_point": self.target_point,
            "status": self.status,
        }


@dataclass
class CanonicalCADLayout:
    name: str
    handle: Optional[str] = None
    is_modelspace: bool = False
    viewports: list[CanonicalCADViewport] = field(default_factory=list)
    entities: list["CanonicalCADEntity"] = field(default_factory=list)
    extents_min: Optional[tuple[float, float, float]] = None
    extents_max: Optional[tuple[float, float, float]] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "handle": self.handle,
            "is_modelspace": self.is_modelspace,
            "viewport_count": len(self.viewports),
            "entity_count": len(self.entities),
            "extents_min": self.extents_min,
            "extents_max": self.extents_max,
        }


@dataclass
class CanonicalCADXRef:
    block_name: str
    original_path: str
    resolved_path: Optional[str] = None
    status: CanonicalXRefStatus = CanonicalXRefStatus.UNAVAILABLE
    handle: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "block_name": self.block_name,
            "original_path": self.original_path,
            "resolved_path": self.resolved_path,
            "status": self.status.value,
            "handle": self.handle,
        }


@dataclass
class CanonicalCADEntity:
    """
    Entidad CAD canónica neutral del agente.
    """
    entity_id: str
    handle: Optional[str]
    entity_type: str
    layer: Optional[str]
    geometry: dict[str, Any]
    space: CanonicalSpaceType = CanonicalSpaceType.MODELSPACE
    attributes: dict[str, Any] = field(default_factory=dict)
    bbox: Optional[dict[str, float]] = None
    transform: Optional[dict[str, Any]] = None
    owner: Optional[str] = None
    source_reference: Optional[dict[str, Any]] = None
    raw_type: Optional[str] = None
    unsupported_properties: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "entity_id": self.entity_id,
            "handle": self.handle,
            "entity_type": self.entity_type,
            "layer": self.layer,
            "space": self.space.value,
            "geometry": self.geometry,
            "attributes": self.attributes,
            "bbox": self.bbox,
            "transform": self.transform,
            "owner": self.owner,
            "source_reference": self.source_reference,
            "raw_type": self.raw_type,
            "unsupported_properties": self.unsupported_properties,
        }


@dataclass
class CanonicalCADDocument:
    """
    Documento CAD Canónico — Contrato Neutral del Agente Modelador 3D.

    Ningún detalle interno de LibreDWG, ezdxf, ODA o Autodesk se propaga
    hacia la reconstrucción semántica ni el kernel paramétrico.
    """
    source_id: str
    source_path: Path
    source_format: str  # "DWG" or "DXF"
    source_version: Optional[str] = None
    sha256: Optional[str] = None
    file_size: Optional[int] = None

    provider: str = "UNKNOWN"
    provider_version: Optional[str] = None
    ingestion_strategy: CanonicalIngestionStrategy = CanonicalIngestionStrategy.UNKNOWN

    units: Optional[str] = None
    unit_status: CanonicalUnitStatus = CanonicalUnitStatus.UNKNOWN
    crs_if_documented: Optional[str] = None

    layers: dict[str, CanonicalCADLayer] = field(default_factory=dict)
    blocks: dict[str, CanonicalCADBlock] = field(default_factory=dict)
    block_references: list[CanonicalCADBlockReference] = field(default_factory=list)
    layouts: dict[str, CanonicalCADLayout] = field(default_factory=dict)
    viewports: list[CanonicalCADViewport] = field(default_factory=list)

    entities: list[CanonicalCADEntity] = field(default_factory=list)
    texts: list[CanonicalCADText] = field(default_factory=list)
    dimensions: list[CanonicalCADDimension] = field(default_factory=list)
    xrefs: list[CanonicalCADXRef] = field(default_factory=list)

    metadata: dict[str, Any] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    unsupported_entities: list[dict[str, Any]] = field(default_factory=list)
    source_traceability: dict[str, Any] = field(default_factory=dict)

    @property
    def modelspace_entities(self) -> list[CanonicalCADEntity]:
        return [
            e for e in self.entities
            if e.space == CanonicalSpaceType.MODELSPACE
        ]

    @property
    def paperspace_entities(self) -> list[CanonicalCADEntity]:
        return [
            e for e in self.entities
            if e.space in (CanonicalSpaceType.PAPERSPACE, CanonicalSpaceType.LAYOUT)
        ]

    def to_source_document(self) -> Any:
        """
        Convierte el CanonicalCADDocument al modelo SourceDocument legacy
        utilizado por el pipeline, asegurando 100% de retrocompatibilidad.
        """
        from core.models import SourceDocument

        # Reconstruir entities livianas compatibles con el extractor de señales
        legacy_entities: list[dict[str, Any]] = []
        for e in self.entities:
            ent_dict: dict[str, Any] = {
                "entity_type": e.entity_type,
                "handle": e.handle,
                "layer": e.layer,
                "space": e.space.value,
                "entity_id": e.entity_id,
            }
            if e.bbox:
                ent_dict["bbox"] = e.bbox
            if e.geometry:
                ent_dict.update(e.geometry)
            legacy_entities.append(ent_dict)

        legacy_texts = [t.to_dict() for t in self.texts]

        return SourceDocument(
            path=self.source_path,
            file_type=self.source_format.upper(),
            source_id=self.source_id,
            sha256=self.sha256,
            file_size=self.file_size,
            units=self.units,
            crs=self.crs_if_documented,
            metadata={
                "cad_version": self.source_version,
                "provider": self.provider,
                "provider_version": self.provider_version,
                "ingestion_strategy": self.ingestion_strategy.value,
                "entity_count": len(self.entities),
                "layers": sorted(list(self.layers.keys())),
                "layer_count": len(self.layers),
                "layouts": [l.to_dict() for l in self.layouts.values()],
                "blocks": [b.to_dict() for b in self.blocks.values()],
                "unsupported_entities_count": len(self.unsupported_entities),
                "source_traceability": self.source_traceability,
                **self.metadata,
            },
            extracted_data={
                "entities": legacy_entities,
                "texts": legacy_texts,
                "dimensions": [d.to_dict() for d in self.dimensions],
                "block_references": [br.to_dict() for br in self.block_references],
            },
            warnings=list(self.warnings),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id,
            "source_path": str(self.source_path),
            "source_format": self.source_format,
            "source_version": self.source_version,
            "sha256": self.sha256,
            "file_size": self.file_size,
            "provider": self.provider,
            "provider_version": self.provider_version,
            "ingestion_strategy": self.ingestion_strategy.value,
            "units": self.units,
            "unit_status": self.unit_status.value,
            "crs_if_documented": self.crs_if_documented,
            "entity_count": len(self.entities),
            "layer_count": len(self.layers),
            "block_count": len(self.blocks),
            "layout_count": len(self.layouts),
            "text_count": len(self.texts),
            "dimension_count": len(self.dimensions),
            "unsupported_entity_count": len(self.unsupported_entities),
            "warnings_count": len(self.warnings),
        }
