"""
reconstruction/document_role_resolver.py
Capa genérica DocumentRoleResolver y aplicación de la regla TYPE != INSTANCE para v0.6.0.
Clasifica fuentes documentales por su función informativa técnica y restringe
la autorización de cardinalidad/implantación vs tipología.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Optional

from core.models import (
    DocumentRole,
    SourceDocument,
)


class DocumentRoleResolver:
    """
    Clasifica documentos por función informativa técnica e impone la separación TYPE != INSTANCE.
    """

    ROLE_PATTERNS = {
        DocumentRole.GENERAL_ARRANGEMENT: [
            r"disposicion general", r"general arrangement", r"implantacion general",
            r"conjunto general", r"plano general", r"overall layout", r"master plan"
        ],
        DocumentRole.AS_BUILT: [
            r"conforme a obra", r"as[-_ ]built", r"registro final", r"conforme_obra",
            r"relevamiento final"
        ],
        DocumentRole.PLAN: [
            r"planta", r"plan view", r"trazado en planta", r"vista en planta",
            r"alineamiento horizontal", r"horizontal alignment"
        ],
        DocumentRole.ELEVATION: [
            r"elevacion", r"elevation", r"vista lateral", r"alzado", r"longitudinal",
            r"perfil longitudinal", r"profile"
        ],
        DocumentRole.SECTION: [
            r"seccion", r"section", r"seccion transversal", r"corte transversal",
            r"cross[-_ ]section", r"corte a-a", r"corte b-b"
        ],
        DocumentRole.DETAIL: [
            r"detalle", r"detail", r"tipo", r"tipico", r"tipologia", r"armadura",
            r"anclaje", r"nodo", r"union tipica", r"detalles constructivos"
        ],
        DocumentRole.SCHEDULE: [
            r"planilla", r"schedule", r"tabla de", r"listado", r"cuadro de",
            r"bill of quantities", r"computo"
        ],
        DocumentRole.INVENTORY: [
            r"inventario", r"inventory", r"registro de activos", r"asset register",
            r"relevamiento", r"censo"
        ],
        DocumentRole.SPECIFICATION: [
            r"especificacion", r"specification", r"memoria", r"pliego", r"norma",
            r"standard", r"criterio de diseno"
        ],
        DocumentRole.SCHEMATIC: [
            r"esquema", r"schematic", r"unifilar", r"diagrama", r"diagram"
        ],
        DocumentRole.SURVEY: [
            r"topografia", r"survey", r"altimetria", r"puntos de terreno", r"dtm", r"curvas de nivel"
        ],
        DocumentRole.GIS_SOURCE: [
            r"gis", r"gpkg", r"geopackage", r"shapefile", r"shp", r"postgis", r"capa espacial"
        ],
        DocumentRole.PHOTO: [
            r"foto", r"photo", r"imagen", r"ortofoto", r"streetview", r"street_view", r"vista"
        ],
        DocumentRole.INSPECTION: [
            r"inspeccion", r"inspection", r"informe tecnico", r"falla", r"deterioro", r"reparacion"
        ],
    }

    def classify_document(self, doc: SourceDocument) -> DocumentRole:
        """
        Determina el rol informativo del documento analizando su título, metadata y nombre de archivo.
        """
        if doc.document_role and hasattr(DocumentRole, doc.document_role):
            return DocumentRole(doc.document_role)

        candidates_text = [
            doc.drawing_title or "",
            doc.drawing_number or "",
            doc.discipline or "",
            Path(doc.path).name,
            str(doc.metadata.get("title", "")),
            str(doc.metadata.get("description", "")),
            str(doc.metadata.get("type", "")),
        ]
        combined = " ".join(candidates_text).lower()

        # Priorizar roles específicos de alta función
        for role, patterns in self.ROLE_PATTERNS.items():
            if any(re.search(pat, combined) for pat in patterns):
                doc.document_role = role.value
                return role

        # Fallback según tipo de archivo
        ext = Path(doc.path).suffix.lower()
        if ext in [".gpkg", ".shp", ".geojson"]:
            doc.document_role = DocumentRole.GIS_SOURCE.value
            return DocumentRole.GIS_SOURCE
        elif ext in [".jpg", ".jpeg", ".png", ".webp"]:
            doc.document_role = DocumentRole.PHOTO.value
            return DocumentRole.PHOTO
        elif ext in [".csv", ".xlsx", ".xls"]:
            doc.document_role = DocumentRole.SCHEDULE.value
            return DocumentRole.SCHEDULE

        doc.document_role = DocumentRole.UNKNOWN.value
        return DocumentRole.UNKNOWN

    @staticmethod
    def can_authorize_cardinality(role: DocumentRole) -> bool:
        """
        Regla TYPE != INSTANCE:
        Un documento DETAIL o SPECIFICATION NO autoriza cantidad de instancias ni implantación.
        Solo documentos de conjunto, plantas, inventarios, planillas o GIS pueden autorizar cardinalidad.
        """
        allowed_roles = {
            DocumentRole.GENERAL_ARRANGEMENT,
            DocumentRole.ASSEMBLY,
            DocumentRole.PLAN,
            DocumentRole.ELEVATION,
            DocumentRole.SCHEDULE,
            DocumentRole.INVENTORY,
            DocumentRole.GIS_SOURCE,
            DocumentRole.AS_BUILT,
        }
        return role in allowed_roles

    @staticmethod
    def can_authorize_placement(role: DocumentRole) -> bool:
        """
        Regla TYPE != INSTANCE:
        La ubicación espacial, orientación y secuencia de un componente no puede surgir de un plano de detalle.
        """
        allowed_roles = {
            DocumentRole.GENERAL_ARRANGEMENT,
            DocumentRole.ASSEMBLY,
            DocumentRole.PLAN,
            DocumentRole.ELEVATION,
            DocumentRole.SCHEDULE,
            DocumentRole.INVENTORY,
            DocumentRole.GIS_SOURCE,
            DocumentRole.AS_BUILT,
            DocumentRole.SURVEY,
        }
        return role in allowed_roles

    @staticmethod
    def can_authorize_typology_geometry(role: DocumentRole) -> bool:
        """
        Indica si el documento tiene autoridad para definir dimensiones de perfil y tipología.
        """
        typology_roles = {
            DocumentRole.DETAIL,
            DocumentRole.SECTION,
            DocumentRole.ELEVATION,
            DocumentRole.ASSEMBLY,
            DocumentRole.SPECIFICATION,
            DocumentRole.SCHEDULE,
            DocumentRole.AS_BUILT,
        }
        return role in typology_roles
