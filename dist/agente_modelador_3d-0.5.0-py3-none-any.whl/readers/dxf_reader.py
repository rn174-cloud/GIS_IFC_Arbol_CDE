from __future__ import annotations

from pathlib import Path
from typing import Any

import ezdxf

from core.models import SourceDocument
from readers.base import BaseReader


class DXFReader(BaseReader):
    """
    Reader vectorial para archivos DXF.

    Extrae información geométrica y documental sin
    convertir automáticamente entidades CAD en activos físicos.

    PRINCIPIO:
    CAD ENTITY != INFRASTRUCTURE OBJECT
    """

    supported_extensions = (
        ".dxf",
    )

    def read(
        self,
        path: str | Path,
    ) -> SourceDocument:

        source_path = self.validate_path(
            path
        )

        try:
            document = ezdxf.readfile(
                str(source_path)
            )

        except Exception as exc:
            raise RuntimeError(
                f"No fue posible leer DXF: {source_path}"
            ) from exc

        source_id, sha256, file_size = self.compute_file_metadata(source_path)

        modelspace = document.modelspace()

        entities: list[dict[str, Any]] = []
        layers: set[str] = set()
        texts: list[dict[str, Any]] = []

        warnings: list[str] = []

        for entity in modelspace:
            try:
                record = self._extract_entity(
                    entity
                )

                if record is not None:
                    record["space"] = "MODELSPACE"
                    entities.append(record)

                    layer = record.get(
                        "layer"
                    )

                    if layer:
                        layers.add(
                            str(layer)
                        )

                    if record.get(
                        "entity_type"
                    ) in {
                        "TEXT",
                        "MTEXT",
                    }:
                        texts.append(
                            record
                        )

            except Exception as exc:
                warnings.append(
                    "No fue posible extraer una entidad "
                    f"{entity.dxftype()}: {exc}"
                )

        # Inventariar layouts y paperspace (extrayendo entidades para ViewSegmenter y CanonicalCADDocument)
        layouts_info: list[dict[str, Any]] = []
        try:
            for layout in document.layouts:
                is_ps = layout.is_any_paperspace
                layout_rec = {
                    "name": layout.name,
                    "is_paperspace": is_ps,
                    "entity_count": len(layout)
                }
                layouts_info.append(layout_rec)

                # Si es paperspace, extraer sus entidades para preservar separación de espacios
                if is_ps:
                    for p_entity in layout:
                        try:
                            p_record = self._extract_entity(p_entity)
                            if p_record is not None:
                                p_record["space"] = "PAPERSPACE"
                                p_record["layout_name"] = layout.name
                                entities.append(p_record)

                                p_layer = p_record.get("layer")
                                if p_layer:
                                    layers.add(str(p_layer))

                                if p_record.get("entity_type") in {"TEXT", "MTEXT"}:
                                    texts.append(p_record)
                        except Exception as exc:
                            warnings.append(
                                f"No fue posible extraer entidad paperspace {p_entity.dxftype()}: {exc}"
                            )
        except Exception as exc:
            warnings.append(f"No fue posible inventariar layouts: {exc}")

        # Inventariar definiciones de bloques
        blocks_info: list[dict[str, Any]] = []
        try:
            for block in document.blocks:
                if not block.name.startswith("*"):  # Ignorar bloques anónimos internos
                    blocks_info.append({
                        "name": block.name,
                        "description": getattr(block, "description", None),
                        "entity_count": len(block),
                        "base_point": self._point(block.base_point) if hasattr(block, "base_point") else None
                    })
        except Exception as exc:
            warnings.append(f"No fue posible inventariar bloques: {exc}")

        header_units = self._detect_units(
            document
        )

        return SourceDocument(
            path=source_path,
            file_type="DXF",
            source_id=source_id,
            sha256=sha256,
            file_size=file_size,
            units=header_units,
            metadata={
                "dxf_version": document.dxfversion,
                "entity_count": len(entities),
                "layers": sorted(layers),
                "layer_count": len(layers),
                "layouts": layouts_info,
                "blocks": blocks_info,
            },
            extracted_data={
                "entities": entities,
                "texts": texts,
            },
            warnings=warnings,
        )

    def _extract_entity(
        self,
        entity: Any,
    ) -> dict[str, Any] | None:
        """
        Extrae tipos CAD comunes.

        No intenta resolver todavía:
        - objetos reales;
        - vistas;
        - secciones;
        - relaciones constructivas;
        - semántica IFC.
        """

        entity_type = entity.dxftype()

        base = {
            "entity_type": entity_type,
            "handle": getattr(
                entity.dxf,
                "handle",
                None,
            ),
            "layer": getattr(
                entity.dxf,
                "layer",
                None,
            ),
        }

        if entity_type == "LINE":

            base["start"] = self._point(
                entity.dxf.start
            )
            base["end"] = self._point(
                entity.dxf.end
            )

            return base

        if entity_type in {
            "LWPOLYLINE",
            "POLYLINE",
        }:

            base["points"] = (
                self._polyline_points(
                    entity
                )
            )

            base["closed"] = bool(
                getattr(
                    entity,
                    "closed",
                    False,
                )
            )

            return base

        if entity_type == "CIRCLE":

            base["center"] = self._point(
                entity.dxf.center
            )

            base["radius"] = float(
                entity.dxf.radius
            )

            return base

        if entity_type == "ARC":

            base["center"] = self._point(
                entity.dxf.center
            )

            base["radius"] = float(
                entity.dxf.radius
            )

            base["start_angle"] = float(
                entity.dxf.start_angle
            )

            base["end_angle"] = float(
                entity.dxf.end_angle
            )

            return base

        if entity_type == "ELLIPSE":

            base["center"] = self._point(
                entity.dxf.center
            )

            base["major_axis"] = self._point(
                entity.dxf.major_axis
            )

            base["ratio"] = float(
                entity.dxf.ratio
            )

            base["start_param"] = float(
                entity.dxf.start_param
            )

            base["end_param"] = float(
                entity.dxf.end_param
            )

            return base

        if entity_type == "POINT":

            base["location"] = self._point(
                entity.dxf.location
            )

            return base

        if entity_type == "TEXT":

            base["text"] = str(
                entity.dxf.text
            )

            base["insert"] = self._point(
                entity.dxf.insert
            )

            base["height"] = float(
                getattr(
                    entity.dxf,
                    "height",
                    0.0,
                )
            )

            base["rotation"] = float(
                getattr(
                    entity.dxf,
                    "rotation",
                    0.0,
                )
            )

            return base

        if entity_type == "MTEXT":

            base["text"] = (
                entity.plain_text()
            )

            base["insert"] = self._point(
                entity.dxf.insert
            )

            base["char_height"] = float(
                getattr(
                    entity.dxf,
                    "char_height",
                    0.0,
                )
            )

            base["rotation"] = float(
                getattr(
                    entity.dxf,
                    "rotation",
                    0.0,
                )
            )

            return base

        if entity_type == "INSERT":

            base["name"] = str(
                entity.dxf.name
            )

            base["insert"] = self._point(
                entity.dxf.insert
            )

            base["rotation"] = float(
                getattr(
                    entity.dxf,
                    "rotation",
                    0.0,
                )
            )

            base["scale"] = {
                "x": float(
                    getattr(
                        entity.dxf,
                        "xscale",
                        1.0,
                    )
                ),
                "y": float(
                    getattr(
                        entity.dxf,
                        "yscale",
                        1.0,
                    )
                ),
                "z": float(
                    getattr(
                        entity.dxf,
                        "zscale",
                        1.0,
                    )
                ),
            }

            base["attributes"] = {
                attrib.dxf.tag: attrib.dxf.text
                for attrib in entity.attribs
            }

            return base

        if entity_type == "SPLINE":

            base["degree"] = int(
                entity.dxf.degree
            )

            base["control_points"] = [
                self._point(point)
                for point
                in entity.control_points
            ]

            return base

        if entity_type == "HATCH":

            base["solid_fill"] = bool(
                entity.dxf.solid_fill
            )

            base["pattern_name"] = getattr(
                entity.dxf,
                "pattern_name",
                None,
            )

            return base

        if entity_type == "DIMENSION":

            base["dimtype"] = int(
                getattr(
                    entity.dxf,
                    "dimtype",
                    0,
                )
            )

            base["text"] = str(
                getattr(
                    entity.dxf,
                    "text",
                    "",
                )
            )

            try:
                base[
                    "actual_measurement"
                ] = float(
                    entity.get_measurement()
                )

            except Exception:
                base[
                    "actual_measurement"
                ] = None

            return base

        #
        # Entidades no reconocidas:
        # se preserva su existencia y metadatos mínimos.
        #
        base["unsupported_geometry"] = True

        return base

    def _polyline_points(
        self,
        entity: Any,
    ) -> list[dict[str, float]]:

        if entity.dxftype() == "LWPOLYLINE":

            return [
                {
                    "x": float(point[0]),
                    "y": float(point[1]),
                    "z": float(
                        entity.dxf.elevation
                        if hasattr(
                            entity.dxf,
                            "elevation",
                        )
                        else 0.0
                    ),
                }
                for point
                in entity.get_points()
            ]

        return [
            self._point(
                vertex.dxf.location
            )
            for vertex
            in entity.vertices
        ]

    @staticmethod
    def _point(
        value: Any,
    ) -> dict[str, float]:

        return {
            "x": float(value[0]),
            "y": float(value[1]),
            "z": (
                float(value[2])
                if len(value) > 2
                else 0.0
            ),
        }

    @staticmethod
    def _detect_units(
        document: Any,
    ) -> str | None:
        """
        Lee $INSUNITS cuando está disponible.

        No inventa unidades si el DXF no las define.
        """

        try:
            code = int(
                document.header.get(
                    "$INSUNITS",
                    0,
                )
            )

        except Exception:
            return None

        units = {
            0: None,
            1: "in",
            2: "ft",
            3: "mi",
            4: "mm",
            5: "cm",
            6: "m",
            7: "km",
            8: "microin",
            9: "mil",
            10: "yd",
            11: "angstrom",
            12: "nm",
            13: "micron",
            14: "dm",
            15: "dam",
            16: "hm",
            17: "Gm",
            18: "AU",
            19: "ly",
            20: "pc",
        }

        return units.get(
            code
        )

    def read_canonical(
        self,
        path: str | Path,
    ) -> Any:
        """
        Lee el archivo DXF y produce directamente un CanonicalCADDocument neutral.
        Permite que DXF y DWG converjan exactamente al mismo contrato canónico interno.
        """
        from core.canonical_cad import (
            CanonicalCADBlock,
            CanonicalCADDocument,
            CanonicalCADEntity,
            CanonicalCADLayer,
            CanonicalCADLayout,
            CanonicalCADText,
            CanonicalIngestionStrategy,
            CanonicalSpaceType,
            CanonicalUnitStatus,
        )

        source_doc = self.read(path)
        source_path = Path(source_doc.path)

        unit_status = (
            CanonicalUnitStatus.DOCUMENTED
            if source_doc.units
            else CanonicalUnitStatus.UNKNOWN
        )

        canonical = CanonicalCADDocument(
            source_id=source_doc.source_id or f"dxf_{source_path.stem}",
            source_path=source_path,
            source_format="DXF",
            source_version=source_doc.metadata.get("dxf_version"),
            sha256=source_doc.sha256,
            file_size=source_doc.file_size,
            provider="EZDXF",
            provider_version="ezdxf",
            ingestion_strategy=CanonicalIngestionStrategy.EZDXF_DIRECT,
            units=source_doc.units,
            unit_status=unit_status,
            crs_if_documented=source_doc.crs,
            warnings=list(source_doc.warnings),
            source_traceability={
                "primary_source": str(source_path),
                "primary_sha256": source_doc.sha256,
                "strategy": CanonicalIngestionStrategy.EZDXF_DIRECT.value,
            },
        )

        # Mapear Layers
        for lyr_name in source_doc.metadata.get("layers", []):
            canonical.layers[lyr_name] = CanonicalCADLayer(name=lyr_name)

        # Mapear Bloques
        for blk in source_doc.metadata.get("blocks", []):
            b_name = blk.get("name")
            if b_name:
                canonical.blocks[b_name] = CanonicalCADBlock(
                    name=b_name,
                    description=blk.get("description"),
                )

        # Mapear Layouts
        for lay in source_doc.metadata.get("layouts", []):
            l_name = lay.get("name")
            if l_name:
                canonical.layouts[l_name] = CanonicalCADLayout(
                    name=l_name,
                    is_modelspace=(l_name.upper() == "MODEL"),
                )

        # Mapear Entidades
        for idx, raw_e in enumerate(source_doc.extracted_data.get("entities", [])):
            handle = raw_e.get("handle")
            ent_type = raw_e.get("entity_type", "UNKNOWN")
            layer = raw_e.get("layer")
            space_str = raw_e.get("space", "MODELSPACE")
            space = (
                CanonicalSpaceType.PAPERSPACE
                if space_str == "PAPERSPACE"
                else CanonicalSpaceType.MODELSPACE
            )

            c_ent = CanonicalCADEntity(
                entity_id=f"{canonical.source_id}:{handle or idx}",
                handle=handle,
                entity_type=ent_type,
                layer=layer,
                space=space,
                geometry=raw_e,
                raw_type=ent_type,
            )
            canonical.entities.append(c_ent)

        # Mapear Textos
        for t_idx, raw_t in enumerate(source_doc.extracted_data.get("texts", [])):
            pos = raw_t.get("insert", raw_t.get("position", (0.0, 0.0, 0.0)))
            if isinstance(pos, dict):
                pt = (
                    float(pos.get("x", 0.0)),
                    float(pos.get("y", 0.0)),
                    float(pos.get("z", 0.0)),
                )
            elif isinstance(pos, (list, tuple)):
                pt = (
                    (float(pos[0]), float(pos[1]), float(pos[2]))
                    if len(pos) >= 3
                    else (float(pos[0]), float(pos[1]), 0.0)
                    if len(pos) == 2
                    else (0.0, 0.0, 0.0)
                )
            else:
                pt = (0.0, 0.0, 0.0)
            c_txt = CanonicalCADText(
                text=raw_t.get("text", ""),
                insertion_point=pt,
                height=raw_t.get("height", raw_t.get("char_height")),
                layer=raw_t.get("layer"),
                handle=raw_t.get("handle"),
                is_mtext=(raw_t.get("entity_type") == "MTEXT"),
            )
            canonical.texts.append(c_txt)

        return canonical
