from __future__ import annotations

import logging
import os
import shlex
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Optional

from core.config import AgentConfig
from core.models import SourceDocument
from readers.base import BaseReader
from readers.dxf_reader import DXFReader
from readers.dwg.registry import get_dwg_registry

LOGGER = logging.getLogger("agente_modelador_3d.readers.dwg")


class DWGReader(BaseReader):
    """
    Reader modular para archivos DWG.

    ARQUITECTURA v0.5:
    Delega la lectura al subsistema modular de proveedores DWG (readers/dwg/):
    - Proveedor primario: LibreDWG (lectura directa estructurada JSON o fallback dwg2dxf).
    - Proveedores futuros: ODA File Converter, Autodesk Core Console, etc.
    - Modo Legacy: Si DWG_TO_DXF_COMMAND está configurado en AgentConfig, permite
      mantener compatibilidad directa con comandos personalizados externos.

    Retorna un SourceDocument respetando rigurosamente:
    1. La fuente primaria inmutable es SIEMPRE el archivo .dwg original (hash SHA-256 original).
    2. Todo archivo intermedio DXF o JSON es DERIVED_INTERMEDIATE y se limpia.
    3. Ningún detalle de implementación de LibreDWG se propaga al pipeline.
    """

    supported_extensions = (
        ".dwg",
    )

    def __init__(
        self,
        config: AgentConfig | None = None,
    ) -> None:
        self.config = (
            config
            or AgentConfig.from_environment()
        )
        self.dwg_registry = get_dwg_registry()

    def read_canonical(
        self,
        path: str | Path,
    ) -> Any:
        """
        Lee el DWG y retorna la representación canónica neutral CanonicalCADDocument.
        """
        source_path = self.validate_path(path)

        # 1. Intentar proveedor activo del DWGProviderRegistry
        active_provider = self.dwg_registry.get_active_provider()
        if active_provider and active_provider.is_available():
            LOGGER.info("Usando proveedor DWG: %s", active_provider.display_name)
            return active_provider.read(source_path)

        # 2. Si hay un comando DWG_TO_DXF_COMMAND legado, usar fallback
        legacy_cmd = self.config.dwg_to_dxf_command
        if legacy_cmd:
            LOGGER.info("Usando comando legado DWG_TO_DXF_COMMAND para conversión a DXF.")
            legacy_doc = self.read(source_path)
            # Reconvertir SourceDocument legado a CanonicalCADDocument
            from core.canonical_cad import (
                CanonicalCADDocument,
                CanonicalCADEntity,
                CanonicalCADLayer,
                CanonicalCADText,
                CanonicalIngestionStrategy,
                CanonicalSpaceType,
                CanonicalUnitStatus,
            )
            canonical = CanonicalCADDocument(
                source_id=legacy_doc.source_id or f"dwg_{source_path.stem}",
                source_path=source_path,
                source_format="DWG",
                source_version=legacy_doc.metadata.get("conversion", {}).get("dwg_version"),
                sha256=legacy_doc.sha256,
                file_size=legacy_doc.file_size,
                provider="EXTERNAL_LEGACY_COMMAND",
                ingestion_strategy=CanonicalIngestionStrategy.EXTERNAL_CLI,
                units=legacy_doc.units,
                unit_status=CanonicalUnitStatus.DOCUMENTED if legacy_doc.units else CanonicalUnitStatus.UNKNOWN,
                crs_if_documented=legacy_doc.crs,
                warnings=list(legacy_doc.warnings),
                source_traceability=legacy_doc.metadata.get("conversion", {}),
            )
            for lyr in legacy_doc.metadata.get("layers", []):
                canonical.layers[lyr] = CanonicalCADLayer(name=lyr)
            for idx, raw_e in enumerate(legacy_doc.extracted_data.get("entities", [])):
                canonical.entities.append(
                    CanonicalCADEntity(
                        entity_id=f"{canonical.source_id}:{raw_e.get('handle') or idx}",
                        handle=raw_e.get("handle"),
                        entity_type=raw_e.get("entity_type", "UNKNOWN"),
                        layer=raw_e.get("layer"),
                        space=CanonicalSpaceType.MODELSPACE,
                        geometry=raw_e,
                        raw_type=raw_e.get("entity_type"),
                    )
                )
            for t_idx, raw_t in enumerate(legacy_doc.extracted_data.get("texts", [])):
                pos = raw_t.get("position", (0.0, 0.0, 0.0))
                pt = (pos[0], pos[1], pos[2]) if len(pos) >= 3 else (pos[0], pos[1], 0.0) if len(pos) == 2 else (0.0, 0.0, 0.0)
                canonical.texts.append(
                    CanonicalCADText(
                        text=raw_t.get("text", ""),
                        insertion_point=pt,
                        height=raw_t.get("height"),
                        layer=raw_t.get("layer"),
                        handle=raw_t.get("handle"),
                    )
                )
            return canonical

        # 3. Ningún proveedor disponible
        health = active_provider.health_check() if active_provider else None
        diag_msg = f" (Diagnóstico: {health.notes})" if health else ""
        raise RuntimeError(
            f"Capacidad DWG no disponible (DWG capability = UNAVAILABLE).\n"
            f"No se encontró un proveedor DWG operativo en el sistema (ej. GNU LibreDWG dwgread/dwg2dxf){diag_msg}.\n"
            f"Instale GNU LibreDWG en su sistema o defina la variable DWG_TO_DXF_COMMAND / LIBREDWG_EXECUTABLE."
        )

    def read(
        self,
        path: str | Path,
    ) -> SourceDocument:
        """
        Lee el archivo DWG y retorna un SourceDocument estándar para el pipeline.
        """
        source_path = self.validate_path(path)

        # Priorizar DWGProviderRegistry si está disponible
        active_provider = self.dwg_registry.get_active_provider()
        if active_provider and active_provider.is_available():
            LOGGER.info("DWGReader delegando a %s", active_provider.display_name)
            canonical_doc = active_provider.read(source_path)
            return canonical_doc.to_source_document()

        # Si no hay proveedor registrado disponible, intentar DWG_TO_DXF_COMMAND legado
        command = self.config.dwg_to_dxf_command
        if not command:
            health = active_provider.health_check() if active_provider else None
            notes = f": {health.notes}" if health else ""
            raise RuntimeError(
                f"No existe un proveedor DWG operativo ni conversor DWG→DXF configurado{notes}.\n"
                f"Instale LibreDWG o defina DWG_TO_DXF_COMMAND antes de procesar {source_path.name!r}."
            )

        # Ejecución legado con comando externo
        source_id, sha256, file_size = self.compute_file_metadata(source_path)

        with tempfile.TemporaryDirectory(
            prefix="agente_modelador_dwg_"
        ) as temp_dir:
            temp_path = Path(temp_dir)
            output_dxf = temp_path / f"{source_path.stem}.dxf"

            self._convert(
                command=command,
                source_path=source_path,
                output_dxf=output_dxf,
                temp_dir=temp_path,
            )

            if not output_dxf.exists():
                candidates = list(temp_path.glob("*.dxf"))
                if len(candidates) == 1:
                    output_dxf = candidates[0]
                else:
                    raise RuntimeError(
                        "El conversor DWG finalizó pero no se encontró un DXF resultante único."
                    )

            dxf_document = DXFReader().read(output_dxf)

        # Retornar SourceDocument reasignando incondicionalmente la fuente primaria al DWG
        return SourceDocument(
            path=source_path,
            file_type="DWG",
            source_id=source_id,
            sha256=sha256,
            file_size=file_size,
            drawing_number=dxf_document.drawing_number,
            drawing_title=dxf_document.drawing_title,
            discipline=dxf_document.discipline,
            revision=dxf_document.revision,
            date=dxf_document.date,
            scale=dxf_document.scale,
            units=dxf_document.units,
            crs=dxf_document.crs,
            document_role=dxf_document.document_role,
            metadata={
                **dxf_document.metadata,
                "conversion": {
                    "source_format": "DWG",
                    "intermediate_format": "DXF",
                    "converter_command": command,
                    "primary_sha256": sha256,
                    "intermediate_sha256": dxf_document.sha256,
                },
            },
            extracted_data=dxf_document.extracted_data,
            warnings=dxf_document.warnings,
        )

    def _convert(
        self,
        command: str,
        source_path: Path,
        output_dxf: Path,
        temp_dir: Path,
    ) -> None:
        formatted_command = command
        has_input_placeholder = "{input}" in formatted_command
        has_output_placeholder = "{output}" in formatted_command
        has_output_dir_placeholder = "{output_dir}" in formatted_command

        formatted_command = (
            formatted_command
            .replace("{input}", str(source_path))
            .replace("{output}", str(output_dxf))
            .replace("{output_dir}", str(temp_dir))
        )

        args = shlex.split(formatted_command, posix=(os.name != "nt"))

        if not has_input_placeholder:
            args.append(str(source_path))
        if not has_output_placeholder and not has_output_dir_placeholder:
            args.append(str(output_dxf))

        try:
            result = subprocess.run(
                args,
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError as exc:
            raise RuntimeError("No se encontró el ejecutable configurado para convertir DWG.") from exc
        except Exception as exc:
            raise RuntimeError("Falló la ejecución del conversor DWG→DXF.") from exc

        if result.returncode != 0:
            raise RuntimeError(
                f"El conversor DWG→DXF devolvió código {result.returncode}.\n"
                f"STDOUT:\n{result.stdout}\n"
                f"STDERR:\n{result.stderr}"
            )
