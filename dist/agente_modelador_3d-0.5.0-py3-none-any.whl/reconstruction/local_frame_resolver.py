from __future__ import annotations

import math
from typing import Any
from core.geometry_kernel import (
    LocalFrame,
    Point3D,
    Vector3D,
    build_local_frame_from_direction,
)
from core.models import ReconstructedObject


class LocalFrameResolver:
    """
    Determina el sistema de referencia local (LocalFrame) ortonormal para un objeto.
    
    Responsabilidad:
    - Calcular origen cartesiano a partir de alignment/station/offset/elevation o coordenadas documentadas.
    - Establecer ejes ortonormales: longitudinal (eje de avance/extrusión), transverse y vertical.
    
    REGLA:
    Un punto obtenido por evaluar una estación o alineamiento NO crea un activo.
    Solo sirve para ubicar y orientar un activo ya identificado y resuelto documentalmente.
    """

    @staticmethod
    def resolve_local_frame(
        obj: ReconstructedObject,
        default_origin: Point3D | None = None,
        tangent_vector: Vector3D | None = None,
    ) -> LocalFrame:
        """
        Calcula el LocalFrame ortonormal para un ReconstructedObject.
        """
        # 1. Determinar origen
        origin = default_origin or Point3D(0.0, 0.0, 0.0)

        # Si el objeto tiene spatial_reference con station y offset
        sp = obj.spatial_reference or {}
        st = sp.get("station")
        off = sp.get("offset", 0.0) or 0.0
        elev = sp.get("elevation", 0.0) or 0.0

        if st is not None:
            # En un modelo lineal simplificado, X = station, Y = offset, Z = elevation
            # o si se proporciona default_origin se toma ese punto
            if default_origin is None:
                origin = Point3D(float(st), float(off), float(elev))

        # 2. Determinar vector longitudinal
        if tangent_vector is not None:
            longitudinal = tangent_vector.normalized()
        else:
            # Por defecto extrusión a lo largo de Z (vertical para columnas/pilotes)
            # o a lo largo de X (longitudinal para calzadas/vigas)
            fam = str(obj.family or "").upper()
            obj_type = str(obj.object_type or "").upper()

            if any(k in fam or k in obj_type for k in ["COLUMN", "PILA", "PILOTE", "ESTRUCTURAL"]):
                # Para columnas y pilotes el eje de altura es vertical Z
                longitudinal = Vector3D(0.0, 0.0, 1.0)
            else:
                # Eje vial habitual X
                longitudinal = Vector3D(1.0, 0.0, 0.0)

        # 3. Construir marco ortonormal garantizado
        return build_local_frame_from_direction(origin=origin, longitudinal=longitudinal)

    @staticmethod
    def frame_to_dict(frame: LocalFrame) -> dict[str, Any]:
        return {
            "origin": frame.origin.to_tuple(),
            "longitudinal": frame.longitudinal.to_tuple(),
            "transverse": frame.transverse.to_tuple(),
            "vertical": frame.vertical.to_tuple(),
        }
