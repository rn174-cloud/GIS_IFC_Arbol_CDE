from __future__ import annotations

from typing import Any
import ifcopenshell
from core.geometry_kernel import LocalFrame, Point3D, Vector3D


class IFCPlacementBuilder:
    """
    Construye IfcLocalPlacement y IfcAxis2Placement3D separando rigurosamente:
    A. Geometría local del elemento (0, 0, 0);
    B. IfcLocalPlacement respecto al facility/site;
    C. Georreferenciación global.
    """

    @staticmethod
    def create_axis2_placement_3d(
        model: ifcopenshell.file,
        point: tuple[float, float, float] = (0.0, 0.0, 0.0),
        axis: tuple[float, float, float] = (0.0, 0.0, 1.0),
        ref_direction: tuple[float, float, float] = (1.0, 0.0, 0.0),
    ) -> Any:
        return model.create_entity(
            "IfcAxis2Placement3D",
            Location=model.create_entity("IfcCartesianPoint", Coordinates=point),
            Axis=model.create_entity("IfcDirection", DirectionRatios=axis),
            RefDirection=model.create_entity("IfcDirection", DirectionRatios=ref_direction),
        )

    @staticmethod
    def create_local_placement(
        model: ifcopenshell.file,
        frame_dict: dict[str, Any] | None,
        relative_to: Any = None,
    ) -> Any:
        """
        Crea IfcLocalPlacement a partir del LocalFrame del elemento.
        """
        if not frame_dict:
            axis_placement = IFCPlacementBuilder.create_axis2_placement_3d(model)
        else:
            orig = tuple(float(x) for x in frame_dict.get("origin", (0.0, 0.0, 0.0)))
            long_axis = tuple(float(x) for x in frame_dict.get("longitudinal", (0.0, 0.0, 1.0)))
            trans_axis = tuple(float(x) for x in frame_dict.get("transverse", (1.0, 0.0, 0.0)))

            axis_placement = IFCPlacementBuilder.create_axis2_placement_3d(
                model=model,
                point=orig,
                axis=long_axis,
                ref_direction=trans_axis,
            )

        return model.create_entity(
            "IfcLocalPlacement",
            PlacementRelTo=relative_to,
            RelativePlacement=axis_placement,
        )
