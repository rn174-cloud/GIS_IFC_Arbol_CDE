"""
reconstruction/conflict_detector.py
Detector formal de conflictos entre fuentes documentales, visuales y de ensamblaje para v0.6.0.
REGLA ESTRICTA: Cuando dos fuentes relevantes discrepan, NO se elige silenciosamente
ni se corrige por lo que 'parece más razonable'. Se registra un conflicto explícito.
"""
from __future__ import annotations

from typing import Any, Optional

from core.models import (
    AssetConflict,
    ConflictType,
)


class ConflictDetector:
    """
    Detecta y audita discrepancias explícitas entre fuentes heterogéneas.
    """

    def detect_conflicts(
        self,
        comparisons: list[dict[str, Any]],
    ) -> list[AssetConflict]:
        """
        Evalúa pares de valores documentados o visuales y emite AssetConflict si hay discrepancia.
        comparisons es una lista de dicts con:
        {
            "subject": str,
            "source_a": str,
            "value_a": Any,
            "source_b": str,
            "value_b": Any,
            "tolerance": Optional[float],
            "conflict_type": Optional[ConflictType],
        }
        """
        conflicts: list[AssetConflict] = []

        for item in comparisons:
            sub = item.get("subject", "UNKNOWN_PARAMETER")
            src_a = item.get("source_a", "SOURCE_A")
            val_a = item.get("value_a")
            src_b = item.get("source_b", "SOURCE_B")
            val_b = item.get("value_b")
            tol = item.get("tolerance", 0.0)
            ctype = item.get("conflict_type", ConflictType.DOCUMENT_CONFLICT)
            ctype_val = ctype.value if hasattr(ctype, "value") else str(ctype)

            if val_a is None or val_b is None:
                continue

            # Comparación numérica o textual
            is_discrepant = False
            if isinstance(val_a, (int, float)) and isinstance(val_b, (int, float)):
                if abs(float(val_a) - float(val_b)) > tol:
                    is_discrepant = True
            else:
                if str(val_a).strip().lower() != str(val_b).strip().lower():
                    is_discrepant = True

            if is_discrepant:
                desc = (
                    f"Conflict on {sub}: source '{src_a}' specifies {val_a!r} "
                    f"whereas source '{src_b}' specifies {val_b!r}."
                )
                conflicts.append(
                    AssetConflict(
                        conflict_type=ctype_val,
                        subject=sub,
                        source_a=src_a,
                        value_a=val_a,
                        source_b=src_b,
                        value_b=val_b,
                        description=desc,
                        resolution_status="UNRESOLVED",
                    )
                )

        return conflicts
