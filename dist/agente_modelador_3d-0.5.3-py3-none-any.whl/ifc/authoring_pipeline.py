from __future__ import annotations

from pathlib import Path
from typing import Any, Optional
import ifcopenshell
import ifcopenshell.api.aggregate
import ifcopenshell.api.context
import ifcopenshell.api.root
import ifcopenshell.api.spatial
import ifcopenshell.api.unit

from core.models import (
    IFCMappingDecision,
    ParametricGeometry,
    QualityConfidenceLevel,
    ReconstructedObject,
)
from ifc.georeferencing_builder import IFCGeoreferencingBuilder
from ifc.geometry_translator import IFCGeometryTranslator
from ifc.guid_registry import IFCGuidRegistry
from ifc.placement_builder import IFCPlacementBuilder
from ifc.property_set_builder import IFCPropertySetBuilder
from ifc.semantic_mapper import IFCSemanticMapper
from ifc.validator import IFCValidator


IFC_SCHEMA = "IFC4X3_ADD2"


class IFCAuthoringPipeline:
    """
    Pipeline maestro de autoría IFC 4.3 (IFC4X3_ADD2).
    
    Responsabilidad:
    - Evaluar reglas de autorización IFC para cada ReconstructedObject.
    - Rechazar la creación de producto físico si no existe ParametricGeometry construida y validada.
    - Traducir geometría validada a entidades de extrusión/área nativas.
    - Asignar clases IFC específicas auditables (evitando proxies cuando hay semántica).
    - Preservar GlobalIds persistentes en object_guid_registry.json.
    - Adjuntar Pset_SourceTraceability, Pset_ReconstructedParameters y Pset_ReconstructionQuality.
    - Validar conformidad estricta mediante IFCValidator.
    """

    def __init__(
        self,
        project_name: str,
        facility_name: str = "Infrastructure Facility",
        facility_class: str = "IfcFacility",
        guid_registry_path: Path | str = "output/ifc/object_guid_registry.json",
    ) -> None:
        self.project_name = project_name
        self.facility_name = facility_name
        self.facility_class = facility_class

        self.guid_registry = IFCGuidRegistry(guid_registry_path)
        self.semantic_mapper = IFCSemanticMapper()
        self.validator = IFCValidator()

    def author_ifc_model(
        self,
        objects_with_geometry: list[tuple[ReconstructedObject, ParametricGeometry]],
        crs_info: Optional[dict[str, Any]] = None,
    ) -> tuple[ifcopenshell.file, dict[str, Any]]:
        """
        Construye el modelo IFC 4.3 autorizando únicamente los objetos con geometría válida.
        """
        # 1. Crear modelo en IFC4X3_ADD2
        model = ifcopenshell.file(schema=IFC_SCHEMA)

        # 2. Proyecto base
        project = ifcopenshell.api.root.create_entity(
            model,
            ifc_class="IfcProject",
            name=self.project_name,
        )

        # Asignar unidades en metros por defecto
        ifcopenshell.api.unit.assign_unit(
            model,
            length={"is_metric": True, "raw": "METERS"},
        )

        # Contextos de representación
        context_model = ifcopenshell.api.context.add_context(model, context_type="Model")
        context_body = ifcopenshell.api.context.add_context(
            model,
            context_type="Model",
            context_identifier="Body",
            target_view="MODEL_VIEW",
            parent=context_model,
        )

        # 3. Jerarquía espacial
        site = ifcopenshell.api.root.create_entity(
            model,
            ifc_class="IfcSite",
            name="Project Site",
        )
        ifcopenshell.api.aggregate.assign_object(
            model,
            relating_object=project,
            products=[site],
        )

        # Crear facility específica
        try:
            facility = ifcopenshell.api.root.create_entity(
                model,
                ifc_class=self.facility_class,
                name=self.facility_name,
            )
        except Exception:
            facility = ifcopenshell.api.root.create_entity(
                model,
                ifc_class="IfcFacility",
                name=self.facility_name,
            )

        ifcopenshell.api.aggregate.assign_object(
            model,
            relating_object=site,
            products=[facility],
        )

        # 4. Georreferenciación (solo si existe CRS documentado)
        IFCGeoreferencingBuilder.apply_georeferencing(
            model=model,
            context_model=context_model,
            crs_info=crs_info,
        )

        # 5. Autorización y traducción de productos
        authorized_products = []
        not_authorized = []
        mapping_decisions = []

        for obj, geom in objects_with_geometry:
            # 1. Mapeo semántico preliminar
            decision = self.semantic_mapper.resolve_mapping(obj)
            mapping_decisions.append(decision.to_dict())

            # 2. IFC AUTHORIZATION GATE
            is_authorized, reason = self._check_authorization(obj, geom, decision)
            if not is_authorized:
                not_authorized.append({
                    "object_id": obj.object_id,
                    "reason": reason,
                    "geometry_confidence": geom.geometry_confidence.value,
                    "data_gaps": [g.to_dict() for g in obj.data_gaps] + geom.data_gaps,
                })
                continue

            # GlobalId estable
            guid = self.guid_registry.get_or_create_guid(obj.object_id, obj.global_id)

            # LocalPlacement
            placement = IFCPlacementBuilder.create_local_placement(
                model=model,
                frame_dict=geom.local_frame,
            )

            # Geometría SweptSolid
            solid_geom = IFCGeometryTranslator.create_extruded_solid(model, geom)

            # Representación
            shape_rep = model.create_entity(
                "IfcShapeRepresentation",
                ContextOfItems=context_body,
                RepresentationIdentifier="Body",
                RepresentationType="SweptSolid",
                Items=[solid_geom],
            )
            product_shape = model.create_entity(
                "IfcProductDefinitionShape",
                Representations=[shape_rep],
            )

            # Instanciar producto IFC
            product_name = obj.name or f"{decision.selected_ifc_class}_{obj.object_id}"
            product = ifcopenshell.api.root.create_entity(
                model,
                ifc_class=decision.selected_ifc_class,
                name=product_name,
                predefined_type=decision.selected_predefined_type,
            )
            # Asignar GUID exacto registrado
            product.GlobalId = guid
            product.ObjectPlacement = placement
            product.Representation = product_shape

            # Asignar al contenedor espacial facility
            ifcopenshell.api.spatial.assign_container(
                model,
                relating_structure=facility,
                products=[product],
            )

            # Property sets obligatorios
            IFCPropertySetBuilder.build_traceability_pset(model, product, obj)
            IFCPropertySetBuilder.build_reconstructed_parameters_pset(model, product, obj)
            IFCPropertySetBuilder.build_quality_pset(model, product, obj, geom)

            authorized_products.append({
                "object_id": obj.object_id,
                "global_id": guid,
                "ifc_class": decision.selected_ifc_class,
                "predefined_type": decision.selected_predefined_type,
            })

        # 6. Validación de conformidad IFC
        validation_report = self.validator.validate_model(model)

        report = {
            "project_name": self.project_name,
            "schema": model.schema,
            "authorized_products_count": len(authorized_products),
            "authorized_products": authorized_products,
            "not_authorized_count": len(not_authorized),
            "not_authorized": not_authorized,
            "semantic_mappings": mapping_decisions,
            "validation": validation_report,
        }

        return model, report

    def _check_authorization(
        self,
        obj: ReconstructedObject,
        geom: ParametricGeometry,
        decision: IFCMappingDecision,
    ) -> tuple[bool, str]:
        """
        Evalúa las condiciones obligatorias de la compuerta IFC AUTHORIZATION GATE.
        """
        # 1. obj y geom deben estar completamente construidos
        if not getattr(obj, "is_built", False) or not geom.is_built:
            return False, f"IFC_NOT_AUTHORIZED: GEOMETRY_NOT_BUILT ({geom.build_failure_reason or 'UNKNOWN'})"

        # 2. Tipo y familia no pueden ser desconocidos
        type_val = getattr(obj.object_type, "value", obj.object_type)
        type_str = str(type_val or "").upper().strip()
        if not type_str or type_str == "UNKNOWN_OBJECT" or type_str.startswith("UNKNOWN_") or type_str.endswith(".UNKNOWN_OBJECT"):
            return False, "IFC_NOT_AUTHORIZED: UNKNOWN_OBJECT"

        fam_val = getattr(obj.family, "value", obj.family)
        fam_str = str(fam_val or "").upper().strip()
        if not fam_str or fam_str == "UNKNOWN" or fam_str.endswith(".UNKNOWN"):
            return False, "IFC_NOT_AUTHORIZED: UNKNOWN_FAMILY"

        # 3. Mapeo semántico soportado y sin fallback proxy
        if decision.fallback_used:
            return False, "IFC_NOT_AUTHORIZED: FALLBACK_USED"

        if not decision.selected_ifc_class or decision.selected_ifc_class in {
            "IfcBuildingElementProxy",
            "SEMANTIC_MAPPING_NOT_SUPPORTED",
            "NONE",
        }:
            return False, f"IFC_NOT_AUTHORIZED: PROHIBITED_OR_UNSUPPORTED_CLASS ({decision.selected_ifc_class})"

        if not geom.parameters:
            return False, "IFC_NOT_AUTHORIZED: GEOMETRY_DEFINITION_EMPTY"

        if geom.geometry_confidence not in {QualityConfidenceLevel.HIGH, QualityConfidenceLevel.VERIFIED}:
            return False, f"IFC_NOT_AUTHORIZED: INSUFFICIENT_GEOMETRY_CONFIDENCE ({geom.geometry_confidence.value})"

        if obj.conflicts:
            unresolved = [c for c in obj.conflicts if c.resolution != "RESOLVED"]
            if unresolved:
                return False, "CRITICAL_DOCUMENT_CONFLICT_ACTIVE"

        return True, "AUTHORIZED"
