# AGENTE MODELADOR 3D — KERNEL & DWG BACKEND VERSIONING
from __future__ import annotations

AGENT_VERSION = "0.5.1"
AGENT_NAME = "agente-modelador-3d"
IFC_SCHEMA = "IFC4X3_ADD2"
DEFAULT_DWG_BACKEND = "libredwg"
