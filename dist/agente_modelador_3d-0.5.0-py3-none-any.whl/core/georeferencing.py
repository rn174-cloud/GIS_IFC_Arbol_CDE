from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from core.geometry_kernel import Point3D


@dataclass(frozen=True)
class CoordinateReference:
    """
    Describe un sistema de referencia espacial.

    Ejemplos:
    - EPSG:5347
    - EPSG:32721
    - sistema local de proyecto
    - coordenadas topográficas
    """

    crs: Optional[str] = None
    description: Optional[str] = None

    def is_defined(self) -> bool:
        return bool(self.crs)


@dataclass(frozen=True)
class LocalOrigin:
    """
    Origen local utilizado para mantener coordenadas IFC
    numéricamente estables.

    Las coordenadas globales no se pierden.
    Se conserva la relación:

    GLOBAL = LOCAL + ORIGIN
    """

    x: float
    y: float
    z: float = 0.0

    def to_point(self) -> Point3D:
        return Point3D(
            self.x,
            self.y,
            self.z,
        )


class GeoreferencingManager:
    """
    Gestiona transformación entre:

    - coordenadas fuente;
    - coordenadas globales;
    - coordenadas locales IFC.

    El agente no debe asumir un CRS cuando la documentación
    no lo define.
    """

    def __init__(
        self,
        source_crs: Optional[str] = None,
        target_crs: Optional[str] = None,
        local_origin: Optional[LocalOrigin] = None,
    ) -> None:

        self.source_crs = source_crs
        self.target_crs = target_crs or source_crs
        self.local_origin = local_origin

        self._transformer = None

        self._initialize_transformer()

    def _initialize_transformer(self) -> None:
        """
        Inicializa pyproj únicamente cuando existe una
        transformación real entre CRS distintos.
        """

        if not self.source_crs:
            return

        if not self.target_crs:
            return

        if self.source_crs == self.target_crs:
            return

        try:
            from pyproj import Transformer
        except ImportError as exc:
            raise RuntimeError(
                "Se requiere pyproj para transformar entre "
                "sistemas de coordenadas distintos."
            ) from exc

        self._transformer = Transformer.from_crs(
            self.source_crs,
            self.target_crs,
            always_xy=True,
        )

    def transform_global(
        self,
        point: Point3D,
    ) -> Point3D:
        """
        Transforma un punto desde source_crs hacia target_crs.

        Si no existe transformación configurada,
        devuelve el mismo punto.
        """

        if self._transformer is None:
            return point

        x, y, z = self._transformer.transform(
            point.x,
            point.y,
            point.z,
        )

        return Point3D(
            float(x),
            float(y),
            float(z),
        )

    def global_to_local(
        self,
        point: Point3D,
    ) -> Point3D:
        """
        Convierte coordenadas globales a coordenadas
        locales IFC.

        Primero aplica transformación CRS si corresponde.
        Después resta el origen local.
        """

        global_point = self.transform_global(point)

        if self.local_origin is None:
            return global_point

        return Point3D(
            global_point.x - self.local_origin.x,
            global_point.y - self.local_origin.y,
            global_point.z - self.local_origin.z,
        )

    def local_to_global(
        self,
        point: Point3D,
    ) -> Point3D:
        """
        Convierte coordenadas locales IFC al sistema global
        de trabajo.

        Esta operación solo aplica el origen local.

        Si además se requiere transformar hacia otro CRS,
        debe realizarse mediante un transformador específico
        adicional.
        """

        if self.local_origin is None:
            return point

        return Point3D(
            point.x + self.local_origin.x,
            point.y + self.local_origin.y,
            point.z + self.local_origin.z,
        )

    def set_local_origin(
        self,
        origin: LocalOrigin,
    ) -> None:
        """
        Define o reemplaza el origen local.
        """

        self.local_origin = origin

    def has_local_origin(self) -> bool:
        return self.local_origin is not None

    def metadata(self) -> dict[str, object]:
        """
        Devuelve metadatos de georreferenciación
        para trazabilidad y build log.
        """

        return {
            "source_crs": self.source_crs,
            "target_crs": self.target_crs,
            "local_origin": (
                {
                    "x": self.local_origin.x,
                    "y": self.local_origin.y,
                    "z": self.local_origin.z,
                }
                if self.local_origin
                else None
            ),
        }


def choose_local_origin(
    points: list[Point3D],
    strategy: str = "FIRST_POINT",
) -> LocalOrigin:
    """
    Selecciona un origen local a partir de un conjunto
    de coordenadas globales.

    Estrategias soportadas:

    FIRST_POINT
        utiliza el primer punto disponible.

    CENTROID
        utiliza el centroide aritmético.

    MIN_CORNER
        utiliza la esquina mínima del bounding box.

    La elección del origen local NO cambia la
    georreferenciación real del activo.
    Solo mejora estabilidad numérica y manejo geométrico.
    """

    if not points:
        raise ValueError(
            "No puede seleccionarse un origen local "
            "sin puntos de referencia."
        )

    strategy = strategy.upper()

    if strategy == "FIRST_POINT":
        point = points[0]

        return LocalOrigin(
            point.x,
            point.y,
            point.z,
        )

    if strategy == "CENTROID":
        count = len(points)

        return LocalOrigin(
            sum(point.x for point in points) / count,
            sum(point.y for point in points) / count,
            sum(point.z for point in points) / count,
        )

    if strategy == "MIN_CORNER":
        return LocalOrigin(
            min(point.x for point in points),
            min(point.y for point in points),
            min(point.z for point in points),
        )

    raise ValueError(
        f"Estrategia de origen local no soportada: {strategy!r}"
    )


def detect_large_coordinates(
    points: list[Point3D],
    threshold: float = 100_000.0,
) -> bool:
    """
    Detecta si las coordenadas presentan magnitudes
    suficientemente grandes como para recomendar un
    origen local IFC.

    Esto es frecuente en sistemas proyectados
    georreferenciados.

    La función NO modifica las coordenadas.
    Solo informa una condición.
    """

    for point in points:
        if (
            abs(point.x) >= threshold
            or abs(point.y) >= threshold
            or abs(point.z) >= threshold
        ):
            return True

    return False
