from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Sequence


EPSILON = 1e-9


@dataclass(frozen=True)
class Point3D:
    """
    Punto cartesiano tridimensional.
    """

    x: float
    y: float
    z: float = 0.0

    def to_tuple(self) -> tuple[float, float, float]:
        return (
            float(self.x),
            float(self.y),
            float(self.z),
        )


@dataclass(frozen=True)
class Vector3D:
    """
    Vector cartesiano tridimensional.
    """

    x: float
    y: float
    z: float = 0.0

    def to_tuple(self) -> tuple[float, float, float]:
        return (
            float(self.x),
            float(self.y),
            float(self.z),
        )

    @property
    def magnitude(self) -> float:
        return math.sqrt(
            self.x * self.x
            + self.y * self.y
            + self.z * self.z
        )

    def normalized(self) -> "Vector3D":
        mag = self.magnitude

        if mag <= EPSILON:
            raise ValueError(
                "No se puede normalizar un vector de magnitud cero."
            )

        return Vector3D(
            self.x / mag,
            self.y / mag,
            self.z / mag,
        )

    def scale(self, factor: float) -> "Vector3D":
        return Vector3D(
            self.x * factor,
            self.y * factor,
            self.z * factor,
        )


@dataclass(frozen=True)
class LocalFrame:
    """
    Sistema de coordenadas local ortonormal.

    origin:
        origen del sistema local.

    longitudinal:
        eje principal, habitualmente tangente al alignment,
        eje del elemento o dirección de extrusión.

    transverse:
        eje transversal.

    vertical:
        eje normal restante.

    Los tres vectores deben formar una base ortonormal.
    """

    origin: Point3D
    longitudinal: Vector3D
    transverse: Vector3D
    vertical: Vector3D


def vector_between(
    start: Point3D,
    end: Point3D,
) -> Vector3D:
    """
    Vector desde start hacia end.
    """
    return Vector3D(
        end.x - start.x,
        end.y - start.y,
        end.z - start.z,
    )


def distance(
    a: Point3D,
    b: Point3D,
) -> float:
    """
    Distancia euclídea 3D.
    """
    return vector_between(a, b).magnitude


def dot(
    a: Vector3D,
    b: Vector3D,
) -> float:
    """
    Producto escalar.
    """
    return (
        a.x * b.x
        + a.y * b.y
        + a.z * b.z
    )


def cross(
    a: Vector3D,
    b: Vector3D,
) -> Vector3D:
    """
    Producto vectorial.
    """
    return Vector3D(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x,
    )


def add_vector(
    point: Point3D,
    vector: Vector3D,
) -> Point3D:
    """
    Traslada un punto mediante un vector.
    """
    return Point3D(
        point.x + vector.x,
        point.y + vector.y,
        point.z + vector.z,
    )


def subtract_vector(
    point: Point3D,
    vector: Vector3D,
) -> Point3D:
    """
    Traslada un punto en sentido contrario a un vector.
    """
    return Point3D(
        point.x - vector.x,
        point.y - vector.y,
        point.z - vector.z,
    )


def midpoint(
    a: Point3D,
    b: Point3D,
) -> Point3D:
    """
    Punto medio entre dos puntos.
    """
    return Point3D(
        (a.x + b.x) / 2.0,
        (a.y + b.y) / 2.0,
        (a.z + b.z) / 2.0,
    )


def interpolate_point(
    a: Point3D,
    b: Point3D,
    fraction: float,
) -> Point3D:
    """
    Interpolación lineal entre dos puntos.

    fraction = 0.0 -> a
    fraction = 1.0 -> b

    Se permiten valores fuera de [0, 1] para extrapolación,
    pero el llamador debe registrar esa decisión si tiene
    relevancia documental.
    """
    return Point3D(
        a.x + (b.x - a.x) * fraction,
        a.y + (b.y - a.y) * fraction,
        a.z + (b.z - a.z) * fraction,
    )


def interpolate_scalar(
    x0: float,
    y0: float,
    x1: float,
    y1: float,
    x: float,
) -> float:
    """
    Interpolación lineal escalar.

    Útil para:
    - perfiles longitudinales;
    - rasantes;
    - cotas entre puntos documentados;
    - parámetros variables.

    No debe utilizarse silenciosamente cuando la fuente
    indique una geometría no lineal.
    """
    denominator = x1 - x0

    if abs(denominator) <= EPSILON:
        raise ValueError(
            "No se puede interpolar con dos abscisas iguales."
        )

    factor = (x - x0) / denominator

    return y0 + factor * (y1 - y0)


def project_xy_direction(
    vector: Vector3D,
) -> Vector3D:
    """
    Proyecta un vector sobre el plano XY y lo normaliza.
    """
    projected = Vector3D(
        vector.x,
        vector.y,
        0.0,
    )

    return projected.normalized()


def left_normal_xy(
    longitudinal: Vector3D,
) -> Vector3D:
    """
    Genera la normal izquierda en planta para una dirección
    longitudinal dada.

    Si longitudinal = (ux, uy, 0),
    la normal izquierda es (-uy, ux, 0).
    """
    horizontal = project_xy_direction(longitudinal)

    return Vector3D(
        -horizontal.y,
        horizontal.x,
        0.0,
    )


def right_normal_xy(
    longitudinal: Vector3D,
) -> Vector3D:
    """
    Genera la normal derecha en planta.
    """
    left = left_normal_xy(longitudinal)

    return Vector3D(
        -left.x,
        -left.y,
        -left.z,
    )


def build_local_frame_from_direction(
    origin: Point3D,
    longitudinal: Vector3D,
    preferred_up: Vector3D | None = None,
) -> LocalFrame:
    """
    Construye un sistema local ortonormal a partir de una
    dirección principal.

    Esta función es genérica y puede utilizarse para:
    - alignment;
    - vigas;
    - tableros;
    - conductos;
    - elementos lineales;
    - cables;
    - extrusiones.

    preferred_up:
        vector vertical preferido.
        Por defecto utiliza Z global.

    Si la dirección longitudinal es prácticamente paralela
    al vector vertical preferido, se selecciona una referencia
    alternativa para evitar degeneración.
    """

    longitudinal_unit = longitudinal.normalized()

    up = (
        preferred_up.normalized()
        if preferred_up is not None
        else Vector3D(0.0, 0.0, 1.0)
    )

    parallel_measure = abs(
        dot(longitudinal_unit, up)
    )

    if parallel_measure > 0.999:
        up = Vector3D(1.0, 0.0, 0.0)

    transverse = cross(
        up,
        longitudinal_unit,
    ).normalized()

    vertical = cross(
        longitudinal_unit,
        transverse,
    ).normalized()

    return LocalFrame(
        origin=origin,
        longitudinal=longitudinal_unit,
        transverse=transverse,
        vertical=vertical,
    )


def build_local_frame_from_points(
    start: Point3D,
    end: Point3D,
    preferred_up: Vector3D | None = None,
) -> LocalFrame:
    """
    Construye un sistema local a partir de dos puntos.
    """
    direction = vector_between(
        start,
        end,
    )

    return build_local_frame_from_direction(
        origin=start,
        longitudinal=direction,
        preferred_up=preferred_up,
    )


def offset_point(
    origin: Point3D,
    frame: LocalFrame,
    longitudinal_offset: float = 0.0,
    transverse_offset: float = 0.0,
    vertical_offset: float = 0.0,
) -> Point3D:
    """
    Calcula un punto desplazado respecto de un sistema local.

    Muy útil para infraestructura:

    alignment position
    + station/local longitudinal
    + offset transversal
    + elevación local
    """

    p = origin

    if longitudinal_offset:
        p = add_vector(
            p,
            frame.longitudinal.scale(
                longitudinal_offset
            ),
        )

    if transverse_offset:
        p = add_vector(
            p,
            frame.transverse.scale(
                transverse_offset
            ),
        )

    if vertical_offset:
        p = add_vector(
            p,
            frame.vertical.scale(
                vertical_offset
            ),
        )

    return p


def polyline_length(
    points: Sequence[Point3D],
) -> float:
    """
    Longitud acumulada de una polilínea 3D.
    """
    if len(points) < 2:
        return 0.0

    return sum(
        distance(points[index], points[index + 1])
        for index in range(len(points) - 1)
    )


def cumulative_lengths(
    points: Sequence[Point3D],
) -> list[float]:
    """
    Devuelve las distancias acumuladas de una polilínea.

    Ejemplo:
    [P0, P1, P2]

    -> [0.0, L01, L01 + L12]
    """
    if not points:
        return []

    result = [0.0]
    total = 0.0

    for index in range(len(points) - 1):
        total += distance(
            points[index],
            points[index + 1],
        )
        result.append(total)

    return result


def point_at_distance_on_polyline(
    points: Sequence[Point3D],
    target_distance: float,
) -> Point3D:
    """
    Interpola un punto a una distancia acumulada sobre
    una polilínea.

    Esta función puede utilizarse para stationing básico
    cuando el alignment ya fue discretizado correctamente.

    IMPORTANTE:
    La discretización del alignment es una representación
    geométrica del eje. Sus puntos NO deben interpretarse
    como activos físicos.
    """

    if not points:
        raise ValueError(
            "La polilínea no contiene puntos."
        )

    if len(points) == 1:
        if abs(target_distance) <= EPSILON:
            return points[0]

        raise ValueError(
            "No puede localizarse una distancia sobre "
            "una polilínea de un solo punto."
        )

    cumulative = cumulative_lengths(points)
    total_length = cumulative[-1]

    if target_distance < -EPSILON:
        raise ValueError(
            "La distancia objetivo no puede ser negativa."
        )

    if target_distance > total_length + EPSILON:
        raise ValueError(
            "La distancia objetivo supera la longitud "
            "de la polilínea."
        )

    if target_distance <= EPSILON:
        return points[0]

    if abs(target_distance - total_length) <= EPSILON:
        return points[-1]

    for index in range(len(points) - 1):
        d0 = cumulative[index]
        d1 = cumulative[index + 1]

        if d0 <= target_distance <= d1:
            segment_length = d1 - d0

            if segment_length <= EPSILON:
                continue

            fraction = (
                target_distance - d0
            ) / segment_length

            return interpolate_point(
                points[index],
                points[index + 1],
                fraction,
            )

    raise RuntimeError(
        "No fue posible localizar el punto sobre la polilínea."
    )


def tangent_at_distance_on_polyline(
    points: Sequence[Point3D],
    target_distance: float,
) -> Vector3D:
    """
    Obtiene una tangente aproximada en una distancia dada
    sobre una polilínea.

    Para alignments IFC reales, este método puede ser
    reemplazado posteriormente por evaluación analítica
    de líneas, arcos, clotoides y segmentos de alignment.
    """

    if len(points) < 2:
        raise ValueError(
            "Se requieren al menos dos puntos."
        )

    cumulative = cumulative_lengths(points)
    total_length = cumulative[-1]

    if target_distance < -EPSILON:
        raise ValueError(
            "La distancia objetivo no puede ser negativa."
        )

    if target_distance > total_length + EPSILON:
        raise ValueError(
            "La distancia objetivo supera "
            "la longitud de la polilínea."
        )

    if target_distance >= total_length:
        return vector_between(
            points[-2],
            points[-1],
        ).normalized()

    for index in range(len(points) - 1):
        if (
            cumulative[index]
            <= target_distance
            <= cumulative[index + 1]
        ):
            segment = vector_between(
                points[index],
                points[index + 1],
            )

            if segment.magnitude > EPSILON:
                return segment.normalized()

    raise RuntimeError(
        "No fue posible calcular la tangente."
    )


def frame_at_distance_on_polyline(
    points: Sequence[Point3D],
    target_distance: float,
) -> LocalFrame:
    """
    Devuelve posición y sistema local a una distancia dada
    sobre una polilínea.
    """

    position = point_at_distance_on_polyline(
        points,
        target_distance,
    )

    tangent = tangent_at_distance_on_polyline(
        points,
        target_distance,
    )

    return build_local_frame_from_direction(
        origin=position,
        longitudinal=tangent,
    )


def is_close(
    a: float,
    b: float,
    tolerance: float = 1e-6,
) -> bool:
    """
    Comparación numérica con tolerancia absoluta.
    """
    return abs(a - b) <= tolerance


def points_are_close(
    a: Point3D,
    b: Point3D,
    tolerance: float = 1e-6,
) -> bool:
    """
    Compara dos puntos con tolerancia espacial.
    """
    return distance(a, b) <= tolerance


def ensure_closed_profile(
    points: Iterable[Point3D],
    tolerance: float = 1e-6,
) -> list[Point3D]:
    """
    Garantiza que un perfil poligonal termine en el mismo
    punto donde comenzó.

    No intenta reparar perfiles geométricamente inválidos.
    Solo agrega el primer punto al final si el perfil
    ya está definido y sus extremos son distintos.
    """

    result = list(points)

    if len(result) < 3:
        raise ValueError(
            "Un perfil cerrado requiere al menos tres puntos."
        )

    if not points_are_close(
        result[0],
        result[-1],
        tolerance=tolerance,
    ):
        result.append(result[0])

    return result
