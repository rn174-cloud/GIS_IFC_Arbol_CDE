from pathlib import Path
import pytest

from core.config import AgentConfig
from core.models import CandidateType, SourceReference, ViewEvidence
from readers.base import BaseReader
from reconstruction.parameter_extractor import ParameterExtractor
from reconstruction.view_segmenter import ViewSegmenter


def test_station_extraction_and_no_independent_measurements():
    extractor = ParameterExtractor()
    source = SourceReference(source_file="test.dxf", view="PLAN")
    
    # 1. Progresiva como estación pura
    view = ViewEvidence(
        view_id="v1",
        view_type="PLAN",
        source=source,
        texts=["PK 12+345.67 EJE PRINCIPAL"]
    )
    
    candidates = extractor.extract_measurements(view)
    
    # Debe producir EXACTAMENTE UN candidato STATION = 12345.67 m
    stations = [c for c in candidates if c.candidate_type == CandidateType.STATION]
    assert len(stations) == 1
    assert stations[0].value == 12345.67
    assert stations[0].unit == "m"
    assert stations[0].raw_text == "PK 12+345.67"
    
    # 2. NO debe producir simultáneamente 12 o 345.67 como measurements independientes
    independent_numbers = [
        c for c in candidates 
        if c.candidate_type in {CandidateType.MEASUREMENT, CandidateType.UNKNOWN_NUMERIC}
        and c.value in {12.0, 345.67}
    ]
    assert len(independent_numbers) == 0


def test_dimension_expression_extraction():
    extractor = ParameterExtractor()
    source = SourceReference(source_file="test.dxf", view="SECTION")
    
    view = ViewEvidence(
        view_id="v2",
        view_type="SECTION",
        source=source,
        texts=["ANCHO=7.30 m\nESPESOR=0.20 m"]
    )
    
    candidates = extractor.extract_measurements(view)
    measurements = [c for c in candidates if c.candidate_type == CandidateType.MEASUREMENT]
    
    assert any(c.value == 7.30 and c.unit == "m" for c in measurements)
    assert any(c.value == 0.20 and c.unit == "m" for c in measurements)


def test_spatial_clustering_two_separated_cad_regions():
    segmenter = ViewSegmenter()
    
    # Dos regiones separadas por 500 metros
    region1_boxes = [
        {"minx": 0.0, "miny": 0.0, "maxx": 10.0, "maxy": 10.0},
        {"minx": 5.0, "miny": 5.0, "maxx": 15.0, "maxy": 15.0},
    ]
    region2_boxes = [
        {"minx": 1000.0, "miny": 1000.0, "maxx": 1020.0, "maxy": 1020.0},
    ]
    
    clusters = segmenter._cluster_bboxes(region1_boxes + region2_boxes, max_gap=150.0)
    assert len(clusters) == 2


def test_source_id_deterministic_and_sha256(tmp_path):
    f1 = tmp_path / "test1.dxf"
    f1.write_text("HEADER_TEST_1", encoding="utf-8")
    
    src_id1, sha1, size1 = BaseReader.compute_file_metadata(f1)
    src_id2, sha2, size2 = BaseReader.compute_file_metadata(f1)
    
    # 6. source_id es determinista
    assert src_id1 == src_id2
    assert sha1 == sha2
    assert size1 == size2
    
    # 7. SHA-256 cambia si cambia el archivo
    f2 = tmp_path / "test2.dxf"
    f2.write_text("HEADER_TEST_2_DIFFERENT", encoding="utf-8")
    src_id_diff, sha_diff, size_diff = BaseReader.compute_file_metadata(f2)
    
    assert sha1 != sha_diff
    assert src_id1 != src_id_diff


def test_lightweight_inventory_and_evidence_separation(tmp_path):
    from reconstruction.pipeline import ReconstructionPipeline
    from readers.dxf_reader import DXFReader
    import json
    
    dxf_sample = Path("scratch/test_infrastructure_sample.dxf").resolve()
    assert dxf_sample.exists()
    
    config = AgentConfig(output_dir=tmp_path)
    pipeline = ReconstructionPipeline(config=config, project_name="Test_Lightweight")
    
    result = pipeline.run([dxf_sample])
    
    # 8. source_inventory no contiene miles de primitivas completas en extracted_data
    doc = result["documents"][0]
    assert "extracted_data" not in doc  # el doc liviano no tiene extracted_data completo
    assert "evidence_file" in doc
    
    # 9. evidence file sí conserva las primitivas
    evidence_rel_path = doc["evidence_file"]
    evidence_file = tmp_path / evidence_rel_path
    assert evidence_file.exists()
    
    with evidence_file.open("r", encoding="utf-8") as ef:
        ev_data = json.load(ef)
    
    assert "extracted_data" in ev_data
    assert len(ev_data["extracted_data"]["entities"]) == 10
