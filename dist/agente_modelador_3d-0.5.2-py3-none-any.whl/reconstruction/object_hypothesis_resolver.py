from __future__ import annotations

import hashlib
from typing import Any

from core.models import (
    CandidateStatus,
    CandidateType,
    ConfidenceLevel,
    DataGap,
    DocumentConflict,
    EvidenceMatch,
    EvidenceStatus,
    MatchDecision,
    ObjectCandidate,
    ObjectConfidenceBreakdown,
    ObjectHypothesis,
    ParameterValue,
    QualityConfidenceLevel,
    ReconstructedObject,
    SemanticFamily,
    SourceReference,
    ViewEvidence,
)


class ObjectHypothesisResolver:
    """
    Consolidador de hipótesis de objeto real a partir de EvidenceMatch y ObjectCandidates.

    Responsabilidad:
    1. Agrupar candidatos conectados por decisiones SAME_OBJECT;
    2. Mantener hipótesis abiertas en POSSIBLE_SAME_OBJECT;
    3. Bloquear fusión en DIFFERENT_OBJECT o conflictos severos;
    4. Respetar REPEATED_INSTANCE conservando objetos distintos;
    5. Consolidar parámetros auditando compatibilidad y generando DOCUMENT_CONFLICT si hay discrepancia;
    6. Generar ReconstructedObject preliminares (drafts) con geometry_definition VACÍA (sin IFC aún);
    7. Asignar object_id determinista basado en evidencia verificable.
    """

    @staticmethod
    def generate_deterministic_object_id(
        family: SemanticFamily,
        station: float | None,
        label: str | None,
        member_ids: list[str],
        offset: float | None = None,
        source_hashes: list[str] | None = None,
    ) -> str:
        """
        Genera un object_id reproducible e independiente del orden de procesamiento.
        
        Garantiza que stations distintas muy próximas (ej. PK 12+345.60 vs PK 12+346.40)
        NUNCA colisionen por redondeo destructivo. El hash determinista incorpora
        la representación canónica completa (estación con precisión decimal exacta,
        offset, miembros ordenados y fuentes).
        """
        # La parte legible abrevia para inspección humana limpia
        st_label = f"PK{int(round(station))}" if station is not None else "NOST"
        lbl_str = label.strip().replace(" ", "_").upper() if label else "UNLABELED"

        # La identidad HASH es estricta, canónica y sin pérdida de precisión:
        st_canonical = f"{station:.4f}" if station is not None else "NONE"
        off_canonical = f"{offset:.4f}" if offset is not None else "NONE"
        sorted_members = sorted(member_ids)
        sorted_sources = sorted(source_hashes) if source_hashes else []

        seed_parts = [
            family.value,
            lbl_str,
            st_canonical,
            off_canonical,
            ":".join(sorted_members),
            ":".join(sorted_sources),
        ]
        hash_seed = "::".join(seed_parts).encode("utf-8")
        h_suffix = hashlib.sha256(hash_seed).hexdigest()[:10]
        return f"obj_{family.value[:4]}_{st_label}_{h_suffix}"

    def resolve_hypotheses_and_drafts(
        self,
        candidates: list[ObjectCandidate],
        matches: list[EvidenceMatch],
        views_dict: dict[str, ViewEvidence] | None = None,
    ) -> tuple[list[ObjectHypothesis], list[ReconstructedObject]]:
        """
        Construye hipótesis de objeto y genera drafts de ReconstructedObject preliminares.
        """
        cand_map: dict[str, ObjectCandidate] = {c.candidate_id: c for c in candidates}

        # 1. Agrupamiento de candidatos según decisiones de match
        # Usamos un grafo de conjuntos disjuntos (Union-Find) para agrupar únicamente SAME_OBJECT
        parent: dict[str, str] = {c_id: c_id for c_id in cand_map}

        def find(i: str) -> str:
            if parent[i] == i:
                return i
            parent[i] = find(parent[i])
            return parent[i]

        def union(i: str, j: str) -> None:
            root_i = find(i)
            root_j = find(j)
            if root_i != root_j:
                parent[root_i] = root_j

        for m in matches:
            if m.decision == MatchDecision.SAME_OBJECT:
                union(m.candidate_a_id, m.candidate_b_id)

        # Agrupar IDs de candidatos por su raíz
        clusters: dict[str, list[str]] = {}
        for c_id in cand_map:
            root = find(c_id)
            clusters.setdefault(root, []).append(c_id)

        hypotheses: list[ObjectHypothesis] = []
        reconstructed_drafts: list[ReconstructedObject] = []

        for root, member_ids in clusters.items():
            members = [cand_map[m_id] for m_id in member_ids]

            # Encontrar matches que involucran a estos miembros
            sup_matches: list[str] = []
            contra_matches: list[str] = []
            for m in matches:
                if m.candidate_a_id in member_ids and m.candidate_b_id in member_ids:
                    if m.decision in {MatchDecision.SAME_OBJECT, MatchDecision.POSSIBLE_SAME_OBJECT}:
                        sup_matches.append(m.match_id)
                    elif m.decision == MatchDecision.DIFFERENT_OBJECT:
                        contra_matches.append(m.match_id)
                elif m.candidate_a_id in member_ids or m.candidate_b_id in member_ids:
                    if m.decision == MatchDecision.SAME_OBJECT:
                        sup_matches.append(m.match_id)

            # Familia y tipo consensuados
            families = [m.probable_family for m in members if m.probable_family != SemanticFamily.UNKNOWN]
            consensus_family = families[0] if families else SemanticFamily.UNKNOWN

            types = [m.probable_type for m in members if not m.probable_type.startswith("UNKNOWN_")]
            consensus_type = types[0] if types else "UNKNOWN_OBJECT"

            # Estación y localización promedio o consensuada
            stations = [m.station for m in members if m.station is not None]
            consensus_station = round(sum(stations) / len(stations), 2) if stations else None

            offsets = [m.offset for m in members if m.offset is not None]
            consensus_offset = round(sum(offsets) / len(offsets), 2) if offsets else None

            elevations = [m.elevation for m in members if m.elevation is not None]
            consensus_elevation = round(sum(elevations) / len(elevations), 2) if elevations else None

            # Fuentes y vistas agregadas
            all_source_ids = sorted(list(set().union(*[m.source_ids for m in members])))
            all_view_ids = sorted(list(set().union(*[m.view_ids for m in members])))

            # Confianza consolidada: promedio ponderado más boost por evidencia multi-candidato
            avg_conf = sum(m.confidence for m in members) / len(members)
            consol_conf = min(0.95, avg_conf + (0.10 if len(members) > 1 else 0.0))
            if contra_matches:
                consol_conf = max(0.10, consol_conf - 0.30)

            status = CandidateStatus.UNRESOLVED
            if len(members) >= 2 and not contra_matches and consol_conf >= 0.70:
                status = CandidateStatus.PARTIALLY_RESOLVED
            elif members[0].status == CandidateStatus.PARTIALLY_RESOLVED and not contra_matches:
                status = CandidateStatus.PARTIALLY_RESOLVED

            # Consolidar parámetros y detectar conflictos
            param_candidates = []
            for m in members:
                param_candidates.extend(m.parameter_candidates)

            is_single = (len(member_ids) == 1)
            hyp_id = f"hyp_{hashlib.sha256('::'.join(sorted(member_ids)).encode('utf-8')).hexdigest()[:10]}"

            hypothesis = ObjectHypothesis(
                hypothesis_id=hyp_id,
                member_candidate_ids=sorted(member_ids),
                probable_family=consensus_family,
                probable_type=consensus_type,
                resolution_status=status,
                confidence=round(consol_conf, 3),
                supporting_matches=sup_matches,
                contradicting_matches=contra_matches,
                parameter_candidates=param_candidates,
                spatial_reference={
                    "station": consensus_station,
                    "offset": consensus_offset,
                    "elevation": consensus_elevation,
                },
                station=consensus_station,
                offset=consensus_offset,
                elevation=consensus_elevation,
                source_ids=all_source_ids,
                view_ids=all_view_ids,
                unresolved_questions=["Confirmar parámetros geométricos 3D"] if status != CandidateStatus.RESOLVED else [],
                data_gaps=["ELEVACION_COTA"] if consensus_elevation is None else [],
                is_singleton=is_single,
                notes=f"Hipótesis consolidada a partir de {len(members)} candidatos.",
            )
            hypotheses.append(hypothesis)

            # 2. Generar ReconstructedObject preliminar si alcanza status PARTIALLY_RESOLVED o evidencia suficiente
            if status in {CandidateStatus.PARTIALLY_RESOLVED, CandidateStatus.RESOLVED}:
                draft_obj = self._build_reconstructed_draft(
                    hypothesis=hypothesis,
                    members=members,
                    views_dict=views_dict,
                )
                reconstructed_drafts.append(draft_obj)

        return hypotheses, reconstructed_drafts

    def _build_reconstructed_draft(
        self,
        hypothesis: ObjectHypothesis,
        members: list[ObjectCandidate],
        views_dict: dict[str, ViewEvidence] | None = None,
    ) -> ReconstructedObject:
        """
        Construye el draft preliminar de ReconstructedObject con parámetros consolidados y geometry_definition VACÍA.
        """
        all_labels = [lbl for m in members for lbl in m.labels]
        rep_label = all_labels[0] if all_labels else None

        # Hash de fuentes para reproducibilidad canónica
        source_hashes = [s for s in hypothesis.source_ids]

        obj_id = self.generate_deterministic_object_id(
            family=hypothesis.probable_family,
            station=hypothesis.station,
            label=rep_label,
            member_ids=hypothesis.member_candidate_ids,
            offset=hypothesis.offset,
            source_hashes=source_hashes,
        )

        draft = ReconstructedObject(
            object_id=obj_id,
            name=f"{hypothesis.probable_type}_{obj_id}",
            object_type=hypothesis.probable_type,
            family=hypothesis.probable_family.value,
            system=None,
            subsystem=None,
            ifc_class=None,            # REGLA: Ninguna clase IFC física aún
            ifc_predefined_type=None,
            geometry_definition={},    # REGLA: VACÍA por ahora
            spatial_reference=hypothesis.spatial_reference,
            source_documents=hypothesis.source_ids,
            confidence_level=ConfidenceLevel.C_PARTIALLY_INFERRED if hypothesis.confidence < 0.85 else ConfidenceLevel.B_MOSTLY_VERIFIED,
            metadata={
                "hypothesis_id": hypothesis.hypothesis_id,
                "member_candidate_ids": hypothesis.member_candidate_ids,
            },
        )

        # Consolidar parámetros y registrar conflictos documentales
        self._consolidate_parameters(draft, hypothesis.parameter_candidates)

        # Evaluar desglose explícito de confianza (Confidence Breakdown)
        # 1. geometry_confidence DEBE SER NOT_EVALUATED mientras geometry_definition esté vacía
        geom_conf = (
            QualityConfidenceLevel.VERIFIED
            if (draft.geometry_definition and draft.ifc_class)
            else QualityConfidenceLevel.NOT_EVALUATED
        )

        # 2. identity_confidence: basada en congruencia multivista y número de miembros
        if len(members) >= 2 and not hypothesis.contradicting_matches and hypothesis.confidence >= 0.80:
            ident_conf = QualityConfidenceLevel.HIGH
        elif len(members) >= 2:
            ident_conf = QualityConfidenceLevel.MEDIUM
        else:
            ident_conf = QualityConfidenceLevel.LOW

        # 3. semantic_confidence: basada en solidez del tipo y familia reconocidos
        if hypothesis.probable_family != SemanticFamily.UNKNOWN and not hypothesis.probable_type.startswith("UNKNOWN_"):
            sem_conf = QualityConfidenceLevel.HIGH if hypothesis.confidence >= 0.75 else QualityConfidenceLevel.MEDIUM
        else:
            sem_conf = QualityConfidenceLevel.LOW

        # 4. parameter_confidence: se degrada si hay conflictos, gaps o parámetros UNKNOWN
        if draft.conflicts or any(p.status == EvidenceStatus.UNKNOWN for p in draft.parameters.values()):
            param_conf = QualityConfidenceLevel.LOW
        elif draft.data_gaps or any(p.status == EvidenceStatus.PROVISIONAL for p in draft.parameters.values()):
            param_conf = QualityConfidenceLevel.MEDIUM
        elif draft.parameters and all(p.status in {EvidenceStatus.DOCUMENTED, EvidenceStatus.DERIVED} for p in draft.parameters.values()):
            param_conf = QualityConfidenceLevel.HIGH
        else:
            param_conf = QualityConfidenceLevel.MEDIUM

        draft.confidence_breakdown = ObjectConfidenceBreakdown(
            identity_confidence=ident_conf,
            semantic_confidence=sem_conf,
            parameter_confidence=param_conf,
            geometry_confidence=geom_conf,
        )

        # Asociar vistas
        if views_dict:
            for v_id in hypothesis.view_ids:
                if v_id in views_dict:
                    draft.views.append(views_dict[v_id])

        return draft

    def _consolidate_parameters(
        self,
        draft: ReconstructedObject,
        param_candidates: list[dict[str, Any]],
    ) -> None:
        """
        Aplica jerarquía documental y consolida parámetros en el ReconstructedObject.
        Detecta DOCUMENT_CONFLICT ante valores documentados divergentes fuera de tolerancia.
        """
        by_name: dict[str, list[dict[str, Any]]] = {}

        for p in param_candidates:
            raw = p.get("raw_text", "")
            # Normalizar nombre del parámetro
            p_name = "DIMENSION_GENERAL"
            if "ANCHO" in raw.upper():
                p_name = "ANCHO"
            elif "ESPESOR" in raw.upper():
                p_name = "ESPESOR"
            elif "DIAMETRO" in raw.upper() or "RADIO" in raw.upper():
                p_name = "DIAMETRO"
            elif "ALTURA" in raw.upper() or "ALTO" in raw.upper():
                p_name = "ALTURA"
            elif p.get("candidate_type") == CandidateType.STATION.value:
                p_name = "PROGRESIVA_EJE"

            by_name.setdefault(p_name, []).append(p)

        for name, p_list in by_name.items():
            if len(p_list) == 1:
                p = p_list[0]
                src = SourceReference(source_file=p.get("source", {}).get("source_file"), view=p.get("view_type"))
                param_val = ParameterValue(
                    name=name,
                    value=p.get("value"),
                    unit=p.get("unit", "m"),
                    status=EvidenceStatus.DOCUMENTED,
                    sources=[src],
                    confidence=0.85,
                    notes=f"Extraído directamente de cota/texto: {p.get('raw_text')}",
                )
                draft.add_parameter(param_val)
            else:
                # Múltiples fuentes para el mismo parámetro
                vals = [float(x.get("value")) for x in p_list if x.get("value") is not None]
                if not vals:
                    continue

                val_min, val_max = min(vals), max(vals)
                if abs(val_max - val_min) <= 0.05:  # Dentro de tolerancia compatible
                    srcs = [
                        SourceReference(source_file=x.get("source", {}).get("source_file"), view=x.get("view_type"))
                        for x in p_list
                    ]
                    param_val = ParameterValue(
                        name=name,
                        value=round(sum(vals) / len(vals), 3),
                        unit=p_list[0].get("unit", "m"),
                        status=EvidenceStatus.DOCUMENTED,
                        sources=srcs,
                        confidence=0.90,
                        notes="Fuentes múltiples compatibles consolidadas.",
                    )
                    draft.add_parameter(param_val)
                else:
                    # Conflicto documental flagrante: registrar DocumentConflict
                    src_a = SourceReference(source_file=p_list[0].get("source", {}).get("source_file"), view=p_list[0].get("view_type"))
                    src_b = SourceReference(source_file=p_list[1].get("source", {}).get("source_file"), view=p_list[1].get("view_type"))
                    conflict = DocumentConflict(
                        object_id=draft.object_id,
                        parameter=name,
                        source_a=src_a,
                        value_a=p_list[0].get("value"),
                        source_b=src_b,
                        value_b=p_list[1].get("value"),
                        impact="Discrepancia fuera de tolerancia; requiere revisión humana.",
                        resolution="UNRESOLVED",
                    )
                    draft.conflicts.append(conflict)
                    # Agregar como gap también
                    draft.data_gaps.append(
                        DataGap(
                            object_id=draft.object_id,
                            parameter=name,
                            description=f"Conflicto de valores ({p_list[0].get('value')} vs {p_list[1].get('value')})",
                            criticality="HIGH",
                        )
                    )
