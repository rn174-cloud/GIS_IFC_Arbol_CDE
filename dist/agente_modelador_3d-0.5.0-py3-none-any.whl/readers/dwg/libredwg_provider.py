from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Optional

from core.canonical_cad import (
    CanonicalCADBlock,
    CanonicalCADBlockReference,
    CanonicalCADDimension,
    CanonicalCADDocument,
    CanonicalCADEntity,
    CanonicalCADLayer,
    CanonicalCADLayout,
    CanonicalCADText,
    CanonicalCADViewport,
    CanonicalCADXRef,
    CanonicalIngestionStrategy,
    CanonicalSpaceType,
    CanonicalUnitStatus,
    CanonicalXRefStatus,
)
from readers.base import BaseReader
from readers.dwg.base import (
    CapabilityStatus,
    DWGProvider,
    ProviderCapabilities,
    ProviderHealth,
)

LOGGER = logging.getLogger("agente_modelador_3d.readers.dwg.libredwg")

LIBREDWG_SUPPORTED_VERSIONS = [
    "AC1002", "AC1003", "AC1004", "AC1006", "AC1009",  # R2.5 - R12
    "AC1012", "AC1014",                                  # R13 - R14
    "AC1015",                                            # 2000
    "AC1018",                                            # 2004
    "AC1021",                                            # 2007
    "AC1024",                                            # 2010
    "AC1027",                                            # 2013
    "AC1032",                                            # 2018
]


class LibreDWGProvider(DWGProvider):
    """
    Proveedor DWG basado en GNU LibreDWG (Strategy A: dwgread subprocess & Strategy E: dwg2dxf fallback).

    Aislamiento Arquitectónico & Licenciamiento:
    - LibreDWG ejecutado como proceso externo proporciona fuerte desacoplamiento
      técnico y de distribución respecto del proceso Python. Las implicancias
      definitivas de GPL para una distribución comercial deben someterse a
      revisión de licenciamiento.
      Estado: LICENSING_REVIEW_REQUIRED.
    - Preserva la fuente primaria original (SHA-256, tamaño, ruta inmutables).
    - Fidelidad de lectura en archivos reales:
      REAL_DWG_FIDELITY = NOT_YET_VALIDATED.
    - Cualquier archivo JSON o DXF generado se trata estrictamente como DERIVED_INTERMEDIATE
      y se almacena en un directorio temporal seguro que se limpia automáticamente.
    """

    provider_id: str = "LIBREDWG"
    display_name: str = "GNU LibreDWG External CLI Provider"

    def __init__(
        self,
        executable_path: Optional[str] = None,
        converter_path: Optional[str] = None,
        allow_dxf_fallback: bool = True,
        keep_intermediates: bool = False,
        temp_dir: Optional[Path] = None,
    ) -> None:
        self._custom_executable = executable_path or os.getenv("LIBREDWG_EXECUTABLE")
        self._custom_converter = converter_path or os.getenv("LIBREDWG_CONVERTER")
        self.allow_dxf_fallback = allow_dxf_fallback or (
            os.getenv("DWG_ALLOW_FALLBACK", "true").lower() in ("1", "true", "yes")
        )
        self.keep_intermediates = keep_intermediates or (
            os.getenv("KEEP_DWG_INTERMEDIATES", "false").lower() in ("1", "true", "yes")
        )
        self.custom_temp_dir = temp_dir or (
            Path(os.getenv("DWG_TEMP_DIR")) if os.getenv("DWG_TEMP_DIR") else None
        )

    def _resolve_dwgread(self) -> Optional[str]:
        if self._custom_executable is not None:
            if Path(self._custom_executable).exists():
                return str(Path(self._custom_executable).resolve())
            return None
        found = shutil.which("dwgread")
        if found:
            return found
        candidates = [
            Path("tools/libredwg/dwgread.exe"),
            Path("tools/libredwg/bin/dwgread.exe"),
        ]
        for cand in candidates:
            if cand.exists():
                return str(cand.resolve())
        return None

    def _resolve_dwg2dxf(self) -> Optional[str]:
        if self._custom_converter is not None:
            if Path(self._custom_converter).exists():
                return str(Path(self._custom_converter).resolve())
            return None
        found = shutil.which("dwg2dxf")
        if found:
            return found
        candidates = [
            Path("tools/libredwg/dwg2dxf.exe"),
            Path("tools/libredwg/bin/dwg2dxf.exe"),
        ]
        for cand in candidates:
            if cand.exists():
                return str(cand.resolve())
        return None

    def probe(self) -> bool:
        return self._resolve_dwgread() is not None or self._resolve_dwg2dxf() is not None

    def is_available(self) -> bool:
        return self.probe()

    def version(self) -> Optional[str]:
        exe = self._resolve_dwgread() or self._resolve_dwg2dxf()
        if not exe:
            return None
        try:
            res = subprocess.run(
                [exe, "--version"],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            output = res.stdout.strip() or res.stderr.strip()
            first_line = output.splitlines()[0] if output else ""
            return first_line or "GNU LibreDWG (unknown version)"
        except Exception:
            return None

    def supported_dwg_versions(self) -> list[str]:
        return list(LIBREDWG_SUPPORTED_VERSIONS)

    def get_capabilities(self) -> ProviderCapabilities:
        has_direct = self._resolve_dwgread() is not None
        has_converter = self._resolve_dwg2dxf() is not None

        if not has_direct and not has_converter:
            return ProviderCapabilities(
                native_dwg=CapabilityStatus.UNSUPPORTED,
                layers=CapabilityStatus.UNSUPPORTED,
                blocks=CapabilityStatus.UNSUPPORTED,
                nested_blocks=CapabilityStatus.UNSUPPORTED,
                dimensions=CapabilityStatus.UNSUPPORTED,
                layouts=CapabilityStatus.UNSUPPORTED,
                paperspace=CapabilityStatus.UNSUPPORTED,
                modelspace=CapabilityStatus.UNSUPPORTED,
                xrefs=CapabilityStatus.UNSUPPORTED,
                xdata=CapabilityStatus.UNSUPPORTED,
                dynamic_blocks=CapabilityStatus.UNSUPPORTED,
                splines=CapabilityStatus.UNSUPPORTED,
                hatches=CapabilityStatus.UNSUPPORTED,
                texts=CapabilityStatus.UNSUPPORTED,
                mtext=CapabilityStatus.UNSUPPORTED,
            )

        return ProviderCapabilities(
            native_dwg=CapabilityStatus.SUPPORTED,
            layers=CapabilityStatus.SUPPORTED,
            blocks=CapabilityStatus.SUPPORTED,
            nested_blocks=CapabilityStatus.PARTIAL,
            dimensions=CapabilityStatus.PARTIAL,
            layouts=CapabilityStatus.SUPPORTED,
            paperspace=CapabilityStatus.SUPPORTED,
            modelspace=CapabilityStatus.SUPPORTED,
            xrefs=CapabilityStatus.PARTIAL,
            xdata=CapabilityStatus.PARTIAL,
            dynamic_blocks=CapabilityStatus.UNSUPPORTED,
            splines=CapabilityStatus.SUPPORTED,
            hatches=CapabilityStatus.SUPPORTED,
            texts=CapabilityStatus.SUPPORTED,
            mtext=CapabilityStatus.SUPPORTED,
        )

    def health_check(self) -> ProviderHealth:
        dwgread_exe = self._resolve_dwgread()
        dwg2dxf_exe = self._resolve_dwg2dxf()
        ver = self.version()

        is_op = bool(dwgread_exe or dwg2dxf_exe)
        notes = (
            f"dwgread: {dwgread_exe or 'NOT_FOUND'}, dwg2dxf: {dwg2dxf_exe or 'NOT_FOUND'}"
            if is_op
            else "LibreDWG binaries (dwgread / dwg2dxf) are not available on system PATH or configured env variables."
        )

        return ProviderHealth(
            is_operational=is_op,
            provider_name=self.display_name,
            version=ver,
            executable_path=dwgread_exe,
            library_path=dwg2dxf_exe,
            notes=notes,
            diagnostics={
                "dwgread_available": dwgread_exe is not None,
                "dwg2dxf_available": dwg2dxf_exe is not None,
                "allow_dxf_fallback": self.allow_dxf_fallback,
                "keep_intermediates": self.keep_intermediates,
            },
        )

    def inspect(self, dwg_path: Path) -> dict[str, Any]:
        """Extrae la versión DWG del encabezado binario estándar de 6 bytes."""
        resolved = Path(dwg_path).expanduser().resolve()
        if not resolved.exists():
            raise FileNotFoundError(f"No existe el archivo DWG: {resolved}")

        source_id, sha256, file_size = BaseReader.compute_file_metadata(resolved)

        version_code = "UNKNOWN"
        try:
            with open(resolved, "rb") as f:
                header = f.read(6).decode("ascii", errors="ignore")
                if header.startswith("AC"):
                    version_code = header
        except Exception:
            pass

        return {
            "source_id": source_id,
            "filename": resolved.name,
            "file_size": file_size,
            "sha256": sha256,
            "dwg_version": version_code,
            "provider": self.provider_id,
        }

    def read(self, dwg_path: Path) -> CanonicalCADDocument:
        """
        Lee el DWG primario y devuelve el CanonicalCADDocument neutral.
        Prueba primero lectura directa estructurada (Strategy A: dwgread -O JSON).
        Si no está disponible o falla, intenta fallback controlado (Strategy E: dwg2dxf).
        """
        resolved = Path(dwg_path).expanduser().resolve()
        if not resolved.exists():
            raise FileNotFoundError(f"No existe el archivo DWG: {resolved}")

        source_id, sha256, file_size = BaseReader.compute_file_metadata(resolved)
        dwgread_exe = self._resolve_dwgread()
        dwg2dxf_exe = self._resolve_dwg2dxf()

        if not dwgread_exe and not dwg2dxf_exe:
            raise RuntimeError(
                f"El proveedor LibreDWG está en estado UNAVAILABLE. "
                f"No se encontraron ejecutables 'dwgread' ni 'dwg2dxf' para procesar {resolved.name}."
            )

        header_info = self.inspect(resolved)
        dwg_version = header_info.get("dwg_version")

        # STRATEGY A: Lectura directa estructurada JSON vía dwgread
        if dwgread_exe:
            try:
                LOGGER.info("Intentando ingesta directa LibreDWG estructurada JSON para: %s", resolved.name)
                canonical_doc = self._read_via_dwgread_json(
                    dwgread_exe=dwgread_exe,
                    source_path=resolved,
                    source_id=source_id,
                    sha256=sha256,
                    file_size=file_size,
                    dwg_version=dwg_version,
                )
                return canonical_doc
            except Exception as exc:
                LOGGER.warning(
                    "Falló la ingesta directa LibreDWG estructurada JSON: %s. "
                    "Evaluando fallback dwg2dxf...", exc
                )
                if not self.allow_dxf_fallback:
                    raise

        # STRATEGY E: Fallback controlado vía dwg2dxf -> Canonical Document
        if dwg2dxf_exe and self.allow_dxf_fallback:
            LOGGER.info("Ejecutando fallback controlado LIBREDWG_DXF_FALLBACK para: %s", resolved.name)
            return self._read_via_dwg2dxf_fallback(
                dwg2dxf_exe=dwg2dxf_exe,
                source_path=resolved,
                source_id=source_id,
                sha256=sha256,
                file_size=file_size,
                dwg_version=dwg_version,
            )

        raise RuntimeError(
            f"No fue posible procesar el DWG {resolved.name} mediante ninguna estrategia de LibreDWG disponible."
        )

    def _format_handle(self, h_val: Any) -> Optional[str]:
        if not h_val:
            return None
        if isinstance(h_val, list) and len(h_val) > 0:
            return hex(int(h_val[-1]))[2:].upper()
        if isinstance(h_val, int):
            return hex(h_val)[2:].upper()
        return str(h_val).upper()

    def _read_via_dwgread_json(
        self,
        dwgread_exe: str,
        source_path: Path,
        source_id: str,
        sha256: str,
        file_size: int,
        dwg_version: Optional[str],
    ) -> CanonicalCADDocument:
        """
        Ejecuta `dwgread -O JSON <dwg_path>` y parsea el JSON resultante
        mapeándolo directamente al CanonicalCADDocument neutral.
        """
        cmd = [dwgread_exe, "-O", "JSON", str(source_path)]
        try:
            res = subprocess.run(
                cmd,
                capture_output=True,
                errors="replace",
                timeout=90,
                check=False,
            )
        except Exception as exc:
            raise RuntimeError(f"Error invocando dwgread: {exc}") from exc

        if res.returncode != 0 and not res.stdout.strip():
            raise RuntimeError(f"dwgread falló con código {res.returncode}: {res.stderr.strip()}")

        raw_json_str = res.stdout.strip()
        if not raw_json_str:
            raise RuntimeError("dwgread no generó salida JSON estructurada.")

        try:
            data = json.loads(raw_json_str)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Salida de dwgread no es un JSON válido: {exc}") from exc

        objects = data.get("OBJECTS", [])
        header = data.get("HEADER", {})

        # 1. Unidades documentadas en HEADER
        insunits = header.get("INSUNITS", 0)
        insunits_map = {
            0: None, 1: "in", 2: "ft", 3: "mi", 4: "mm", 5: "cm",
            6: "m", 7: "km", 8: "microin", 9: "mil", 10: "yd",
        }
        detected_units = insunits_map.get(insunits)
        unit_status = CanonicalUnitStatus.DOCUMENTED if detected_units else CanonicalUnitStatus.UNKNOWN

        # Construir CanonicalCADDocument base
        doc = CanonicalCADDocument(
            source_id=source_id,
            source_path=source_path,
            source_format="DWG",
            source_version=dwg_version,
            sha256=sha256,
            file_size=file_size,
            provider=self.provider_id,
            provider_version=self.version(),
            ingestion_strategy=CanonicalIngestionStrategy.LIBREDWG_DIRECT,
            units=detected_units,
            unit_status=unit_status,
            source_traceability={
                "primary_source": str(source_path),
                "primary_sha256": sha256,
                "strategy": CanonicalIngestionStrategy.LIBREDWG_DIRECT.value,
                "raw_entity_count": len(objects),
            },
        )

        # 2. Mapear Capas (LAYER) y construir tabla de punteros para resolución
        # En LibreDWG JSON, punteros a layers son listas [code, size, handle_val, ...]
        layer_by_handle: dict[str, str] = {}
        layers_dict: dict[str, CanonicalCADLayer] = {}
        for obj in objects:
            if obj.get("object") == "LAYER":
                name = obj.get("name", "0")
                h_hex = self._format_handle(obj.get("handle"))
                if h_hex:
                    layer_by_handle[h_hex] = name
                layers_dict[name] = CanonicalCADLayer(
                    name=name,
                    is_frozen=bool(obj.get("frozen", False)),
                    is_locked=bool(obj.get("locked", False)),
                    color_index=obj.get("color"),
                )
        doc.layers = layers_dict

        # 3. Mapear Bloques (BLOCK_HEADER)
        block_by_handle: dict[str, str] = {}
        for obj in objects:
            if obj.get("object") == "BLOCK_HEADER":
                b_name = obj.get("name", "ANONYMOUS")
                b_hex = self._format_handle(obj.get("handle"))
                if b_hex:
                    block_by_handle[b_hex] = b_name
                if not b_name.startswith("*"):
                    doc.blocks[b_name] = CanonicalCADBlock(
                        name=b_name,
                        handle=b_hex,
                        description=obj.get("description"),
                    )

        # 4. Mapear Layouts (LAYOUT)
        for obj in objects:
            if obj.get("object") == "LAYOUT":
                l_name = obj.get("layout_name") or obj.get("name") or "LAYOUT"
                l_hex = self._format_handle(obj.get("handle"))
                doc.layouts[l_name] = CanonicalCADLayout(
                    name=l_name,
                    handle=l_hex,
                    is_modelspace=(l_name.upper() == "MODEL"),
                )

        def _resolve_layer(raw_lyr: Any) -> str:
            if isinstance(raw_lyr, str):
                return raw_lyr
            h_ref = self._format_handle(raw_lyr)
            return layer_by_handle.get(h_ref, "0")

        # 5. Parsear Entidades gráficas
        for obj in objects:
            ent_type = obj.get("entity")
            if not ent_type:
                continue

            h_hex = self._format_handle(obj.get("handle"))
            layer = _resolve_layer(obj.get("layer"))
            owner_hex = self._format_handle(obj.get("ownerhandle"))
            owner_name = block_by_handle.get(owner_hex, "")

            # Determinar espacio (MODELSPACE vs PAPERSPACE vs BLOCK_DEFINITION)
            # En LibreDWG: entmode == 1 indica paperspace; entmode == 2 indica modelspace.
            entmode = obj.get("entmode", 2)
            if "*PAPER" in owner_name.upper() or entmode == 1:
                space = CanonicalSpaceType.PAPERSPACE
            elif owner_name and not owner_name.startswith("*"):
                space = CanonicalSpaceType.BLOCK_DEFINITION
            else:
                space = CanonicalSpaceType.MODELSPACE

            ent_id = f"{source_id}:{h_hex or len(doc.entities)}"

            if ent_type in (
                "LINE", "LWPOLYLINE", "POLYLINE", "CIRCLE", "ARC",
                "ELLIPSE", "SPLINE", "HATCH", "SOLID", "POINT"
            ):
                geometry_data: dict[str, Any] = {"entity_type": ent_type}
                if ent_type == "LINE":
                    st = obj.get("start", [0, 0, 0])
                    en = obj.get("end", [0, 0, 0])
                    geometry_data["start"] = {"x": float(st[0]), "y": float(st[1]), "z": float(st[2]) if len(st) > 2 else 0.0}
                    geometry_data["end"] = {"x": float(en[0]), "y": float(en[1]), "z": float(en[2]) if len(en) > 2 else 0.0}
                elif ent_type == "CIRCLE":
                    cen = obj.get("center", [0, 0, 0])
                    geometry_data["center"] = {"x": float(cen[0]), "y": float(cen[1]), "z": float(cen[2]) if len(cen) > 2 else 0.0}
                    geometry_data["radius"] = float(obj.get("radius", 0.0))
                elif ent_type == "ARC":
                    cen = obj.get("center", [0, 0, 0])
                    geometry_data["center"] = {"x": float(cen[0]), "y": float(cen[1]), "z": float(cen[2]) if len(cen) > 2 else 0.0}
                    geometry_data["radius"] = float(obj.get("radius", 0.0))
                    geometry_data["start_angle"] = float(obj.get("start_angle", 0.0))
                    geometry_data["end_angle"] = float(obj.get("end_angle", 0.0))
                elif ent_type in ("LWPOLYLINE", "POLYLINE"):
                    pts = obj.get("points", [])
                    geometry_data["points"] = [
                        {"x": float(p[0]), "y": float(p[1]), "z": float(p[2]) if len(p) > 2 else 0.0}
                        for p in pts if isinstance(p, (list, tuple)) and len(p) >= 2
                    ]
                    geometry_data["closed"] = bool(obj.get("flag", 0) & 1)

                canonical_ent = CanonicalCADEntity(
                    entity_id=ent_id,
                    handle=h_hex,
                    entity_type=ent_type,
                    layer=layer,
                    space=space,
                    geometry=geometry_data,
                    raw_type=ent_type,
                )
                doc.entities.append(canonical_ent)

            elif ent_type in ("TEXT", "MTEXT"):
                ins_pt = obj.get("ins_pt", [0.0, 0.0, 0.0])
                pt_tuple = (
                    float(ins_pt[0]) if len(ins_pt) > 0 else 0.0,
                    float(ins_pt[1]) if len(ins_pt) > 1 else 0.0,
                    float(ins_pt[2]) if len(ins_pt) > 2 else 0.0,
                )
                txt_val = obj.get("text_value") or obj.get("text") or obj.get("user_text") or ""
                canonical_txt = CanonicalCADText(
                    text=str(txt_val),
                    insertion_point=pt_tuple,
                    height=float(obj.get("height", 0.0)),
                    layer=layer,
                    handle=h_hex,
                    is_mtext=(ent_type == "MTEXT"),
                )
                doc.texts.append(canonical_txt)

            elif "DIMENSION" in ent_type:
                meas = obj.get("act_measurement") or obj.get("actual_measurement")
                user_txt = obj.get("user_text") or obj.get("text")
                dim_type = "ALIGNED" if "ALIGNED" in ent_type else "LINEAR"
                def_pts = []
                for pt_key in ("def_pt", "xline1_pt", "xline2_pt"):
                    p_val = obj.get(pt_key)
                    if p_val and isinstance(p_val, (list, tuple)) and len(p_val) >= 2:
                        def_pts.append((
                            float(p_val[0]),
                            float(p_val[1]),
                            float(p_val[2]) if len(p_val) > 2 else 0.0,
                        ))

                canonical_dim = CanonicalCADDimension(
                    handle=h_hex,
                    layer=layer,
                    dimension_type=dim_type,
                    measurement=float(meas) if meas is not None else None,
                    text_override=str(user_txt) if user_txt else None,
                    definition_points=def_pts,
                    status="SUPPORTED" if def_pts else "PARTIAL",
                )
                doc.dimensions.append(canonical_dim)

            elif ent_type == "INSERT":
                b_ref_hex = self._format_handle(obj.get("block_header"))
                b_name = block_by_handle.get(b_ref_hex, "UNKNOWN_BLOCK")
                ins_pt = obj.get("ins_pt", [0.0, 0.0, 0.0])
                sc = obj.get("scale", [1.0, 1.0, 1.0])
                scale_tuple = (
                    float(sc[0]) if len(sc) > 0 else 1.0,
                    float(sc[1]) if len(sc) > 1 else 1.0,
                    float(sc[2]) if len(sc) > 2 else 1.0,
                )
                canonical_insert = CanonicalCADBlockReference(
                    insert_id=ent_id,
                    block_name=b_name,
                    handle=h_hex,
                    layer=layer,
                    space=space,
                    insertion_point=(
                        float(ins_pt[0]) if len(ins_pt) > 0 else 0.0,
                        float(ins_pt[1]) if len(ins_pt) > 1 else 0.0,
                        float(ins_pt[2]) if len(ins_pt) > 2 else 0.0,
                    ),
                    scale=scale_tuple,
                    rotation=float(obj.get("rotation", 0.0)),
                    owner_handle=owner_hex,
                )
                doc.block_references.append(canonical_insert)

                # También registrar como entidad básica tipo INSERT para retrocompatibilidad
                doc.entities.append(
                    CanonicalCADEntity(
                        entity_id=ent_id,
                        handle=h_hex,
                        entity_type="INSERT",
                        layer=layer,
                        space=space,
                        geometry={
                            "name": b_name,
                            "insert": {"x": float(ins_pt[0]), "y": float(ins_pt[1]), "z": float(ins_pt[2]) if len(ins_pt) > 2 else 0.0},
                            "rotation": float(obj.get("rotation", 0.0)),
                            "scale": {"x": scale_tuple[0], "y": scale_tuple[1], "z": scale_tuple[2]},
                        },
                        raw_type="INSERT",
                    )
                )

            elif ent_type == "VIEWPORT":
                vp_center = obj.get("center", [0.0, 0.0, 0.0])
                canonical_vp = CanonicalCADViewport(
                    handle=h_hex,
                    layout_name=owner_name,
                    center_point=(
                        float(vp_center[0]) if len(vp_center) > 0 else 0.0,
                        float(vp_center[1]) if len(vp_center) > 1 else 0.0,
                        float(vp_center[2]) if len(vp_center) > 2 else 0.0,
                    ),
                    width=float(obj.get("width", 0.0)),
                    height=float(obj.get("height", 0.0)),
                )
                doc.viewports.append(canonical_vp)

        return doc

    def _read_via_dwg2dxf_fallback(
        self,
        dwg2dxf_exe: str,
        source_path: Path,
        source_id: str,
        sha256: str,
        file_size: int,
        dwg_version: Optional[str],
    ) -> CanonicalCADDocument:
        """
        Ejecuta `dwg2dxf` hacia un directorio temporal seguro, lee el DXF resultante
        con el convertidor canónico, y reasigna rigurosamente la trazabilidad
        a la FUENTE PRIMARIA (DWG original inmutable).
        """
        from readers.dxf_reader import DXFReader

        temp_dir_obj = tempfile.TemporaryDirectory(
            prefix="agente_dwg_intermediate_",
            dir=self.custom_temp_dir,
        )

        try:
            temp_path = Path(temp_dir_obj.name)
            output_dxf = temp_path / f"{source_path.stem}.dxf"

            cmd = [dwg2dxf_exe, "-y", "-o", str(output_dxf), str(source_path)]
            LOGGER.debug("Ejecutando fallback dwg2dxf: %s", " ".join(cmd))

            res = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120,
                check=False,
            )

            if not output_dxf.exists():
                candidates = list(temp_path.glob("*.dxf"))
                if len(candidates) == 1:
                    output_dxf = candidates[0]
                else:
                    raise RuntimeError(
                        f"dwg2dxf finalizó con returncode {res.returncode} pero no generó el DXF esperado.\n"
                        f"STDOUT: {res.stdout}\nSTDERR: {res.stderr}"
                    )

            # Leer el DXF intermedio con DXFReader
            dxf_reader = DXFReader()
            dxf_doc = dxf_reader.read(output_dxf)

            # Transformar a CanonicalCADDocument preservando 100% la identidad del DWG original
            canonical_doc = CanonicalCADDocument(
                source_id=source_id,
                source_path=source_path,
                source_format="DWG",
                source_version=dwg_version,
                sha256=sha256,
                file_size=file_size,
                provider=self.provider_id,
                provider_version=self.version(),
                ingestion_strategy=CanonicalIngestionStrategy.LIBREDWG_DXF_FALLBACK,
                units=dxf_doc.units,
                unit_status=CanonicalUnitStatus.DOCUMENTED if dxf_doc.units else CanonicalUnitStatus.UNKNOWN,
                crs_if_documented=dxf_doc.crs,
                warnings=list(dxf_doc.warnings),
                source_traceability={
                    "primary_source": str(source_path),
                    "primary_sha256": sha256,
                    "primary_size": file_size,
                    "strategy": CanonicalIngestionStrategy.LIBREDWG_DXF_FALLBACK.value,
                    "intermediate_format": "DXF",
                    "intermediate_sha256": dxf_doc.sha256,
                    "provider": self.provider_id,
                    "converter_binary": dwg2dxf_exe,
                },
            )

            # Mapear layers
            for lyr_name in dxf_doc.metadata.get("layers", []):
                canonical_doc.layers[lyr_name] = CanonicalCADLayer(name=lyr_name)

            # Mapear entities
            raw_entities = dxf_doc.extracted_data.get("entities", [])
            for idx, raw_ent in enumerate(raw_entities):
                handle = raw_ent.get("handle")
                ent_type = raw_ent.get("entity_type", "UNKNOWN")
                layer = raw_ent.get("layer")
                space_str = raw_ent.get("space", "MODELSPACE")
                space = CanonicalSpaceType.PAPERSPACE if space_str == "PAPERSPACE" else CanonicalSpaceType.MODELSPACE

                c_ent = CanonicalCADEntity(
                    entity_id=f"{source_id}:{handle or idx}",
                    handle=handle,
                    entity_type=ent_type,
                    layer=layer,
                    space=space,
                    geometry=raw_ent,
                    raw_type=ent_type,
                )
                canonical_doc.entities.append(c_ent)

            # Mapear textos
            raw_texts = dxf_doc.extracted_data.get("texts", [])
            for t_idx, raw_t in enumerate(raw_texts):
                pos = raw_t.get("position", (0.0, 0.0, 0.0))
                pt = (pos[0], pos[1], pos[2]) if len(pos) >= 3 else (pos[0], pos[1], 0.0) if len(pos) == 2 else (0.0, 0.0, 0.0)
                txt_obj = CanonicalCADText(
                    text=raw_t.get("text", ""),
                    insertion_point=pt,
                    height=raw_t.get("height"),
                    layer=raw_t.get("layer"),
                    handle=raw_t.get("handle"),
                    is_mtext=(raw_t.get("entity_type") == "MTEXT"),
                )
                canonical_doc.texts.append(txt_obj)

            # Mapear bloques
            for blk in dxf_doc.metadata.get("blocks", []):
                name = blk.get("name")
                if name:
                    canonical_doc.blocks[name] = CanonicalCADBlock(
                        name=name,
                        description=blk.get("description"),
                    )

            # Mapear layouts
            for lay in dxf_doc.metadata.get("layouts", []):
                lay_name = lay.get("name")
                if lay_name:
                    canonical_doc.layouts[lay_name] = CanonicalCADLayout(
                        name=lay_name,
                        is_modelspace=(lay_name.upper() == "MODEL"),
                    )

            return canonical_doc

        finally:
            if not self.keep_intermediates:
                temp_dir_obj.cleanup()
            else:
                LOGGER.info("KEEP_DWG_INTERMEDIATES activo. Intermediarios conservados en: %s", temp_dir_obj.name)
