"""
reconstruction/parametric_recipe_library.py
Biblioteca genérica de recetas geométricas paramétricas para v0.6.0.
Organiza recetas por patrones geométricos/funcionales.
REGLA CENTRAL: Una receta NO decide la identidad del objeto; solo materializa
un objeto cuya identidad y semántica ya fue resuelta previamente.
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Optional

from core.models import (
    EvidenceStatus,
    GeometryRecipe,
    QualityConfidenceLevel,
    RecipeType,
    ReconstructedObject,
)


class GenericRecipePattern(str, Enum):
    """
    Patrones geométricos y funcionales admitidos en la biblioteca de recetas v0.6.0.
    """
    LINEAR_EXTRUSION = "LINEAR_EXTRUSION"
    PROFILE_EXTRUSION = "PROFILE_EXTRUSION"
    CIRCULAR_EXTRUSION = "CIRCULAR_EXTRUSION"
    RECTANGULAR_EXTRUSION = "RECTANGULAR_EXTRUSION"
    SWEEP_ALONG_ALIGNMENT = "SWEEP_ALONG_ALIGNMENT"
    REVOLUTION = "REVOLUTION"
    LOFT = "LOFT"
    ARRAY_ALONG_ALIGNMENT = "ARRAY_ALONG_ALIGNMENT"
    ARRAY_ON_GRID = "ARRAY_ON_GRID"
    INSTANCE_FROM_TYPE = "INSTANCE_FROM_TYPE"
    FRAME_ASSEMBLY = "FRAME_ASSEMBLY"
    SURFACE_BASED = "SURFACE_BASED"
    MESH_FROM_EVIDENCE = "MESH_FROM_EVIDENCE"


class ParametricRecipeLibrary:
    """
    Catálogo y validador de recetas paramétricas genéricas.
    """

    RECIPE_PARAMETER_REQUIREMENTS = {
        GenericRecipePattern.CIRCULAR_EXTRUSION: {
            "required": ["RADIO", "ALTURA"],
            "optional": ["RADIO_INTERIOR", "ESPESOR"],
            "core_recipe_type": RecipeType.CIRCULAR_EXTRUSION,
        },
        GenericRecipePattern.RECTANGULAR_EXTRUSION: {
            "required": ["ANCHO", "LONGITUD", "ALTURA"],
            "optional": ["ESPESOR", "CHAFLAN"],
            "core_recipe_type": RecipeType.RECTANGULAR_EXTRUSION,
        },
        GenericRecipePattern.PROFILE_EXTRUSION: {
            "required": ["PROFILE_POLYGON", "LONGITUD"],
            "optional": ["TORSION", "SCALE"],
            "core_recipe_type": RecipeType.POLYGON_EXTRUSION,
        },
        GenericRecipePattern.SWEEP_ALONG_ALIGNMENT: {
            "required": ["PROFILE_CROSS_SECTION", "ALIGNMENT_PATH", "START_STATION", "END_STATION"],
            "optional": ["CROSS_FALL", "SUPER_ELEVATION"],
            "core_recipe_type": RecipeType.PROFILE_SWEEP,
        },
        GenericRecipePattern.ARRAY_ALONG_ALIGNMENT: {
            "required": ["BASE_TYPOLOGY_ID", "ALIGNMENT_PATH", "STATIONS_LIST"],
            "optional": ["OFFSETS_LIST", "ROTATIONS_LIST"],
            "core_recipe_type": RecipeType.LINEAR_SWEEP,
        },
        GenericRecipePattern.ARRAY_ON_GRID: {
            "required": ["BASE_TYPOLOGY_ID", "GRID_ORIGIN", "SPACING_X", "SPACING_Y", "COUNT_X", "COUNT_Y"],
            "optional": ["ROTATION"],
            "core_recipe_type": RecipeType.RECTANGULAR_EXTRUSION,
        },
        GenericRecipePattern.INSTANCE_FROM_TYPE: {
            "required": ["TYPOLOGY_DEFINITION_ID", "PLACEMENT_POINT"],
            "optional": ["ORIENTATION_VECTOR", "SCALE_FACTOR"],
            "core_recipe_type": RecipeType.POLYGON_EXTRUSION,
        },
        GenericRecipePattern.FRAME_ASSEMBLY: {
            "required": ["NODES", "MEMBERS_CONNECTIVITY", "SECTION_PROFILES"],
            "optional": ["JOINT_RELEASES"],
            "core_recipe_type": RecipeType.BOOLEAN_COMBINATION,
        },
        GenericRecipePattern.SURFACE_BASED: {
            "required": ["BOUNDARY_CURVES", "SURFACE_LEVEL"],
            "optional": ["THICKNESS", "SLOPE"],
            "core_recipe_type": RecipeType.POLYLINE_SURFACE,
        },
        GenericRecipePattern.REVOLUTION: {
            "required": ["PROFILE_CURVE", "AXIS_POINT", "AXIS_VECTOR", "ANGLE"],
            "optional": [],
            "core_recipe_type": RecipeType.REVOLUTION,
        },
        GenericRecipePattern.LOFT: {
            "required": ["PROFILES_LIST", "SPINE_CURVE"],
            "optional": ["GUIDE_CURVES"],
            "core_recipe_type": RecipeType.LOFT,
        },
        GenericRecipePattern.MESH_FROM_EVIDENCE: {
            "required": ["VERTICES", "FACES"],
            "optional": ["NORMALS"],
            "core_recipe_type": RecipeType.UNKNOWN,
        },
    }

    def select_recipe(
        self,
        pattern: GenericRecipePattern,
        object_id: str,
        parameters: dict[str, Any],
        local_frame: Optional[dict[str, Any]] = None,
    ) -> GeometryRecipe:
        """
        Crea una GeometryRecipe estricta a partir de un patrón genérico y parámetros resueltos.
        """
        spec = self.RECIPE_PARAMETER_REQUIREMENTS.get(pattern)
        if not spec:
            raise ValueError(f"Patrón de receta no soportado: {pattern}")

        required = spec["required"]
        optional = spec["optional"]
        core_type = spec["core_recipe_type"]

        # Verificar qué parámetros requeridos están presentes
        missing = [p for p in required if p not in parameters or parameters[p] is None]

        recipe_id = f"rec_{pattern.value.lower()}_{object_id[:10]}"

        return GeometryRecipe(
            recipe_id=recipe_id,
            object_id=object_id,
            recipe_type=core_type,
            required_parameters=required,
            optional_parameters=optional,
            source_parameters=parameters,
            local_frame=local_frame,
            unresolved_parameters=missing,
            evidence_status=EvidenceStatus.DOCUMENTED if not missing else EvidenceStatus.UNKNOWN,
            geometry_confidence=QualityConfidenceLevel.HIGH if not missing else QualityConfidenceLevel.LOW,
            notes=f"Generated via GenericRecipePattern.{pattern.value}",
        )
