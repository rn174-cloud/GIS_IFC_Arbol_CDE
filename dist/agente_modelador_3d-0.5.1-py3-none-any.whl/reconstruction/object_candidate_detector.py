from __future__ import annotations

import hashlib
import math
from typing import Any

from core.models import (
    CandidateRelation,
    CandidateRelationType,
    CandidateStatus,
    CandidateType,
    EvidenceOrigin,
    ObjectCandidate,
    ProximityLevel,
    SemanticFamily,
    SemanticSignal,
    SourceDocument,
    ViewEvidence,
)
from reconstruction.semantic_signal_extractor import SemanticSignalExtractor


def compute_candidate_confidence(
    signals: list[SemanticSignal],
    ent_type: str,
    layer: str,
    has_contradictions: bool = False,
) -> tuple[float, float, float, float, float, float, list[SemanticSignal]]:
    """
    Función única y matemáticamente exacta para calcular la confianza de un candidato.

    Algoritmo totalmente auditable:
    1. Agrupar señales por `signal_group` (EvidenceOrigin). Para grupos correlacionados (ej. CAD_LAYER con
       LAYER_NAME y LAYER_FAMILY_HINT), se toma la señal más representativa para evitar doble conteo.
    2. Sumar contribuciones ponderadas de grupos positivos: weighted_score = sum(w * conf).
    3. Normalizar por el total de pesos de grupos únicos: raw_signal_score = weighted_score / total_weight.
    4. Aplicar boosts por convergencia multi-origen (si hay >= 2 grupos independientes de distinta naturaleza).
    5. Aplicar penalizaciones (penalties) por señales negativas o contradicciones detectadas.
    6. final_confidence = clamp(raw_signal_score + boosts - penalties, 0.05, 0.95).

    Retorna:
    (raw_signal_score, weighted_score, normalization_factor, penalties, boosts, final_confidence, scored_signals)
    """
    if not signals:
        return 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, []

    # Separar señales positivas y negativas
    positive_signals = [s for s in signals if not s.is_negative]
    negative_signals = [s for s in signals if s.is_negative]

    # Agrupar positivas por signal_group para evitar doble conteo
    group_signals: dict[EvidenceOrigin, list[SemanticSignal]] = {}
    for s in positive_signals:
        group_signals.setdefault(s.signal_group, []).append(s)

    # De cada grupo, seleccionamos la señal con mayor ponderación (w * conf) como representativa
    representative_signals: list[SemanticSignal] = []
    total_weight = 0.0
    weighted_sum = 0.0

    for grp, sig_list in group_signals.items():
        best_sig = max(sig_list, key=lambda x: x.weight * x.confidence)
        representative_signals.append(best_sig)
        total_weight += best_sig.weight
        weighted_sum += (best_sig.weight * best_sig.confidence)

    norm_factor = total_weight if total_weight > 0 else 1.0
    raw_score = (weighted_sum / norm_factor) if total_weight > 0 else 0.0

    # Boosts por independencia real de fuentes:
    # Si tenemos al menos 2 grupos de diferente naturaleza (ej. CAD_LAYER + TEXTUAL o GEOMETRIC + CAD_LAYER)
    independent_groups = set(group_signals.keys())
    boosts = 0.0
    if len(independent_groups) >= 3:
        boosts = 0.15
    elif len(independent_groups) >= 2:
        boosts = 0.08

    # Penalties por evidencia negativa
    penalties = 0.0
    if negative_signals or has_contradictions:
        for neg in negative_signals:
            penalties += (neg.weight * neg.confidence)
        if has_contradictions and not negative_signals:
            penalties += 0.20

    final_conf = max(0.05, min(0.95, raw_score + boosts - penalties))

    # Asignar auditoría a cada señal individual
    scored_signals: list[SemanticSignal] = []
    for s in signals:
        c = round((s.weight * s.confidence) / norm_factor, 4) if norm_factor > 0 else 0.0
        scored_copy = SemanticSignal(
            signal_type=s.signal_type,
            value=s.value,
            source_id=s.source_id,
            confidence=s.confidence,
            weight=s.weight,
            contribution=-c if s.is_negative else c,
            signal_group=s.signal_group,
            is_negative=s.is_negative,
            entity_reference=s.entity_reference,
            view_id=s.view_id,
            real_distance=s.real_distance,
            proximity_level=s.proximity_level,
            coordinate_system=s.coordinate_system,
            entity_bbox=s.entity_bbox,
            target_bbox=s.target_bbox,
            distance_threshold=s.distance_threshold,
            distance_method=s.distance_method,
            notes=s.notes,
        )
        scored_signals.append(scored_copy)

    return (
        round(raw_score, 4),
        round(weighted_sum, 4),
        round(norm_factor, 4),
        round(penalties, 4),
        round(boosts, 4),
        round(final_conf, 4),
        scored_signals,
    )


class ObjectCandidateDetector:
    """
    Detector endurecido de candidatos a objeto real.

    Principios v0.2A.1:
    - Vocabulario de tipos estrictamente conservador (UNKNOWN_*, POSSIBLE_*).
    - Trazabilidad de type_rule_id y type_evidence.
    - Proximidad espacial real evaluada entre bounding boxes.
    - Reglas de evidencia mínima para transiciones de estado:
      * UNRESOLVED: evidencia insuficiente o de un solo grupo.
      * PARTIALLY_RESOLVED: >= 2 grupos independientes (al menos 1 semántico y 1 geométrico/espacial).
      * RESOLVED: restringido (nunca automático sin evidencia documental inequívoca).
    """

    def __init__(self) -> None:
        self.signal_extractor = SemanticSignalExtractor()

    @staticmethod
    def _make_candidate_id(source_id: str, view_id: str, key_ref: str) -> str:
        raw_seed = f"{source_id}::{view_id}::{key_ref}".encode("utf-8")
        hash_hex = hashlib.sha256(raw_seed).hexdigest()[:12]
        return f"cand_{hash_hex}"

    def detect_candidates(
        self,
        documents: list[SourceDocument],
        views: list[ViewEvidence],
        classified_measurements: list[dict[str, Any]],
    ) -> tuple[list[ObjectCandidate], list[SemanticSignal], list[CandidateRelation]]:
        all_candidates: list[ObjectCandidate] = []
        all_signals: list[SemanticSignal] = []
        all_relations: list[CandidateRelation] = []

        doc_by_source: dict[str, SourceDocument] = {
            doc.source_id or str(doc.path): doc for doc in documents
        }

        views_by_source: dict[str, list[ViewEvidence]] = {}
        for v in views:
            src_file = v.source.source_file
            matching_doc_id = None
            for d_id, doc in doc_by_source.items():
                if str(doc.path) == src_file or doc.path.name == src_file or d_id == src_file:
                    matching_doc_id = d_id
                    break
            if matching_doc_id:
                views_by_source.setdefault(matching_doc_id, []).append(v)

        for view in views:
            src_file = view.source.source_file
            doc = next((d for d in documents if str(d.path) == src_file or d.path.name == src_file), None)
            if doc:
                v_signals = self.signal_extractor.extract_signals_from_view(
                    view=view,
                    source_document=doc,
                    classified_measurements=classified_measurements,
                )
                all_signals.extend(v_signals)

        for doc in documents:
            source_id = doc.source_id or "src_unknown"
            doc_views = views_by_source.get(source_id, [])

            if doc.file_type in {"DXF", "DWG"}:
                cands, sigs = self._detect_from_cad(doc, doc_views, classified_measurements)
            elif doc.file_type == "PDF":
                cands, sigs = self._detect_from_pdf(doc, doc_views, classified_measurements)
            else:
                cands, sigs = [], []

            all_candidates.extend(cands)
            all_signals.extend(sigs)

        relations = self._detect_relations(all_candidates)
        all_relations.extend(relations)

        return all_candidates, all_signals, all_relations

    def _detect_from_cad(
        self,
        document: SourceDocument,
        views: list[ViewEvidence],
        classified_measurements: list[dict[str, Any]],
    ) -> tuple[list[ObjectCandidate], list[SemanticSignal]]:
        candidates: list[ObjectCandidate] = []
        signals: list[SemanticSignal] = []
        source_id = document.source_id or "src_unknown"

        entities = document.extracted_data.get("entities", [])
        if not entities:
            return candidates, signals

        canonical_texts = document.extracted_data.get("texts", [])
        text_entities: list[dict[str, Any]] = []
        for t in canonical_texts:
            if isinstance(t, dict) and t.get("text"):
                pos = t.get("insertion_point") or t.get("insert")
                t_dict = {
                    "entity_type": "MTEXT" if t.get("is_mtext") else "TEXT",
                    "text": t.get("text"),
                    "layer": t.get("layer"),
                    "handle": t.get("handle"),
                    "height": t.get("height", 2.5),
                }
                if isinstance(pos, dict) and "x" in pos and "y" in pos:
                    t_dict["insert"] = {"x": float(pos["x"]), "y": float(pos["y"]), "z": float(pos.get("z", 0.0))}
                elif isinstance(pos, (list, tuple)) and len(pos) >= 2:
                    t_dict["insert"] = {"x": float(pos[0]), "y": float(pos[1]), "z": float(pos[2]) if len(pos) > 2 else 0.0}
                text_entities.append(t_dict)

        for e in entities:
            if e.get("entity_type") in {"TEXT", "MTEXT"}:
                text_entities.append(e)

        # 2. Recuperar mediciones y cotas estructuradas
        stations = [
            m.get("value") for m in classified_measurements
            if m.get("candidate_type") == CandidateType.STATION.value
        ]
        default_station = stations[0] if stations else None

        dim_candidates = [
            m for m in classified_measurements
            if m.get("candidate_type") == CandidateType.MEASUREMENT.value
        ]

        graphical_entities = [
            e for e in entities
            if e.get("entity_type") not in {"TEXT", "MTEXT", "DIMENSION"}
        ]

        # 3. DETECCIÓN DE MOTIVOS GEOMÉTRICOS NEUTROS:
        # A) Círculos concéntricos: agrupamiento en UNKNOWN_CIRCULAR_ASSEMBLY
        circle_ents = [e for e in graphical_entities if e.get("entity_type") == "CIRCLE"]
        centers: dict[tuple[float, float], list[dict[str, Any]]] = {}
        for c in circle_ents:
            c_center = c.get("center", {})
            if "x" in c_center and "y" in c_center:
                k = (round(c_center["x"], 2), round(c_center["y"], 2))
                centers.setdefault(k, []).append(c)

        handled_circle_handles: set[str] = set()

        for (cx, cy), group_circles in centers.items():
            if len(group_circles) >= 2:
                # Agrupamiento de motivo geométrico neutro: UNKNOWN_CIRCULAR_ASSEMBLY
                c_handles = [str(c.get("handle")) for c in group_circles if c.get("handle")]
                handled_circle_handles.update(c_handles)
                radii = sorted([float(c.get("radius", 0.0)) for c in group_circles])
                outer_r = radii[-1]
                inner_r = radii[0]

                associated_view_id = "cad_modelspace"
                for v in views:
                    if any(h in v.entity_references for h in c_handles):
                        associated_view_id = v.view_id
                        break

                motif_id = f"motif_circle_{cx:.2f}_{cy:.2f}".replace("-", "m").replace(".", "_")
                cand_id = self._make_candidate_id(source_id, associated_view_id, motif_id)

                motif_extent = {
                    "center": {"x": cx, "y": cy, "z": 0.0},
                    "outer_radius": outer_r,
                    "inner_radius": inner_r,
                    "radii": radii,
                    "bbox": {
                        "minx": cx - outer_r,
                        "miny": cy - outer_r,
                        "maxx": cx + outer_r,
                        "maxy": cy + outer_r,
                    },
                }

                # Extraer señales combinadas para el motivo
                synthetic_ent = {
                    "entity_type": "CIRCLE",
                    "center": {"x": cx, "y": cy, "z": 0.0},
                    "radius": outer_r,
                    "layer": group_circles[0].get("layer", ""),
                    "handle": c_handles[0] if c_handles else motif_id,
                }
                motif_signals = self.signal_extractor.extract_signals_for_entity(
                    entity=synthetic_ent,
                    source_id=source_id,
                    view_id=associated_view_id,
                    candidate_text_entities=text_entities,
                    nearby_station=default_station,
                    station_distance=10.0 if default_station else None,
                    candidate_dimension_entities=dim_candidates,
                )
                motif_signals.append(
                    SemanticSignal(
                        signal_type="GEOMETRIC_MOTIF",
                        value={"motif": "CONCENTRIC_CIRCLES", "circle_count": len(group_circles), "radii": radii},
                        source_id=source_id,
                        entity_reference=",".join(c_handles),
                        view_id=associated_view_id,
                        confidence=0.85,
                        weight=0.30,
                        signal_group=EvidenceOrigin.GEOMETRIC,
                        notes=f"Motivo geométrico concéntrico: {len(group_circles)} círculos concéntricos en ({cx}, {cy})",
                    )
                )
                signals.extend(motif_signals)

                (
                    m_family,
                    m_prob_type,
                    m_rule_id,
                    m_type_ev,
                    m_status,
                    m_raw_score,
                    m_w_score,
                    m_norm_factor,
                    m_penalties,
                    m_boosts,
                    m_final_conf,
                    m_scored_signals,
                ) = self._classify_and_score(ent=synthetic_ent, signals=motif_signals)

                # Si no hay texto o evidencia semántica independiente, el tipo se mantiene neutral
                if m_prob_type.startswith("UNKNOWN_") or m_family == SemanticFamily.UNKNOWN:
                    m_prob_type = "UNKNOWN_CIRCULAR_ASSEMBLY"
                    m_rule_id = "RULE_MOTIF_CONCENTRIC_CIRCLES_NEUTRAL"
                    m_type_ev.append("CONCENTRIC_CIRCLES_MOTIF")

                candidate = ObjectCandidate(
                    candidate_id=cand_id,
                    probable_family=m_family,
                    probable_type=m_prob_type,
                    confidence=m_final_conf,
                    status=m_status,
                    source_ids=[source_id],
                    entity_references=c_handles,
                    view_ids=[associated_view_id],
                    spatial_extent=motif_extent,
                    station=default_station,
                    offset=cy,
                    elevation=None,
                    labels=[f"MOTIF_CONCENTRIC_{len(group_circles)}_CIRCLES"],
                    related_texts=[
                        str(s.value) for s in motif_signals
                        if s.signal_group == EvidenceOrigin.TEXTUAL
                    ][:5],
                    semantic_signals=m_scored_signals,
                    parameter_candidates=[
                        m for m in classified_measurements
                        if m.get("view_id") == associated_view_id
                    ],
                    type_evidence=m_type_ev,
                    type_rule_id=m_rule_id,
                    raw_signal_score=m_raw_score,
                    weighted_score=m_w_score,
                    normalization_factor=m_norm_factor,
                    penalties=m_penalties,
                    boosts=m_boosts,
                    final_confidence=m_final_conf,
                    notes=f"Candidato de ensamblaje circular concéntrico ({len(group_circles)} círculos)",
                )
                candidates.append(candidate)

        # 4. Entidades gráficas individuales (incluyendo círculos no concéntricos, líneas, polilíneas, bloques)
        for ent in graphical_entities:
            handle = str(ent.get("handle", ""))
            ent_type = ent.get("entity_type", "")
            layer = str(ent.get("layer", ""))

            # Si el círculo ya forma parte de un ensamblaje concéntrico, evitar duplicación
            if ent_type == "CIRCLE" and handle in handled_circle_handles:
                continue

            associated_view_id = "cad_modelspace"
            for v in views:
                if handle in v.entity_references:
                    associated_view_id = v.view_id
                    break

            # Extraer señales con evaluación de distancia real hacia textos y cotas
            ent_signals = self.signal_extractor.extract_signals_for_entity(
                entity=ent,
                source_id=source_id,
                view_id=associated_view_id,
                candidate_text_entities=text_entities,
                nearby_station=default_station,
                station_distance=10.0 if default_station else None,
                candidate_dimension_entities=dim_candidates,
            )
            signals.extend(ent_signals)

            # Clasificación conservadora y scoring auditable
            (
                family,
                probable_type,
                rule_id,
                type_ev,
                status,
                raw_score,
                w_score,
                norm_factor,
                penalties,
                boosts,
                final_conf,
                scored_signals,
            ) = self._classify_and_score(ent=ent, signals=ent_signals)

            extent = self._extract_spatial_extent(ent)
            candidate_id = self._make_candidate_id(source_id, associated_view_id, handle or ent_type)

            candidate = ObjectCandidate(
                candidate_id=candidate_id,
                probable_family=family,
                probable_type=probable_type,
                confidence=final_conf,
                status=status,
                source_ids=[source_id],
                entity_references=[handle] if handle else [],
                view_ids=[associated_view_id],
                spatial_extent=extent,
                station=default_station,
                offset=extent.get("center", {}).get("y") if extent and "center" in extent else None,
                elevation=extent.get("center", {}).get("z") if extent and "center" in extent else None,
                labels=[f"CAD_{ent_type}_{handle}"] if handle else [f"CAD_{ent_type}"],
                related_texts=[
                    str(s.value) for s in ent_signals
                    if s.signal_group == EvidenceOrigin.TEXTUAL
                ][:5],
                semantic_signals=scored_signals,
                parameter_candidates=[
                    m for m in classified_measurements
                    if m.get("view_id") == associated_view_id
                ],
                type_evidence=type_ev,
                type_rule_id=rule_id,
                raw_signal_score=raw_score,
                weighted_score=w_score,
                normalization_factor=norm_factor,
                penalties=penalties,
                boosts=boosts,
                final_confidence=final_conf,
                notes=f"Candidato entidad {ent_type} handle={handle} layer={layer}",
            )
            candidates.append(candidate)

        return candidates, signals

    def _detect_from_pdf(
        self,
        document: SourceDocument,
        views: list[ViewEvidence],
        classified_measurements: list[dict[str, Any]],
    ) -> tuple[list[ObjectCandidate], list[SemanticSignal]]:
        candidates: list[ObjectCandidate] = []
        signals: list[SemanticSignal] = []
        source_id = document.source_id or "src_unknown"

        pages = document.extracted_data.get("pages", [])
        for page_rec in pages:
            page_idx = page_rec.get("page_index", 0)
            page_text = page_rec.get("text", "")

            page_views = [
                v for v in views
                if f"page_{page_idx + 1}" in v.view_id or f"p_{page_idx + 1}" in v.view_id
            ] or [v for v in views if v.source.source_file == str(document.path)]

            for v_idx, v in enumerate(page_views):
                cand_id = self._make_candidate_id(source_id, v.view_id, f"region_{v_idx}")
                cand_signals: list[SemanticSignal] = [
                    SemanticSignal(
                        signal_type="SPATIAL_CLUSTER",
                        value=v.bounding_box,
                        source_id=source_id,
                        view_id=v.view_id,
                        confidence=v.confidence or 0.40,
                        weight=0.20,
                        signal_group=EvidenceOrigin.SPATIAL,
                        notes="Región delimitada en plano PDF",
                    )
                ]

                region_texts = v.texts or [page_text[:200]]
                family = SemanticFamily.UNKNOWN
                prob_type = "UNKNOWN_CLOSED_PROFILE"
                rule_id = "RULE_PDF_FALLBACK_UNKNOWN"
                type_ev = ["PDF_REGION_BBOX"]

                upper_text = " ".join(region_texts).upper()
                if any(k in upper_text for k in ["REPAV", "PAVIM", "CALZADA", "MEZCLA", "ASFALT"]):
                    family = SemanticFamily.PAVEMENT
                    prob_type = "POSSIBLE_SURFACE_BOUNDARY"
                    rule_id = "RULE_PDF_TEXT_PAVEMENT"
                    type_ev.append("TEXT_PAVEMENT_MATCH")
                    cand_signals.append(
                        SemanticSignal(
                            signal_type="TEXT_SAME_REGION",
                            value="PAVIMENTO / REPAVIMENTACION",
                            source_id=source_id,
                            view_id=v.view_id,
                            confidence=0.50,
                            weight=0.15,
                            signal_group=EvidenceOrigin.TEXTUAL,
                            proximity_level=ProximityLevel.SAME_REGION,
                            notes="Texto en región contiene términos de calzada",
                        )
                    )

                signals.extend(cand_signals)

                raw_s, w_s, norm_f, pen, bst, final_c, scored_sigs = compute_candidate_confidence(
                    cand_signals, "REGION", "PDF"
                )

                candidate = ObjectCandidate(
                    candidate_id=cand_id,
                    probable_family=family,
                    probable_type=prob_type,
                    confidence=final_c,
                    status=CandidateStatus.UNRESOLVED,
                    source_ids=[source_id],
                    entity_references=[],
                    view_ids=[v.view_id],
                    spatial_extent=v.bounding_box,
                    labels=[f"PDF_PAGE_{page_idx + 1}_REGION_{v_idx}"],
                    related_texts=region_texts[:5],
                    semantic_signals=scored_sigs,
                    parameter_candidates=[
                        m for m in classified_measurements
                        if m.get("view_id") == v.view_id
                    ],
                    type_evidence=type_ev,
                    type_rule_id=rule_id,
                    raw_signal_score=raw_s,
                    weighted_score=w_s,
                    normalization_factor=norm_f,
                    penalties=pen,
                    boosts=bst,
                    final_confidence=final_c,
                    notes=f"Candidato de región en página {page_idx + 1} de PDF",
                )
                candidates.append(candidate)

        return candidates, signals

    def _classify_and_score(
        self,
        ent: dict[str, Any],
        signals: list[SemanticSignal],
    ) -> tuple[
        SemanticFamily,
        str,
        str,
        list[str],
        CandidateStatus,
        float,
        float,
        float,
        float,
        float,
        float,
        list[SemanticSignal],
    ]:
        """
        Determina familia, tipo probable conservador, reglas de evidencia mínima y scoring auditable.
        """
        ent_type = ent.get("entity_type", "")
        layer = str(ent.get("layer", "")).upper()

        family = SemanticFamily.UNKNOWN
        probable_type = "UNKNOWN"
        rule_id = "RULE_FALLBACK"
        type_evidence: list[str] = []

        # Detectar hints de familia
        family_hint_sigs = [s for s in signals if s.signal_type == "LAYER_FAMILY_HINT"]
        if family_hint_sigs:
            try:
                family = SemanticFamily(family_hint_sigs[0].value)
                type_evidence.append(f"LAYER_HINT:{family_hint_sigs[0].value}")
            except ValueError:
                family = SemanticFamily.UNKNOWN

        # Contar grupos de evidencia independientes
        distinct_groups = set(s.signal_group for s in signals if not s.is_negative)
        semantic_groups = distinct_groups.intersection({
            EvidenceOrigin.CAD_LAYER,
            EvidenceOrigin.CAD_BLOCK,
            EvidenceOrigin.TEXTUAL,
            EvidenceOrigin.TABULAR,
            EvidenceOrigin.GIS,
        })
        geometric_spatial_groups = distinct_groups.intersection({
            EvidenceOrigin.GEOMETRIC,
            EvidenceOrigin.SPATIAL,
            EvidenceOrigin.STATIONING,
            EvidenceOrigin.DIMENSIONAL,
        })

        has_negative = any(s.is_negative for s in signals)

        # Reglas por tipo de entidad con vocabulario conservador
        if ent_type == "CIRCLE":
            has_layer_struct = any("PILOT" in layer or "PILA" in layer or "COLUMN" in layer for _ in [1])
            nearby_texts = [s for s in signals if s.signal_group == EvidenceOrigin.TEXTUAL and not s.is_negative]
            has_close_text = any(
                s.proximity_level in {ProximityLevel.VERY_NEAR, ProximityLevel.NEAR}
                and any(k in str(s.value).upper() for k in ["PILA", "PILOTE", "COLUMNA", "P3", "PIER"])
                for s in nearby_texts
            )

            if has_negative:
                family = SemanticFamily.UNKNOWN
                probable_type = "UNKNOWN_CIRCULAR_FEATURE"
                rule_id = "RULE_CIRCLE_NEGATIVE_CONTRADICTION"
                type_evidence.append("NEGATIVE_TEXT_CONTRADICTION")
            elif has_layer_struct and has_close_text:
                probable_type = "POSSIBLE_FOUNDATION_MEMBER"
                rule_id = "RULE_CIRCLE_LAYER_AND_NEARBY_TEXT"
                type_evidence.extend(["CIRCLE_GEOMETRY", "LAYER_STRUCTURAL", "TEXT_VERY_NEAR"])
            elif has_layer_struct:
                probable_type = "POSSIBLE_STRUCTURAL_MEMBER"
                rule_id = "RULE_CIRCLE_LAYER_ONLY"
                type_evidence.extend(["CIRCLE_GEOMETRY", "LAYER_STRUCTURAL"])
            else:
                family = SemanticFamily.UNKNOWN
                probable_type = "UNKNOWN_CIRCULAR_FEATURE"
                rule_id = "RULE_CIRCLE_ISOLATED"
                type_evidence.append("CIRCLE_GEOMETRY")

        elif ent_type == "INSERT":
            block_name = str(ent.get("name", "")).upper()
            if "COLUMN" in block_name or "COLUMNA" in block_name:
                family = SemanticFamily.STRUCTURAL
                probable_type = "POSSIBLE_COLUMN_COMPONENT"
                rule_id = "RULE_BLOCK_COLUMN"
                type_evidence.extend(["BLOCK_NAME_MATCH", "BLOCK_INSTANCE"])
            else:
                probable_type = "POSSIBLE_STRUCTURAL_MEMBER"
                rule_id = "RULE_BLOCK_GENERIC"
                type_evidence.append("BLOCK_INSTANCE")

        elif ent_type in {"LWPOLYLINE", "POLYLINE"}:
            is_closed = ent.get("closed", False)
            if "CALZADA" in layer or "PAVIMENTO" in layer:
                family = SemanticFamily.PAVEMENT
                probable_type = "POSSIBLE_SURFACE_BOUNDARY"
                rule_id = "RULE_POLYLINE_PAVEMENT_LAYER"
                type_evidence.extend(["LAYER_PAVEMENT", "CLOSED_CONTOUR" if is_closed else "OPEN_POLYLINE"])
            elif "EJE" in layer:
                family = SemanticFamily.ALIGNMENT
                probable_type = "POSSIBLE_ALIGNMENT_FEATURE"
                rule_id = "RULE_POLYLINE_ALIGNMENT_LAYER"
                type_evidence.extend(["LAYER_ALIGNMENT", "CENTERLINE_GEOMETRY"])
            else:
                probable_type = "UNKNOWN_CLOSED_PROFILE" if is_closed else "UNKNOWN_LINEAR_FEATURE"
                rule_id = "RULE_POLYLINE_UNKNOWN"
                type_evidence.append("POLYLINE_GEOMETRY")

        elif ent_type == "LINE":
            if "EJE" in layer:
                family = SemanticFamily.ALIGNMENT
                probable_type = "POSSIBLE_ALIGNMENT_FEATURE"
                rule_id = "RULE_LINE_ALIGNMENT_LAYER"
                type_evidence.extend(["LAYER_ALIGNMENT", "LINE_GEOMETRY"])
            else:
                probable_type = "UNKNOWN_LINEAR_FEATURE"
                rule_id = "RULE_LINE_GENERIC"
                type_evidence.append("LINE_GEOMETRY")

        # REGLAS DE EVIDENCIA MÍNIMA PARA ESTADO:
        # PARTIALLY_RESOLVED exige:
        # 1. Al menos 2 grupos de evidencia independientes;
        # 2. Al menos 1 señal semántica (CAD_LAYER, CAD_BLOCK, TEXTUAL);
        # 3. Al menos 1 señal geométrica o espacial (GEOMETRIC, SPATIAL, STATIONING);
        # 4. Significado técnico identificado (probable_family != UNKNOWN y probable_type != UNKNOWN_*);
        # 5. Sin contradicciones severas no resueltas.
        is_classified = (
            family != SemanticFamily.UNKNOWN
            and not probable_type.startswith("UNKNOWN_")
            and probable_type != "UNKNOWN"
        )

        if (
            len(distinct_groups) >= 2
            and len(semantic_groups) >= 1
            and len(geometric_spatial_groups) >= 1
            and is_classified
            and not has_negative
        ):
            status = CandidateStatus.PARTIALLY_RESOLVED
        else:
            status = CandidateStatus.UNRESOLVED

        # Cálculo matemático auditable
        raw_s, w_s, norm_f, pen, bst, final_c, scored_sigs = compute_candidate_confidence(
            signals=signals,
            ent_type=ent_type,
            layer=layer,
            has_contradictions=has_negative,
        )

        return (
            family,
            probable_type,
            rule_id,
            type_evidence,
            status,
            raw_s,
            w_s,
            norm_f,
            pen,
            bst,
            final_c,
            scored_sigs,
        )

    def _extract_spatial_extent(self, ent: dict[str, Any]) -> dict[str, Any]:
        ent_type = ent.get("entity_type", "")
        if ent_type == "CIRCLE":
            center = ent.get("center", {"x": 0.0, "y": 0.0, "z": 0.0})
            r = ent.get("radius", 0.0)
            return {
                "center": center,
                "radius": r,
                "bbox": {
                    "minx": center["x"] - r,
                    "miny": center["y"] - r,
                    "maxx": center["x"] + r,
                    "maxy": center["y"] + r,
                }
            }
        elif ent_type == "INSERT":
            pt = ent.get("insert", {"x": 0.0, "y": 0.0, "z": 0.0})
            return {"center": pt, "location": pt}
        elif ent_type == "LINE":
            s = ent.get("start", {"x": 0.0, "y": 0.0, "z": 0.0})
            e = ent.get("end", {"x": 0.0, "y": 0.0, "z": 0.0})
            return {
                "start": s,
                "end": e,
                "bbox": {
                    "minx": min(s["x"], e["x"]),
                    "miny": min(s["y"], e["y"]),
                    "maxx": max(s["x"], e["x"]),
                    "maxy": max(s["y"], e["y"]),
                }
            }
        elif ent_type in {"LWPOLYLINE", "POLYLINE"}:
            pts = ent.get("points", [])
            if pts:
                xs = [p["x"] for p in pts if "x" in p]
                ys = [p["y"] for p in pts if "y" in p]
                if xs and ys:
                    return {
                        "bbox": {
                            "minx": min(xs),
                            "miny": min(ys),
                            "maxx": max(xs),
                            "maxy": max(ys),
                        },
                        "vertex_count": len(pts),
                    }
        return {}

    def _detect_relations(self, candidates: list[ObjectCandidate]) -> list[CandidateRelation]:
        relations: list[CandidateRelation] = []

        for i in range(len(candidates)):
            cand_a = candidates[i]
            for j in range(i + 1, len(candidates)):
                cand_b = candidates[j]

                signals_a = {s.signal_type: s.value for s in cand_a.semantic_signals}
                signals_b = {s.signal_type: s.value for s in cand_b.semantic_signals}

                block_a = signals_a.get("BLOCK_NAME")
                block_b = signals_b.get("BLOCK_NAME")

                if block_a and block_b and block_a == block_b:
                    relations.append(
                        CandidateRelation(
                            relation_type=CandidateRelationType.POSSIBLE_REPEATED_INSTANCE,
                            source_candidate_id=cand_a.candidate_id,
                            target_candidate_id=cand_b.candidate_id,
                            confidence=0.85,
                            notes=f"Instancias repetidas del bloque {block_a!r}",
                        )
                    )

                circle_a = signals_a.get("CIRCULAR_GEOMETRY")
                circle_b = signals_b.get("CIRCULAR_GEOMETRY")
                layer_a = signals_a.get("LAYER_NAME")
                layer_b = signals_b.get("LAYER_NAME")

                if circle_a and circle_b and layer_a and layer_a == layer_b:
                    if circle_a.get("radius") == circle_b.get("radius"):
                        relations.append(
                            CandidateRelation(
                                relation_type=CandidateRelationType.POSSIBLE_REPEATED_INSTANCE,
                                source_candidate_id=cand_a.candidate_id,
                                target_candidate_id=cand_b.candidate_id,
                                confidence=0.75,
                                notes=f"Círculos de igual radio={circle_a.get('radius')} en layer {layer_a!r}",
                            )
                        )

                if (
                    cand_a.probable_family == cand_b.probable_family
                    and cand_a.probable_family in {SemanticFamily.PAVEMENT, SemanticFamily.STRUCTURAL}
                    and cand_a.probable_family != SemanticFamily.UNKNOWN
                ):
                    relations.append(
                        CandidateRelation(
                            relation_type=CandidateRelationType.POSSIBLE_SYSTEM_MEMBER,
                            source_candidate_id=cand_a.candidate_id,
                            target_candidate_id=cand_b.candidate_id,
                            confidence=0.60,
                            notes=f"Ambos candidatos pertenecen a la familia {cand_a.probable_family.value}",
                        )
                    )

        for rel in relations:
            for cand in candidates:
                if cand.candidate_id == rel.source_candidate_id or cand.candidate_id == rel.target_candidate_id:
                    if rel not in cand.candidate_relations:
                        cand.candidate_relations.append(rel)

        return relations
