import json
from pathlib import Path
import pytest

from core.config import AgentConfig
from core.models import (
    CandidateRelationType,
    CandidateStatus,
    CandidateType,
    ObjectCandidate,
    SemanticFamily,
    SemanticSignal,
    SourceReference,
    ViewEvidence,
)
from reconstruction.object_candidate_detector import ObjectCandidateDetector
from reconstruction.pipeline import ReconstructionPipeline
from reconstruction.semantic_signal_extractor import SemanticSignalExtractor


def test_isolated_circle_does_not_produce_resolved_pile():
    """
    Test 1: Un círculo aislado NO produce una pila resuelta.
    Test 8: Ninguna clase IFC física se asigna automáticamente.
    """
    detector = ObjectCandidateDetector()
    
    # Entidad CIRCLE en layer neutral, sin texto de apoyo
    entity = {
        "entity_type": "CIRCLE",
        "handle": "C_TEST_1",
        "layer": "GEOMETRIA_VARIOS",
        "center": {"x": 50.0, "y": 50.0, "z": 0.0},
        "radius": 0.6,
    }
    
    signals = detector.signal_extractor.extract_signals_for_entity(
        entity=entity,
        source_id="src_isolated",
    )
    
    (
        family,
        prob_type,
        rule_id,
        type_ev,
        status,
        raw_score,
        w_score,
        norm_factor,
        penalties,
        boosts,
        conf,
        scored_signals,
    ) = detector._classify_and_score(ent=entity, signals=signals)
    
    # Debe permanecer UNRESOLVED
    assert status == CandidateStatus.UNRESOLVED
    # No debe asignarse a IfcPile ni pile
    assert prob_type != "IfcPile"
    assert "Ifc" not in prob_type
    assert conf < 0.50


def test_layer_block_text_geometry_increases_confidence():
    """
    Test 2: layer + block + text + geometry puede elevar confianza.
    Test 7: Todas las señales son trazables.
    """
    detector = ObjectCandidateDetector()
    
    entity = {
        "entity_type": "CIRCLE",
        "handle": "C_PILA_1",
        "layer": "SUBESTRUCTURA_PILOTES",
        "center": {"x": 100.0, "y": 0.0, "z": -5.0},
        "radius": 1.2,
    }
    
    text_entities = [
        {
            "entity_type": "TEXT",
            "handle": "TXT_1",
            "layer": "TEXTOS",
            "text": "PILA P3",
            "insert": {"x": 102.0, "y": 0.0, "z": 0.0},
            "height": 2.5,
        }
    ]

    signals = detector.signal_extractor.extract_signals_for_entity(
        entity=entity,
        source_id="src_bridge",
        view_id="v_bridge",
        candidate_text_entities=text_entities,
        nearby_station=12345.67,
        station_distance=10.0,
    )
    
    # Trazabilidad de señales
    for s in signals:
        assert s.source_id == "src_bridge"
        assert s.entity_reference == "C_PILA_1"
        assert s.weight > 0
    
    (
        family,
        prob_type,
        rule_id,
        type_ev,
        status,
        raw_score,
        w_score,
        norm_factor,
        penalties,
        boosts,
        conf,
        scored_signals,
    ) = detector._classify_and_score(ent=entity, signals=signals)
    
    # Con layer + text + station, la confianza se eleva
    assert conf >= 0.70
    assert status == CandidateStatus.PARTIALLY_RESOLVED
    assert family == SemanticFamily.STRUCTURAL
    # Pero sigue sin ser clase IFC directa
    assert "Ifc" not in prob_type


def test_station_associated_as_position_not_as_object():
    """
    Test 3: station se asocia como posición, no como objeto físico.
    """
    detector = ObjectCandidateDetector()
    
    # Candidato con station asociada
    ent = {
        "entity_type": "LINE",
        "handle": "L_EJE",
        "layer": "EJE_CALZADA",
        "start": {"x": 0.0, "y": 0.0, "z": 0.0},
        "end": {"x": 100.0, "y": 0.0, "z": 0.0},
    }
    
    extent = detector._extract_spatial_extent(ent)
    candidate_id = detector._make_candidate_id("src_align", "v_plan", "L_EJE")
    
    candidate = ObjectCandidate(
        candidate_id=candidate_id,
        probable_family=SemanticFamily.ALIGNMENT,
        probable_type="ALIGNMENT_CENTERLINE",
        confidence=0.70,
        status=CandidateStatus.PARTIALLY_RESOLVED,
        station=12345.67,
        spatial_extent=extent,
    )
    
    # Station es un atributo de localización/posición escalar (float)
    assert isinstance(candidate.station, float)
    assert candidate.station == 12345.67
    # El objeto es un ALIGNMENT o elemento civil, no la estación en sí
    assert candidate.probable_family == SemanticFamily.ALIGNMENT
    assert candidate.probable_type != "STATION"


def test_repeated_blocks_produce_possible_repeated_instances():
    """
    Test 5: Mismo block repetido produce posibles instancias repetidas.
    """
    detector = ObjectCandidateDetector()
    
    cand1 = ObjectCandidate(
        candidate_id="cand_col_1",
        probable_family=SemanticFamily.STRUCTURAL,
        probable_type="POSSIBLE_COLUMN_COMPONENT",
        semantic_signals=[
            SemanticSignal(
                signal_type="BLOCK_NAME",
                value="COLUMNA_TIPO",
                source_id="src_1",
                confidence=0.7,
            )
        ]
    )
    
    cand2 = ObjectCandidate(
        candidate_id="cand_col_2",
        probable_family=SemanticFamily.STRUCTURAL,
        probable_type="POSSIBLE_COLUMN_COMPONENT",
        semantic_signals=[
            SemanticSignal(
                signal_type="BLOCK_NAME",
                value="COLUMNA_TIPO",
                source_id="src_1",
                confidence=0.7,
            )
        ]
    )
    
    relations = detector._detect_relations([cand1, cand2])
    
    assert len(relations) >= 1
    repeated_rel = [r for r in relations if r.relation_type == CandidateRelationType.POSSIBLE_REPEATED_INSTANCE]
    assert len(repeated_rel) == 1
    assert repeated_rel[0].source_candidate_id == "cand_col_1"
    assert repeated_rel[0].target_candidate_id == "cand_col_2"


def test_candidate_id_is_deterministic():
    """
    Test 6: candidate_id es determinista.
    """
    id1 = ObjectCandidateDetector._make_candidate_id("src_abc", "v_plan", "handle_100")
    id2 = ObjectCandidateDetector._make_candidate_id("src_abc", "v_plan", "handle_100")
    id_different = ObjectCandidateDetector._make_candidate_id("src_abc", "v_plan", "handle_101")
    
    assert id1 == id2
    assert id1 != id_different
    assert id1.startswith("cand_")


def test_pipeline_semantic_outputs_and_no_3d_geometry(tmp_path):
    """
    Test 4: Dos clusters producen candidatos distintos.
    Test 9: No se genera geometría 3D.
    Test 10: Salidas completas en output/semantic/.
    """
    dxf_sample = Path("scratch/test_infrastructure_sample.dxf").resolve()
    assert dxf_sample.exists()
    
    config = AgentConfig(output_dir=tmp_path)
    pipeline = ReconstructionPipeline(config=config, project_name="Test_Semantic_v02A")
    
    result = pipeline.run([dxf_sample])
    
    # 9. No se genera geometría 3D
    assert result["model_generation"]["performed"] is False
    
    # 10. Salidas generadas en output/semantic/
    semantic_dir = tmp_path / "semantic"
    assert (semantic_dir / "object_candidates.json").exists()
    assert (semantic_dir / "semantic_signals.json").exists()
    assert (semantic_dir / "candidate_relations.json").exists()
    
    with (semantic_dir / "object_candidates.json").open("r", encoding="utf-8") as f:
        cands_data = json.load(f)
    
    assert len(cands_data) > 0
    # Ninguna clase IFC asignada
    for c in cands_data:
        assert not str(c.get("probable_type", "")).startswith("Ifc")
        assert not str(c.get("probable_family", "")).startswith("Ifc")
        # Todos tienen candidate_id y señales
        assert "candidate_id" in c
        assert "semantic_signals" in c
