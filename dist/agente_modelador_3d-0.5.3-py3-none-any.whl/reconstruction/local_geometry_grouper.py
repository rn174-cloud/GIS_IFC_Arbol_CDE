"""
reconstruction/local_geometry_grouper.py
Agrupamiento Geométrico Local y Descubrimiento de Motivos para Real CAD (v0.5.2).

Cumple los principios:
1. CANONICAL CAD ENTITY -> PRIMITIVE EVIDENCE -> LOCAL GEOMETRY GROUP -> GEOMETRIC MOTIF.
2. Responsabilidad única: se ejecuta una sola vez en el pipeline.
3. Region Boundaries: Agrupamiento estrictamente region-local; nunca conecta primitivas
   de distintas regiones por cercanía geométrica.
4. Threshold adaptativo multi-factor auditable derivado de estadísticas locales:
   nearest-neighbour endpoint distances, bbox gap distribution, median, p75, p90,
   robust spread / IQR, local density, con floors y caps relativos documentados.
5. Spatial Indexing: Indexación espacial mediante shapely.STRtree / spatial grid para evitar O(N^2).
   Audita: primitive_count, spatial_queries, candidate_neighbour_pairs, actual_connectivity_checks.
6. Identidad determinista: IDs independientes del orden de procesamiento de las entidades.
7. Blocks: Un INSERT se conserva como instancia documental atómica (no se explota automáticamente).
"""
from __future__ import annotations

import hashlib
import math
from typing import Any, Optional

import numpy as np
from shapely.geometry import box, LineString, Point
from shapely.strtree import STRtree

from core.models import (
    EvidenceOrigin,
    GeometricMotif,
    LocalGeometryGroup,
    PrimitiveEvidence,
    ProximityLevel,
    SourceDocument,
    ViewEvidence,
)


class LocalGeometryGrouper:
    """
    Agrupador geométrico local y detector de motivos estructurales dentro de regiones de CAD.
    """

    def __init__(self) -> None:
        pass

    @staticmethod
    def _make_primitive_id(region_id: str, handle: str, ent_type: str, coords_repr: str) -> str:
        """
        Genera un ID determinista e independiente del orden de procesamiento para una primitiva.
        """
        raw_key = f"{region_id}::{handle}::{ent_type}::{coords_repr}".encode("utf-8")
        return f"prim_{hashlib.sha256(raw_key).hexdigest()[:12]}"

    @staticmethod
    def _make_group_id(region_id: str, member_handles: list[str], conn_type: str) -> str:
        """
        Genera un ID determinista independiente del orden de las entidades para un grupo local.
        """
        sorted_handles = sorted(str(h) for h in member_handles)
        raw_key = f"{region_id}::{','.join(sorted_handles)}::{conn_type}".encode("utf-8")
        return f"grp_{hashlib.sha256(raw_key).hexdigest()[:12]}"

    @staticmethod
    def _make_motif_id(region_id: str, motif_type: str, member_handles: list[str], key_param: str) -> str:
        """
        Genera un ID determinista para un motivo geométrico.
        """
        sorted_handles = sorted(str(h) for h in member_handles)
        raw_key = f"{region_id}::{motif_type}::{','.join(sorted_handles)}::{key_param}".encode("utf-8")
        return f"motif_{hashlib.sha256(raw_key).hexdigest()[:12]}"

    def group_cad_document(
        self,
        document: SourceDocument,
        views: list[ViewEvidence],
    ) -> tuple[
        list[PrimitiveEvidence],
        list[LocalGeometryGroup],
        list[GeometricMotif],
        dict[str, Any],
    ]:
        """
        Ejecuta la conversión canónica y el agrupamiento local por regiones.
        Retorna:
        - Primitivas tipificadas (PrimitiveEvidence)
        - Grupos geométricos locales (LocalGeometryGroup)
        - Motivos geométricos (GeometricMotif)
        - Métricas auditables de ejecución y escalabilidad
        """
        all_primitives: list[PrimitiveEvidence] = []
        all_groups: list[LocalGeometryGroup] = []
        all_motifs: list[GeometricMotif] = []

        metrics: dict[str, Any] = {
            "primitive_count": 0,
            "spatial_queries": 0,
            "candidate_neighbour_pairs": 0,
            "actual_connectivity_checks": 0,
            "region_summaries": [],
        }

        entities = document.extracted_data.get("entities", [])
        if not entities:
            return all_primitives, all_groups, all_motifs, metrics

        texts = document.extracted_data.get("texts", [])
        dimensions = document.extracted_data.get("dimensions", [])

        # Mapear entidades gráficas a vistas/regiones
        # Si no hay vistas segmentadas, se asigna una región default 'cad_modelspace'
        handle_to_view_id: dict[str, str] = {}
        for v in views:
            for h in v.entity_references:
                handle_to_view_id[str(h)] = v.view_id

        # Agrupar entidades por región para garantizar frontera estricta
        entities_by_region: dict[str, list[dict[str, Any]]] = {}
        for ent in entities:
            ent_type = ent.get("entity_type", "")
            if ent_type in {"TEXT", "MTEXT", "DIMENSION"}:
                continue
            h = str(ent.get("handle", ""))
            reg_id = handle_to_view_id.get(h, "cad_modelspace")
            entities_by_region.setdefault(reg_id, []).append(ent)

        # Procesar cada región de manera aislada (estrictamente region-local)
        for reg_id, reg_entities in entities_by_region.items():
            reg_view = next((v for v in views if v.view_id == reg_id), None)

            prim_evidences, groups, motifs, reg_stats = self._process_region(
                region_id=reg_id,
                region_entities=reg_entities,
                region_view=reg_view,
                all_texts=texts,
                all_dimensions=dimensions,
            )

            all_primitives.extend(prim_evidences)
            all_groups.extend(groups)
            all_motifs.extend(motifs)

            metrics["primitive_count"] += reg_stats.get("primitive_count", 0)
            metrics["spatial_queries"] += reg_stats.get("spatial_queries", 0)
            metrics["candidate_neighbour_pairs"] += reg_stats.get("candidate_neighbour_pairs", 0)
            metrics["actual_connectivity_checks"] += reg_stats.get("actual_connectivity_checks", 0)
            metrics["region_summaries"].append(reg_stats)

        return all_primitives, all_groups, all_motifs, metrics

    def _process_region(
        self,
        region_id: str,
        region_entities: list[dict[str, Any]],
        region_view: Optional[ViewEvidence],
        all_texts: list[dict[str, Any]],
        all_dimensions: list[dict[str, Any]],
    ) -> tuple[
        list[PrimitiveEvidence],
        list[LocalGeometryGroup],
        list[GeometricMotif],
        dict[str, Any],
    ]:
        """
        Procesa una región aislada con indexación espacial y umbral adaptativo auditable.
        """
        primitives: list[PrimitiveEvidence] = []
        reg_stats: dict[str, Any] = {
            "region_id": region_id,
            "primitive_count": len(region_entities),
            "spatial_queries": 0,
            "candidate_neighbour_pairs": 0,
            "actual_connectivity_checks": 0,
        }

        # 1. Transformar entidades a PrimitiveEvidence
        for ent in region_entities:
            pe = self._create_primitive_evidence(ent, region_id)
            if pe is not None:
                primitives.append(pe)

        if not primitives:
            return primitives, [], [], reg_stats

        # 2. Calcular umbral de conectividad adaptativo multi-factor auditable
        threshold_audit = self._compute_adaptive_threshold(primitives, region_view)
        reg_stats["threshold_audit"] = threshold_audit
        conn_threshold = threshold_audit["final_threshold"]

        # 3. Detectar Motivos Geométricos (Círculos concéntricos, etc.)
        motifs = self._detect_motifs(primitives, region_id, conn_threshold)

        # 4. Agrupamiento con Índice Espacial (STRtree) sobre primitivas conectables
        groups, group_stats = self._build_connected_groups(
            primitives=primitives,
            region_id=region_id,
            conn_threshold=conn_threshold,
            threshold_method=threshold_audit["threshold_method"],
            motifs=motifs,
        )

        reg_stats["spatial_queries"] = group_stats["spatial_queries"]
        reg_stats["candidate_neighbour_pairs"] = group_stats["candidate_neighbour_pairs"]
        reg_stats["actual_connectivity_checks"] = group_stats["actual_connectivity_checks"]
        reg_stats["group_count"] = len(groups)
        reg_stats["motif_count"] = len(motifs)

        return primitives, groups, motifs, reg_stats

    def _create_primitive_evidence(self, ent: dict[str, Any], region_id: str) -> Optional[PrimitiveEvidence]:
        """
        Crea una instancia inmutable y determinista de PrimitiveEvidence a partir de una entidad CAD.
        """
        ent_type = str(ent.get("entity_type", "")).upper()
        handle = str(ent.get("handle", ""))
        layer = str(ent.get("layer", ""))

        geometry: dict[str, Any] = {}
        bbox: dict[str, float] = {}

        if ent_type == "LINE":
            s = ent.get("start", {})
            e = ent.get("end", {})
            if "x" not in s or "x" not in e:
                return None
            p1 = [float(s["x"]), float(s["y"]), float(s.get("z", 0.0))]
            p2 = [float(e["x"]), float(e["y"]), float(e.get("z", 0.0))]
            geometry = {"p1": p1, "p2": p2, "length": math.hypot(p2[0] - p1[0], p2[1] - p1[1])}
            bbox = {
                "minx": min(p1[0], p2[0]),
                "miny": min(p1[1], p2[1]),
                "maxx": max(p1[0], p2[0]),
                "maxy": max(p1[1], p2[1]),
            }
            coords_repr = f"{p1[0]:.2f},{p1[1]:.2f}_{p2[0]:.2f},{p2[1]:.2f}"

        elif ent_type == "CIRCLE":
            c = ent.get("center", {})
            r = float(ent.get("radius", 0.0))
            if "x" not in c or "y" not in c:
                return None
            center = [float(c["x"]), float(c["y"]), float(c.get("z", 0.0))]
            geometry = {"center": center, "radius": r}
            bbox = {
                "minx": center[0] - r,
                "miny": center[1] - r,
                "maxx": center[0] + r,
                "maxy": center[1] + r,
            }
            coords_repr = f"{center[0]:.2f},{center[1]:.2f}_r{r:.2f}"

        elif ent_type == "ARC":
            c = ent.get("center", {})
            r = float(ent.get("radius", 0.0))
            sa = float(ent.get("start_angle", 0.0))
            ea = float(ent.get("end_angle", 360.0))
            if "x" not in c or "y" not in c:
                return None
            center = [float(c["x"]), float(c["y"]), float(c.get("z", 0.0))]
            # Endpoints del arco
            sa_rad = math.radians(sa)
            ea_rad = math.radians(ea)
            p1 = [center[0] + r * math.cos(sa_rad), center[1] + r * math.sin(sa_rad), center[2]]
            p2 = [center[0] + r * math.cos(ea_rad), center[1] + r * math.sin(ea_rad), center[2]]
            geometry = {"center": center, "radius": r, "start_angle": sa, "end_angle": ea, "p1": p1, "p2": p2}
            bbox = {
                "minx": center[0] - r,
                "miny": center[1] - r,
                "maxx": center[0] + r,
                "maxy": center[1] + r,
            }
            coords_repr = f"{center[0]:.2f},{center[1]:.2f}_r{r:.2f}_{sa:.1f}_{ea:.1f}"

        elif ent_type in {"LWPOLYLINE", "POLYLINE"}:
            pts = ent.get("points", [])
            if not pts:
                return None
            clean_pts = [[float(p["x"]), float(p["y"]), float(p.get("z", 0.0))] for p in pts if "x" in p and "y" in p]
            if len(clean_pts) < 2:
                return None
            xs = [p[0] for p in clean_pts]
            ys = [p[1] for p in clean_pts]
            is_closed = bool(ent.get("closed", False))
            geometry = {"points": clean_pts, "closed": is_closed, "point_count": len(clean_pts)}
            bbox = {
                "minx": min(xs),
                "miny": min(ys),
                "maxx": max(xs),
                "maxy": max(ys),
            }
            coords_repr = f"poly_{len(clean_pts)}_{xs[0]:.2f},{ys[0]:.2f}_{xs[-1]:.2f},{ys[-1]:.2f}"

        elif ent_type == "INSERT":
            # Instancia atómica de bloque documental
            ins = ent.get("insert", {})
            name = str(ent.get("name", ""))
            x = float(ins.get("x", 0.0))
            y = float(ins.get("y", 0.0))
            z = float(ins.get("z", 0.0))
            geometry = {"name": name, "insertion_point": [x, y, z], "attributes": ent.get("attributes", {})}
            bbox = {"minx": x - 0.5, "miny": y - 0.5, "maxx": x + 0.5, "maxy": y + 0.5}
            coords_repr = f"insert_{name}_{x:.2f},{y:.2f}"

        else:
            # Primitiva genérica con bbox
            if "bbox" in ent and isinstance(ent["bbox"], dict):
                bbox = ent["bbox"]
                coords_repr = f"{bbox.get('minx',0):.2f},{bbox.get('miny',0):.2f}"
            else:
                return None

        prim_id = self._make_primitive_id(region_id, handle or "nohandle", ent_type, coords_repr)

        return PrimitiveEvidence(
            primitive_id=prim_id,
            entity_handle=handle,
            entity_type=ent_type,
            layer=layer,
            bbox=bbox,
            geometry=geometry,
            region_id=region_id,
            evidence_groups=[EvidenceOrigin.GEOMETRIC.value, EvidenceOrigin.CAD_LAYER.value],
        )

    def _compute_adaptive_threshold(
        self,
        primitives: list[PrimitiveEvidence],
        region_view: Optional[ViewEvidence],
    ) -> dict[str, Any]:
        """
        Calcula el umbral de conectividad adaptativo multi-factor auditable.
        Deriva de:
        - endpoint nearest-neighbour distances;
        - bbox gap distribution;
        - median, p75, p90;
        - robust spread / IQR;
        - local density.
        """
        # Extraer puntos extremos (endpoints) de entidades lineales
        endpoints: list[list[float]] = []
        diagonals: list[float] = []

        for p in primitives:
            b = p.bbox
            dx = b.get("maxx", 0.0) - b.get("minx", 0.0)
            dy = b.get("maxy", 0.0) - b.get("miny", 0.0)
            diag = math.hypot(dx, dy)
            if diag > 1e-6:
                diagonals.append(diag)

            if "p1" in p.geometry and "p2" in p.geometry:
                endpoints.append(p.geometry["p1"][:2])
                endpoints.append(p.geometry["p2"][:2])
            elif "points" in p.geometry:
                pts = p.geometry["points"]
                if pts:
                    endpoints.append(pts[0][:2])
                    endpoints.append(pts[-1][:2])
            elif "center" in p.geometry:
                endpoints.append(p.geometry["center"][:2])

        # Dimensiones de la región
        if region_view and region_view.bounding_box:
            rb = region_view.bounding_box
            region_diag = math.hypot(rb.get("maxx", 0.0) - rb.get("minx", 0.0), rb.get("maxy", 0.0) - rb.get("miny", 0.0))
        else:
            all_minx = min(p.bbox["minx"] for p in primitives)
            all_miny = min(p.bbox["miny"] for p in primitives)
            all_maxx = max(p.bbox["maxx"] for p in primitives)
            all_maxy = max(p.bbox["maxy"] for p in primitives)
            region_diag = math.hypot(all_maxx - all_minx, all_maxy - all_miny)

        median_diag = float(np.median(diagonals)) if diagonals else 1.0

        # Calcular distancias nearest-neighbour si hay suficientes endpoints
        nn_distances: list[float] = []
        if len(endpoints) >= 4:
            pts_arr = np.array(endpoints)
            # Muestra hasta 250 puntos para rapidez
            if len(pts_arr) > 250:
                idx = np.random.RandomState(42).choice(len(pts_arr), 250, replace=False)
                sample = pts_arr[idx]
            else:
                sample = pts_arr

            for i, pt in enumerate(sample):
                diffs = sample - pt
                dists = np.hypot(diffs[:, 0], diffs[:, 1])
                # Excluir distancia cero consigo mismo
                dists = dists[dists > 1e-6]
                if len(dists) > 0:
                    nn_distances.append(float(np.min(dists)))

        if nn_distances:
            median_gap = float(np.median(nn_distances))
            p75_gap = float(np.percentile(nn_distances, 75))
            p90_gap = float(np.percentile(nn_distances, 90))
            p25_gap = float(np.percentile(nn_distances, 25))
            iqr = p75_gap - p25_gap
            local_scale = p75_gap + 0.5 * iqr
        else:
            median_gap = 0.05 * median_diag
            p75_gap = 0.08 * median_diag
            p90_gap = 0.12 * median_diag
            local_scale = median_gap

        # Floors y caps relativos para garantizar estabilidad matemática
        # Floor: 0.0005 de la diagonal regional (mínimo técnico para evitar gaps numéricos)
        # Cap: 0.05 de la diagonal regional (evita unir regiones o elementos muy distantes)
        floor_val = max(0.0005 * region_diag, 0.01)
        cap_val = max(0.05 * region_diag, 5.0 * floor_val)

        # Base adaptativa ponderada: da prioridad a las estadísticas de endpoints
        raw_threshold = max(median_gap, local_scale * 0.8)
        final_threshold = float(np.clip(raw_threshold, floor_val, cap_val))

        return {
            "threshold_method": "ADAPTIVE_LOCAL_STATS",
            "median_gap": round(median_gap, 4),
            "p75_gap": round(p75_gap, 4),
            "p90_gap": round(p90_gap, 4),
            "local_scale": round(local_scale, 4),
            "region_diag": round(region_diag, 4),
            "median_diag": round(median_diag, 4),
            "floor": round(floor_val, 4),
            "cap": round(cap_val, 4),
            "final_threshold": round(final_threshold, 4),
        }

    def _detect_motifs(
        self,
        primitives: list[PrimitiveEvidence],
        region_id: str,
        conn_threshold: float,
    ) -> list[GeometricMotif]:
        """
        Descubre motivos geométricos dentro de una región:
        - CONCENTRIC_CIRCLES: círculos concéntricos con mismo centro (tolerancia adaptativa)
        - REPEATED_CIRCLES: círculos con mismo radio distribuidos
        - PARALLEL_LINES: pares colineales/paralelos con espaciado constante
        """
        motifs: list[GeometricMotif] = []

        # 1. Círculos Concéntricos
        circles = [p for p in primitives if p.entity_type == "CIRCLE"]
        centers_map: dict[tuple[float, float], list[PrimitiveEvidence]] = {}

        tol = max(0.05, conn_threshold * 0.1)
        for c in circles:
            cen = c.geometry.get("center", [0.0, 0.0])
            # Cuantizar centro según tolerancia
            k = (round(cen[0] / tol) * tol, round(cen[1] / tol) * tol)
            centers_map.setdefault(k, []).append(c)

        for (cx, cy), c_group in centers_map.items():
            if len(c_group) >= 2:
                # Círculos con radios distintos concéntricos
                radii = sorted([float(c.geometry.get("radius", 0.0)) for c in c_group])
                member_ids = [c.primitive_id for c in c_group]
                member_handles = [c.entity_handle for c in c_group if c.entity_handle]
                outer_r = radii[-1]
                bbox = {
                    "minx": cx - outer_r,
                    "miny": cy - outer_r,
                    "maxx": cx + outer_r,
                    "maxy": cy + outer_r,
                }
                motif_id = self._make_motif_id(region_id, "CONCENTRIC_CIRCLES", member_handles, f"{cx:.2f}_{cy:.2f}")
                motifs.append(
                    GeometricMotif(
                        motif_id=motif_id,
                        motif_type="CONCENTRIC_CIRCLES",
                        member_primitive_ids=member_ids,
                        member_handles=member_handles,
                        bbox=bbox,
                        region_id=region_id,
                        properties={
                            "center": [cx, cy],
                            "radii": radii,
                            "circle_count": len(c_group),
                            "outer_radius": outer_r,
                            "inner_radius": radii[0],
                        },
                        confidence=0.85,
                    )
                )

        return motifs

    def _build_connected_groups(
        self,
        primitives: list[PrimitiveEvidence],
        region_id: str,
        conn_threshold: float,
        threshold_method: str,
        motifs: list[GeometricMotif],
    ) -> tuple[list[LocalGeometryGroup], dict[str, int]]:
        """
        Construye connected components sobre primitivas lineales y arcos usando índice espacial (STRtree).
        Evita comparación exhaustiva N^2.
        """
        groups: list[LocalGeometryGroup] = []
        stats = {
            "spatial_queries": 0,
            "candidate_neighbour_pairs": 0,
            "actual_connectivity_checks": 0,
        }

        # Filtrar primitivas conectables (LINE, ARC, LWPOLYLINE, POLYLINE)
        connectable: list[PrimitiveEvidence] = []
        for p in primitives:
            if p.entity_type in {"LINE", "ARC", "LWPOLYLINE", "POLYLINE"}:
                connectable.append(p)

        if not connectable:
            return groups, stats

        # Preparar geometrías Shapely expandidas por conn_threshold / 2 para consulta STRtree
        shapely_boxes = []
        for p in connectable:
            b = p.bbox
            shapely_boxes.append(
                box(
                    b["minx"] - conn_threshold,
                    b["miny"] - conn_threshold,
                    b["maxx"] + conn_threshold,
                    b["maxy"] + conn_threshold,
                )
            )

        tree = STRtree(shapely_boxes)
        n = len(connectable)

        # Union-Find para componentes conexos
        parent = list(range(n))

        def find(i: int) -> int:
            path = []
            while parent[i] != i:
                path.append(i)
                i = parent[i]
            for node in path:
                parent[node] = i
            return i

        def union(i: int, j: int) -> None:
            root_i = find(i)
            root_j = find(j)
            if root_i != root_j:
                parent[root_i] = root_j

        # Consultar vecinos cercanos usando el STRtree
        checked_pairs: set[tuple[int, int]] = set()

        for i in range(n):
            stats["spatial_queries"] += 1
            cand_indices = tree.query(shapely_boxes[i])

            for j in cand_indices:
                if i == j:
                    continue
                pair = (min(i, j), max(i, j))
                if pair in checked_pairs:
                    continue
                checked_pairs.add(pair)
                stats["candidate_neighbour_pairs"] += 1

                # Comprobar conectividad extrema real
                stats["actual_connectivity_checks"] += 1
                if self._are_primitives_connected(connectable[i], connectable[j], conn_threshold):
                    union(i, j)

        # Agrupar miembros por componente conexo
        components: dict[int, list[int]] = {}
        for i in range(n):
            root = find(i)
            components.setdefault(root, []).append(i)

        # Crear LocalGeometryGroup solo para componentes con >= 2 primitivas conectadas
        for root, member_indices in components.items():
            if len(member_indices) < 2:
                # Primitiva aislada: no se promueve a grupo geométrico local
                continue

            members = [connectable[idx] for idx in member_indices]
            member_ids = [m.primitive_id for m in members]
            member_handles = [m.entity_handle for m in members if m.entity_handle]

            # Bounding box del grupo
            grp_minx = min(m.bbox["minx"] for m in members)
            grp_miny = min(m.bbox["miny"] for m in members)
            grp_maxx = max(m.bbox["maxx"] for m in members)
            grp_maxy = max(m.bbox["maxy"] for m in members)
            grp_bbox = {"minx": grp_minx, "miny": grp_miny, "maxx": grp_maxx, "maxy": grp_maxy}

            # Evaluar si la cadena forma un contorno cerrado (CLOSED_CONTOUR)
            is_closed = self._is_chain_closed(members, conn_threshold)
            conn_type = "CLOSED_CONTOUR" if is_closed else "CONNECTED_CHAIN"

            grp_id = self._make_group_id(region_id, member_handles, conn_type)

            groups.append(
                LocalGeometryGroup(
                    group_id=grp_id,
                    member_primitive_ids=member_ids,
                    member_handles=member_handles,
                    bbox=grp_bbox,
                    region_id=region_id,
                    connectivity_type=conn_type,
                    connectivity_threshold=conn_threshold,
                    threshold_method=threshold_method,
                    confidence=0.75 if is_closed else 0.60,
                )
            )

        return groups, stats

    def _are_primitives_connected(self, p1: PrimitiveEvidence, p2: PrimitiveEvidence, threshold: float) -> bool:
        """
        Determina si dos primitivas lineales/arcos comparten extremos dentro del umbral adaptativo.
        """
        ends1 = self._get_endpoints(p1)
        ends2 = self._get_endpoints(p2)

        if not ends1 or not ends2:
            return False

        for e1 in ends1:
            for e2 in ends2:
                if math.hypot(e1[0] - e2[0], e1[1] - e2[1]) <= threshold:
                    return True
        return False

    @staticmethod
    def _get_endpoints(p: PrimitiveEvidence) -> list[list[float]]:
        """
        Obtiene los puntos extremos de una primitiva.
        """
        if "p1" in p.geometry and "p2" in p.geometry:
            return [p.geometry["p1"][:2], p.geometry["p2"][:2]]
        elif "points" in p.geometry:
            pts = p.geometry["points"]
            if len(pts) >= 2:
                return [pts[0][:2], pts[-1][:2]]
        return []

    def _is_chain_closed(self, members: list[PrimitiveEvidence], threshold: float) -> bool:
        """
        Verifica si un conjunto de primitivas forma un ciclo cerrado (cada vértice conectado con valencia >= 2).
        """
        if len(members) < 3:
            return False

        # Si alguna polilínea de los miembros ya es cerrada por sí misma
        for m in members:
            if m.geometry.get("closed", False):
                return True

        # Cuantizar endpoints para contar valencias
        endpoints = []
        for m in members:
            ends = self._get_endpoints(m)
            if len(ends) == 2:
                endpoints.extend(ends)

        if len(endpoints) < 6:
            return False

        # Agrupar endpoints por cercanía <= threshold
        clusters: list[list[list[float]]] = []
        for pt in endpoints:
            placed = False
            for c in clusters:
                if math.hypot(pt[0] - c[0][0], pt[1] - c[0][1]) <= threshold:
                    c.append(pt)
                    placed = True
                    break
            if not placed:
                clusters.append([pt])

        # En un ciclo cerrado, cada cluster de extremos tiene al menos 2 incidencias
        valences = [len(c) for c in clusters]
        return len(valences) >= 3 and all(v >= 2 for v in valences)
