from __future__ import annotations

import math
from typing import Any
from core.models import (
    ParametricGeometry,
    QualityConfidenceLevel,
    RecipeType,
    ReconstructedObject,
)


class GeometryValidator:
    """
    Motor de validación geométrica contra la documentación fuente y round-trip dimensional.
    
    Responsabilidad:
    - Comprobar TODOS los parámetros geométricos críticos de la receta, mapeando equivalencias
      canónicas (ej. DIAMETRO <-> 2 * RADIO).
    - Ningún parámetro crítico puede quedar silenciosamente omitido.
    - Si falta cualquier parámetro o discrepa fuera de tolerancia: ROUND_TRIP_INCOMPLETE o FAIL,
      invalidando is_built y prohibiendo QualityConfidenceLevel.VERIFIED.
    """

    def __init__(self, default_tolerance: float = 0.005) -> None:
        self.default_tolerance = default_tolerance

    def validate_geometry(
        self,
        obj: ReconstructedObject,
        geom: ParametricGeometry,
    ) -> tuple[list[dict[str, Any]], QualityConfidenceLevel]:
        """
        Ejecuta la batería de validaciones dimensionales y round-trip completo.
        """
        validation_results: list[dict[str, Any]] = []

        if not geom.is_built:
            return validation_results, QualityConfidenceLevel.NOT_EVALUATED

        # Determinar parámetros críticos requeridos según la receta
        if geom.geometry_type == RecipeType.CIRCULAR_EXTRUSION:
            critical_requirements = ["RADIO", "ALTURA"]
        elif geom.geometry_type == RecipeType.RECTANGULAR_EXTRUSION:
            critical_requirements = ["ANCHO", "ESPESOR", "LONGITUD"]
        else:
            critical_requirements = list(geom.parameters.keys())

        all_passed = True
        round_trip_complete = True

        for req_param in critical_requirements:
            actual = float(geom.parameters.get(req_param, 0.0))
            expected: float | None = None
            src_param_name: str | None = None
            evidence_status_val = "UNKNOWN"

            # 1. Búsqueda directa
            if req_param in obj.parameters:
                p = obj.parameters[req_param]
                if isinstance(p.value, (int, float)):
                    expected = float(p.value)
                    src_param_name = req_param
                    evidence_status_val = p.status.value

            # 2. Mapeo de equivalencias canónicas
            if expected is None:
                if req_param == "RADIO" and "DIAMETRO" in obj.parameters:
                    p = obj.parameters["DIAMETRO"]
                    if isinstance(p.value, (int, float)):
                        expected = float(p.value) / 2.0
                        src_param_name = "DIAMETRO"
                        evidence_status_val = p.status.value

            # Si el parámetro crítico no pudo mapearse contra la fuente: ROUND_TRIP_INCOMPLETE
            if expected is None or src_param_name is None:
                round_trip_complete = False
                all_passed = False
                validation_results.append({
                    "parameter": req_param,
                    "source_parameter": None,
                    "derived_expected_parameter": req_param,
                    "generated_parameter": req_param,
                    "expected": None,
                    "actual": actual,
                    "absolute_error": None,
                    "relative_error": None,
                    "tolerance": self.default_tolerance,
                    "status": "FAIL",
                    "validation_type": "ROUND_TRIP_DIMENSIONAL",
                    "evidence_status": "MISSING",
                    "reason": f"ROUND_TRIP_INCOMPLETE: Parámetro crítico {req_param} no documentado en objeto",
                })
                continue

            diff = abs(actual - expected)
            rel_err = round(diff / expected, 6) if expected > 0 else 0.0
            status = "PASS" if diff <= self.default_tolerance else "FAIL"
            if status == "FAIL":
                all_passed = False

            validation_results.append({
                "parameter": src_param_name,
                "source_parameter": src_param_name,
                "derived_expected_parameter": req_param,
                "generated_parameter": req_param,
                "expected": round(expected, 6),
                "actual": round(actual, 6),
                "absolute_error": round(diff, 6),
                "difference": round(diff, 6),
                "relative_error": rel_err,
                "tolerance": self.default_tolerance,
                "status": status,
                "validation_type": "ROUND_TRIP_DIMENSIONAL",
                "evidence_status": evidence_status_val,
            })

        # Validar consistencia del bounding box
        if geom.bounding_box:
            bbox = geom.bounding_box
            dx = bbox["maxx"] - bbox["minx"]
            dy = bbox["maxy"] - bbox["miny"]
            dz = bbox["maxz"] - bbox["minz"]

            bbox_pass = (dx > 0 and dy > 0 and dz > 0)
            if not bbox_pass:
                all_passed = False

            validation_results.append({
                "parameter": "BOUNDING_BOX_EXTENTS",
                "dx": round(dx, 4),
                "dy": round(dy, 4),
                "dz": round(dz, 4),
                "status": "PASS" if bbox_pass else "FAIL",
                "validation_type": "EXTENTS_CONSISTENCY",
            })

        # Determinar nivel final de confianza geométrica
        can_be_verified = (geom.geometry_confidence in {QualityConfidenceLevel.HIGH, QualityConfidenceLevel.VERIFIED})
        if all_passed and round_trip_complete and can_be_verified and validation_results:
            final_conf = QualityConfidenceLevel.VERIFIED
        elif all_passed and round_trip_complete and geom.is_built:
            final_conf = geom.geometry_confidence
        else:
            final_conf = QualityConfidenceLevel.LOW
            geom.is_built = False
            if not round_trip_complete:
                geom.build_failure_reason = "ROUND_TRIP_INCOMPLETE"
            elif not all_passed:
                geom.build_failure_reason = "ROUND_TRIP_TOLERANCE_EXCEEDED"

        return validation_results, final_conf
