"""
reconstruction/relationship_reasoner.py
Razonamiento relacional y grafo de relaciones ontológicas/funcionales para v0.6.0.
La identidad de un objeto emerge no solo de su forma 2D/3D, sino de su contexto,
rol documental, relaciones topológicas y funcionales, cotas y texto.
"""
from __future__ import annotations

from typing import Any, Optional

from core.models import (
    AssetRelationship,
    AssetRelationshipType,
    EvidenceStatus,
    ObjectCandidate,
    ObjectHypothesis,
    ReconstructedObject,
    RelationshipGraph,
    SourceReference,
)


class RelationshipReasoner:
    """
    Infiere y valida relaciones ontológicas y funcionales entre componentes y ensamblajes.
    """

    SUPPORTED_RELATIONS = {r.value for r in AssetRelationshipType}

    def infer_relationships(
        self,
        objects: list[ReconstructedObject | ObjectHypothesis | ObjectCandidate],
        context_system_relations: Optional[list[dict[str, Any]]] = None,
    ) -> RelationshipGraph:
        """
        Infiere y compila el grafo de relaciones a partir de la jerarquía espacial,
        subsistemas y relaciones documentadas.
        """
        context_system_relations = context_system_relations or []
        relationships: list[AssetRelationship] = []

        # Indexar por id y clasificar por sistema / elevación / estación si disponible
        for i, obj_a in enumerate(objects):
            id_a = getattr(obj_a, "object_id", None) or getattr(obj_a, "hypothesis_id", None) or getattr(obj_a, "candidate_id", f"obj_{i}")
            sys_a = getattr(obj_a, "system", None)
            family_a = getattr(obj_a, "family", None) or getattr(obj_a, "probable_family", None)
            family_a_str = family_a.value if hasattr(family_a, "value") else str(family_a or "")

            # 1. Relación de tipología e instancia (TYPE_OF / INSTANCE_OF)
            typology_ref = getattr(obj_a, "metadata", {}).get("typology_id") if hasattr(obj_a, "metadata") else None
            if typology_ref:
                relationships.append(
                    AssetRelationship(
                        relation_type=AssetRelationshipType.INSTANCE_OF.value,
                        source_id=id_a,
                        target_id=typology_ref,
                        confidence=0.90,
                        evidence_status=EvidenceStatus.DOCUMENTED,
                        notes="Bound to governed typology specification",
                    )
                )

            # 2. Relaciones espaciales y de soporte entre pares de objetos
            for j, obj_b in enumerate(objects):
                if i >= j:
                    continue
                id_b = getattr(obj_b, "object_id", None) or getattr(obj_b, "hypothesis_id", None) or getattr(obj_b, "candidate_id", f"obj_{j}")
                sys_b = getattr(obj_b, "system", None)
                family_b = getattr(obj_b, "family", None) or getattr(obj_b, "probable_family", None)
                family_b_str = family_b.value if hasattr(family_b, "value") else str(family_b or "")

                # Relaciones estructurales directas
                if sys_a == "SUPERSTRUCTURE" and sys_b == "SUBSTRUCTURE":
                    relationships.append(
                        AssetRelationship(
                            relation_type=AssetRelationshipType.SUPPORTED_BY.value,
                            source_id=id_a,
                            target_id=id_b,
                            confidence=0.75,
                            evidence_status=EvidenceStatus.DERIVED,
                            notes="Superstructure is supported by Substructure piers/abutments",
                        )
                    )
                elif sys_a == "SUBSTRUCTURE" and sys_b == "FOUNDATIONS":
                    relationships.append(
                        AssetRelationship(
                            relation_type=AssetRelationshipType.SUPPORTED_BY.value,
                            source_id=id_a,
                            target_id=id_b,
                            confidence=0.75,
                            evidence_status=EvidenceStatus.DERIVED,
                            notes="Substructure is supported by Foundation piles/footings",
                        )
                    )
                elif "LIGHTING" in family_a_str and "STRUCTURAL" in family_b_str:
                    relationships.append(
                        AssetRelationship(
                            relation_type=AssetRelationshipType.LOCATED_ON.value,
                            source_id=id_a,
                            target_id=id_b,
                            confidence=0.65,
                            evidence_status=EvidenceStatus.INFERRED,
                            notes="Lighting fixture/pole located on structural deck/ground",
                        )
                    )

        # 3. Incorporar relaciones de sistema provistas por el contexto de ensamblaje
        for csr in context_system_relations:
            src = csr.get("source", "")
            rel = csr.get("relation", AssetRelationshipType.PART_OF.value)
            tgt = csr.get("target", "")
            if rel in self.SUPPORTED_RELATIONS and src and tgt:
                relationships.append(
                    AssetRelationship(
                        relation_type=rel,
                        source_id=src,
                        target_id=tgt,
                        confidence=0.80,
                        evidence_status=EvidenceStatus.DERIVED,
                        notes="Archetypal system relation derived from facility assembly hypothesis",
                    )
                )

        return RelationshipGraph(relations=relationships)
