from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import ifcopenshell
import ifcopenshell.api
import ifcopenshell.api.aggregate
import ifcopenshell.api.context
import ifcopenshell.api.pset
import ifcopenshell.api.root
import ifcopenshell.api.spatial
import ifcopenshell.api.unit

from core.geometry_kernel import LocalFrame, Point3D, Vector3D
from core.models import ReconstructedObject


IFC_SCHEMA = "IFC4X3_ADD2"


@dataclass
class IFCProjectContext:
    model: ifcopenshell.file
    project: Any
    site: Any
    facility: Any
    context_model: Any
    context_body: Any


class IFCFactory:
    """
    Fábrica genérica para creación de modelos IFC 4.3
    orientados a infraestructura.

    PRINCIPIOS:

    1. La salida principal es IFC4X3_ADD2.
    2. No asumir que el activo es un edificio.
    3. Utilizar la clase IFC más específica disponible.
    4. Separar geometría, semántica y trazabilidad.
    5. No crear geometría si faltan parámetros críticos.
    """

    def __init__(
        self,
        project_name: str,
        facility_name: str,
        facility_class: str = "IfcFacility",
    ) -> None:

        self.project_name = project_name
        self.facility_name = facility_name
        self.facility_class = facility_class

        self.context = self._create_project_context()

    @property
    def model(self) -> ifcopenshell.file:
        return self.context.model

    def _create_project_context(
        self,
    ) -> IFCProjectContext:
        """
        Crea estructura base IFC 4.3:

        IfcProject
        └── IfcSite
            └── IfcFacility / IfcBridge / IfcRoad /
                IfcRailway / otra clase válida
        """

        model = ifcopenshell.file(
            schema=IFC_SCHEMA
        )

        project = (
            ifcopenshell.api.root.create_entity(
                model,
                ifc_class="IfcProject",
                name=self.project_name,
            )
        )

        ifcopenshell.api.unit.assign_unit(
            model,
            length={
                "is_metric": True,
                "raw": "METERS",
            },
        )

        context_model = (
            ifcopenshell.api.context.add_context(
                model,
                context_type="Model",
            )
        )

        context_body = (
            ifcopenshell.api.context.add_context(
                model,
                context_type="Model",
                context_identifier="Body",
                target_view="MODEL_VIEW",
                parent=context_model,
            )
        )

        site = (
            ifcopenshell.api.root.create_entity(
                model,
                ifc_class="IfcSite",
                name="Infrastructure Site",
            )
        )

        ifcopenshell.api.aggregate.assign_object(
            model,
            relating_object=project,
            products=[site],
        )

        facility = self._create_facility(
            model=model,
            site=site,
        )

        return IFCProjectContext(
            model=model,
            project=project,
            site=site,
            facility=facility,
            context_model=context_model,
            context_body=context_body,
        )

    def _create_facility(
        self,
        model: ifcopenshell.file,
        site: Any,
    ) -> Any:
        """
        Crea la infraestructura principal.

        facility_class puede ser, según corresponda:

        - IfcFacility
        - IfcBridge
        - IfcRoad
        - IfcRailway
        - IfcMarineFacility
        - otra clase IFC 4.3 válida.

        Si la clase solicitada no existe en el schema,
        se genera un error explícito.
        """

        try:
            facility = (
                ifcopenshell.api.root.create_entity(
                    model,
                    ifc_class=self.facility_class,
                    name=self.facility_name,
                )
            )

        except Exception as exc:
            raise ValueError(
                "No fue posible crear la clase IFC "
                f"{self.facility_class!r} en {IFC_SCHEMA}."
            ) from exc

        ifcopenshell.api.aggregate.assign_object(
            model,
            relating_object=site,
            products=[facility],
        )

        return facility

    def create_rectangular_extrusion(
        self,
        name: str,
        ifc_class: str,
        width: float,
        height: float,
        depth: float,
        frame: LocalFrame,
        predefined_type: Optional[str] = None,
    ) -> Any:
        """
        Crea un sólido rectangular extruido.

        width:
            dimensión local X del perfil.

        height:
            dimensión local Y del perfil.

        depth:
            longitud de extrusión en el eje longitudinal.

        frame:
            sistema local del objeto.

        Este método no determina qué representa la geometría.
        Esa decisión debe venir del reconstructor.
        """

        self._validate_positive_dimension(
            width,
            "width",
        )
        self._validate_positive_dimension(
            height,
            "height",
        )
        self._validate_positive_dimension(
            depth,
            "depth",
        )

        profile = self.model.create_entity(
            "IfcRectangleProfileDef",
            ProfileType="AREA",
            XDim=float(width),
            YDim=float(height),
        )

        placement = self._axis_placement_from_frame(
            frame
        )

        solid = self.model.create_entity(
            "IfcExtrudedAreaSolid",
            SweptArea=profile,
            Position=placement,
            ExtrudedDirection=self.model.create_entity(
                "IfcDirection",
                DirectionRatios=(0.0, 0.0, 1.0),
            ),
            Depth=float(depth),
        )

        representation = (
            self.model.create_entity(
                "IfcShapeRepresentation",
                ContextOfItems=(
                    self.context.context_body
                ),
                RepresentationIdentifier="Body",
                RepresentationType="SweptSolid",
                Items=[solid],
            )
        )

        product = (
            ifcopenshell.api.root.create_entity(
                self.model,
                ifc_class=ifc_class,
                name=name,
                predefined_type=predefined_type,
            )
        )

        product.Representation = (
            self.model.create_entity(
                "IfcProductDefinitionShape",
                Representations=[representation],
            )
        )

        self.assign_to_facility(product)

        return product

    def create_circular_extrusion(
        self,
        name: str,
        ifc_class: str,
        radius: float,
        depth: float,
        frame: LocalFrame,
        predefined_type: Optional[str] = None,
    ) -> Any:
        """
        Crea un sólido cilíndrico o tubular simple
        a partir de un perfil circular.
        """

        self._validate_positive_dimension(
            radius,
            "radius",
        )
        self._validate_positive_dimension(
            depth,
            "depth",
        )

        profile = self.model.create_entity(
            "IfcCircleProfileDef",
            ProfileType="AREA",
            Radius=float(radius),
        )

        placement = self._axis_placement_from_frame(
            frame
        )

        solid = self.model.create_entity(
            "IfcExtrudedAreaSolid",
            SweptArea=profile,
            Position=placement,
            ExtrudedDirection=self.model.create_entity(
                "IfcDirection",
                DirectionRatios=(0.0, 0.0, 1.0),
            ),
            Depth=float(depth),
        )

        representation = (
            self.model.create_entity(
                "IfcShapeRepresentation",
                ContextOfItems=(
                    self.context.context_body
                ),
                RepresentationIdentifier="Body",
                RepresentationType="SweptSolid",
                Items=[solid],
            )
        )

        product = (
            ifcopenshell.api.root.create_entity(
                self.model,
                ifc_class=ifc_class,
                name=name,
                predefined_type=predefined_type,
            )
        )

        product.Representation = (
            self.model.create_entity(
                "IfcProductDefinitionShape",
                Representations=[representation],
            )
        )

        self.assign_to_facility(product)

        return product

    def create_product_without_geometry(
        self,
        name: str,
        ifc_class: str,
        predefined_type: Optional[str] = None,
    ) -> Any:
        """
        Crea un producto IFC sin geometría.

        Puede utilizarse temporalmente en AUDIT/EXTRACT
        cuando existe evidencia semántica del activo,
        pero todavía no existe geometría verificable.

        No debe utilizarse para ocultar un DATA_GAP.
        """

        product = (
            ifcopenshell.api.root.create_entity(
                self.model,
                ifc_class=ifc_class,
                name=name,
                predefined_type=predefined_type,
            )
        )

        self.assign_to_facility(product)

        return product

    def assign_to_facility(
        self,
        product: Any,
    ) -> None:
        """
        Asigna un producto al contenedor principal
        de infraestructura.
        """

        ifcopenshell.api.spatial.assign_container(
            self.model,
            relating_structure=(
                self.context.facility
            ),
            products=[product],
        )

    def add_traceability_pset(
        self,
        product: Any,
        reconstructed_object: ReconstructedObject,
    ) -> Any:
        """
        Crea Pset_SourceTraceability.

        Conserva el vínculo entre el objeto IFC y
        su evidencia documental.
        """

        pset = ifcopenshell.api.pset.add_pset(
            self.model,
            product=product,
            name="Pset_SourceTraceability",
        )

        source_files = sorted(
            set(
                reconstructed_object.source_documents
            )
        )

        properties = {
            "ObjectId": (
                reconstructed_object.object_id
            ),
            "ObjectType": (
                reconstructed_object.object_type
                or ""
            ),
            "Family": (
                reconstructed_object.family
                or ""
            ),
            "System": (
                reconstructed_object.system
                or ""
            ),
            "Subsystem": (
                reconstructed_object.subsystem
                or ""
            ),
            "ConfidenceLevel": (
                reconstructed_object
                .confidence_level
                .value
            ),
            "SourceFiles": "; ".join(
                source_files
            ),
        }

        if reconstructed_object.global_id:
            properties[
                "PreviousGlobalId"
            ] = reconstructed_object.global_id

        ifcopenshell.api.pset.edit_pset(
            self.model,
            pset=pset,
            properties=properties,
        )

        return pset

    def add_parameter_pset(
        self,
        product: Any,
        reconstructed_object: ReconstructedObject,
        pset_name: str = "Pset_ReconstructedParameters",
    ) -> Any:
        """
        Transfiere parámetros simples del objeto reconstruido
        a un Property Set IFC.

        Solo se exportan automáticamente valores escalares
        compatibles.

        La trazabilidad detallada permanece también
        en la matriz externa de parámetros.
        """

        pset = ifcopenshell.api.pset.add_pset(
            self.model,
            product=product,
            name=pset_name,
        )

        properties: dict[str, Any] = {}

        for parameter in (
            reconstructed_object.parameters.values()
        ):
            value = parameter.value

            if isinstance(
                value,
                (str, int, float, bool),
            ):
                properties[
                    parameter.name
                ] = value

                properties[
                    f"{parameter.name}_Status"
                ] = parameter.status.value

                if parameter.unit:
                    properties[
                        f"{parameter.name}_Unit"
                    ] = parameter.unit

        if properties:
            ifcopenshell.api.pset.edit_pset(
                self.model,
                pset=pset,
                properties=properties,
            )

        return pset

    def apply_reconstructed_object_metadata(
        self,
        product: Any,
        reconstructed_object: ReconstructedObject,
    ) -> None:
        """
        Aplica trazabilidad y parámetros básicos
        a un producto IFC ya creado.
        """

        reconstructed_object.update_confidence_level()

        self.add_traceability_pset(
            product,
            reconstructed_object,
        )

        self.add_parameter_pset(
            product,
            reconstructed_object,
        )

    def preserve_global_id_if_valid(
        self,
        product: Any,
        previous_global_id: Optional[str],
    ) -> None:
        """
        Preserva un GlobalId existente cuando el objeto
        sigue representando el mismo activo real.

        El llamador debe haber validado previamente
        que la identidad del activo no cambió.
        """

        if not previous_global_id:
            return

        try:
            product.GlobalId = previous_global_id

        except Exception as exc:
            raise ValueError(
                "No fue posible preservar el GlobalId "
                f"{previous_global_id!r}."
            ) from exc

    def write(
        self,
        output_path: str | Path,
    ) -> Path:
        """
        Guarda el modelo IFC.

        Verifica:
        - extensión .ifc;
        - creación del directorio padre.
        """

        path = Path(
            output_path
        ).expanduser().resolve()

        if path.suffix.lower() != ".ifc":
            path = path.with_suffix(".ifc")

        path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        self.model.write(
            str(path)
        )

        return path

    def _axis_placement_from_frame(
        self,
        frame: LocalFrame,
    ) -> Any:
        """
        Convierte LocalFrame a IfcAxis2Placement3D.

        El eje local Z de IFC se alinea con la dirección
        longitudinal de extrusión.

        RefDirection utiliza el eje transversal.
        """

        origin = frame.origin

        axis = frame.longitudinal.normalized()
        ref_direction = frame.transverse.normalized()

        return self.model.create_entity(
            "IfcAxis2Placement3D",
            Location=self.model.create_entity(
                "IfcCartesianPoint",
                Coordinates=(
                    float(origin.x),
                    float(origin.y),
                    float(origin.z),
                ),
            ),
            Axis=self.model.create_entity(
                "IfcDirection",
                DirectionRatios=(
                    float(axis.x),
                    float(axis.y),
                    float(axis.z),
                ),
            ),
            RefDirection=self.model.create_entity(
                "IfcDirection",
                DirectionRatios=(
                    float(ref_direction.x),
                    float(ref_direction.y),
                    float(ref_direction.z),
                ),
            ),
        )

    @staticmethod
    def _validate_positive_dimension(
        value: float,
        name: str,
    ) -> None:
        """
        Prohíbe dimensiones nulas o negativas.
        """

        if value is None:
            raise ValueError(
                f"La dimensión {name!r} no puede ser None."
            )

        if float(value) <= 0.0:
            raise ValueError(
                f"La dimensión {name!r} debe ser positiva. "
                f"Valor recibido: {value!r}"
            )


def create_frame(
    origin: Point3D,
    longitudinal: Vector3D,
    transverse: Optional[Vector3D] = None,
) -> LocalFrame:
    """
    Helper para construir un LocalFrame válido.

    Si no se proporciona transverse,
    se utiliza el kernel geométrico para generar
    una base ortonormal.
    """

    from core.geometry_kernel import (
        build_local_frame_from_direction,
        cross,
    )

    if transverse is None:
        return build_local_frame_from_direction(
            origin=origin,
            longitudinal=longitudinal,
        )

    long_unit = longitudinal.normalized()
    trans_unit = transverse.normalized()

    vertical = cross(
        long_unit,
        trans_unit,
    ).normalized()

    return LocalFrame(
        origin=origin,
        longitudinal=long_unit,
        transverse=trans_unit,
        vertical=vertical,
    )
