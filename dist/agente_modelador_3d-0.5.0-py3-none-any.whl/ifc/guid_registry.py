from __future__ import annotations

import json
from pathlib import Path
from typing import Optional
import ifcopenshell.guid


class IFCGuidRegistry:
    """
    Registro persistente de mapeo object_id -> GlobalId (GUID IFC).
    
    Responsabilidad:
    Garantizar que un mismo activo real preserve su GlobalId ante reconstrucciones
    o actualizaciones (UPDATE), evitando que un cambio geométrico del mismo objeto
    genere una nueva identidad IFC.
    """

    def __init__(self, registry_file: Path | str) -> None:
        self.registry_file = Path(registry_file)
        self._registry: dict[str, str] = {}
        self.load()

    def load(self) -> None:
        if self.registry_file.exists():
            try:
                with self.registry_file.open("r", encoding="utf-8") as f:
                    self._registry = json.load(f)
            except Exception:
                self._registry = {}
        else:
            self._registry = {}

    def save(self) -> None:
        self.registry_file.parent.mkdir(parents=True, exist_ok=True)
        with self.registry_file.open("w", encoding="utf-8") as f:
            json.dump(self._registry, f, ensure_ascii=False, indent=2)

    def get_or_create_guid(self, object_id: str, existing_global_id: Optional[str] = None) -> str:
        """
        Devuelve el GlobalId existente o crea uno nuevo de 22 caracteres válido para IFC.
        """
        # 1. Si ya está registrado para este object_id, preservarlo
        if object_id in self._registry:
            return self._registry[object_id]

        # 2. Si se proporciona un existing_global_id válido, registrarlo
        if existing_global_id and len(existing_global_id) == 22:
            self._registry[object_id] = existing_global_id
            self.save()
            return existing_global_id

        # 3. Generar nuevo GUID IFC conforme a estándar
        new_guid = ifcopenshell.guid.new()
        self._registry[object_id] = new_guid
        self.save()
        return new_guid

    def all_mappings(self) -> dict[str, str]:
        return dict(self._registry)
