from core.geometry_kernel import (
    Point3D,
    Vector3D,
    build_local_frame_from_points,
    distance,
    interpolate_point,
    point_at_distance_on_polyline,
    polyline_length,
)


def test_distance():
    a = Point3D(0.0, 0.0, 0.0)
    b = Point3D(3.0, 4.0, 0.0)

    assert distance(a, b) == 5.0


def test_interpolate_point():
    a = Point3D(0.0, 0.0, 0.0)
    b = Point3D(10.0, 0.0, 0.0)

    p = interpolate_point(
        a,
        b,
        0.5,
    )

    assert p == Point3D(
        5.0,
        0.0,
        0.0,
    )


def test_polyline_length():
    points = [
        Point3D(0.0, 0.0, 0.0),
        Point3D(3.0, 4.0, 0.0),
        Point3D(6.0, 8.0, 0.0),
    ]

    assert polyline_length(
        points
    ) == 10.0


def test_point_at_distance_on_polyline():
    points = [
        Point3D(0.0, 0.0, 0.0),
        Point3D(10.0, 0.0, 0.0),
    ]

    p = point_at_distance_on_polyline(
        points,
        4.0,
    )

    assert p == Point3D(
        4.0,
        0.0,
        0.0,
    )


def test_local_frame_is_normalized():
    frame = build_local_frame_from_points(
        Point3D(0.0, 0.0, 0.0),
        Point3D(10.0, 0.0, 0.0),
    )

    assert frame.longitudinal == Vector3D(
        1.0,
        0.0,
        0.0,
    )

    assert abs(
        frame.transverse.magnitude
        - 1.0
    ) < 1e-9

    assert abs(
        frame.vertical.magnitude
        - 1.0
    ) < 1e-9
