from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterable

from core.models import (
    CandidateType,
    EvidenceStatus,
    ParameterValue,
    SourceReference,
    ViewEvidence,
)


@dataclass(frozen=True)
class ExtractedMeasurement:
    """
    Medición o token técnico encontrado en evidencia documental.

    candidate_type clasifica la naturaleza técnica del valor:
    - MEASUREMENT: dimensión física (ancho, espesor, cota, etc.)
    - STATION: progresiva / kilometraje (eje lineal, NO activo físico)
    - ELEVATION: cota altimétrica sobre el nivel de referencia
    - ANGLE: orientación, rumbo, azimut o ángulo
    - IDENTIFIER: código o número de identificación
    - COUNT: cantidad entera de elementos
    - UNKNOWN_NUMERIC: valor numérico no contextualizado
    """

    raw_text: str
    value: float
    unit: str | None
    source: SourceReference
    candidate_type: CandidateType = CandidateType.UNKNOWN_NUMERIC
    status: EvidenceStatus = EvidenceStatus.DOCUMENTED
    derivation_method: str | None = None
    derivation_inputs: dict[str, Any] | None = None
    raw_act_measurement: float | None = None
    dimension_handle: str | None = None
    dimension_type: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_type": self.candidate_type.value,
            "raw_text": self.raw_text,
            "value": self.value,
            "unit": self.unit,
            "source": self.source.to_dict() if hasattr(self.source, "to_dict") else self.source,
            "status": self.status.value,
            "derivation_method": self.derivation_method,
            "derivation_inputs": self.derivation_inputs,
            "raw_act_measurement": self.raw_act_measurement,
            "dimension_handle": self.dimension_handle,
            "dimension_type": self.dimension_type,
        }


class ParameterExtractor:
    """
    Extractor conservador de valores y cotas documentales.

    PRINCIPIO:

    detectar un número no significa conocer automáticamente
    su significado técnico.

    Este módulo extrae candidatos clasificados.
    La asociación:

    valor -> dimensión -> objeto

    debe resolverse posteriormente.
    """

    STATION_PATTERN = re.compile(
        r"""
        (?P<full_station>
            (?:PK|KM)?\s*
            (?P<km>\d+)\s*\+\s*
            (?P<meters>\d+(?:[.,]\d+)?)
        )
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    ELEVATION_PATTERN = re.compile(
        r"""
        (?:COTA|ELEV|EL|Z)\s*[=:]?\s*
        (?P<value>[-+]?\d+(?:[.,]\d+)?)\s*
        (?P<unit>m|mm|cm)?
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    ANGLE_PATTERN = re.compile(
        r"""
        (?P<value>[-+]?\d+(?:[.,]\d+)?)\s*
        (?P<unit>°|deg|gon|rad)
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    DIMENSION_EXPRESSION_PATTERN = re.compile(
        r"""
        (?P<label>[A-ZÁÉÍÓÚÑ_]+)\s*=\s*
        (?P<value>[-+]?\d+(?:[.,]\d+)?)\s*
        (?P<unit>mm|cm|km|m)?
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    NUMBER_UNIT_PATTERN = re.compile(
        r"""
        (?<![\w.])
        (?P<value>
            [-+]?
            (?:\d+(?:[.,]\d+)?)
        )
        \s*
        (?P<unit>
            mm|cm|km|m
        )?
        (?![\w+])
        """,
        re.IGNORECASE | re.VERBOSE,
    )

    def extract_measurements(
        self,
        view: ViewEvidence,
    ) -> list[ExtractedMeasurement]:
        """
        Extrae candidatos numéricos de los textos asociados a una vista,
        clasificándolos según su tipo técnico y evitando duplicaciones.
        """

        measurements: list[ExtractedMeasurement] = []

        for text in view.texts:
            consumed_spans: list[tuple[int, int]] = []

            # 1. Progresivas / Stations (PK 12+345.67, KM 12+345.67, 12+345.67)
            for match in self.STATION_PATTERN.finditer(text):
                km = float(self._parse_number(match.group("km")))
                meters = float(self._parse_number(match.group("meters")))
                station_m = km * 1000.0 + meters
                consumed_spans.append(match.span())

                measurements.append(
                    ExtractedMeasurement(
                        raw_text=match.group("full_station").strip(),
                        value=station_m,
                        unit="m",
                        source=view.source,
                        candidate_type=CandidateType.STATION,
                    )
                )

            # 2. Expresiones dimensionales explícitas (ANCHO = 7.30 m, ESPESOR = 0.20 m)
            for match in self.DIMENSION_EXPRESSION_PATTERN.finditer(text):
                # Verificar si se solapa con algo ya consumido
                span = match.span()
                if any(start <= span[0] and span[1] <= end for start, end in consumed_spans):
                    continue

                consumed_spans.append(span)
                val = self._parse_number(match.group("value"))
                unit = match.group("unit").lower() if match.group("unit") else None

                measurements.append(
                    ExtractedMeasurement(
                        raw_text=match.group(0).strip(),
                        value=val,
                        unit=unit,
                        source=view.source,
                        candidate_type=CandidateType.MEASUREMENT,
                    )
                )

            # 3. Elevaciones (COTA = 125.40 m)
            for match in self.ELEVATION_PATTERN.finditer(text):
                span = match.span()
                if any(start <= span[0] and span[1] <= end for start, end in consumed_spans):
                    continue

                consumed_spans.append(span)
                val = self._parse_number(match.group("value"))
                unit = match.group("unit").lower() if match.group("unit") else "m"

                measurements.append(
                    ExtractedMeasurement(
                        raw_text=match.group(0).strip(),
                        value=val,
                        unit=unit,
                        source=view.source,
                        candidate_type=CandidateType.ELEVATION,
                    )
                )

            # 4. Ángulos
            for match in self.ANGLE_PATTERN.finditer(text):
                span = match.span()
                if any(start <= span[0] and span[1] <= end for start, end in consumed_spans):
                    continue

                consumed_spans.append(span)
                val = self._parse_number(match.group("value"))
                unit = match.group("unit").lower()

                measurements.append(
                    ExtractedMeasurement(
                        raw_text=match.group(0).strip(),
                        value=val,
                        unit=unit,
                        source=view.source,
                        candidate_type=CandidateType.ANGLE,
                    )
                )

            # 5. Mediciones generales / números restantes
            for match in self.NUMBER_UNIT_PATTERN.finditer(text):
                span = match.span()
                # Omitir si este fragmento fue parte de una estación, elevación o dimensión ya procesada
                if any(not (span[1] <= start or span[0] >= end) for start, end in consumed_spans):
                    continue

                raw_value = match.group("value")
                value = self._parse_number(raw_value)
                unit = match.group("unit").lower() if match.group("unit") else None

                cand_type = (
                    CandidateType.MEASUREMENT
                    if unit in {"mm", "cm", "m", "km"}
                    else CandidateType.UNKNOWN_NUMERIC
                )

                measurements.append(
                    ExtractedMeasurement(
                        raw_text=match.group(0).strip(),
                        value=value,
                        unit=unit,
                        source=view.source,
                        candidate_type=cand_type,
                    )
                )

        # 6. Dimensiones estructuradas (DIMENSION entities asociadas a la vista)
        if getattr(view, "dimensions", None):
            dim_measurements = self.extract_from_cad_dimensions(
                dimensions=view.dimensions,
                source=view.source,
            )
            measurements.extend(dim_measurements)

        return measurements

    def extract_from_cad_dimensions(
        self,
        dimensions: list[dict[str, Any]],
        source: SourceReference,
    ) -> list[ExtractedMeasurement]:
        """
        Extrae y clasifica mediciones a partir de entidades CAD DIMENSION.

        POLÍTICA DE DERIVACIÓN (v0.5.1):
        - Si existe measurement documentado y positivo (> 0.0):
          EvidenceStatus = DOCUMENTED.
        - Si measurement <= 0.0 o None (ej. LibreDWG act_measurement = -1.0):
          * ALIGNED:
            Derivar mediante distancia euclidiana entre puntos de definición
            únicamente cuando la geometría de los 2 defpoints sea inequívoca.
          * LINEAR / ROTATED:
            Determinar el eje/orientación documental de la dimensión.
            Proyectar la separación de los puntos sobre dicho eje.
            Derivar únicamente si la proyección es inequívoca.
          * Geometría ambigua o faltante:
            No derivar -> status UNRESOLVED / no genera medición ficticia.
        - Toda medición derivada:
          EvidenceStatus = DERIVED
          unit = source_unit si existe, o "CAD_UNIT" si INSUNITS == 0 o UNKNOWN (NUNCA forzar a metros).
        """
        results: list[ExtractedMeasurement] = []

        for dim in dimensions:
            handle = dim.get("handle")
            dim_type = str(dim.get("dimension_type", "LINEAR")).upper()
            meas = dim.get("measurement")
            text_override = dim.get("text_override")
            def_pts = dim.get("definition_points", [])

            dim_source = SourceReference(
                source_file=source.source_file,
                source_type=source.source_type,
                sheet=source.sheet,
                layer=dim.get("layer") or source.layer,
                entity_id=handle or source.entity_id,
                view=source.view,
            )

            # Determinar unidad contextual
            unit = source.coordinate_reference or "CAD_UNIT"
            if unit in {"UNKNOWN", None, ""}:
                unit = "CAD_UNIT"

            # 1. Valor Documentado explícito (> 0.0)
            if meas is not None and meas > 0.0:
                raw_txt = text_override or f"DIM_{handle}_{meas:.3f}"
                results.append(
                    ExtractedMeasurement(
                        raw_text=raw_txt,
                        value=float(meas),
                        unit=unit,
                        source=dim_source,
                        candidate_type=CandidateType.MEASUREMENT,
                        status=EvidenceStatus.DOCUMENTED,
                        raw_act_measurement=float(meas),
                        dimension_handle=handle,
                        dimension_type=dim_type,
                    )
                )
                continue

            # 2. Derivación Geométrica cuando measurement <= 0.0 o None
            # Requiere al menos 2 puntos de definición (p1=xline1, p2=xline2)
            if len(def_pts) < 2:
                # Geometría insuficiente -> DIMENSION_UNRESOLVED (no inventar)
                continue

            # En DXF/DWG estándar:
            # Si len(def_pts) >= 3: def_pts[0] = p0 (línea de cota), def_pts[1] = p1, def_pts[2] = p2
            # Si len(def_pts) == 2: def_pts[0] = p1, def_pts[1] = p2
            if len(def_pts) >= 3:
                p0, p1, p2 = def_pts[0], def_pts[1], def_pts[2]
            else:
                p0, p1, p2 = None, def_pts[0], def_pts[1]

            dx = abs(p2[0] - p1[0])
            dy = abs(p2[1] - p1[1])
            euc_dist = (dx * dx + dy * dy) ** 0.5

            if euc_dist < 1e-6:
                # Puntos coincidentes o degenerados -> no derivable
                continue

            derived_val: float | None = None
            derivation_method: str | None = None
            derivation_inputs: dict[str, Any] = {
                "p1": list(p1),
                "p2": list(p2),
                "dimension_type": dim_type,
            }
            if p0 is not None:
                derivation_inputs["p0"] = list(p0)

            if "ALIGNED" in dim_type:
                # ALIGNED DIMENSION: La dimensión mide la distancia directa entre puntos de extensión
                derived_val = round(euc_dist, 4)
                derivation_method = "ALIGNED_DEFINITION_POINTS_EUCLIDEAN"
                derivation_inputs["euclidean_distance"] = euc_dist

            elif "LINEAR" in dim_type or "ROTATED" in dim_type:
                # LINEAR DIMENSION: Requiere proyectar sobre el eje de la cota
                # Determinamos el eje canónico (Horizontal X vs Vertical Y) a partir de:
                # A) Coincidencia de coordenadas en puntos de definición
                # B) Posición de la línea de cota p0 respecto a p1/p2
                is_vertical = False
                is_horizontal = False

                if dx < 1e-4 and dy > 1e-4:
                    # p1 y p2 están en la misma vertical
                    is_vertical = True
                elif dy < 1e-4 and dx > 1e-4:
                    # p1 y p2 están en la misma horizontal
                    is_horizontal = True
                elif p0 is not None:
                    # Evaluar hacia dónde corre la línea de cota p0
                    # Si p0 comparte X con p1 o p2 -> cota vertical midiendo dy
                    # Si p0 comparte Y con p1 o p2 -> cota horizontal midiendo dx
                    if abs(p0[0] - p1[0]) < 1e-3 or abs(p0[0] - p2[0]) < 1e-3:
                        is_vertical = True
                    elif abs(p0[1] - p1[1]) < 1e-3 or abs(p0[1] - p2[1]) < 1e-3:
                        is_horizontal = True
                    else:
                        # Evaluar la separación dominante
                        if dy > 5.0 * dx:
                            is_vertical = True
                        elif dx > 5.0 * dy:
                            is_horizontal = True

                if is_vertical:
                    derived_val = round(dy, 4)
                    derivation_method = "LINEAR_VERTICAL_AXIS_PROJECTION"
                    derivation_inputs["projected_axis"] = "Y"
                    derivation_inputs["delta_y"] = dy
                elif is_horizontal:
                    derived_val = round(dx, 4)
                    derivation_method = "LINEAR_HORIZONTAL_AXIS_PROJECTION"
                    derivation_inputs["projected_axis"] = "X"
                    derivation_inputs["delta_x"] = dx
                else:
                    # Si no es puramente horizontal ni vertical pero euc_dist es inequívoca:
                    # Si la rotación documental no está disponible y los deltas son oblicuos:
                    # Mantener DIMENSION_UNRESOLVED
                    derived_val = None

            if derived_val is not None:
                raw_txt = text_override or f"DIM_{handle}_DERIVED_{derived_val:.3f}"
                results.append(
                    ExtractedMeasurement(
                        raw_text=raw_txt,
                        value=derived_val,
                        unit=unit,
                        source=dim_source,
                        candidate_type=CandidateType.MEASUREMENT,
                        status=EvidenceStatus.DERIVED,
                        derivation_method=derivation_method,
                        derivation_inputs=derivation_inputs,
                        raw_act_measurement=meas,
                        dimension_handle=handle,
                        dimension_type=dim_type,
                    )
                )

        return results

    def extract_station_values(
        self,
        texts: Iterable[str],
    ) -> list[float]:
        """
        Convierte progresivas tipo:

        PK 12+345.67

        a metros acumulados:

        12345.67

        IMPORTANTE:
        una progresiva es una posición sobre un eje.
        NO representa un objeto físico.
        """

        stations: list[
            float
        ] = []

        for text in texts:

            for pattern in (
                self.STATION_PATTERNS
            ):

                for match in (
                    pattern.finditer(
                        text
                    )
                ):

                    km = float(
                        self._parse_number(
                            match.group(1)
                        )
                    )

                    meters = float(
                        self._parse_number(
                            match.group(2)
                        )
                    )

                    stations.append(
                        km * 1000.0
                        + meters
                    )

        return stations

    def parameter_from_documented_value(
        self,
        name: str,
        value: float | str,
        unit: str | None,
        source: SourceReference,
        notes: str | None = None,
    ) -> ParameterValue:
        """
        Helper para crear explícitamente un parámetro
        documentado cuando la asociación semántica ya
        fue resuelta por otra etapa.
        """

        return ParameterValue(
            name=name,
            value=value,
            unit=unit,
            status=(
                EvidenceStatus.DOCUMENTED
            ),
            sources=[
                source
            ],
            notes=notes,
        )

    @staticmethod
    def normalize_length(
        value: float,
        unit: str | None,
    ) -> tuple[
        float,
        str | None,
    ]:
        """
        Normaliza longitudes conocidas a metros.

        Si la unidad es desconocida, NO se asume.
        """

        if unit is None:
            return (
                value,
                None,
            )

        normalized = (
            unit.lower()
        )

        factors = {
            "mm": 0.001,
            "cm": 0.01,
            "m": 1.0,
            "km": 1000.0,
        }

        if normalized not in factors:
            return (
                value,
                unit,
            )

        return (
            value
            * factors[
                normalized
            ],
            "m",
        )

    @staticmethod
    def _parse_number(
        value: str,
    ) -> float:
        """
        Soporta separador decimal coma o punto.
        """

        normalized = (
            value.strip()
            .replace(
                ",",
                ".",
            )
        )

        return float(
            normalized
        )
