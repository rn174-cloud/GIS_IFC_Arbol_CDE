from __future__ import annotations

from readers.dwg.base import (
    CapabilityStatus,
    DWGProvider,
    ProviderCapabilities,
    ProviderHealth,
)
from readers.dwg.libredwg_provider import LibreDWGProvider
from readers.dwg.models import (
    CanonicalCADBlock,
    CanonicalCADBlockReference,
    CanonicalCADDimension,
    CanonicalCADDocument,
    CanonicalCADEntity,
    CanonicalCADLayer,
    CanonicalCADLayout,
    CanonicalCADText,
    CanonicalCADViewport,
    CanonicalCADXRef,
    CanonicalIngestionStrategy,
    CanonicalSpaceType,
    CanonicalUnitStatus,
    CanonicalXRefStatus,
)
from readers.dwg.registry import DWGProviderRegistry, get_dwg_registry

__all__ = [
    "DWGProvider",
    "ProviderCapabilities",
    "ProviderHealth",
    "CapabilityStatus",
    "LibreDWGProvider",
    "DWGProviderRegistry",
    "get_dwg_registry",
    "CanonicalCADDocument",
    "CanonicalCADEntity",
    "CanonicalCADLayer",
    "CanonicalCADBlock",
    "CanonicalCADBlockReference",
    "CanonicalCADLayout",
    "CanonicalCADViewport",
    "CanonicalCADText",
    "CanonicalCADDimension",
    "CanonicalCADXRef",
    "CanonicalSpaceType",
    "CanonicalUnitStatus",
    "CanonicalXRefStatus",
    "CanonicalIngestionStrategy",
]
