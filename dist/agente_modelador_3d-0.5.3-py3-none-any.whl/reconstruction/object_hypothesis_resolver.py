from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from core.models import (
    CandidateStatus,
    CandidateType,
    ConfidenceLevel,
    ConsolidatedParameter,
    DataGap,
    DocumentConflict,
    EvidenceMatch,
    EvidenceStatus,
    MatchDecision,
    ObjectCandidate,
    ObjectConfidenceBreakdown,
    ObjectHypothesis,
    ParameterBindingCandidate,
    ParameterReadiness,
    ParameterValue,
    QualityConfidenceLevel,
    ReconstructedObject,
    SemanticFamily,
    SourceReference,
    UnitResolutionStatus,
    ViewEvidence,
)
from reconstruction.multidocument_synthesizer import MultidocumentSynthesizer
from reconstruction.parameter_binding_resolver import ParameterBindingResolver
from reconstruction.unit_resolver import UnitResolver


class ObjectHypothesisResolver:
    """
    Consolidador de hipótesis de objeto real a partir de EvidenceMatch y ObjectCandidates.

    Responsabilidad en v0.5.3:
    1. Agrupar candidatos conectados por decisiones SAME_OBJECT;
    2. Mantener hipótesis abiertas en POSSIBLE_SAME_OBJECT;
    3. Bloquear fusión en DIFFERENT_OBJECT o conflictos severos;
    4. Respetar REPEATED_INSTANCE conservando objetos distintos;
    5. Vincular cotas a parámetros físicos reales con ParameterBindingResolver (sin colapsar en DIMENSION_GENERAL);
    6. Resolver unidades y escalas documentalmente con UnitResolver;
    7. Aplicar Multidocument Identity Gate con MultidocumentSynthesizer;
    8. Consolidar parámetros auditando compatibilidad y generando DOCUMENT_CONFLICT únicamente ante incompatibilidades reales;
    9. Generar ReconstructedObject preliminares (drafts);
    10. Asignar object_id determinista basado en evidencia verificable.
    """

    def __init__(
        self,
        binding_resolver: Optional[ParameterBindingResolver] = None,
        synthesizer: Optional[MultidocumentSynthesizer] = None,
        unit_resolver: Optional[UnitResolver] = None,
    ) -> None:
        self.unit_resolver = unit_resolver or UnitResolver()
        self.binding_resolver = binding_resolver or ParameterBindingResolver(unit_resolver=self.unit_resolver)
        self.synthesizer = synthesizer or MultidocumentSynthesizer(unit_resolver=self.unit_resolver)

    @staticmethod
    def generate_deterministic_object_id(
        family: SemanticFamily,
        station: float | None,
        label: str | None,
        member_ids: list[str],
        offset: float | None = None,
        source_hashes: list[str] | None = None,
    ) -> str:
        """
        Genera un object_id reproducible e independiente del orden de procesamiento.
        
        Garantiza que stations distintas muy próximas (ej. PK 12+345.60 vs PK 12+346.40)
        NUNCA colisionen por redondeo destructivo. El hash determinista incorpora
        la representación canónica completa (estación con precisión decimal exacta,
        offset, miembros ordenados y fuentes).
        """
        # La parte legible abrevia para inspección humana limpia
        st_label = f"PK{int(round(station))}" if station is not None else "NOST"
        lbl_str = label.strip().replace(" ", "_").upper() if label else "UNLABELED"

        # La identidad HASH es estricta, canónica y sin pérdida de precisión:
        st_canonical = f"{station:.4f}" if station is not None else "NONE"
        off_canonical = f"{offset:.4f}" if offset is not None else "NONE"
        sorted_members = sorted(member_ids)
        sorted_sources = sorted(source_hashes) if source_hashes else []

        seed_parts = [
            family.value,
            lbl_str,
            st_canonical,
            off_canonical,
            ":".join(sorted_members),
            ":".join(sorted_sources),
        ]
        hash_seed = "::".join(seed_parts).encode("utf-8")
        h_suffix = hashlib.sha256(hash_seed).hexdigest()[:10]
        return f"obj_{family.value[:4]}_{st_label}_{h_suffix}"

    def resolve_hypotheses_and_drafts(
        self,
        candidates: list[ObjectCandidate],
        matches: list[EvidenceMatch],
        views_dict: dict[str, ViewEvidence] | None = None,
        documents: list[Any] | None = None,
    ) -> tuple[list[ObjectHypothesis], list[ReconstructedObject]]:
        """
        Construye hipótesis de objeto y genera drafts de ReconstructedObject preliminares.
        """
        cand_map: dict[str, ObjectCandidate] = {c.candidate_id: c for c in candidates}

        # Pre-calcular evidencia documental de unidades por documento fuente
        doc_unit_evidence_map: dict[str, dict[str, Any]] = {}
        if documents:
            for doc in documents:
                s_id = getattr(doc, "source_id", None) or str(getattr(doc, "path", ""))
                ev = self.unit_resolver.detect_document_unit_evidence(doc)
                doc_unit_evidence_map[s_id] = ev
                if hasattr(doc, "path") and doc.path:
                    doc_unit_evidence_map[Path(doc.path).name] = ev
                    doc_unit_evidence_map[str(doc.path)] = ev

        # 1. Agrupamiento de candidatos según decisiones de match
        # Usamos un grafo de conjuntos disjuntos (Union-Find) para agrupar únicamente SAME_OBJECT
        parent: dict[str, str] = {c_id: c_id for c_id in cand_map}

        def find(i: str) -> str:
            if parent[i] == i:
                return i
            parent[i] = find(parent[i])
            return parent[i]

        def union(i: str, j: str) -> None:
            root_i = find(i)
            root_j = find(j)
            if root_i != root_j:
                parent[root_i] = root_j

        for m in matches:
            if m.decision == MatchDecision.SAME_OBJECT:
                cand_a = cand_map.get(m.candidate_a_id)
                cand_b = cand_map.get(m.candidate_b_id)
                src_a = cand_a.source_ids[0] if (cand_a and cand_a.source_ids) else ""
                src_b = cand_b.source_ids[0] if (cand_b and cand_b.source_ids) else ""
                if src_a and src_b and src_a != src_b:
                    # MULTIDOCUMENT IDENTITY GATE:
                    # Exigir autorización formal antes de fusionar entre documentos
                    ok, dec, conf, ev = self.synthesizer.evaluate_multidocument_identity_gate(cand_a, cand_b)
                    if not ok or dec != "SAME_OBJECT":
                        continue
                union(m.candidate_a_id, m.candidate_b_id)

        # Agrupar IDs de candidatos por su raíz
        clusters: dict[str, list[str]] = {}
        for c_id in cand_map:
            root = find(c_id)
            clusters.setdefault(root, []).append(c_id)

        hypotheses: list[ObjectHypothesis] = []
        reconstructed_drafts: list[ReconstructedObject] = []

        for root, member_ids in clusters.items():
            members = [cand_map[m_id] for m_id in member_ids]

            # Encontrar matches que involucran a estos miembros
            sup_matches: list[str] = []
            contra_matches: list[str] = []
            for m in matches:
                if m.candidate_a_id in member_ids and m.candidate_b_id in member_ids:
                    if m.decision in {MatchDecision.SAME_OBJECT, MatchDecision.POSSIBLE_SAME_OBJECT}:
                        sup_matches.append(m.match_id)
                    elif m.decision == MatchDecision.DIFFERENT_OBJECT:
                        contra_matches.append(m.match_id)
                elif m.candidate_a_id in member_ids or m.candidate_b_id in member_ids:
                    if m.decision == MatchDecision.SAME_OBJECT:
                        sup_matches.append(m.match_id)

            # Familia y tipo consensuados
            families = [m.probable_family for m in members if m.probable_family != SemanticFamily.UNKNOWN]
            consensus_family = families[0] if families else SemanticFamily.UNKNOWN

            types = [m.probable_type for m in members if not m.probable_type.startswith("UNKNOWN_")]
            consensus_type = types[0] if types else "UNKNOWN_OBJECT"

            # Estación y localización promedio o consensuada
            stations = [m.station for m in members if m.station is not None]
            consensus_station = round(sum(stations) / len(stations), 2) if stations else None

            offsets = [m.offset for m in members if m.offset is not None]
            consensus_offset = round(sum(offsets) / len(offsets), 2) if offsets else None

            elevations = [m.elevation for m in members if m.elevation is not None]
            consensus_elevation = round(sum(elevations) / len(elevations), 2) if elevations else None

            # Fuentes y vistas agregadas
            all_source_ids = sorted(list(set().union(*[m.source_ids for m in members])))
            all_view_ids = sorted(list(set().union(*[m.view_ids for m in members])))

            # Confianza consolidada: promedio ponderado más boost por evidencia multi-candidato
            avg_conf = sum(m.confidence for m in members) / len(members)
            consol_conf = min(0.95, avg_conf + (0.10 if len(members) > 1 else 0.0))
            if contra_matches:
                consol_conf = max(0.10, consol_conf - 0.30)

            status = CandidateStatus.UNRESOLVED
            if len(members) >= 2 and not contra_matches and consol_conf >= 0.70:
                status = CandidateStatus.PARTIALLY_RESOLVED
            elif members and members[0].status == CandidateStatus.PARTIALLY_RESOLVED and not contra_matches:
                status = CandidateStatus.PARTIALLY_RESOLVED
            elif members and (len(members[0].parameter_candidates) > 0 or len(members[0].related_texts) > 0 or consol_conf >= 0.50):
                status = CandidateStatus.PARTIALLY_RESOLVED

            # Consolidar parámetros y detectar conflictos
            param_candidates = []
            for m in members:
                param_candidates.extend(m.parameter_candidates)

            is_single = (len(member_ids) == 1)
            hyp_id = f"hyp_{hashlib.sha256('::'.join(sorted(member_ids)).encode('utf-8')).hexdigest()[:10]}"

            hypothesis = ObjectHypothesis(
                hypothesis_id=hyp_id,
                member_candidate_ids=sorted(member_ids),
                probable_family=consensus_family,
                probable_type=consensus_type,
                resolution_status=status,
                confidence=round(consol_conf, 3),
                supporting_matches=sup_matches,
                contradicting_matches=contra_matches,
                parameter_candidates=param_candidates,
                spatial_reference={
                    "station": consensus_station,
                    "offset": consensus_offset,
                    "elevation": consensus_elevation,
                },
                station=consensus_station,
                offset=consensus_offset,
                elevation=consensus_elevation,
                source_ids=all_source_ids,
                view_ids=all_view_ids,
                unresolved_questions=["Confirmar parámetros geométricos 3D"] if status != CandidateStatus.RESOLVED else [],
                data_gaps=["ELEVACION_COTA"] if consensus_elevation is None else [],
                is_singleton=is_single,
                notes=f"Hipótesis consolidada a partir de {len(members)} candidatos.",
            )
            hypotheses.append(hypothesis)

            # 2. Generar ReconstructedObject preliminar si alcanza status PARTIALLY_RESOLVED o evidencia suficiente
            if status in {CandidateStatus.PARTIALLY_RESOLVED, CandidateStatus.RESOLVED}:
                draft_obj = self._build_reconstructed_draft(
                    hypothesis=hypothesis,
                    members=members,
                    views_dict=views_dict,
                    doc_unit_evidence_map=doc_unit_evidence_map,
                )
                reconstructed_drafts.append(draft_obj)

        return hypotheses, reconstructed_drafts

    def _build_reconstructed_draft(
        self,
        hypothesis: ObjectHypothesis,
        members: list[ObjectCandidate],
        views_dict: dict[str, ViewEvidence] | None = None,
        doc_unit_evidence_map: dict[str, dict[str, Any]] | None = None,
    ) -> ReconstructedObject:
        """
        Construye el draft preliminar de ReconstructedObject con parámetros consolidados y geometry_definition VACÍA.
        """
        all_labels = [lbl for m in members for lbl in m.labels]
        rep_label = all_labels[0] if all_labels else None

        # Hash de fuentes para reproducibilidad canónica
        source_hashes = [s for s in hypothesis.source_ids]

        obj_id = self.generate_deterministic_object_id(
            family=hypothesis.probable_family,
            station=hypothesis.station,
            label=rep_label,
            member_ids=hypothesis.member_candidate_ids,
            offset=hypothesis.offset,
            source_hashes=source_hashes,
        )

        draft = ReconstructedObject(
            object_id=obj_id,
            name=f"{hypothesis.probable_type}_{obj_id}",
            object_type=hypothesis.probable_type,
            family=hypothesis.probable_family.value,
            system=None,
            subsystem=None,
            ifc_class=None,            # REGLA: Ninguna clase IFC física aún
            ifc_predefined_type=None,
            geometry_definition={},    # REGLA: VACÍA por ahora
            spatial_reference=hypothesis.spatial_reference,
            source_documents=hypothesis.source_ids,
            confidence_level=ConfidenceLevel.C_PARTIALLY_INFERRED if hypothesis.confidence < 0.85 else ConfidenceLevel.B_MOSTLY_VERIFIED,
            metadata={
                "hypothesis_id": hypothesis.hypothesis_id,
                "member_candidate_ids": hypothesis.member_candidate_ids,
            },
        )

        # Consolidar parámetros y registrar conflictos documentales
        self._consolidate_parameters(draft, hypothesis, members, views_dict, doc_unit_evidence_map)

        # Evaluar desglose explícito de confianza (Confidence Breakdown)
        # 1. geometry_confidence DEBE SER NOT_EVALUATED mientras geometry_definition esté vacía
        geom_conf = (
            QualityConfidenceLevel.VERIFIED
            if (draft.geometry_definition and draft.ifc_class)
            else QualityConfidenceLevel.NOT_EVALUATED
        )

        # 2. identity_confidence: basada en congruencia multivista y número de miembros
        if len(members) >= 2 and not hypothesis.contradicting_matches and hypothesis.confidence >= 0.80:
            ident_conf = QualityConfidenceLevel.HIGH
        elif len(members) >= 2:
            ident_conf = QualityConfidenceLevel.MEDIUM
        else:
            ident_conf = QualityConfidenceLevel.LOW

        # 3. semantic_confidence: basada en solidez del tipo y familia reconocidos
        if hypothesis.probable_family != SemanticFamily.UNKNOWN and not hypothesis.probable_type.startswith("UNKNOWN_"):
            sem_conf = QualityConfidenceLevel.HIGH if hypothesis.confidence >= 0.75 else QualityConfidenceLevel.MEDIUM
        else:
            sem_conf = QualityConfidenceLevel.LOW

        # 4. parameter_confidence: se degrada si hay conflictos, gaps o parámetros UNKNOWN
        if draft.conflicts or any(p.status == EvidenceStatus.UNKNOWN for p in draft.parameters.values()):
            param_conf = QualityConfidenceLevel.LOW
        elif draft.data_gaps or any(p.status == EvidenceStatus.PROVISIONAL for p in draft.parameters.values()):
            param_conf = QualityConfidenceLevel.MEDIUM
        elif draft.parameters and all(p.status in {EvidenceStatus.DOCUMENTED, EvidenceStatus.DERIVED} for p in draft.parameters.values()):
            param_conf = QualityConfidenceLevel.HIGH
        else:
            param_conf = QualityConfidenceLevel.MEDIUM

        draft.confidence_breakdown = ObjectConfidenceBreakdown(
            identity_confidence=ident_conf,
            semantic_confidence=sem_conf,
            parameter_confidence=param_conf,
            geometry_confidence=geom_conf,
        )

        # Asociar vistas
        if views_dict:
            for v_id in hypothesis.view_ids:
                if v_id in views_dict:
                    draft.views.append(views_dict[v_id])

        return draft

    def _consolidate_parameters(
        self,
        draft: ReconstructedObject,
        hypothesis: ObjectHypothesis,
        members: list[ObjectCandidate],
        views_dict: dict[str, ViewEvidence] | None = None,
        doc_unit_evidence_map: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        """
        Aplica parameter binding local, unit resolution y síntesis multidocumental v0.5.3.
        Elimina el colapso en DIMENSION_GENERAL y restringe DOCUMENT_CONFLICT a discrepancias
        reales del mismo parámetro físico.
        """
        # 1. Recuperar bbox y datos espaciales combinados de los miembros
        combined_bbox: dict[str, float] = {}
        for m in members:
            sp = m.spatial_extent or {}
            bb = sp.get("bbox")
            if bb and isinstance(bb, dict):
                combined_bbox = {
                    "minx": min(combined_bbox.get("minx", bb.get("minx", 0.0)), bb.get("minx", 0.0)),
                    "miny": min(combined_bbox.get("miny", bb.get("miny", 0.0)), bb.get("miny", 0.0)),
                    "maxx": max(combined_bbox.get("maxx", bb.get("maxx", 0.0)), bb.get("maxx", 0.0)),
                    "maxy": max(combined_bbox.get("maxy", bb.get("maxy", 0.0)), bb.get("maxy", 0.0)),
                }

        # 2. Bindings para cada candidato de medición
        binding_candidates: list[ParameterBindingCandidate] = []
        for p in hypothesis.parameter_candidates:
            v_id = p.get("view_id")
            v_type = p.get("view_type")
            if not v_type and views_dict and v_id in views_dict:
                v_type = views_dict[v_id].view_type

            doc_ev = None
            if doc_unit_evidence_map:
                p_src = p.get("source", {}).get("source_file") if isinstance(p.get("source"), dict) else None
                if p_src and p_src in doc_unit_evidence_map:
                    doc_ev = doc_unit_evidence_map[p_src]
                elif p_src and Path(p_src).name in doc_unit_evidence_map:
                    doc_ev = doc_unit_evidence_map[Path(p_src).name]
                elif hypothesis.source_ids:
                    h_src = hypothesis.source_ids[0]
                    doc_ev = doc_unit_evidence_map.get(h_src) or doc_unit_evidence_map.get(Path(h_src).name)

            binding = self.binding_resolver.bind_measurement_to_candidate(
                measurement=p,
                candidate_bbox=combined_bbox if combined_bbox else None,
                candidate_type=hypothesis.probable_type,
                view_type=v_type,
                local_frame=None,
                document_unit_evidence=doc_ev,
            )
            binding_candidates.append(binding)

        # 3. Multidocument Identity Gate si hay candidatos de múltiples documentos
        doc_ids = set(hypothesis.source_ids)
        if len(doc_ids) > 1 and len(members) >= 2:
            gate_passed = False
            gate_decision = "PENDING"
            gate_records = []
            for i in range(len(members)):
                for j in range(i + 1, len(members)):
                    m_a, m_b = members[i], members[j]
                    src_a = m_a.source_ids[0] if m_a.source_ids else ""
                    src_b = m_b.source_ids[0] if m_b.source_ids else ""
                    if src_a != src_b:
                        ok, dec, conf, ev = self.synthesizer.evaluate_multidocument_identity_gate(m_a, m_b)
                        gate_records.extend(ev)
                        if ok and dec == "SAME_OBJECT":
                            gate_passed = True
                            gate_decision = "SAME_OBJECT"
                        else:
                            gate_records.append({
                                "rejected_multidocument_fusion": f"{src_a} <-> {src_b}",
                                "reason": f"Decision was {dec} (requires SAME_OBJECT)",
                            })
            if not gate_passed or gate_decision != "SAME_OBJECT":
                hypothesis.identity_gate_status = "MULTIDOCUMENT_SYNTHESIS_NOT_AUTHORIZED"
                draft.identity_gate_status = "MULTIDOCUMENT_SYNTHESIS_NOT_AUTHORIZED"
            else:
                hypothesis.identity_gate_status = "SAME_OBJECT"
                draft.identity_gate_status = "SAME_OBJECT"
            hypothesis.identity_evidence = gate_records
            draft.identity_evidence = gate_records
        else:
            hypothesis.identity_gate_status = "INTRA_DOCUMENT"
            draft.identity_gate_status = "INTRA_DOCUMENT"

        # 4. Síntesis y consolidación de parámetros
        consolidated, conflicts, readiness = self.synthesizer.synthesize_parameters_for_hypothesis(
            hypothesis=hypothesis,
            binding_candidates=binding_candidates,
        )

        hypothesis.parameter_bindings = binding_candidates
        hypothesis.consolidated_parameters = consolidated
        hypothesis.parameter_readiness = readiness

        draft.parameter_bindings = binding_candidates
        draft.consolidated_parameters = consolidated
        draft.parameter_readiness = readiness

        # 5. Volcar parámetros y conflictos al ReconstructedObject
        for p_name, cp in consolidated.items():
            if cp.canonical_value is not None:
                param_val = ParameterValue(
                    name=p_name,
                    value=cp.canonical_value,
                    unit=cp.canonical_unit,
                    status=cp.status,
                    sources=cp.sources,
                    confidence=cp.confidence,
                    notes=cp.notes,
                )
                draft.add_parameter(param_val)

        for conflict in conflicts:
            draft.conflicts.append(conflict)
            draft.data_gaps.append(
                DataGap(
                    object_id=draft.object_id,
                    parameter=conflict.parameter,
                    description=conflict.impact or f"Conflicto en parámetro {conflict.parameter}",
                    criticality="HIGH",
                )
            )

        # 6. Registrar DataGaps para parámetros requeridos no resueltos
        for unres in readiness.unresolved_required_parameters:
            draft.data_gaps.append(
                DataGap(
                    object_id=draft.object_id,
                    parameter=unres,
                    description=f"Parámetro crítico requerido {unres} no resuelto para {draft.object_id}",
                    criticality="HIGH",
                )
            )
