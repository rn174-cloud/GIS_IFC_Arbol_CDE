from __future__ import annotations

from typing import Any
import ifcopenshell
from core.models import ParametricGeometry, RecipeType


class IFCGeometryTranslator:
    """
    Traduce ParametricGeometry validada a representaciones paramétricas nativas IFC4X3
    (IfcExtrudedAreaSolid, IfcRectangleProfileDef, IfcCircleProfileDef, etc.).
    
    REGLAS:
    - Preferir SweptSolid / CSG sobre Tessellation/Mesh.
    - Preservar la representación paramétrica maestra.
    """

    @staticmethod
    def create_extruded_solid(
        model: ifcopenshell.file,
        geom: ParametricGeometry,
    ) -> Any:
        """
        Crea el IfcExtrudedAreaSolid correspondiente a la receta de la geometría.
        """
        recipe_type = geom.geometry_type

        # 1. Marco de colocación local de extrusión (IfcAxis2Placement3D en origen local)
        placement_solid = model.create_entity(
            "IfcAxis2Placement3D",
            Location=model.create_entity("IfcCartesianPoint", Coordinates=(0.0, 0.0, 0.0)),
            Axis=model.create_entity("IfcDirection", DirectionRatios=(0.0, 0.0, 1.0)),
            RefDirection=model.create_entity("IfcDirection", DirectionRatios=(1.0, 0.0, 0.0)),
        )

        direction = model.create_entity("IfcDirection", DirectionRatios=(0.0, 0.0, 1.0))

        if recipe_type == RecipeType.RECTANGULAR_EXTRUSION:
            w = float(geom.parameters.get("ANCHO", 1.0))
            h = float(geom.parameters.get("ESPESOR", 1.0))
            depth = float(geom.parameters.get("LONGITUD", 1.0))

            profile = model.create_entity(
                "IfcRectangleProfileDef",
                ProfileType="AREA",
                XDim=w,
                YDim=h,
            )

            solid = model.create_entity(
                "IfcExtrudedAreaSolid",
                SweptArea=profile,
                Position=placement_solid,
                ExtrudedDirection=direction,
                Depth=depth,
            )
            return solid

        elif recipe_type == RecipeType.CIRCULAR_EXTRUSION:
            r = float(geom.parameters.get("RADIO", 0.5))
            depth = float(geom.parameters.get("ALTURA", 1.0))

            profile = model.create_entity(
                "IfcCircleProfileDef",
                ProfileType="AREA",
                Radius=r,
            )

            solid = model.create_entity(
                "IfcExtrudedAreaSolid",
                SweptArea=profile,
                Position=placement_solid,
                ExtrudedDirection=direction,
                Depth=depth,
            )
            return solid

        else:
            raise ValueError(f"Tipo de geometría paramétrica no soportado para SweptSolid: {recipe_type.value}")
