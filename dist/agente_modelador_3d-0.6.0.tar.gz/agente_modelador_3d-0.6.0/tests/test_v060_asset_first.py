"""
tests/test_v060_asset_first.py
Batería de 20 tests obligatorios para el Agente Modelador 3D v0.6.0
ASSET-FIRST MULTIMODAL RECONSTRUCTION.
"""
from __future__ import annotations

import os
import re
from pathlib import Path
import pytest

from core.models import (
    AssetAssemblyHypothesis,
    AssetConflict,
    AssetContext,
    AssetRelationship,
    AssetRelationshipType,
    AssetVisualEvidence,
    AssetVisualEvidenceSet,
    ConflictType,
    DocumentRole,
    EvidenceStatus,
    FacilityType,
    GeometryRecipe,
    ObjectCandidate,
    ObjectConfidenceBreakdown,
    ObjectHypothesis,
    ParameterValue,
    QualityConfidenceLevel,
    RecipeType,
    ReconstructedObject,
    SemanticFamily,
    SemanticSignal,
    SourceDocument,
    SourceQuestionPlan,
    UnitResolutionStatus,
    VisualContextAssessment,
)
from reconstruction.alignment_generator import AlignmentAwareGenerator
from reconstruction.asset_assembly_resolver import AssetAssemblyResolver
from reconstruction.asset_context_resolver import AssetContextResolver
from reconstruction.conflict_detector import ConflictDetector
from reconstruction.directed_evidence_searcher import DirectedEvidenceSearcher
from reconstruction.document_role_resolver import DocumentRoleResolver
from reconstruction.parametric_recipe_library import GenericRecipePattern, ParametricRecipeLibrary
from reconstruction.provisional_model_manager import ProvisionalModelManager
from reconstruction.relationship_reasoner import RelationshipReasoner
from reconstruction.source_question_planner import SourceQuestionPlanner
from reconstruction.visual_context_resolver import VisualContextResolver


# 1. asset context can be created from document metadata
def test_01_asset_context_from_document_metadata():
    resolver = AssetContextResolver()
    metadata = {
        "project_name": "Autopista Acceso Norte",
        "discipline": "Estructuras Viales",
        "description": "Viaducto y puente sobre rio",
    }
    doc = SourceDocument(
        path=Path("plano_viaducto_principal.dwg"),
        file_type="DWG",
        drawing_title="Viaducto Principal - Disposicion General",
        drawing_number="STR-001",
    )

    ctx = resolver.resolve_context(
        metadata=metadata,
        source_documents=[doc],
    )

    assert ctx.infrastructure_domain == "TRANSPORTATION"
    assert ctx.facility_or_asset_type == FacilityType.BRIDGE.value
    assert "SUPERSTRUCTURE" in ctx.system_contexts
    assert "SUBSTRUCTURE" in ctx.system_contexts
    assert ctx.confidence >= 0.70
    assert ctx.evidence_status in {EvidenceStatus.DOCUMENTED, EvidenceStatus.DERIVED}


# 2. asset context can be enriched by visual evidence
def test_02_asset_context_enriched_by_visual_evidence():
    vis_resolver = VisualContextResolver()
    vis_set = AssetVisualEvidenceSet(
        asset_id="asset_test_01",
        images=[
            AssetVisualEvidence(
                source="foto_lateral_drone.jpg",
                viewpoint_type="lateral",
                confidence=0.8,
            ),
            AssetVisualEvidence(
                source="ortofoto_aerea.jpg",
                viewpoint_type="aerial",
                confidence=0.85,
            ),
        ],
    )

    assessment = vis_resolver.assess_visual_set(vis_set)

    assert "LONGITUDINAL_ELEVATION_PROFILE" in assessment.visible_features
    assert "PLANAR_FOOTPRINT_AND_ALIGNMENT" in assessment.visible_features
    assert "SUPERSTRUCTURE" in assessment.possible_systems
    assert len(assessment.recommended_document_queries) > 0


# 3. visual evidence cannot become DOCUMENTED geometry by itself
def test_03_visual_evidence_cannot_become_documented_geometry_by_itself():
    vis_resolver = VisualContextResolver()
    vis_set = AssetVisualEvidenceSet(
        asset_id="asset_vis_02",
        images=[
            AssetVisualEvidence(
                source="streetview_panoramica.jpg",
                viewpoint_type="Street View",
                evidence_status=EvidenceStatus.DOCUMENTED,  # Intento de marcarlo como documentado
                confidence=0.95,
            )
        ],
    )

    assessment = vis_resolver.assess_visual_set(vis_set)

    # La imagen debe ser degradada de DOCUMENTED a INFERRED
    assert vis_set.images[0].evidence_status != EvidenceStatus.DOCUMENTED
    assert vis_set.images[0].evidence_status == EvidenceStatus.INFERRED
    # La confianza visual está acotada y no puede ser 1.0
    assert assessment.confidence < 0.70


# 4. document role classification works independently of extension
def test_04_document_role_classification_independent_of_extension():
    role_resolver = DocumentRoleResolver()

    doc_dwg = SourceDocument(
        path=Path("ICDT001.dwg"),
        file_type="DWG",
        drawing_title="Detalle Tipico de Armadura y Columnas",
    )
    doc_pdf = SourceDocument(
        path=Path("especificaciones.pdf"),
        file_type="PDF",
        drawing_title="Detalle de Anclajes y Perfiles",
    )
    doc_general = SourceDocument(
        path=Path("planta_general.dwg"),
        file_type="DWG",
        drawing_title="Disposicion General e Implantacion",
    )

    role_dwg = role_resolver.classify_document(doc_dwg)
    role_pdf = role_resolver.classify_document(doc_pdf)
    role_gen = role_resolver.classify_document(doc_general)

    assert role_dwg == DocumentRole.DETAIL
    assert role_pdf == DocumentRole.DETAIL
    assert role_gen == DocumentRole.GENERAL_ARRANGEMENT


# 5. DETAIL cannot authorize instance count
def test_05_detail_cannot_authorize_instance_count():
    assert not DocumentRoleResolver.can_authorize_cardinality(DocumentRole.DETAIL)
    assert not DocumentRoleResolver.can_authorize_cardinality(DocumentRole.SPECIFICATION)
    assert not DocumentRoleResolver.can_authorize_placement(DocumentRole.DETAIL)


# 6. GENERAL_ARRANGEMENT can support instance placement
def test_06_general_arrangement_can_support_instance_placement():
    assert DocumentRoleResolver.can_authorize_cardinality(DocumentRole.GENERAL_ARRANGEMENT)
    assert DocumentRoleResolver.can_authorize_placement(DocumentRole.GENERAL_ARRANGEMENT)
    assert DocumentRoleResolver.can_authorize_placement(DocumentRole.PLAN)
    assert DocumentRoleResolver.can_authorize_placement(DocumentRole.AS_BUILT)


# 7. inventory can support instance identity/count
def test_07_inventory_can_support_instance_identity_count():
    assert DocumentRoleResolver.can_authorize_cardinality(DocumentRole.INVENTORY)
    assert DocumentRoleResolver.can_authorize_placement(DocumentRole.INVENTORY)
    assert DocumentRoleResolver.can_authorize_cardinality(DocumentRole.SCHEDULE)


# 8. assembly hypothesis narrows semantic search space
def test_08_assembly_hypothesis_narrows_semantic_search_space():
    hypothesis = AssetAssemblyHypothesis(
        assembly_id="asm_light_01",
        asset_context="Sistema de Iluminacion Vial",
        facility_type=FacilityType.LIGHTING_SYSTEM.value,
        systems=["SUPPORT_STRUCTURES", "LUMINAIRES"],
        expected_component_types=["COLUMNA_ILUMINACION", "LUMINARIA"],
    )
    question_plan = SourceQuestionPlan(
        plan_id="sqp_01",
        assembly_id=hypothesis.assembly_id,
        questions=[],
    )

    candidate = ObjectCandidate(
        candidate_id="cand_unkn_01",
        probable_family=SemanticFamily.UNKNOWN,
        probable_type="UNKNOWN",
        semantic_signals=[
            SemanticSignal(
                signal_type="TEXT",
                value="COLUMNA_ILUMINACION H=10m",
                source_id="src_01",
                confidence=0.8,
            )
        ],
    )

    searcher = DirectedEvidenceSearcher()
    guided = searcher.filter_and_guide_candidates(
        assembly=hypothesis,
        question_plan=question_plan,
        candidates=[candidate],
        document_role=DocumentRole.DETAIL,
    )

    assert len(guided) == 1
    # La hipótesis de iluminación orienta la familia hacia LIGHTING
    assert guided[0].probable_family == SemanticFamily.LIGHTING
    assert any("DIRECTED_MATCH_TO_COLUMNA_ILUMINACION" in ev for ev in guided[0].type_evidence)


# 9. CAD primitives remain evidence, not primary semantic truth
def test_09_cad_primitives_remain_evidence_not_primary_semantic_truth():
    from core.models import PrimitiveEvidence

    prim = PrimitiveEvidence(
        primitive_id="prim_01",
        entity_handle="2B4",
        entity_type="LWPOLYLINE",
        layer="ESTRUCTURA",
        bbox={"min_x": 0.0, "min_y": 0.0, "max_x": 10.0, "max_y": 2.0},
        geometry={"vertices": [[0, 0], [10, 0], [10, 2], [0, 2]]},
        region_id="reg_01",
    )

    # PrimitiveEvidence es puramente evidencia documental neutral
    assert prim.primitive_id == "prim_01"
    assert not hasattr(prim, "is_built")
    assert not hasattr(prim, "ifc_class")


# 10. context alone cannot authorize BUILT
def test_10_context_alone_cannot_authorize_built():
    ctx = AssetContext(
        infrastructure_domain="TRANSPORTATION",
        facility_or_asset_type=FacilityType.BRIDGE.value,
        asset_context="Puente Mayor",
        evidence_status=EvidenceStatus.DOCUMENTED,
        confidence=0.99,
    )

    # Objeto con parámetros faltantes y sin geometría construida
    obj = ReconstructedObject(
        object_id="obj_test_ctx",
        name="PILA_01",
        object_type="PILA",
        family=SemanticFamily.STRUCTURAL.value,
    )

    model_mgr = ProvisionalModelManager()
    auth_model = model_mgr.filter_authorized_model(
        objects=[obj],
        parametric_geometries={},
    )

    # Contexto documentado NO autoriza BUILT si no superó gates geométricas
    assert auth_model.authorized_objects_count == 0


# 11. inference remains INFERRED
def test_11_inference_remains_inferred():
    param = ParameterValue(
        name="ALTURA_ESTIMADA",
        value=15.0,
        unit="m",
        status=EvidenceStatus.INFERRED,
    )
    rel = AssetRelationship(
        relation_type=AssetRelationshipType.SUPPORTED_BY.value,
        source_id="deck",
        target_id="pier",
        evidence_status=EvidenceStatus.INFERRED,
    )

    assert param.status == EvidenceStatus.INFERRED
    assert param.is_low_evidence()
    assert not param.is_usable_for_verified_geometry()
    assert rel.evidence_status == EvidenceStatus.INFERRED


# 12. provisional model can contain inferred elements
def test_12_provisional_model_can_contain_inferred_elements():
    obj = ReconstructedObject(
        object_id="obj_provisional_01",
        name="PILOTE_INFERIDO",
        object_type="PILOTE",
        family=SemanticFamily.GEOTECHNICAL.value,
    )
    obj.confidence_level = obj.confidence_level.D_PROVISIONAL

    model_mgr = ProvisionalModelManager()
    prov_model = model_mgr.build_provisional_model(
        assembly_id="asm_test_01",
        objects=[obj],
        provisional_elements=[{"id": "elem_infer_01", "status": "INFERRED"}],
    )

    assert prov_model.total_objects == 2
    assert "D_PROVISIONAL" in prov_model.status_summary
    assert "INFERRED" in prov_model.status_summary
    assert "CANNOT BE USED AS DOCUMENTARY EVIDENCE" in prov_model.disclaimer


# 13. authorized model cannot bypass v0.5.3 gates
def test_13_authorized_model_cannot_bypass_v053_gates():
    obj = ReconstructedObject(
        object_id="obj_cand_01",
        name="COLUMNA_01",
        object_type="COLUMNA",
        family="UNKNOWN",  # UNKNOWN family bloquea BUILT
    )
    model_mgr = ProvisionalModelManager()
    auth_model = model_mgr.filter_authorized_model([obj])

    assert auth_model.authorized_objects_count == 0


# 14. alignment placement does not invent spacing
def test_14_alignment_placement_does_not_invent_spacing():
    generator = AlignmentAwareGenerator()

    # Si se piden estaciones sin suministrar lista ni espaciado gobernado
    res = generator.generate_alignment_array(
        start_station=0.0,
        end_station=500.0,
        spacing=None,  # No spacing provided
    )

    # NO debe inventar un espaciado como 35m o 50m
    assert res == []


# 15. duplicate evidence is not double counted
def test_15_duplicate_evidence_is_not_double_counted():
    from reconstruction.unit_resolver import UnitResolver

    resolver = UnitResolver()
    # Mismo valor y texto de la misma hoja reportado dos veces
    res1 = resolver.resolve_measurement_unit(
        raw_value=10.0,
        declared_unit="m",
        raw_text="10.0m",
        doc_evidence={"dominant_unit": "m", "primary_evidence": ["title_block: m"], "secondary_evidence": []},
    )
    res2 = resolver.resolve_measurement_unit(
        raw_value=10.0,
        declared_unit="m",
        raw_text="10.0m",
        doc_evidence={"dominant_unit": "m", "primary_evidence": ["title_block: m"], "secondary_evidence": []},
    )

    assert res1.conversion_factor == res2.conversion_factor
    assert res1.unit_resolution_status == UnitResolutionStatus.UNIT_DOCUMENTED


# 16. conflicting sources create explicit conflict
def test_16_conflicting_sources_create_explicit_conflict():
    detector = ConflictDetector()
    comparisons = [
        {
            "subject": "ALTURA_TOTAL",
            "source_a": "PLANO_ELEVACION_01",
            "value_a": 12.0,
            "source_b": "PLANO_DETALLE_02",
            "value_b": 10.0,
            "tolerance": 0.05,
            "conflict_type": ConflictType.DOCUMENT_CONFLICT,
        }
    ]

    conflicts = detector.detect_conflicts(comparisons)

    assert len(conflicts) == 1
    assert conflicts[0].conflict_type == ConflictType.DOCUMENT_CONFLICT.value
    assert conflicts[0].resolution_status == "UNRESOLVED"
    assert "12.0" in conflicts[0].description and "10.0" in conflicts[0].description


# 17. RN174 filenames do not appear in production rules
def test_17_rn174_filenames_do_not_appear_in_production_rules():
    forbidden_terms = [
        "OCIM601rvA2",
        "ZCARB04rvA2",
        "RN174_GEMELO",
        "ICDT001rvA2",
    ]

    prod_dirs = [
        Path("reconstruction"),
        Path("core"),
        Path("ifc"),
        Path("readers"),
    ]

    violations = []
    for pdir in prod_dirs:
        for pyfile in pdir.glob("**/*.py"):
            with pyfile.open("r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
                for term in forbidden_terms:
                    if term.lower() in content.lower():
                        violations.append(f"{pyfile}: contains {term}")

    assert not violations, f"Violaciones de hardcode encontradas en producción: {violations}"


# 18. bridge-specific logic does not appear in production core
def test_18_bridge_specific_logic_does_not_appear_in_production_core():
    # Verificar que el pipeline y los modelos manejan múltiples tipologías sin subordinarse a bridge
    library = ParametricRecipeLibrary()
    patterns = [p.value for p in GenericRecipePattern]

    assert "LINEAR_EXTRUSION" in patterns
    assert "RECTANGULAR_EXTRUSION" in patterns
    assert "SWEEP_ALONG_ALIGNMENT" in patterns
    assert "ARRAY_ON_GRID" in patterns

    # FacilityType incluye tipologías no-puente
    fac_types = [f.value for f in FacilityType]
    assert "INDUSTRIAL_FACILITY" in fac_types
    assert "DRAINAGE_SYSTEM" in fac_types
    assert "LIGHTING_SYSTEM" in fac_types
    assert "AIRPORT_APRON" in fac_types


# 19. non-bridge synthetic case passes context pipeline
def test_19_non_bridge_synthetic_case_passes_context_pipeline():
    ctx_resolver = AssetContextResolver()
    role_resolver = DocumentRoleResolver()
    assembly_resolver = AssetAssemblyResolver()
    question_planner = SourceQuestionPlanner()

    doc1 = SourceDocument(
        path=Path("plano_general_planta_tratamiento.dwg"),
        file_type="DWG",
        drawing_title="Planta de Tratamiento de Efluentes - Disposicion General",
    )
    doc2 = SourceDocument(
        path=Path("detalle_canal_drenaje.dwg"),
        file_type="DWG",
        drawing_title="Corte Transversal Canal y Camaras de Drenaje",
    )

    ctx = ctx_resolver.resolve_context(
        metadata={"project_name": "Planta Industrial Sanitaria"},
        source_documents=[doc1, doc2],
    )

    assert ctx.infrastructure_domain == "WATER_AND_DRAINAGE"
    assert ctx.facility_or_asset_type == FacilityType.DRAINAGE_SYSTEM.value

    r1 = role_resolver.classify_document(doc1)
    r2 = role_resolver.classify_document(doc2)
    assert r1 == DocumentRole.GENERAL_ARRANGEMENT
    assert r2 == DocumentRole.SECTION

    assembly = assembly_resolver.resolve_assembly_hypothesis(
        asset_context=ctx,
        documents=[doc1, doc2],
        document_roles={str(doc1.path): r1, str(doc2.path): r2},
    )
    assert assembly.facility_type == FacilityType.DRAINAGE_SYSTEM.value
    assert "CONVEYANCE_NETWORK" in assembly.systems

    plan = question_planner.plan_questions(
        assembly=assembly,
        available_documents=[doc1, doc2],
        document_roles={str(doc1.path): r1, str(doc2.path): r2},
    )
    assert plan.total_questions >= 5
    assert any(q.status == "ANSWERED" for q in plan.questions)


# 20. legacy hardcoded assumptions are not imported into generic product
def test_20_legacy_hardcoded_assumptions_not_imported_into_generic_product():
    # Verificar que en ParametricRecipeLibrary y AlignmentAwareGenerator no hay valores fijos como 35.0 o 120.0
    rec_file = Path("reconstruction/parametric_recipe_library.py")
    align_file = Path("reconstruction/alignment_generator.py")

    for fpath in [rec_file, align_file]:
        with fpath.open("r", encoding="utf-8") as f:
            code = f.read()
            # No deben existir asignaciones fijas como spacing = 35 o height = 120
            assert "spacing = 35" not in code
            assert "spacing=35" not in code
            assert "height = 120" not in code
            assert "piles_count = 4" not in code
