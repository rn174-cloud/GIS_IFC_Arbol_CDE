from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path
from typing import Any

from core.config import AgentConfig
from reconstruction.pipeline import ReconstructionPipeline
from version import AGENT_NAME, AGENT_VERSION, IFC_SCHEMA


def configure_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )


def serialize_result(value: Any) -> Any:
    if hasattr(value, "to_dict") and callable(value.to_dict):
        return serialize_result(value.to_dict())

    if isinstance(value, Path):
        return str(value)

    if isinstance(value, dict):
        return {
            str(key): serialize_result(item)
            for key, item in value.items()
        }

    if isinstance(value, (list, tuple)):
        return [serialize_result(item) for item in value]

    return value


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agente-modelador-3d",
        description=(
            "Ingesta documental neutral y modelado 3D paramétrico "
            "de infraestructura hacia IFC 4.3 (IFC4X3_ADD2)."
        ),
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"{AGENT_NAME} v{AGENT_VERSION} (IFC: {IFC_SCHEMA})",
    )

    subparsers = parser.add_subparsers(dest="subcommand", help="Comandos disponibles")

    # Subcomando opcional 'dwg-providers' para diagnosticar salud de backends DWG
    provider_parser = subparsers.add_parser(
        "dwg-providers",
        help="Diagnostica los proveedores DWG disponibles en el entorno.",
    )
    provider_parser.add_argument(
        "--json",
        action="store_true",
        help="Muestra el resultado en formato JSON.",
    )

    # Argumentos para la invocación directa con archivos fuente
    parser.add_argument(
        "sources",
        nargs="*",
        help=(
            "Archivos fuente a analizar (DWG, DXF, PDF, GIS, etc.)."
        ),
    )

    parser.add_argument(
        "--output-dir",
        default=None,
        help="Directorio de salida. Si se omite, usa OUTPUT_DIR o 'output'.",
    )

    parser.add_argument(
        "--mode",
        choices=[
            "AUDIT",
            "EXTRACT",
            "MODEL",
            "VALIDATE",
            "UPDATE",
            "REBUILD",
        ],
        default="AUDIT",
        help="Modo de operación del agente. Por defecto: AUDIT.",
    )

    parser.add_argument(
        "--project-name",
        default="Infrastructure_Project",
        help="Nombre lógico del proyecto/modelo.",
    )

    parser.add_argument(
        "--crs",
        default=None,
        help="CRS de entrada cuando corresponda (ej. EPSG:5347).",
    )

    parser.add_argument(
        "--log-level",
        default=None,
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Nivel de logging.",
    )

    return parser


def validate_sources(source_paths: list[Path]) -> None:
    missing = [path for path in source_paths if not path.exists()]
    if missing:
        formatted = "\n".join(f"  - {path}" for path in missing)
        raise FileNotFoundError(
            "No se encontraron los siguientes archivos fuente:\n"
            f"{formatted}"
        )


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    # Si se invoca 'dwg-providers'
    if getattr(args, "subcommand", None) == "dwg-providers":
        from readers.dwg.registry import get_dwg_registry
        registry = get_dwg_registry()
        summary = registry.health_summary()
        if getattr(args, "json", False):
            print(json.dumps(summary, indent=2))
        else:
            print("=== DWG PROVIDER HEALTH & CAPABILITIES ===")
            for pid, status in summary.items():
                print(f"[{pid}] Operational: {status.get('is_operational')} | Name: {status.get('provider_name')}")
                print(f"  Notes: {status.get('notes')}")
        return 0

    if not args.sources:
        parser.print_help()
        return 0

    config = AgentConfig.from_environment()
    log_level = args.log_level or config.log_level
    configure_logging(log_level)

    logger = logging.getLogger("agente_modelador_3d.cli")

    source_paths = [
        Path(source).expanduser().resolve()
        for source in args.sources
    ]

    try:
        validate_sources(source_paths)
    except FileNotFoundError as exc:
        logger.error("%s", exc)
        return 2

    output_dir = (
        Path(args.output_dir).expanduser().resolve()
        if args.output_dir
        else config.output_dir
    )

    output_dir.mkdir(parents=True, exist_ok=True)

    logger.info("%s v%s (IFC: %s)", AGENT_NAME, AGENT_VERSION, IFC_SCHEMA)
    logger.info("Modo: %s", args.mode)
    logger.info("Proyecto: %s", args.project_name)
    logger.info("Fuentes: %d", len(source_paths))
    logger.info("Salida: %s", output_dir)

    effective_config = AgentConfig(
        output_dir=output_dir,
        db_host=config.db_host,
        db_port=config.db_port,
        db_name=config.db_name,
        db_user=config.db_user,
        db_password=config.db_password,
        dwg_to_dxf_command=config.dwg_to_dxf_command,
        default_crs=config.default_crs,
        local_origin_x=config.local_origin_x,
        local_origin_y=config.local_origin_y,
        local_origin_z=config.local_origin_z,
        log_level=config.log_level,
    )

    pipeline = ReconstructionPipeline(
        config=effective_config,
        project_name=args.project_name,
        mode=args.mode,
        crs=args.crs or config.default_crs,
    )

    try:
        result = pipeline.run(source_paths)
    except Exception:
        logger.exception("La ejecución del pipeline terminó con un error.")
        return 1

    inventory_path = output_dir / "source_inventory.json"
    with inventory_path.open("w", encoding="utf-8") as file:
        json.dump(
            serialize_result(result),
            file,
            ensure_ascii=False,
            indent=2,
        )

    logger.info("Inventario de fuentes generado: %s", inventory_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
