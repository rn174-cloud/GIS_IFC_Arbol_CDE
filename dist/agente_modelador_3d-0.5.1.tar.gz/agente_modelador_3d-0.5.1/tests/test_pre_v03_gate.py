from __future__ import annotations

import pytest
from core.models import (
    CandidateStatus,
    CandidateType,
    ConfidenceLevel,
    DataGap,
    DocumentConflict,
    EvidenceMatch,
    EvidenceStatus,
    MatchDecision,
    ObjectCandidate,
    ObjectConfidenceBreakdown,
    ObjectHypothesis,
    ParameterValue,
    QualityConfidenceLevel,
    ReconstructedObject,
    SemanticFamily,
    SourceReference,
)
from reconstruction.object_hypothesis_resolver import ObjectHypothesisResolver


# ==============================================================================
# J. TEST DE IDENTIDAD
# ==============================================================================

def test_j1_different_close_stations_produce_distinct_object_ids():
    """
    1. stations distintas muy próximas (ej: PK 12+345.60 y PK 12+346.40)
       producen object_id distintos sin colisión por redondeo.
    """
    id_1 = ObjectHypothesisResolver.generate_deterministic_object_id(
        family=SemanticFamily.STRUCTURAL,
        station=12345.60,
        label="PILOTE",
        member_ids=["cand_1"],
    )
    id_2 = ObjectHypothesisResolver.generate_deterministic_object_id(
        family=SemanticFamily.STRUCTURAL,
        station=12346.40,
        label="PILOTE",
        member_ids=["cand_1"],
    )

    # Ambos habrían redondeado a PK12346 en una implementación ingenua
    assert id_1 != id_2, f"Colisión indebida: {id_1} == {id_2}"


def test_j2_processing_order_does_not_change_object_id():
    """
    2. Cambiar orden de procesamiento de miembros no cambia object_id.
    """
    id_order_a = ObjectHypothesisResolver.generate_deterministic_object_id(
        family=SemanticFamily.DRAINAGE,
        station=500.0,
        label="SUMIDERO",
        member_ids=["cand_b", "cand_a", "cand_c"],
    )
    id_order_b = ObjectHypothesisResolver.generate_deterministic_object_id(
        family=SemanticFamily.DRAINAGE,
        station=500.0,
        label="SUMIDERO",
        member_ids=["cand_a", "cand_c", "cand_b"],
    )

    assert id_order_a == id_order_b


def test_j3_same_evidence_from_different_folder_preserves_identity():
    """
    3. Misma evidencia procesada con hash de contenido y entidades equivalentes
       conserva identidad sin depender de rutas absolutas locales.
    """
    source_hash = ["content_sha256:abc123def456"]
    members = ["ent_line_45", "ent_circle_99"]

    id_env_a = ObjectHypothesisResolver.generate_deterministic_object_id(
        family=SemanticFamily.ROAD_SAFETY,
        station=100.5,
        label="DEFENSA_METALICA",
        member_ids=members,
        offset=-3.5,
        source_hashes=source_hash,
    )
    id_env_b = ObjectHypothesisResolver.generate_deterministic_object_id(
        family=SemanticFamily.ROAD_SAFETY,
        station=100.5,
        label="DEFENSA_METALICA",
        member_ids=members,
        offset=-3.5,
        source_hashes=source_hash,
    )

    assert id_env_a == id_env_b


def test_j4_repeated_instances_keep_distinct_ids():
    """
    4. Dos instancias repetidas (distintos candidatos/entidades en posiciones distintas)
       conservan IDs distintos.
    """
    id_instance_1 = ObjectHypothesisResolver.generate_deterministic_object_id(
        family=SemanticFamily.STRUCTURAL,
        station=250.0,
        label="COLUMNA",
        member_ids=["cand_col_1"],
        offset=2.5,
    )
    id_instance_2 = ObjectHypothesisResolver.generate_deterministic_object_id(
        family=SemanticFamily.STRUCTURAL,
        station=250.0,
        label="COLUMNA",
        member_ids=["cand_col_2"],
        offset=-2.5,
    )

    assert id_instance_1 != id_instance_2


def test_j5_legitimate_multiview_merge_produces_single_stable_id():
    """
    5. Merge legítimo de vistas produce un único object_id estable para la hipótesis.
    """
    cand_plan = ObjectCandidate(
        candidate_id="cand_plan_1",
        probable_family=SemanticFamily.DRAINAGE,
        probable_type="ALCANTARILLA",
        confidence=0.85,
        status=CandidateStatus.PARTIALLY_RESOLVED,
        source_ids=["plan_planta.dwg"],
        entity_references=["ent_1"],
        view_ids=["view_plan"],
        labels=["ALCANTARILLA"],
        station=320.0,
    )
    cand_profile = ObjectCandidate(
        candidate_id="cand_prof_1",
        probable_family=SemanticFamily.DRAINAGE,
        probable_type="ALCANTARILLA",
        confidence=0.88,
        status=CandidateStatus.PARTIALLY_RESOLVED,
        source_ids=["plan_perfil.dwg"],
        entity_references=["ent_2"],
        view_ids=["view_prof"],
        labels=["ALCANTARILLA"],
        station=320.0,
    )

    match = EvidenceMatch(
        match_id="m_1_2",
        candidate_a_id="cand_plan_1",
        candidate_b_id="cand_prof_1",
        decision=MatchDecision.SAME_OBJECT,
        confidence=0.92,
        final_score=0.92,
    )

    resolver = ObjectHypothesisResolver()
    hyps, drafts = resolver.resolve_hypotheses_and_drafts(
        candidates=[cand_plan, cand_profile],
        matches=[match],
    )

    assert len(drafts) == 1
    assert drafts[0].object_id.startswith("obj_DRAI_PK320_")
    assert len(drafts[0].metadata["member_candidate_ids"]) == 2


# ==============================================================================
# K. TEST DE CONFIANZA
# ==============================================================================

def test_k1_geometry_definition_empty_implies_geometry_confidence_not_evaluated():
    """
    1. geometry_definition={} implica geometry_confidence=NOT_EVALUATED.
    """
    obj = ReconstructedObject(
        object_id="obj_test_1",
        geometry_definition={},
    )
    assert obj.confidence_breakdown.geometry_confidence == QualityConfidenceLevel.NOT_EVALUATED


def test_k2_high_semantic_confidence_does_not_imply_high_geometry_confidence():
    """
    2. Alta semantic_confidence no implica alta geometry_confidence.
    """
    cand_a = ObjectCandidate(
        candidate_id="cand_a",
        probable_family=SemanticFamily.STRUCTURAL,
        probable_type="VIGA",
        confidence=0.95,
        status=CandidateStatus.PARTIALLY_RESOLVED,
        labels=["VIGA"],
    )
    cand_b = ObjectCandidate(
        candidate_id="cand_b",
        probable_family=SemanticFamily.STRUCTURAL,
        probable_type="VIGA",
        confidence=0.95,
        status=CandidateStatus.PARTIALLY_RESOLVED,
        labels=["VIGA"],
    )
    match = EvidenceMatch(
        match_id="m_ab",
        candidate_a_id="cand_a",
        candidate_b_id="cand_b",
        decision=MatchDecision.SAME_OBJECT,
        confidence=0.95,
    )

    resolver = ObjectHypothesisResolver()
    hyps, drafts = resolver.resolve_hypotheses_and_drafts(
        candidates=[cand_a, cand_b],
        matches=[match],
    )

    draft = drafts[0]
    assert draft.confidence_breakdown.semantic_confidence in {
        QualityConfidenceLevel.HIGH,
        QualityConfidenceLevel.VERIFIED,
    }
    # GEOMETRIA DEBE PERMANECER NOT_EVALUATED
    assert draft.confidence_breakdown.geometry_confidence == QualityConfidenceLevel.NOT_EVALUATED
    assert draft.geometry_definition == {}


def test_k3_unknown_parameters_reduce_parameter_confidence():
    """
    3. Parámetros UNKNOWN reducen parameter_confidence a LOW.
    """
    cand = ObjectCandidate(
        candidate_id="cand_u",
        probable_family=SemanticFamily.PAVEMENT,
        probable_type="CALZADA",
        confidence=0.85,
        status=CandidateStatus.PARTIALLY_RESOLVED,
    )
    cand_2 = ObjectCandidate(
        candidate_id="cand_u2",
        probable_family=SemanticFamily.PAVEMENT,
        probable_type="CALZADA",
        confidence=0.85,
        status=CandidateStatus.PARTIALLY_RESOLVED,
    )
    match = EvidenceMatch(
        match_id="m_u",
        candidate_a_id="cand_u",
        candidate_b_id="cand_u2",
        decision=MatchDecision.SAME_OBJECT,
        confidence=0.90,
    )
    resolver = ObjectHypothesisResolver()
    hyps, drafts = resolver.resolve_hypotheses_and_drafts(
        candidates=[cand, cand_2],
        matches=[match],
    )
    draft = drafts[0]
    draft.add_parameter(
        ParameterValue(
            name="ESPESOR",
            value=None,
            status=EvidenceStatus.UNKNOWN,
        )
    )
    # Recalcular breakdown simulado
    if any(p.status == EvidenceStatus.UNKNOWN for p in draft.parameters.values()):
        draft.confidence_breakdown.parameter_confidence = QualityConfidenceLevel.LOW

    assert draft.confidence_breakdown.parameter_confidence == QualityConfidenceLevel.LOW


def test_k4_document_conflict_reduces_parameter_confidence():
    """
    4. DOCUMENT_CONFLICT reduce parameter_confidence a LOW.
    """
    p1 = {
        "candidate_id": "c1",
        "value": 7.30,
        "raw_text": "ANCHO 7.30",
        "unit": "m",
        "candidate_type": CandidateType.MEASUREMENT,
        "source": {"source_file": "plano_a.dxf"},
        "view_type": "PLANTA",
    }
    p2 = {
        "candidate_id": "c2",
        "value": 6.70,
        "raw_text": "ANCHO 6.70",
        "unit": "m",
        "candidate_type": CandidateType.MEASUREMENT,
        "source": {"source_file": "plano_b.dxf"},
        "view_type": "SECCION",
    }

    cand_1 = ObjectCandidate(
        candidate_id="c1",
        probable_family=SemanticFamily.PAVEMENT,
        probable_type="CALZADA",
        confidence=0.85,
        status=CandidateStatus.PARTIALLY_RESOLVED,
        parameter_candidates=[p1],
    )
    cand_2 = ObjectCandidate(
        candidate_id="c2",
        probable_family=SemanticFamily.PAVEMENT,
        probable_type="CALZADA",
        confidence=0.85,
        status=CandidateStatus.PARTIALLY_RESOLVED,
        parameter_candidates=[p2],
    )
    match = EvidenceMatch(
        match_id="m_c12",
        candidate_a_id="c1",
        candidate_b_id="c2",
        decision=MatchDecision.SAME_OBJECT,
        confidence=0.90,
    )

    resolver = ObjectHypothesisResolver()
    _, drafts = resolver.resolve_hypotheses_and_drafts(
        candidates=[cand_1, cand_2],
        matches=[match],
    )
    draft = drafts[0]

    assert len(draft.conflicts) > 0
    assert draft.confidence_breakdown.parameter_confidence == QualityConfidenceLevel.LOW


def test_k5_strong_multiview_identity_raises_identity_confidence():
    """
    5. Identidad multivista fuerte eleva identity_confidence a HIGH.
    """
    cand_1 = ObjectCandidate(
        candidate_id="cm1",
        probable_family=SemanticFamily.STRUCTURAL,
        probable_type="PILOTE",
        confidence=0.90,
        status=CandidateStatus.PARTIALLY_RESOLVED,
    )
    cand_2 = ObjectCandidate(
        candidate_id="cm2",
        probable_family=SemanticFamily.STRUCTURAL,
        probable_type="PILOTE",
        confidence=0.90,
        status=CandidateStatus.PARTIALLY_RESOLVED,
    )
    match = EvidenceMatch(
        match_id="m_strong",
        candidate_a_id="cm1",
        candidate_b_id="cm2",
        decision=MatchDecision.SAME_OBJECT,
        confidence=0.92,
    )
    resolver = ObjectHypothesisResolver()
    _, drafts = resolver.resolve_hypotheses_and_drafts(
        candidates=[cand_1, cand_2],
        matches=[match],
    )
    draft = drafts[0]

    assert draft.confidence_breakdown.identity_confidence == QualityConfidenceLevel.HIGH


def test_k6_four_facets_serialize_independently():
    """
    6. Los cuatro niveles de confianza pueden serializarse por separado en to_dict().
    """
    breakdown = ObjectConfidenceBreakdown(
        identity_confidence=QualityConfidenceLevel.HIGH,
        semantic_confidence=QualityConfidenceLevel.VERIFIED,
        parameter_confidence=QualityConfidenceLevel.MEDIUM,
        geometry_confidence=QualityConfidenceLevel.NOT_EVALUATED,
    )
    data = breakdown.to_dict()

    assert data["identity_confidence"] == "HIGH"
    assert data["semantic_confidence"] == "VERIFIED"
    assert data["parameter_confidence"] == "MEDIUM"
    assert data["geometry_confidence"] == "NOT_EVALUATED"

    # Verificar que ReconstructedObject.to_dict() lo incluye
    obj = ReconstructedObject(
        object_id="obj_serial",
        confidence_breakdown=breakdown,
    )
    obj_dict = obj.to_dict()
    assert "confidence_breakdown" in obj_dict
    assert obj_dict["confidence_breakdown"]["geometry_confidence"] == "NOT_EVALUATED"
