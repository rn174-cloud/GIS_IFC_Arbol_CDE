"""
Módulo de autoría IFC 4.3 (IFC4X3_ADD2) para infraestructura vial y de transporte.

Regla fundamental:
Un objeto solo puede convertirse en producto físico IFC si posee una
geometría paramétrica 3D validada sin conflictos documentales críticos.
"""

from ifc.authoring_pipeline import IFCAuthoringPipeline
from ifc.guid_registry import IFCGuidRegistry
from ifc.semantic_mapper import IFCSemanticMapper
from ifc.geometry_translator import IFCGeometryTranslator
from ifc.placement_builder import IFCPlacementBuilder
from ifc.property_set_builder import IFCPropertySetBuilder
from ifc.validator import IFCValidator

__all__ = [
    "IFCAuthoringPipeline",
    "IFCGuidRegistry",
    "IFCSemanticMapper",
    "IFCGeometryTranslator",
    "IFCPlacementBuilder",
    "IFCPropertySetBuilder",
    "IFCValidator",
]
