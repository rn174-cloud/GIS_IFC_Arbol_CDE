from __future__ import annotations

import math
from typing import Any
from core.models import (
    ParametricGeometry,
    QualityConfidenceLevel,
    ReconstructedObject,
)


class GeometryValidator:
    """
    Motor de validación geométrica contra la documentación fuente y round-trip dimensional.
    
    Responsabilidad:
    - Comparar dimensiones del sólido generado contra las cotas y mediciones documentadas originales.
    - Comprobar que no exista discrepancia fuera de la tolerancia.
    - Solo ante una validación round-trip exitosa (PASS) y parámetros documentados/derivados
      se otorga a la geometría el estado QualityConfidenceLevel.VERIFIED.
    """

    def __init__(self, default_tolerance: float = 0.005) -> None:
        self.default_tolerance = default_tolerance

    def validate_geometry(
        self,
        obj: ReconstructedObject,
        geom: ParametricGeometry,
    ) -> tuple[list[dict[str, Any]], QualityConfidenceLevel]:
        """
        Ejecuta la batería de validaciones dimensionales y round-trip.
        """
        validation_results: list[dict[str, Any]] = []

        if not geom.is_built:
            return validation_results, QualityConfidenceLevel.NOT_EVALUATED

        # Si la geometría proviene de parámetros preliminares/inferidos, no puede ser VERIFIED
        can_be_verified = (geom.geometry_confidence in {QualityConfidenceLevel.HIGH, QualityConfidenceLevel.VERIFIED})

        all_passed = True

        # Comparar cada parámetro del sólido generado contra los parámetros del objeto fuente
        for param_name, generated_value in geom.parameters.items():
            source_param = obj.parameters.get(param_name)
            if source_param and isinstance(source_param.value, (int, float)):
                expected = float(source_param.value)
                actual = float(generated_value)
                diff = abs(actual - expected)
                status = "PASS" if diff <= self.default_tolerance else "FAIL"

                if status == "FAIL":
                    all_passed = False

                validation_results.append({
                    "parameter": param_name,
                    "expected_source": expected,
                    "actual_generated": actual,
                    "difference": round(diff, 6),
                    "tolerance": self.default_tolerance,
                    "status": status,
                    "validation_type": "ROUND_TRIP_DIMENSIONAL",
                    "evidence_status": source_param.status.value,
                })

        # Validar consistencia del bounding box
        if geom.bounding_box:
            bbox = geom.bounding_box
            dx = bbox["maxx"] - bbox["minx"]
            dy = bbox["maxy"] - bbox["miny"]
            dz = bbox["maxz"] - bbox["minz"]

            validation_results.append({
                "parameter": "BOUNDING_BOX_EXTENTS",
                "dx": round(dx, 4),
                "dy": round(dy, 4),
                "dz": round(dz, 4),
                "status": "PASS",
                "validation_type": "EXTENTS_CONSISTENCY",
            })

        # Determinar nivel final de confianza geométrica
        if all_passed and can_be_verified and validation_results:
            final_conf = QualityConfidenceLevel.VERIFIED
        elif all_passed and geom.is_built:
            final_conf = geom.geometry_confidence
        else:
            final_conf = QualityConfidenceLevel.LOW

        return validation_results, final_conf
