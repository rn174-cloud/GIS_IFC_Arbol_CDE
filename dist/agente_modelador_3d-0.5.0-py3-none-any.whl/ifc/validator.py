from __future__ import annotations

from typing import Any
import ifcopenshell


class IFCValidator:
    """
    Motor de validación estricta de conformidad para modelos IFC 4.3 (IFC4X3_ADD2).
    
    Verificaciones:
    - Schema IFC4X3_ADD2.
    - Exactamente un IfcProject.
    - Presencia de IfcSite e IfcFacility (o subtipo).
    - Containment espacial de todos los productos físicos.
    - GlobalIds únicos y válidos.
    - Representación geométrica existente en productos construidos.
    - Presencia de Psets obligatorios.
    """

    def validate_model(self, model: ifcopenshell.file) -> dict[str, Any]:
        errors: list[str] = []
        warnings: list[str] = []

        # 1. Schema
        schema = model.schema
        if not schema.startswith("IFC4X3"):
            errors.append(f"Schema no conforme: se esperaba IFC4X3, se obtuvo {schema}")

        # 2. Proyecto único
        projects = model.by_type("IfcProject")
        if len(projects) != 1:
            errors.append(f"Debe existir exactamente 1 IfcProject, se encontraron {len(projects)}")

        # 3. Spatial Hierarchy
        sites = model.by_type("IfcSite")
        if not sites:
            errors.append("No se encontró ninguna entidad IfcSite en el modelo")

        facilities = model.by_type("IfcFacility")
        if not facilities:
            warnings.append("No se encontró IfcFacility explícito (podría ser un subtipo como IfcRoad o IfcBridge)")

        # 4. GlobalIds
        all_guids = [e.GlobalId for e in model if hasattr(e, "GlobalId") and e.GlobalId]
        if len(all_guids) != len(set(all_guids)):
            errors.append("Existen GlobalIds duplicados en el modelo IFC")

        # 5. Productos físicos
        products = model.by_type("IfcProduct")
        # Filtrar espaciales
        spatial_types = {"IfcProject", "IfcSite", "IfcFacility", "IfcBridge", "IfcRoad", "IfcRailway", "IfcMarineFacility", "IfcBuilding"}
        physical_products = [p for p in products if p.is_a() not in spatial_types]

        for p in physical_products:
            # Containment
            if not p.ContainedInStructure:
                errors.append(f"El producto {p.GlobalId} ({p.is_a()}) no está contenido en una estructura espacial")

            # Representación
            if not p.Representation:
                errors.append(f"El producto físico {p.GlobalId} ({p.is_a()}) carece de IfcProductDefinitionShape")

        # 6. Property sets
        psets = model.by_type("IfcPropertySet")
        pset_names = {ps.Name for ps in psets if ps.Name}

        for mandatory_pset in ["Pset_SourceTraceability", "Pset_ReconstructedParameters", "Pset_ReconstructionQuality"]:
            if physical_products and mandatory_pset not in pset_names:
                warnings.append(f"Falta el Property Set obligatorio {mandatory_pset} en el modelo")

        is_valid = (len(errors) == 0)

        return {
            "is_valid": is_valid,
            "schema": schema,
            "total_entities": len(list(model)),
            "physical_products_count": len(physical_products),
            "errors": errors,
            "warnings": warnings,
        }
