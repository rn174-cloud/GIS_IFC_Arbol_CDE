from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional


class CandidateType(str, Enum):
    """
    Clasificación técnica de candidatos de valor extraídos.
    """
    MEASUREMENT = "MEASUREMENT"
    STATION = "STATION"
    ELEVATION = "ELEVATION"
    ANGLE = "ANGLE"
    IDENTIFIER = "IDENTIFIER"
    COUNT = "COUNT"
    UNKNOWN_NUMERIC = "UNKNOWN_NUMERIC"


class SemanticFamily(str, Enum):
    """
    Familias semánticas generales y neutrales para clasificación de candidatos.
    NO representan clases IFC finales.
    """
    STRUCTURAL = "STRUCTURAL"
    PAVEMENT = "PAVEMENT"
    DRAINAGE = "DRAINAGE"
    EARTHWORKS = "EARTHWORKS"
    ROAD_SAFETY = "ROAD_SAFETY"
    LIGHTING = "LIGHTING"
    SIGNAGE = "SIGNAGE"
    UTILITIES = "UTILITIES"
    RAIL = "RAIL"
    MARINE = "MARINE"
    GEOTECHNICAL = "GEOTECHNICAL"
    ALIGNMENT = "ALIGNMENT"
    BUILDING_SUPPORT = "BUILDING_SUPPORT"
    EQUIPMENT = "EQUIPMENT"
    UNKNOWN = "UNKNOWN"


class CandidateStatus(str, Enum):
    """
    Estados permitidos para un ObjectCandidate.
    """
    UNRESOLVED = "UNRESOLVED"
    PARTIALLY_RESOLVED = "PARTIALLY_RESOLVED"
    RESOLVED = "RESOLVED"
    REJECTED = "REJECTED"


class CandidateRelationType(str, Enum):
    """
    Tipos de relación entre candidatos a objeto.
    """
    POSSIBLE_SAME_OBJECT = "POSSIBLE_SAME_OBJECT"
    POSSIBLE_PARENT = "POSSIBLE_PARENT"
    POSSIBLE_CHILD = "POSSIBLE_CHILD"
    POSSIBLE_SYSTEM_MEMBER = "POSSIBLE_SYSTEM_MEMBER"
    POSSIBLE_REPEATED_INSTANCE = "POSSIBLE_REPEATED_INSTANCE"
    UNRELATED = "UNRELATED"


class EvidenceOrigin(str, Enum):
    """
    Grupo u origen de evidencia para prevenir doble conteo de fuentes correlacionadas.
    """
    CAD_LAYER = "CAD_LAYER"
    CAD_BLOCK = "CAD_BLOCK"
    TEXTUAL = "TEXTUAL"
    GEOMETRIC = "GEOMETRIC"
    SPATIAL = "SPATIAL"
    STATIONING = "STATIONING"
    DIMENSIONAL = "DIMENSIONAL"
    MULTIVIEW = "MULTIVIEW"
    TABULAR = "TABULAR"
    GIS = "GIS"
    NEGATIVE = "NEGATIVE"
    UNKNOWN = "UNKNOWN"


class ProximityLevel(str, Enum):
    """
    Nivel de proximidad espacial real entre entidades, textos o cotas.
    """
    VERY_NEAR = "VERY_NEAR"
    NEAR = "NEAR"
    SAME_REGION = "SAME_REGION"
    FAR = "FAR"


class SignalScope(str, Enum):
    """
    Alcance documental de una señal semántica.
    """
    LOCAL_TO_PRIMITIVE = "LOCAL_TO_PRIMITIVE"
    GROUP_LEVEL = "GROUP_LEVEL"
    SHARED_REGION_CONTEXT = "SHARED_REGION_CONTEXT"


@dataclass
class SemanticSignal:
    """
    Evidencia atómica con significado técnico que apoya o refuta la hipótesis de un objeto.
    """
    signal_type: str
    value: Any
    source_id: str
    confidence: float
    weight: float = 1.0
    contribution: float = 0.0
    signal_group: EvidenceOrigin = EvidenceOrigin.UNKNOWN
    is_negative: bool = False
    entity_reference: Optional[str] = None
    view_id: Optional[str] = None
    notes: Optional[str] = None
    scope: str = "LOCAL_TO_PRIMITIVE"

    # Auditoría de proximidad real (cuando aplica)
    real_distance: Optional[float] = None
    proximity_level: Optional[ProximityLevel] = None
    coordinate_system: Optional[str] = None
    entity_bbox: Optional[dict[str, float]] = None
    target_bbox: Optional[dict[str, float]] = None
    distance_threshold: Optional[float] = None
    distance_method: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "signal_type": self.signal_type,
            "value": self.value,
            "source_id": self.source_id,
            "entity_reference": self.entity_reference,
            "view_id": self.view_id,
            "confidence": self.confidence,
            "weight": self.weight,
            "contribution": self.contribution,
            "signal_group": self.signal_group.value,
            "is_negative": self.is_negative,
            "scope": self.scope,
            "real_distance": self.real_distance,
            "proximity_level": self.proximity_level.value if self.proximity_level else None,
            "coordinate_system": self.coordinate_system,
            "entity_bbox": self.entity_bbox,
            "target_bbox": self.target_bbox,
            "distance_threshold": self.distance_threshold,
            "distance_method": self.distance_method,
            "notes": self.notes,
        }


@dataclass
class PrimitiveEvidence:
    """
    Representación atómica neutral de una entidad geométrica en modelspace.
    No es un candidato a objeto. Es evidencia gráfica documental.
    """
    primitive_id: str
    entity_handle: str
    entity_type: str
    layer: str
    bbox: dict[str, float]
    geometry: dict[str, Any]
    region_id: str
    nearby_text_refs: list[str] = field(default_factory=list)
    nearby_dimension_refs: list[str] = field(default_factory=list)
    block_ref: Optional[str] = None
    signal_refs: list[str] = field(default_factory=list)
    evidence_groups: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "primitive_id": self.primitive_id,
            "entity_handle": self.entity_handle,
            "entity_type": self.entity_type,
            "layer": self.layer,
            "bbox": self.bbox,
            "geometry": self.geometry,
            "region_id": self.region_id,
            "nearby_text_refs": self.nearby_text_refs,
            "nearby_dimension_refs": self.nearby_dimension_refs,
            "block_ref": self.block_ref,
            "signal_refs": self.signal_refs,
            "evidence_groups": self.evidence_groups,
        }


@dataclass
class GeometricMotif:
    """
    Patrón geométrico recurrente o estructurado descubierto entre una o más primitivas.
    """
    motif_id: str
    motif_type: str
    member_primitive_ids: list[str] = field(default_factory=list)
    member_handles: list[str] = field(default_factory=list)
    bbox: dict[str, float] = field(default_factory=dict)
    region_id: str = ""
    properties: dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.5

    def to_dict(self) -> dict[str, Any]:
        return {
            "motif_id": self.motif_id,
            "motif_type": self.motif_type,
            "member_primitive_ids": self.member_primitive_ids,
            "member_handles": self.member_handles,
            "bbox": self.bbox,
            "region_id": self.region_id,
            "properties": self.properties,
            "confidence": self.confidence,
        }


@dataclass
class LocalGeometryGroup:
    """
    Grupo de primitivas geométricas conectadas o clusterizadas espacialmente dentro de una región.
    Es estrictamente region-local.
    """
    group_id: str
    member_primitive_ids: list[str] = field(default_factory=list)
    member_handles: list[str] = field(default_factory=list)
    bbox: dict[str, float] = field(default_factory=dict)
    region_id: str = ""
    connectivity_type: str = "CONNECTED_CHAIN"
    connectivity_threshold: float = 0.0
    threshold_method: str = "ADAPTIVE_LOCAL_STATS"
    text_refs: list[str] = field(default_factory=list)
    dimension_refs: list[str] = field(default_factory=list)
    motif_refs: list[str] = field(default_factory=list)
    confidence: float = 0.5

    def to_dict(self) -> dict[str, Any]:
        return {
            "group_id": self.group_id,
            "member_primitive_ids": self.member_primitive_ids,
            "member_handles": self.member_handles,
            "bbox": self.bbox,
            "region_id": self.region_id,
            "connectivity_type": self.connectivity_type,
            "connectivity_threshold": self.connectivity_threshold,
            "threshold_method": self.threshold_method,
            "text_refs": self.text_refs,
            "dimension_refs": self.dimension_refs,
            "motif_refs": self.motif_refs,
            "confidence": self.confidence,
        }



@dataclass
class CandidateRelation:
    """
    Relación inferida o detectada entre dos candidatos a objeto.
    """
    relation_type: CandidateRelationType
    source_candidate_id: str
    target_candidate_id: str
    confidence: float = 0.5
    notes: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "relation_type": self.relation_type.value,
            "source_candidate_id": self.source_candidate_id,
            "target_candidate_id": self.target_candidate_id,
            "confidence": self.confidence,
            "notes": self.notes,
        }


@dataclass
class ObjectCandidate:
    """
    Candidato a objeto real detectado a partir de evidencia documental agrupada.
    No asigna clase IFC física final salvo regla inequívoca y explícita.
    """
    candidate_id: str
    probable_family: SemanticFamily = SemanticFamily.UNKNOWN
    probable_type: str = "UNKNOWN"
    confidence: float = 0.0
    status: CandidateStatus = CandidateStatus.UNRESOLVED
    source_ids: list[str] = field(default_factory=list)
    entity_references: list[str] = field(default_factory=list)
    view_ids: list[str] = field(default_factory=list)
    spatial_extent: Optional[dict[str, Any]] = None
    station: Optional[float] = None
    offset: Optional[float] = None
    elevation: Optional[float] = None
    labels: list[str] = field(default_factory=list)
    related_texts: list[str] = field(default_factory=list)
    semantic_signals: list[SemanticSignal] = field(default_factory=list)
    candidate_relations: list[CandidateRelation] = field(default_factory=list)
    parameter_candidates: list[dict[str, Any]] = field(default_factory=list)
    notes: Optional[str] = None

    # Trazabilidad de tipo de regla y evidencia de tipo
    type_evidence: list[str] = field(default_factory=list)
    type_rule_id: Optional[str] = None

    # Auditoría matemática exacta del scoring
    raw_signal_score: float = 0.0
    weighted_score: float = 0.0
    normalization_factor: float = 1.0
    penalties: float = 0.0
    boosts: float = 0.0
    final_confidence: float = 0.0

    # Agrupamiento v0.5.2
    group_id: Optional[str] = None
    motifs: list[str] = field(default_factory=list)
    member_primitive_count: int = 1
    promotion_reason: str = "OTHER_EXPLICIT_EVIDENCE"

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "probable_family": self.probable_family.value,
            "probable_type": self.probable_type,
            "confidence": self.confidence,
            "status": self.status.value,
            "source_ids": self.source_ids,
            "entity_references": self.entity_references,
            "view_ids": self.view_ids,
            "spatial_extent": self.spatial_extent,
            "station": self.station,
            "offset": self.offset,
            "elevation": self.elevation,
            "labels": self.labels,
            "related_texts": self.related_texts,
            "semantic_signals": [s.to_dict() for s in self.semantic_signals],
            "candidate_relations": [r.to_dict() for r in self.candidate_relations],
            "parameter_candidates": self.parameter_candidates,
            "type_evidence": self.type_evidence,
            "type_rule_id": self.type_rule_id,
            "raw_signal_score": self.raw_signal_score,
            "weighted_score": self.weighted_score,
            "normalization_factor": self.normalization_factor,
            "penalties": self.penalties,
            "boosts": self.boosts,
            "final_confidence": self.final_confidence,
            "group_id": self.group_id,
            "motifs": self.motifs,
            "member_primitive_count": self.member_primitive_count,
            "promotion_reason": self.promotion_reason,
            "notes": self.notes,
        }


class MatchDecision(str, Enum):
    """
    Decisión de correspondencia entre dos candidatos procedentes de distintas vistas/fuentes.
    """
    SAME_OBJECT = "SAME_OBJECT"
    POSSIBLE_SAME_OBJECT = "POSSIBLE_SAME_OBJECT"
    DIFFERENT_OBJECT = "DIFFERENT_OBJECT"
    PARENT_CHILD = "PARENT_CHILD"
    SYSTEM_RELATED = "SYSTEM_RELATED"
    REPEATED_INSTANCE = "REPEATED_INSTANCE"
    UNRESOLVED = "UNRESOLVED"


@dataclass
class ResolutionEvidence:
    """
    Pieza atómica de evidencia a favor o en contra de un match multivista.
    """
    criterion: str
    description: str
    score: float = 0.0
    is_supporting: bool = True
    rule_id: Optional[str] = None
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "criterion": self.criterion,
            "description": self.description,
            "score": self.score,
            "is_supporting": self.is_supporting,
            "rule_id": self.rule_id,
            "details": self.details,
        }


@dataclass
class EvidenceMatch:
    """
    Resultado auditable de comparación entre dos ObjectCandidate.
    """
    match_id: str
    candidate_a_id: str
    candidate_b_id: str
    decision: MatchDecision
    confidence: float
    evidence_for: list[ResolutionEvidence] = field(default_factory=list)
    evidence_against: list[ResolutionEvidence] = field(default_factory=list)

    # Desglose de sub-scores auditables
    spatial_score: float = 0.0
    station_score: float = 0.0
    label_score: float = 0.0
    dimensional_score: float = 0.0
    geometric_score: float = 0.0
    view_compatibility_score: float = 0.0
    source_independence_score: float = 0.0
    penalties: float = 0.0
    final_score: float = 0.0

    rule_ids: list[str] = field(default_factory=list)
    notes: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "match_id": self.match_id,
            "candidate_a_id": self.candidate_a_id,
            "candidate_b_id": self.candidate_b_id,
            "decision": self.decision.value,
            "confidence": self.confidence,
            "evidence_for": [e.to_dict() for e in self.evidence_for],
            "evidence_against": [e.to_dict() for e in self.evidence_against],
            "spatial_score": self.spatial_score,
            "station_score": self.station_score,
            "label_score": self.label_score,
            "dimensional_score": self.dimensional_score,
            "geometric_score": self.geometric_score,
            "view_compatibility_score": self.view_compatibility_score,
            "source_independence_score": self.source_independence_score,
            "penalties": self.penalties,
            "final_score": self.final_score,
            "rule_ids": self.rule_ids,
            "notes": self.notes,
        }


@dataclass
class ObjectHypothesis:
    """
    Hipótesis consolidada de un objeto real a partir de candidatos conectados por EvidenceMatch.
    """
    hypothesis_id: str
    member_candidate_ids: list[str] = field(default_factory=list)
    probable_family: SemanticFamily = SemanticFamily.UNKNOWN
    probable_type: str = "UNKNOWN"
    resolution_status: CandidateStatus = CandidateStatus.UNRESOLVED
    confidence: float = 0.0
    supporting_matches: list[str] = field(default_factory=list)
    contradicting_matches: list[str] = field(default_factory=list)
    parameter_candidates: list[dict[str, Any]] = field(default_factory=list)
    spatial_reference: dict[str, Any] = field(default_factory=dict)
    station: Optional[float] = None
    offset: Optional[float] = None
    elevation: Optional[float] = None
    source_ids: list[str] = field(default_factory=list)
    view_ids: list[str] = field(default_factory=list)
    unresolved_questions: list[str] = field(default_factory=list)
    data_gaps: list[str] = field(default_factory=list)
    is_singleton: bool = False
    notes: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "hypothesis_id": self.hypothesis_id,
            "member_candidate_ids": self.member_candidate_ids,
            "probable_family": self.probable_family.value,
            "probable_type": self.probable_type,
            "resolution_status": self.resolution_status.value,
            "confidence": self.confidence,
            "supporting_matches": self.supporting_matches,
            "contradicting_matches": self.contradicting_matches,
            "parameter_candidates": self.parameter_candidates,
            "spatial_reference": self.spatial_reference,
            "station": self.station,
            "offset": self.offset,
            "elevation": self.elevation,
            "source_ids": self.source_ids,
            "view_ids": self.view_ids,
            "unresolved_questions": self.unresolved_questions,
            "data_gaps": self.data_gaps,
            "is_singleton": self.is_singleton,
            "notes": self.notes,
        }


class EvidenceStatus(str, Enum):
    """
    Estado de evidencia de un parámetro.

    DOCUMENTED:
        El valor aparece explícitamente en una fuente documental.

    DERIVED:
        El valor fue calculado a partir de información documentada.

    INTERPOLATED:
        El valor fue obtenido por interpolación entre datos documentados.

    INFERRED:
        El valor fue deducido razonablemente, pero no aparece de forma explícita.

    PROVISIONAL:
        Valor temporal adoptado para permitir una representación preliminar.

    UNKNOWN:
        No existe información suficiente para determinar el valor.
    """

    DOCUMENTED = "DOCUMENTED"
    DERIVED = "DERIVED"
    INTERPOLATED = "INTERPOLATED"
    INFERRED = "INFERRED"
    PROVISIONAL = "PROVISIONAL"
    UNKNOWN = "UNKNOWN"


class ConfidenceLevel(str, Enum):
    """
    Nivel global de confianza de un objeto reconstruido (conservado para compatibilidad).
    """

    A_VERIFIED = "A_VERIFIED"
    B_MOSTLY_VERIFIED = "B_MOSTLY_VERIFIED"
    C_PARTIALLY_INFERRED = "C_PARTIALLY_INFERRED"
    D_PROVISIONAL = "D_PROVISIONAL"


class QualityConfidenceLevel(str, Enum):
    """
    Niveles explícitos de confianza por faceta (identidad, semántica, parámetros, geometría).
    """
    NOT_EVALUATED = "NOT_EVALUATED"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    VERIFIED = "VERIFIED"


@dataclass
class ObjectConfidenceBreakdown:
    """
    Desglose transparente de confianza que previene confundir evidencia semántica con completitud geométrica.
    """
    identity_confidence: QualityConfidenceLevel = QualityConfidenceLevel.NOT_EVALUATED
    semantic_confidence: QualityConfidenceLevel = QualityConfidenceLevel.NOT_EVALUATED
    parameter_confidence: QualityConfidenceLevel = QualityConfidenceLevel.NOT_EVALUATED
    geometry_confidence: QualityConfidenceLevel = QualityConfidenceLevel.NOT_EVALUATED

    def to_dict(self) -> dict[str, str]:
        return {
            "identity_confidence": self.identity_confidence.value,
            "semantic_confidence": self.semantic_confidence.value,
            "parameter_confidence": self.parameter_confidence.value,
            "geometry_confidence": self.geometry_confidence.value,
        }


class RecipeType(str, Enum):
    """
    Tipos fundamentales de receta geométrica 3D paramétrica.
    """
    RECTANGULAR_EXTRUSION = "RECTANGULAR_EXTRUSION"
    CIRCULAR_EXTRUSION = "CIRCULAR_EXTRUSION"
    POLYGON_EXTRUSION = "POLYGON_EXTRUSION"
    LINEAR_SWEEP = "LINEAR_SWEEP"
    PROFILE_SWEEP = "PROFILE_SWEEP"
    REVOLUTION = "REVOLUTION"
    LOFT = "LOFT"
    BOOLEAN_COMBINATION = "BOOLEAN_COMBINATION"
    POLYLINE_SURFACE = "POLYLINE_SURFACE"
    UNKNOWN = "UNKNOWN"


class ParameterEligibilityStatus(str, Enum):
    """
    Clasificación de admisibilidad de parámetros para uso en reconstrucción geométrica.
    """
    ACCEPTED_DOCUMENTED = "ACCEPTED_DOCUMENTED"
    ACCEPTED_DERIVED = "ACCEPTED_DERIVED"
    ACCEPTED_INTERPOLATED = "ACCEPTED_INTERPOLATED"
    REJECTED_INFERRED = "REJECTED_INFERRED"
    REJECTED_PROVISIONAL = "REJECTED_PROVISIONAL"
    REJECTED_UNKNOWN = "REJECTED_UNKNOWN"
    REJECTED_CONFLICT = "REJECTED_CONFLICT"


@dataclass
class GeometryRecipe:
    """
    Especificación paramétrica para construir la geometría 3D de un objeto
    a partir de evidencia verificable sin inventar dimensiones.
    """
    recipe_id: str
    object_id: str
    recipe_type: RecipeType
    required_parameters: list[str] = field(default_factory=list)
    optional_parameters: list[str] = field(default_factory=list)
    source_parameters: dict[str, Any] = field(default_factory=dict)
    coordinate_system: Optional[str] = None
    local_frame: Optional[dict[str, Any]] = None
    profile_definition: dict[str, Any] = field(default_factory=dict)
    path_definition: Optional[dict[str, Any]] = None
    operations: list[dict[str, Any]] = field(default_factory=list)
    evidence_status: EvidenceStatus = EvidenceStatus.UNKNOWN
    geometry_confidence: QualityConfidenceLevel = QualityConfidenceLevel.NOT_EVALUATED
    unresolved_parameters: list[str] = field(default_factory=list)
    validation_rules: list[str] = field(default_factory=list)
    notes: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "recipe_id": self.recipe_id,
            "object_id": self.object_id,
            "recipe_type": self.recipe_type.value,
            "required_parameters": self.required_parameters,
            "optional_parameters": self.optional_parameters,
            "source_parameters": self.source_parameters,
            "coordinate_system": self.coordinate_system,
            "local_frame": self.local_frame,
            "profile_definition": self.profile_definition,
            "path_definition": self.path_definition,
            "operations": self.operations,
            "evidence_status": self.evidence_status.value,
            "geometry_confidence": self.geometry_confidence.value,
            "unresolved_parameters": self.unresolved_parameters,
            "validation_rules": self.validation_rules,
            "notes": self.notes,
        }


@dataclass
class ParametricGeometry:
    """
    Resultado de la construcción geométrica 3D trazable.
    """
    geometry_id: str
    object_id: str
    recipe_id: str
    geometry_type: RecipeType
    parameters: dict[str, Any] = field(default_factory=dict)
    local_frame: Optional[dict[str, Any]] = None
    vertices: list[list[float]] = field(default_factory=list)
    faces: list[list[int]] = field(default_factory=list)
    bounding_box: Optional[dict[str, float]] = None
    volume: Optional[float] = None
    surface_area: Optional[float] = None
    source_traceability: list[dict[str, Any]] = field(default_factory=list)
    geometry_confidence: QualityConfidenceLevel = QualityConfidenceLevel.NOT_EVALUATED
    validation_results: list[dict[str, Any]] = field(default_factory=list)
    data_gaps: list[dict[str, Any]] = field(default_factory=list)
    conflicts: list[dict[str, Any]] = field(default_factory=list)
    is_built: bool = False
    build_failure_reason: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "geometry_id": self.geometry_id,
            "object_id": self.object_id,
            "recipe_id": self.recipe_id,
            "geometry_type": self.geometry_type.value,
            "parameters": self.parameters,
            "local_frame": self.local_frame,
            "vertices": self.vertices,
            "faces": self.faces,
            "bounding_box": self.bounding_box,
            "volume": self.volume,
            "surface_area": self.surface_area,
            "source_traceability": self.source_traceability,
            "geometry_confidence": self.geometry_confidence.value,
            "validation_results": self.validation_results,
            "data_gaps": self.data_gaps,
            "conflicts": self.conflicts,
            "is_built": self.is_built,
            "build_failure_reason": self.build_failure_reason,
        }


@dataclass
class IFCMappingDecision:
    """
    Decisión auditable de asignación de clase y tipo predefinido IFC 4.3.
    """
    object_id: str
    requested_family: str
    probable_type: str
    selected_ifc_class: str
    selected_predefined_type: Optional[str] = None
    mapping_confidence: float = 1.0
    rule_id: Optional[str] = None
    supporting_evidence: list[str] = field(default_factory=list)
    fallback_used: bool = False
    notes: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "object_id": self.object_id,
            "requested_family": self.requested_family,
            "probable_type": self.probable_type,
            "selected_ifc_class": self.selected_ifc_class,
            "selected_predefined_type": self.selected_predefined_type,
            "mapping_confidence": self.mapping_confidence,
            "rule_id": self.rule_id,
            "supporting_evidence": self.supporting_evidence,
            "fallback_used": self.fallback_used,
            "notes": self.notes,
        }


@dataclass
class SourceReference:
    """
    Referencia trazable hacia una fuente documental.

    Los campos son opcionales porque diferentes fuentes
    pueden ofrecer distintos niveles de detalle.
    """

    source_file: Optional[str] = None
    source_type: Optional[str] = None

    drawing_number: Optional[str] = None
    drawing_title: Optional[str] = None

    sheet: Optional[str] = None
    revision: Optional[str] = None
    date: Optional[str] = None

    layer: Optional[str] = None
    entity_id: Optional[str] = None

    view: Optional[str] = None
    parameter_reference: Optional[str] = None

    coordinate_reference: Optional[str] = None

    notes: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_file": self.source_file,
            "source_type": self.source_type,
            "drawing_number": self.drawing_number,
            "drawing_title": self.drawing_title,
            "sheet": self.sheet,
            "revision": self.revision,
            "date": self.date,
            "layer": self.layer,
            "entity_id": self.entity_id,
            "view": self.view,
            "parameter_reference": self.parameter_reference,
            "coordinate_reference": self.coordinate_reference,
            "notes": self.notes,
        }


@dataclass
class ParameterValue:
    """
    Parámetro técnico asociado a un objeto reconstruido.

    Nunca debe existir un valor importante sin:
    - unidad;
    - estado de evidencia;
    - fuente, cuando esté disponible.
    """

    name: str
    value: Any = None
    unit: Optional[str] = None

    status: EvidenceStatus = EvidenceStatus.UNKNOWN

    sources: list[SourceReference] = field(
        default_factory=list
    )

    tolerance: Optional[float] = None
    confidence: Optional[float] = None

    notes: Optional[str] = None

    def is_usable_for_verified_geometry(self) -> bool:
        """
        Indica si este parámetro puede utilizarse directamente
        para construir geometría considerada verificable.
        """
        return (
            self.value is not None
            and self.status
            in {
                EvidenceStatus.DOCUMENTED,
                EvidenceStatus.DERIVED,
                EvidenceStatus.INTERPOLATED,
            }
        )

    def is_low_evidence(self) -> bool:
        """
        Indica si el parámetro depende de inferencia,
        provisionalidad o falta de datos.
        """
        return self.status in {
            EvidenceStatus.INFERRED,
            EvidenceStatus.PROVISIONAL,
            EvidenceStatus.UNKNOWN,
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "value": self.value,
            "unit": self.unit,
            "status": self.status.value,
            "sources": [
                source.to_dict()
                for source in self.sources
            ],
            "tolerance": self.tolerance,
            "confidence": self.confidence,
            "notes": self.notes,
        }


@dataclass
class SourceDocument:
    """
    Representación interna de una fuente documental.

    Puede ser un DWG, DXF, PDF, GIS, CSV, XLSX u otro
    formato admitido por el pipeline.
    """

    path: Path
    file_type: str

    source_id: Optional[str] = None
    sha256: Optional[str] = None
    file_size: Optional[int] = None

    drawing_number: Optional[str] = None
    drawing_title: Optional[str] = None

    discipline: Optional[str] = None
    revision: Optional[str] = None
    date: Optional[str] = None

    scale: Optional[str] = None
    units: Optional[str] = None
    crs: Optional[str] = None

    document_role: Optional[str] = None

    metadata: dict[str, Any] = field(
        default_factory=dict
    )

    extracted_data: dict[str, Any] = field(
        default_factory=dict
    )

    warnings: list[str] = field(
        default_factory=list
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id,
            "sha256": self.sha256,
            "file_size": self.file_size,
            "path": str(self.path),
            "file_type": self.file_type,
            "drawing_number": self.drawing_number,
            "drawing_title": self.drawing_title,
            "discipline": self.discipline,
            "revision": self.revision,
            "date": self.date,
            "scale": self.scale,
            "units": self.units,
            "crs": self.crs,
            "document_role": self.document_role,
            "metadata": self.metadata,
            "extracted_data": self.extracted_data,
            "warnings": self.warnings,
        }


@dataclass
class ViewEvidence:
    """
    Evidencia proveniente de una vista o representación.

    Ejemplos:
    - planta;
    - perfil;
    - sección;
    - elevación;
    - detalle;
    - tabla;
    - esquema.
    """

    view_id: str
    view_type: str

    source: SourceReference

    bounding_box: Optional[dict[str, float]] = None
    detection_method: str = "UNRESOLVED"

    geometry: dict[str, Any] = field(
        default_factory=dict
    )

    entity_references: list[str] = field(
        default_factory=list
    )

    texts: list[str] = field(
        default_factory=list
    )

    dimensions: list[dict[str, Any]] = field(
        default_factory=list
    )

    candidate_object_ids: list[str] = field(
        default_factory=list
    )

    confidence: Optional[float] = None

    notes: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "view_id": self.view_id,
            "view_type": self.view_type,
            "bounding_box": self.bounding_box,
            "detection_method": self.detection_method,
            "source": self.source.to_dict(),
            "geometry": self.geometry,
            "entity_references": self.entity_references,
            "texts": self.texts,
            "dimensions": self.dimensions,
            "candidate_object_ids": self.candidate_object_ids,
            "confidence": self.confidence,
            "notes": self.notes,
        }


@dataclass
class DataGap:
    """
    Información faltante necesaria para completar o validar
    un objeto o parámetro.
    """

    object_id: str
    parameter: str

    description: str

    criticality: str = "MEDIUM"

    expected_source: Optional[str] = None

    impact: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "object_id": self.object_id,
            "parameter": self.parameter,
            "description": self.description,
            "criticality": self.criticality,
            "expected_source": self.expected_source,
            "impact": self.impact,
        }


@dataclass
class DocumentConflict:
    """
    Conflicto entre fuentes que definen valores incompatibles
    para el mismo parámetro.
    """

    object_id: str
    parameter: str

    source_a: SourceReference
    value_a: Any

    source_b: SourceReference
    value_b: Any

    impact: Optional[str] = None

    resolution: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "object_id": self.object_id,
            "parameter": self.parameter,
            "source_a": self.source_a.to_dict(),
            "value_a": self.value_a,
            "source_b": self.source_b.to_dict(),
            "value_b": self.value_b,
            "impact": self.impact,
            "resolution": self.resolution,
        }


@dataclass
class ReconstructedObject:
    """
    Objeto técnico identificado y reconstruido a partir
    de evidencia documental.

    Este objeto es independiente de IFC.
    Primero se comprende y reconstruye el activo.
    Después se traduce a semántica IFC 4.3.
    """

    object_id: str

    name: Optional[str] = None

    object_type: Optional[str] = None
    family: Optional[str] = None

    system: Optional[str] = None
    subsystem: Optional[str] = None

    ifc_class: Optional[str] = None
    ifc_predefined_type: Optional[str] = None

    parameters: dict[str, ParameterValue] = field(
        default_factory=dict
    )

    views: list[ViewEvidence] = field(
        default_factory=list
    )

    geometry_definition: dict[str, Any] = field(
        default_factory=dict
    )

    spatial_reference: dict[str, Any] = field(
        default_factory=dict
    )

    source_documents: list[str] = field(
        default_factory=list
    )

    confidence_level: ConfidenceLevel = (
        ConfidenceLevel.D_PROVISIONAL
    )

    confidence_breakdown: ObjectConfidenceBreakdown = field(
        default_factory=ObjectConfidenceBreakdown
    )

    data_gaps: list[DataGap] = field(
        default_factory=list
    )

    conflicts: list[DocumentConflict] = field(
        default_factory=list
    )

    metadata: dict[str, Any] = field(
        default_factory=dict
    )

    global_id: Optional[str] = None

    def add_parameter(
        self,
        parameter: ParameterValue,
    ) -> None:
        self.parameters[parameter.name] = parameter

    def get_parameter(
        self,
        name: str,
    ) -> Optional[ParameterValue]:
        return self.parameters.get(name)

    def require_parameter(
        self,
        name: str,
    ) -> ParameterValue:
        """
        Obtiene un parámetro obligatorio.

        Si no existe, genera una excepción explícita.
        El agente no debe reemplazar silenciosamente
        parámetros faltantes por constantes arbitrarias.
        """
        parameter = self.get_parameter(name)

        if parameter is None:
            raise KeyError(
                f"El objeto {self.object_id!r} no posee "
                f"el parámetro obligatorio {name!r}."
            )

        return parameter

    def has_verified_parameter(
        self,
        name: str,
    ) -> bool:
        parameter = self.get_parameter(name)

        return bool(
            parameter
            and parameter.is_usable_for_verified_geometry()
        )

    def low_evidence_parameters(
        self,
    ) -> list[ParameterValue]:
        return [
            parameter
            for parameter in self.parameters.values()
            if parameter.is_low_evidence()
        ]

    def update_confidence_level(self) -> ConfidenceLevel:
        """
        Calcula un nivel conservador de confianza en función
        de los parámetros disponibles, gaps y conflictos.

        Este cálculo es deliberadamente prudente.
        """

        if self.data_gaps or self.conflicts:
            self.confidence_level = (
                ConfidenceLevel.D_PROVISIONAL
            )
            return self.confidence_level

        if not self.parameters:
            self.confidence_level = (
                ConfidenceLevel.D_PROVISIONAL
            )
            return self.confidence_level

        statuses = {
            parameter.status
            for parameter in self.parameters.values()
        }

        if EvidenceStatus.UNKNOWN in statuses:
            self.confidence_level = (
                ConfidenceLevel.D_PROVISIONAL
            )

        elif EvidenceStatus.PROVISIONAL in statuses:
            self.confidence_level = (
                ConfidenceLevel.D_PROVISIONAL
            )

        elif EvidenceStatus.INFERRED in statuses:
            self.confidence_level = (
                ConfidenceLevel.C_PARTIALLY_INFERRED
            )

        elif statuses.issubset(
            {
                EvidenceStatus.DOCUMENTED,
                EvidenceStatus.DERIVED,
                EvidenceStatus.INTERPOLATED,
            }
        ):
            if statuses == {
                EvidenceStatus.DOCUMENTED
            }:
                self.confidence_level = (
                    ConfidenceLevel.A_VERIFIED
                )
            else:
                self.confidence_level = (
                    ConfidenceLevel.B_MOSTLY_VERIFIED
                )

        return self.confidence_level

    def to_dict(self) -> dict[str, Any]:
        return {
            "object_id": self.object_id,
            "name": self.name,
            "object_type": self.object_type,
            "family": self.family,
            "system": self.system,
            "subsystem": self.subsystem,
            "ifc_class": self.ifc_class,
            "ifc_predefined_type": self.ifc_predefined_type,
            "parameters": {
                name: parameter.to_dict()
                for name, parameter
                in self.parameters.items()
            },
            "views": [
                view.to_dict()
                for view in self.views
            ],
            "geometry_definition": self.geometry_definition,
            "spatial_reference": self.spatial_reference,
            "source_documents": self.source_documents,
            "confidence_level": self.confidence_level.value,
            "confidence_breakdown": self.confidence_breakdown.to_dict(),
            "data_gaps": [
                gap.to_dict()
                for gap in self.data_gaps
            ],
            "conflicts": [
                conflict.to_dict()
                for conflict in self.conflicts
            ],
            "metadata": self.metadata,
            "global_id": self.global_id,
        }
