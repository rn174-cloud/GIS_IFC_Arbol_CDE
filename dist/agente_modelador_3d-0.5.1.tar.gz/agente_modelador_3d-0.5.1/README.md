# Agente Modelador 3D de Infraestructura

Arquitectura refactorizada y neutral al proyecto para evolucionar desde documentación 2D y datos técnicos hacia modelos **IFC 4.3 (`IFC4X3_ADD2`)**.

## Qué se hizo

Los scripts históricos fueron movidos a `legacy_reference/` y quedaron fuera del núcleo reutilizable. Se extrajeron responsabilidades genéricas en módulos independientes:

- `core/ifc_factory.py`: autoría IFC 4.3 con IfcOpenShell.
- `core/geometry_kernel.py`: vectores, marcos locales e interpolación.
- `core/georeferencing.py`: origen local y transformación CRS opcional.
- `core/traceability.py`: matriz de trazabilidad y build log.
- `core/validators.py`: validación de objetos e IFC.
- `readers/dxf_reader.py`: extracción vectorial DXF.
- `readers/dwg_reader.py`: flujo DWG→DXF mediante convertidor externo configurado; no finge soporte DWG si no existe.
- `readers/pdf_vector_reader.py`: extracción de texto y geometría vectorial PDF con PyMuPDF.
- `readers/gis_reader.py`: fuentes GIS opcionales.
- `reconstruction/view_classifier.py`: clasificación inicial de vistas.
- `reconstruction/parameter_extractor.py`: extracción y normalización básica de valores.
- `reconstruction/multiview_solver.py`: agrupamiento de evidencias multivista.
- `reconstruction/object_reconstructor.py`: reglas de reconstrucción con prohibición explícita de inventar geometría.
- `reconstruction/pipeline.py`: ingesta multi-formato.

## Qué NO hace todavía

Esta versión es el **kernel modular**, no un modelador autónomo terminado. A propósito no se implementaron reglas que “adivinen” objetos a partir de líneas. Faltan capas superiores de interpretación semántica y reglas por familia de infraestructura.

En particular:

1. La lectura DWG requiere un convertidor externo fiable que preserve entidades CAD.
2. Un PDF raster requiere un módulo visual adicional; este paquete no usa OCR indiscriminado.
3. La correspondencia entre planta/perfil/sección todavía necesita reglas de identificación por proyecto y evidencia.
4. La creación IFC automática a partir de cualquier documento debe pasar primero por una `Parameter Matrix` y controles de evidencia.

## Principio rector

**2D → significado → objeto → parámetros → relaciones → 3D → IFC 4.3**

Nunca: **línea 2D → sólido arbitrario**.

## Legacy

`legacy_reference/` conserva las tres referencias sanitizadas del desarrollo histórico. Son ejemplos de técnicas de IfcOpenShell, lectura PDF, cálculo geométrico y parametrización. Sus dimensiones, progresivas, nombres y reglas específicas **no forman parte del conocimiento universal del agente**.

## Prueba rápida de ingesta

```bash
python cli.py archivo.dxf plano.pdf
```
