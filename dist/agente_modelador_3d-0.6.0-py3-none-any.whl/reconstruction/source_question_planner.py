"""
reconstruction/source_question_planner.py
Planificador de preguntas documentales dirigidas para v0.6.0.
A partir de la AssetAssemblyHypothesis formula preguntas específicas sobre disposición,
cardinalidad, tipología, dimensiones, materiales y localización, y evalúa qué fuentes responden cada una.
"""
from __future__ import annotations

import uuid
from typing import Any, Optional

from core.models import (
    AssetAssemblyHypothesis,
    DocumentRole,
    SourceDocument,
    SourceQuestion,
    SourceQuestionPlan,
)


class SourceQuestionPlanner:
    """
    Genera y gestiona el plan de preguntas documentales dirigidas (SourceQuestionPlan).
    """

    def plan_questions(
        self,
        assembly: AssetAssemblyHypothesis,
        available_documents: Optional[list[SourceDocument]] = None,
        document_roles: Optional[dict[str, DocumentRole]] = None,
    ) -> SourceQuestionPlan:
        """
        Genera el conjunto de preguntas dirigidas necesarias para resolver el ensamblaje.
        """
        available_documents = available_documents or []
        document_roles = document_roles or {}

        plan_id = f"sqp_{uuid.uuid4().hex[:8]}"
        questions: list[SourceQuestion] = []

        # 1. Pregunta sobre Disposición General
        q_disp = SourceQuestion(
            question_id="Q_GENERAL_ARRANGEMENT",
            question="Which documents define the general spatial layout, overall arrangement, and component boundaries?",
            required_information="OVERALL_FACILITY_LAYOUT_AND_BOUNDARIES",
            preferred_document_roles=[
                DocumentRole.GENERAL_ARRANGEMENT.value,
                DocumentRole.PLAN.value,
                DocumentRole.AS_BUILT.value,
            ],
            candidate_sources=[],
            status="OPEN",
            answer_evidence=[],
        )
        questions.append(q_disp)

        # 2. Pregunta sobre Cardinalidad e Implantación (Regla TYPE != INSTANCE)
        q_card = SourceQuestion(
            question_id="Q_CARDINALITY_AND_PLACEMENT",
            question="Which authoritative sources define the exact instance count, stationing, offsets, and physical placement of components?",
            required_information="INSTANCE_CARDINALITY_AND_SPATIAL_COORDINATES",
            preferred_document_roles=[
                DocumentRole.GENERAL_ARRANGEMENT.value,
                DocumentRole.SCHEDULE.value,
                DocumentRole.INVENTORY.value,
                DocumentRole.PLAN.value,
                DocumentRole.GIS_SOURCE.value,
                DocumentRole.AS_BUILT.value,
            ],
            candidate_sources=[],
            status="OPEN",
            answer_evidence=[],
        )
        questions.append(q_card)

        # 3. Pregunta sobre Geometría de Tipología (Perfiles y Cortes)
        q_typo = SourceQuestion(
            question_id="Q_TYPOLOGY_GEOMETRY",
            question="Which drawings define the parametric cross-section profiles, joint details, and component typologies?",
            required_information="CROSS_SECTION_PROFILE_AND_TYPOLOGY_SPECS",
            preferred_document_roles=[
                DocumentRole.DETAIL.value,
                DocumentRole.SECTION.value,
                DocumentRole.ASSEMBLY.value,
                DocumentRole.SPECIFICATION.value,
            ],
            candidate_sources=[],
            status="OPEN",
            answer_evidence=[],
        )
        questions.append(q_typo)

        # 4. Pregunta sobre Cotas Métricas y Unidades
        q_dim = SourceQuestion(
            question_id="Q_DIMENSIONS_AND_UNITS",
            question="Which primary documents provide verified dimension callouts with documented physical units (e.g. m, mm)?",
            required_information="VERIFIED_NUMERICAL_DIMENSIONS_AND_PRIMARY_UNITS",
            preferred_document_roles=[
                DocumentRole.DETAIL.value,
                DocumentRole.SECTION.value,
                DocumentRole.ELEVATION.value,
                DocumentRole.SCHEDULE.value,
            ],
            candidate_sources=[],
            status="OPEN",
            answer_evidence=[],
        )
        questions.append(q_dim)

        # 5. Pregunta sobre Materiales y Estándares
        q_mat = SourceQuestion(
            question_id="Q_MATERIALS_AND_STANDARDS",
            question="Which documents or notes govern component material grades (concrete, steel) and execution standards?",
            required_information="MATERIAL_GRADES_AND_TECHNICAL_SPECIFICATIONS",
            preferred_document_roles=[
                DocumentRole.SPECIFICATION.value,
                DocumentRole.GENERAL_ARRANGEMENT.value,
                DocumentRole.DETAIL.value,
            ],
            candidate_sources=[],
            status="OPEN",
            answer_evidence=[],
        )
        questions.append(q_mat)

        # 6. Preguntas específicas según sistemas esperados en la hipótesis
        for sys in assembly.systems[:4]:
            q_sys = SourceQuestion(
                question_id=f"Q_SYSTEM_{sys}",
                question=f"Which documents define the complete structural and functional specification for system {sys}?",
                required_information=f"SYSTEM_SPECIFICATION_FOR_{sys}",
                preferred_document_roles=[
                    DocumentRole.GENERAL_ARRANGEMENT.value,
                    DocumentRole.PLAN.value,
                    DocumentRole.SECTION.value,
                    DocumentRole.DETAIL.value,
                    DocumentRole.INVENTORY.value,
                ],
                candidate_sources=[],
                status="OPEN",
                answer_evidence=[],
            )
            questions.append(q_sys)

        # 7. Evaluar respuestas con los documentos disponibles
        for doc in available_documents:
            doc_path_str = str(doc.path)
            role = document_roles.get(doc_path_str, DocumentRole.UNKNOWN)
            role_val = role.value if hasattr(role, "value") else str(role)

            for q in questions:
                if role_val in q.preferred_document_roles:
                    if doc_path_str not in q.candidate_sources:
                        q.candidate_sources.append(doc_path_str)
                    q.answer_evidence.append({
                        "source": doc_path_str,
                        "role": role_val,
                        "title": doc.drawing_title or "",
                        "notes": f"Matches preferred role {role_val}",
                    })
                    q.status = "ANSWERED"

        return SourceQuestionPlan(
            plan_id=plan_id,
            assembly_id=assembly.assembly_id,
            questions=questions,
        )
