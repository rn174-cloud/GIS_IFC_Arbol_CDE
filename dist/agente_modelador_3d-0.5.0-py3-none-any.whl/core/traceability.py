from __future__ import annotations

import csv
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from core.models import (
    DocumentConflict,
    ParameterValue,
    ReconstructedObject,
    SourceReference,
)


@dataclass
class TraceabilityRecord:
    """
    Registro plano de trazabilidad.

    Relaciona:

    objeto
    -> parámetro
    -> valor
    -> unidad
    -> estado de evidencia
    -> fuente documental

    Este formato está pensado para exportarse fácilmente
    a CSV y permitir auditoría externa al IFC.
    """

    object_id: str
    parameter: str

    value: Any = None
    unit: str | None = None
    evidence_status: str | None = None

    source_file: str | None = None
    source_type: str | None = None

    drawing_number: str | None = None
    drawing_title: str | None = None

    sheet: str | None = None
    revision: str | None = None

    layer: str | None = None
    entity_id: str | None = None

    view: str | None = None
    parameter_reference: str | None = None

    coordinate_reference: str | None = None

    source_notes: str | None = None

    parameter_notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "object_id": self.object_id,
            "parameter": self.parameter,
            "value": self.value,
            "unit": self.unit,
            "evidence_status": self.evidence_status,
            "source_file": self.source_file,
            "source_type": self.source_type,
            "drawing_number": self.drawing_number,
            "drawing_title": self.drawing_title,
            "sheet": self.sheet,
            "revision": self.revision,
            "layer": self.layer,
            "entity_id": self.entity_id,
            "view": self.view,
            "parameter_reference": self.parameter_reference,
            "coordinate_reference": self.coordinate_reference,
            "source_notes": self.source_notes,
            "parameter_notes": self.parameter_notes,
        }


def records_from_parameter(
    object_id: str,
    parameter: ParameterValue,
) -> list[TraceabilityRecord]:
    """
    Convierte un ParameterValue en uno o más registros.

    Si un parámetro tiene varias fuentes,
    se genera un registro por cada fuente.

    Si no tiene fuente explícita,
    se genera igualmente un registro para no perder
    el estado del parámetro.
    """

    if not parameter.sources:
        return [
            TraceabilityRecord(
                object_id=object_id,
                parameter=parameter.name,
                value=parameter.value,
                unit=parameter.unit,
                evidence_status=parameter.status.value,
                parameter_notes=parameter.notes,
            )
        ]

    records: list[TraceabilityRecord] = []

    for source in parameter.sources:
        records.append(
            TraceabilityRecord(
                object_id=object_id,
                parameter=parameter.name,
                value=parameter.value,
                unit=parameter.unit,
                evidence_status=parameter.status.value,
                source_file=source.source_file,
                source_type=source.source_type,
                drawing_number=source.drawing_number,
                drawing_title=source.drawing_title,
                sheet=source.sheet,
                revision=source.revision,
                layer=source.layer,
                entity_id=source.entity_id,
                view=source.view,
                parameter_reference=(
                    source.parameter_reference
                ),
                coordinate_reference=(
                    source.coordinate_reference
                ),
                source_notes=source.notes,
                parameter_notes=parameter.notes,
            )
        )

    return records


def records_from_object(
    reconstructed_object: ReconstructedObject,
) -> list[TraceabilityRecord]:
    """
    Genera todos los registros de trazabilidad
    asociados a un objeto reconstruido.
    """

    records: list[TraceabilityRecord] = []

    for parameter in (
        reconstructed_object.parameters.values()
    ):
        records.extend(
            records_from_parameter(
                object_id=reconstructed_object.object_id,
                parameter=parameter,
            )
        )

    return records


def records_from_objects(
    objects: Iterable[ReconstructedObject],
) -> list[TraceabilityRecord]:
    """
    Genera una matriz plana de trazabilidad
    para múltiples objetos.
    """

    records: list[TraceabilityRecord] = []

    for reconstructed_object in objects:
        records.extend(
            records_from_object(
                reconstructed_object
            )
        )

    return records


def write_traceability_csv(
    records: Iterable[TraceabilityRecord],
    output_path: str | Path,
) -> Path:
    """
    Exporta la matriz de trazabilidad a CSV.
    """

    path = Path(
        output_path
    ).expanduser().resolve()

    if path.suffix.lower() != ".csv":
        path = path.with_suffix(".csv")

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    records_list = list(records)

    fieldnames = [
        "object_id",
        "parameter",
        "value",
        "unit",
        "evidence_status",
        "source_file",
        "source_type",
        "drawing_number",
        "drawing_title",
        "sheet",
        "revision",
        "layer",
        "entity_id",
        "view",
        "parameter_reference",
        "coordinate_reference",
        "source_notes",
        "parameter_notes",
    ]

    with path.open(
        "w",
        encoding="utf-8",
        newline="",
    ) as file:
        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        for record in records_list:
            writer.writerow(
                record.to_dict()
            )

    return path


def write_parameters_csv(
    objects: Iterable[ReconstructedObject],
    output_path: str | Path,
) -> Path:
    """
    Exporta una matriz simplificada:

    Object_ID
    Parameter
    Value
    Unit
    Status
    Confidence

    Es la matriz base desde la cual debe poder
    regenerarse la geometría paramétrica.
    """

    path = Path(
        output_path
    ).expanduser().resolve()

    if path.suffix.lower() != ".csv":
        path = path.with_suffix(".csv")

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fieldnames = [
        "object_id",
        "parameter",
        "value",
        "unit",
        "status",
        "parameter_confidence",
        "object_confidence",
        "notes",
    ]

    with path.open(
        "w",
        encoding="utf-8",
        newline="",
    ) as file:
        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        for reconstructed_object in objects:
            reconstructed_object.update_confidence_level()

            for parameter in (
                reconstructed_object.parameters.values()
            ):
                writer.writerow(
                    {
                        "object_id": (
                            reconstructed_object.object_id
                        ),
                        "parameter": parameter.name,
                        "value": parameter.value,
                        "unit": parameter.unit,
                        "status": parameter.status.value,
                        "parameter_confidence": (
                            parameter.confidence
                        ),
                        "object_confidence": (
                            reconstructed_object
                            .confidence_level
                            .value
                        ),
                        "notes": parameter.notes,
                    }
                )

    return path


def write_conflicts_csv(
    conflicts: Iterable[DocumentConflict],
    output_path: str | Path,
) -> Path:
    """
    Exporta conflictos documentales.
    """

    path = Path(
        output_path
    ).expanduser().resolve()

    if path.suffix.lower() != ".csv":
        path = path.with_suffix(".csv")

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fieldnames = [
        "object_id",
        "parameter",
        "value_a",
        "source_a_file",
        "source_a_drawing",
        "source_a_sheet",
        "source_a_revision",
        "value_b",
        "source_b_file",
        "source_b_drawing",
        "source_b_sheet",
        "source_b_revision",
        "impact",
        "resolution",
    ]

    with path.open(
        "w",
        encoding="utf-8",
        newline="",
    ) as file:
        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        for conflict in conflicts:
            writer.writerow(
                {
                    "object_id": conflict.object_id,
                    "parameter": conflict.parameter,
                    "value_a": conflict.value_a,
                    "source_a_file": (
                        conflict.source_a.source_file
                    ),
                    "source_a_drawing": (
                        conflict.source_a.drawing_number
                    ),
                    "source_a_sheet": (
                        conflict.source_a.sheet
                    ),
                    "source_a_revision": (
                        conflict.source_a.revision
                    ),
                    "value_b": conflict.value_b,
                    "source_b_file": (
                        conflict.source_b.source_file
                    ),
                    "source_b_drawing": (
                        conflict.source_b.drawing_number
                    ),
                    "source_b_sheet": (
                        conflict.source_b.sheet
                    ),
                    "source_b_revision": (
                        conflict.source_b.revision
                    ),
                    "impact": conflict.impact,
                    "resolution": conflict.resolution,
                }
            )

    return path


@dataclass
class BuildLog:
    """
    Registro técnico de una ejecución del agente.

    Debe permitir reconstruir qué ocurrió durante
    una generación o actualización de modelo.
    """

    project_name: str
    mode: str

    started_at: str = field(
        default_factory=lambda: (
            datetime.now(timezone.utc).isoformat()
        )
    )

    finished_at: str | None = None

    ifc_schema: str = "IFC4X3_ADD2"

    software: dict[str, str] = field(
        default_factory=dict
    )

    sources: list[dict[str, Any]] = field(
        default_factory=list
    )

    created_objects: list[str] = field(
        default_factory=list
    )

    updated_objects: list[str] = field(
        default_factory=list
    )

    preserved_objects: list[str] = field(
        default_factory=list
    )

    removed_objects: list[str] = field(
        default_factory=list
    )

    inferred_parameters: list[dict[str, Any]] = field(
        default_factory=list
    )

    provisional_parameters: list[dict[str, Any]] = field(
        default_factory=list
    )

    data_gaps: list[dict[str, Any]] = field(
        default_factory=list
    )

    conflicts: list[dict[str, Any]] = field(
        default_factory=list
    )

    warnings: list[str] = field(
        default_factory=list
    )

    errors: list[str] = field(
        default_factory=list
    )

    metadata: dict[str, Any] = field(
        default_factory=dict
    )

    def finish(self) -> None:
        """
        Marca el momento de finalización de la ejecución.
        """
        self.finished_at = (
            datetime.now(timezone.utc).isoformat()
        )

    def add_source(
        self,
        source: dict[str, Any],
    ) -> None:
        self.sources.append(source)

    def add_warning(
        self,
        message: str,
    ) -> None:
        self.warnings.append(message)

    def add_error(
        self,
        message: str,
    ) -> None:
        self.errors.append(message)

    def to_dict(self) -> dict[str, Any]:
        return {
            "project_name": self.project_name,
            "mode": self.mode,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "ifc_schema": self.ifc_schema,
            "software": self.software,
            "sources": self.sources,
            "created_objects": self.created_objects,
            "updated_objects": self.updated_objects,
            "preserved_objects": self.preserved_objects,
            "removed_objects": self.removed_objects,
            "inferred_parameters": self.inferred_parameters,
            "provisional_parameters": (
                self.provisional_parameters
            ),
            "data_gaps": self.data_gaps,
            "conflicts": self.conflicts,
            "warnings": self.warnings,
            "errors": self.errors,
            "metadata": self.metadata,
        }

    def write_json(
        self,
        output_path: str | Path,
    ) -> Path:
        """
        Guarda PROJECT_BUILD_LOG.json.
        """

        path = Path(
            output_path
        ).expanduser().resolve()

        if path.suffix.lower() != ".json":
            path = path.with_suffix(".json")

        path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        with path.open(
            "w",
            encoding="utf-8",
        ) as file:
            json.dump(
                self.to_dict(),
                file,
                ensure_ascii=False,
                indent=2,
            )

        return path
