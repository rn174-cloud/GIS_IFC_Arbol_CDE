from __future__ import annotations

from pathlib import Path
from typing import Type

from readers.base import BaseReader


class ReaderRegistry:
    """
    Registro central de readers.

    Permite que el pipeline seleccione automáticamente
    el reader correspondiente según la extensión
    del archivo fuente.

    El registry no interpreta el contenido.
    Solo resuelve qué reader debe utilizarse.
    """

    def __init__(self) -> None:
        self._reader_classes: list[
            Type[BaseReader]
        ] = []

    def register(
        self,
        reader_class: Type[BaseReader],
    ) -> None:
        """
        Registra una clase de reader.

        No se permiten duplicados exactos.
        """

        if reader_class in self._reader_classes:
            return

        self._reader_classes.append(
            reader_class
        )

    def create_reader_for(
        self,
        path: str | Path,
    ) -> BaseReader:
        """
        Devuelve una instancia del reader compatible
        con la fuente indicada.
        """

        source_path = Path(path)

        for reader_class in self._reader_classes:
            reader = reader_class()

            if reader.supports(source_path):
                return reader

        raise ValueError(
            "No existe un reader registrado para "
            f"la extensión {source_path.suffix!r}."
        )

    def supports(
        self,
        path: str | Path,
    ) -> bool:
        """
        Indica si existe algún reader registrado
        compatible con la fuente.
        """

        source_path = Path(path)

        return any(
            reader_class().supports(source_path)
            for reader_class in self._reader_classes
        )

    def registered_readers(
        self,
    ) -> list[str]:
        """
        Devuelve los nombres de los readers registrados.
        """

        return [
            reader_class.__name__
            for reader_class in self._reader_classes
        ]

    def supported_extensions(
        self,
    ) -> list[str]:
        """
        Devuelve todas las extensiones soportadas
        por los readers registrados.
        """

        extensions: set[str] = set()

        for reader_class in self._reader_classes:
            extensions.update(
                extension.lower()
                for extension
                in reader_class.supported_extensions
            )

        return sorted(extensions)


def build_default_registry() -> ReaderRegistry:
    """
    Construye el registry estándar del agente.

    Los imports se realizan dentro de la función para evitar
    dependencias circulares y permitir módulos opcionales.
    """

    from readers.dwg_reader import DWGReader
    from readers.dxf_reader import DXFReader
    from readers.gis_reader import GISReader
    from readers.pdf_vector_reader import PDFVectorReader

    registry = ReaderRegistry()

    registry.register(DWGReader)
    registry.register(DXFReader)
    registry.register(PDFVectorReader)
    registry.register(GISReader)

    return registry
