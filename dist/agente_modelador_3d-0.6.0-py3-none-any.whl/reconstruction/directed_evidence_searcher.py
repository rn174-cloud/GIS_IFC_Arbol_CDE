"""
reconstruction/directed_evidence_searcher.py
Búsqueda y confirmación dirigida de evidencia para v0.6.0.
Reposiciona las primitivas CAD, grupos geométricos y motivos como herramientas de búsqueda dirigida
guiadas por la hipótesis de ensamblaje (AssetAssemblyHypothesis) y el plan de preguntas (SourceQuestionPlan).
"""
from __future__ import annotations

import re
from typing import Any, Optional

from core.models import (
    AssetAssemblyHypothesis,
    DocumentRole,
    GeometricMotif,
    LocalGeometryGroup,
    ObjectCandidate,
    ObjectHypothesis,
    PrimitiveEvidence,
    SemanticFamily,
    SemanticSignal,
    SourceDocument,
    SourceQuestionPlan,
)


class DirectedEvidenceSearcher:
    """
    Ejecuta búsquedas dirigidas en documentos CAD/PDF/GIS/tablas a partir de las preguntas
    y sistemas esperados por la AssetAssemblyHypothesis.
    """

    def filter_and_guide_candidates(
        self,
        assembly: AssetAssemblyHypothesis,
        question_plan: SourceQuestionPlan,
        candidates: list[ObjectCandidate],
        document_role: DocumentRole = DocumentRole.UNKNOWN,
    ) -> list[ObjectCandidate]:
        """
        Restringe y enriquece los ObjectCandidate existentes utilizando el contexto del activo
        y el rol del documento fuente.
        """
        guided_candidates: list[ObjectCandidate] = []

        # Lista de tipos de componentes esperados en el ensamblaje
        expected_types = {c.upper() for c in assembly.expected_component_types}

        for cand in candidates:
            # 1. Restringir candidatos según rol del documento
            # Si el documento es DETAIL, el candidato se marca explícitamente como TYPOLOGY_DEFINITION
            if document_role == DocumentRole.DETAIL:
                cand.notes = (cand.notes or "") + " [SOURCE_ROLE: DETAIL - Typology definition only, cardinality NOT authorized]"

            # 2. Correlacionar señales semánticas con sistemas esperados
            matched_system = False
            for sig in cand.semantic_signals:
                sig_val = str(sig.value).upper()
                for exp in expected_types:
                    if exp in sig_val:
                        cand.type_evidence.append(f"DIRECTED_MATCH_TO_{exp}")
                        matched_system = True

            # 3. Asignar familia semántica coherente si la hipótesis lo orienta
            if cand.probable_family == SemanticFamily.UNKNOWN:
                if assembly.facility_type == "BRIDGE":
                    cand.probable_family = SemanticFamily.STRUCTURAL
                    cand.notes = (cand.notes or "") + " [CONTEXT_GUIDED: BRIDGE -> STRUCTURAL]"
                elif assembly.facility_type == "LIGHTING_SYSTEM":
                    cand.probable_family = SemanticFamily.LIGHTING
                    cand.notes = (cand.notes or "") + " [CONTEXT_GUIDED: LIGHTING_SYSTEM -> LIGHTING]"
                elif assembly.facility_type == "DRAINAGE_SYSTEM":
                    cand.probable_family = SemanticFamily.DRAINAGE
                    cand.notes = (cand.notes or "") + " [CONTEXT_GUIDED: DRAINAGE_SYSTEM -> DRAINAGE]"

            guided_candidates.append(cand)

        return guided_candidates
