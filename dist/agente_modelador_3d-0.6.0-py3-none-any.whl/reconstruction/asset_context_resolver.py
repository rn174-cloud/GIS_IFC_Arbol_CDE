"""
reconstruction/asset_context_resolver.py
Capa genérica AssetContextResolver para v0.6.0.
Determina el contexto macro del activo/conjunto construido a partir de fuentes disponibles.
Contexto restringe el espacio semántico de búsqueda; NO autoriza BUILT por sí solo.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Optional

from core.models import (
    AssetContext,
    EvidenceStatus,
    FacilityType,
    SourceDocument,
    SourceReference,
)


class AssetContextResolver:
    """
    Determina de manera neutral y genérica qué clase de conjunto construido o activo
    se intenta modelar antes de interpretar líneas o primitivas CAD aisladas.
    """

    # Dominios de infraestructura genéricos
    DOMAIN_PATTERNS = {
        "TRANSPORTATION": [
            r"puente", r"bridge", r"viaduct", r"viaducto", r"camino", r"road",
            r"autopista", r"highway", r"calzada", r"traza", r"peaje", r"toll",
            r"ferrocarril", r"rail", r"pista", r"runway", r"aeropuerto", r"airport"
        ],
        "WATER_AND_DRAINAGE": [
            r"drenaje", r"drainage", r"alcantarilla", r"culvert", r"canal", r"pluvial",
            r"colector", r"saneamiento", r"acueducto", r"treatment_plant", r"cloaca"
        ],
        "ENERGY_AND_UTILITIES": [
            r"iluminacion", r"lighting", r"electrica", r"subestacion", r"substation",
            r"transformador", r"gasoducto", r"ducto", r"red_electrica", r"luminaire"
        ],
        "INDUSTRIAL_AND_BUILDINGS": [
            r"edificio", r"building", r"nave", r"galpon", r"planta_industrial",
            r"taller", r"oficina", r"hangar", r"deposito"
        ],
    }

    # Tipologías de instalación genéricas
    FACILITY_PATTERNS = {
        FacilityType.BRIDGE.value: [
            r"puente", r"bridge", r"viaducto", r"viaduct", r"estribo", r"abutment", r"pila", r"pier"
        ],
        FacilityType.TOLL_PLAZA.value: [
            r"peaje", r"toll", r"estacion_peaje", r"islas_peaje", r"cabina"
        ],
        FacilityType.ROAD_CORRIDOR.value: [
            r"camino", r"ruta", r"carretera", r"road", r"calzada", r"tramo_vial", r"corredor"
        ],
        FacilityType.DRAINAGE_SYSTEM.value: [
            r"drenaje", r"drainage", r"pluvial", r"alcantarillado", r"cuneta", r"sumidero"
        ],
        FacilityType.LIGHTING_SYSTEM.value: [
            r"iluminacion", r"lighting", r"luminaria", r"columna_iluminacion", r"alumbrado"
        ],
        FacilityType.INDUSTRIAL_FACILITY.value: [
            r"industrial", r"fabrica", r"planta", r"refineria", r"galpon", r"deposito"
        ],
        FacilityType.AIRPORT_APRON.value: [
            r"aeropuerto", r"airport", r"pista", r"apron", r"taxiway", r"hangar"
        ],
        FacilityType.RAILWAY_STATION.value: [
            r"ferrocarril", r"railway", r"estacion_ferroviaria", r"via_ferrea", r"anden"
        ],
        FacilityType.TUNNEL.value: [
            r"tunel", r"tunnel", r"galeria_subterranea"
        ],
        FacilityType.BUILDING.value: [
            r"edificio", r"building", r"sede", r"modulo_habitacional"
        ],
    }

    def resolve_context(
        self,
        metadata: Optional[dict[str, Any]] = None,
        source_documents: Optional[list[SourceDocument]] = None,
        inventory_records: Optional[list[dict[str, Any]]] = None,
        gis_metadata: Optional[dict[str, Any]] = None,
        user_hint: Optional[str] = None,
    ) -> AssetContext:
        """
        Resuelve el contexto del activo combinando todas las evidencias disponibles.
        """
        metadata = metadata or {}
        source_documents = source_documents or []
        inventory_records = inventory_records or []
        gis_metadata = gis_metadata or {}

        # 1. Recopilar texto indicativo de contexto
        text_tokens: list[str] = []
        source_refs: list[SourceReference] = []

        if user_hint:
            text_tokens.append(user_hint)

        for k, v in metadata.items():
            if isinstance(v, str):
                text_tokens.append(v)

        for doc in source_documents:
            if doc.drawing_title:
                text_tokens.append(doc.drawing_title)
            if doc.drawing_number:
                text_tokens.append(doc.drawing_number)
            if doc.discipline:
                text_tokens.append(doc.discipline)
            text_tokens.append(Path(doc.path).name)

            source_refs.append(
                SourceReference(
                    source_file=str(doc.path),
                    drawing_title=doc.drawing_title,
                    drawing_number=doc.drawing_number,
                    notes=f"Document title: {doc.drawing_title or Path(doc.path).name}",
                )
            )

        for inv in inventory_records:
            for field_name in ["tipo", "descripcion", "clase", "sistema", "activo"]:
                if field_name in inv and isinstance(inv[field_name], str):
                    text_tokens.append(inv[field_name])

        for k, v in gis_metadata.items():
            if isinstance(v, str):
                text_tokens.append(v)

        combined_text = " ".join(text_tokens).lower()

        # 2. Identificar dominio de infraestructura
        domain = "GENERAL_INFRASTRUCTURE"
        for dom_name, patterns in self.DOMAIN_PATTERNS.items():
            if any(re.search(p, combined_text) for p in patterns):
                domain = dom_name
                break

        # 3. Identificar facility type
        facility_type = FacilityType.OTHER.value
        matched_facility = False
        for fac_type, patterns in self.FACILITY_PATTERNS.items():
            if any(re.search(p, combined_text) for p in patterns):
                facility_type = fac_type
                matched_facility = True
                break

        # 4. Derivar sistemas y subsistemas esperados según facility type
        systems, subsystems, components = self._derive_expected_decomposition(facility_type)

        # 5. Evaluar lifecycle context
        lifecycle = "UNKNOWN"
        if re.search(r"as_built|conforme_obra|conforme a obra|registro de obra", combined_text):
            lifecycle = "AS_BUILT"
        elif re.search(r"proyecto|diseno|design|plano ejecutivo|licitacion", combined_text):
            lifecycle = "DESIGN"
        elif re.search(r"inspeccion|inspection|mantenimiento|deterioro", combined_text):
            lifecycle = "OPERATION_AND_MAINTENANCE"

        # 6. Evaluar status y confidence
        evidence_status = EvidenceStatus.UNKNOWN
        confidence = 0.2

        if metadata.get("facility_type") or metadata.get("asset_context"):
            evidence_status = EvidenceStatus.DOCUMENTED
            confidence = 0.95
            facility_type = metadata.get("facility_type", facility_type)
        elif matched_facility:
            evidence_status = EvidenceStatus.DERIVED
            confidence = 0.80
        elif domain != "GENERAL_INFRASTRUCTURE":
            evidence_status = EvidenceStatus.INFERRED
            confidence = 0.50
        else:
            evidence_status = EvidenceStatus.PROVISIONAL
            confidence = 0.30

        asset_name = metadata.get("asset_name") or metadata.get("project_name") or f"{facility_type}_ASSET"

        spatial_scope = {
            "coordinate_reference": gis_metadata.get("crs") or metadata.get("crs") or "LOCAL_CAD_COORDINATES",
            "linear_reference_available": "station" in combined_text or "pk" in combined_text or "progresiva" in combined_text,
            "bounds": gis_metadata.get("bounds"),
        }

        return AssetContext(
            infrastructure_domain=domain,
            facility_or_asset_type=facility_type,
            asset_context=asset_name,
            system_contexts=systems,
            subsystem_contexts=subsystems,
            visible_or_documented_components=components,
            spatial_scope=spatial_scope,
            lifecycle_context=lifecycle,
            confidence=confidence,
            evidence_status=evidence_status,
            source_references=source_refs,
        )

    def _derive_expected_decomposition(
        self, facility_type: str
    ) -> tuple[list[str], list[str], list[str]]:
        """
        Retorna descomposición funcional y ontológica genérica por tipo de instalación.
        """
        if facility_type == FacilityType.BRIDGE.value:
            systems = ["SUPERSTRUCTURE", "SUBSTRUCTURE", "FOUNDATIONS", "ROADWAY", "SAFETY_AND_EQUIPMENT"]
            subsystems = ["DECK_SLAB", "GIRDERS", "PIERS", "ABUTMENTS", "PILES", "BEARINGS", "EXPANSION_JOINTS"]
            components = ["VIGA", "TABLERO", "PILA", "ESTRIBO", "PILOTE", "BARANDA", "CORDON", "JUNTA"]
        elif facility_type == FacilityType.TOLL_PLAZA.value:
            systems = ["TOLL_LANES", "CANOPY_STRUCTURE", "CONTROL_CABINS", "PAVEMENT", "UTILITIES"]
            subsystems = ["ISLANDS", "BOOTH_HOUSING", "ROOF_FRAME", "BARRIERS", "SIGNAGE_GANTRY"]
            components = ["ISLA_PEAJE", "CABINA", "TECHO_MARQUESINA", "BARRERA", "CORDON", "CARTEL"]
        elif facility_type == FacilityType.LIGHTING_SYSTEM.value:
            systems = ["ELECTRICAL_CIRCUITS", "SUPPORT_STRUCTURES", "LUMINAIRES", "FOUNDATIONS"]
            subsystems = ["FEEDER_LINES", "POLES", "LIGHT_FIXTURES", "BASE_ANCHORS"]
            components = ["COLUMNA_ILUMINACION", "LUMINARIA", "BASE_HORMIGON", "PUESTA_TIERRA"]
        elif facility_type == FacilityType.DRAINAGE_SYSTEM.value:
            systems = ["CONVEYANCE_NETWORK", "INLETS_AND_CHAMBERS", "OUTFALLS"]
            subsystems = ["PIPES", "CHANNELS", "MANHOLES", "CULVERTS"]
            components = ["CANAL", "SUMIDERO", "CAMARA_INSPECCION", "ALCANTARILLA", "TUBO"]
        elif facility_type == FacilityType.ROAD_CORRIDOR.value:
            systems = ["PAVEMENT_STRUCTURE", "SAFETY_BARRIERS", "DRAINAGE", "SIGNAGE_AND_MARKING"]
            subsystems = ["WEARING_COURSE", "BASE_LAYER", "GUARD_RAIL", "ROAD_MARKINGS"]
            components = ["CALZADA", "BANQUINA", "DEFENSA_METALICA", "SENAL_VERTICAL", "DEMARCACION"]
        elif facility_type == FacilityType.INDUSTRIAL_FACILITY.value:
            systems = ["STRUCTURAL_FRAME", "PROCESS_EQUIPMENT", "PIPING", "ELECTRICAL"]
            subsystems = ["PORTAL_FRAMES", "FOUNDATION_SLAB", "STORAGE_TANKS", "PIPE_RACKS"]
            components = ["COLUMNA_ACERO", "VIGA_RETICULADA", "PLATEA", "TANQUE", "RACK"]
        else:
            systems = ["PRIMARY_STRUCTURE", "SECONDARY_SYSTEMS", "ENCLOSURES", "UTILITIES"]
            subsystems = ["SUPPORT_FRAME", "FOUNDATION", "ACCESS", "EQUIPMENT"]
            components = ["ESTRUCTURA_PRINCIPAL", "BASE", "CERRAMIENTO", "EQUIPO"]

        return systems, subsystems, components
