from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from core.models import SourceDocument


class BaseReader(ABC):
    """
    Contrato base para todos los readers.

    Un reader debe:
    - recibir una fuente;
    - verificar si puede procesarla;
    - extraer información sin inventar semántica;
    - devolver SourceDocument.

    No debe reconstruir objetos físicos ni generar IFC.
    """

    supported_extensions: tuple[str, ...] = ()

    def supports(
        self,
        path: str | Path,
    ) -> bool:
        """
        Indica si el reader soporta la extensión del archivo.
        """
        suffix = Path(path).suffix.lower()

        return suffix in {
            extension.lower()
            for extension in self.supported_extensions
        }

    @abstractmethod
    def read(
        self,
        path: str | Path,
    ) -> SourceDocument:
        """
        Procesa la fuente y devuelve un SourceDocument.
        """
        raise NotImplementedError

    def validate_path(
        self,
        path: str | Path,
    ) -> Path:
        """
        Verifica existencia y compatibilidad de extensión.
        """

        resolved = Path(
            path
        ).expanduser().resolve()

        if not resolved.exists():
            raise FileNotFoundError(
                f"No existe la fuente: {resolved}"
            )

        if not resolved.is_file():
            raise ValueError(
                f"La fuente no es un archivo: {resolved}"
            )

        if not self.supports(resolved):
            raise ValueError(
                f"{self.__class__.__name__} no soporta "
                f"la extensión {resolved.suffix!r}."
            )

        return resolved

    @staticmethod
    def compute_file_metadata(path: Path) -> tuple[str, str, int]:
        """
        Calcula determinísticamente:
        - sha256
        - source_id (hash de filename + size + sha256)
        - file_size en bytes
        """
        import hashlib

        hasher = hashlib.sha256()
        file_size = path.stat().st_size

        with path.open("rb") as f:
            while chunk := f.read(65536):
                hasher.update(chunk)

        sha256 = hasher.hexdigest()

        # Generar source_id determinista
        id_material = f"{path.name}:{file_size}:{sha256}".encode("utf-8")
        source_id = f"src_{hashlib.sha256(id_material).hexdigest()[:16]}"

        return source_id, sha256, file_size

