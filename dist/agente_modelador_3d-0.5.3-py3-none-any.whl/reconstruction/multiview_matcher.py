from __future__ import annotations

import hashlib
import math
import re
from typing import Any

from core.models import (
    CandidateStatus,
    CandidateType,
    EvidenceMatch,
    MatchDecision,
    ObjectCandidate,
    ResolutionEvidence,
    SemanticFamily,
    ViewEvidence,
)
from reconstruction.reference_resolver import ReferenceResolver


class MultiViewMatcher:
    """
    Motor de correspondencia y resolución multivista de candidatos a objeto.

    Responsabilidad:
    Comparar pares de ObjectCandidate provenientes de vistas o fuentes distintas
    para emitir un EvidenceMatch con MatchDecision auditable:
    - SAME_OBJECT
    - POSSIBLE_SAME_OBJECT
    - DIFFERENT_OBJECT
    - PARENT_CHILD
    - SYSTEM_RELATED
    - REPEATED_INSTANCE
    - UNRESOLVED

    Criterios auditables evaluados:
    1. Compatibilidad de vistas (matriz explícita);
    2. Progresiva / Station compatible (con tolerancia configurable);
    3. Offset / Coordenadas compatibles;
    4. Etiquetas / Nombres compatibles;
    5. Dimensiones y parámetros compatibles (ej. circle radius 0.60 m vs diameter 1.20 m);
    6. Geometría compatible;
    7. Familia semántica compatible;
    8. Referencias documentales explícitas (ej. A-A, DETALLE X);
    9. Independencia de fuentes (Source independence).
    """

    # Matriz explícita de compatibilidad entre tipos de vista
    VIEW_COMPATIBILITY_MATRIX = {
        ("PLAN", "SECTION"): 0.85,
        ("PLAN", "PROFILE"): 0.80,
        ("PLAN", "ELEVATION"): 0.75,
        ("PROFILE", "SECTION"): 0.80,
        ("ELEVATION", "SECTION"): 0.85,
        ("PLAN", "DETAIL"): 0.90,
        ("SECTION", "DETAIL"): 0.90,
        ("PROFILE", "DETAIL"): 0.85,
        ("ELEVATION", "DETAIL"): 0.85,
        ("PLAN", "PLAN"): 0.50,         # Vistas del mismo tipo requieren más evidencia para fusionar
        ("SECTION", "SECTION"): 0.50,
        ("UNKNOWN", "UNKNOWN"): 0.20,
    }

    def __init__(
        self,
        station_tolerance: float = 5.0,     # Tolerancia máxima en metros para considerar misma estación
        dimension_tolerance: float = 0.05,  # Tolerancia dimensional relativa (5%)
    ) -> None:
        self.station_tolerance = station_tolerance
        self.dimension_tolerance = dimension_tolerance
        self.reference_resolver = ReferenceResolver()

    def get_view_compatibility(self, view_type_a: str, view_type_b: str) -> float:
        """
        Retorna el score de compatibilidad de la matriz para dos tipos de vista.
        """
        v1, v2 = view_type_a.upper(), view_type_b.upper()
        if (v1, v2) in self.VIEW_COMPATIBILITY_MATRIX:
            return self.VIEW_COMPATIBILITY_MATRIX[(v1, v2)]
        if (v2, v1) in self.VIEW_COMPATIBILITY_MATRIX:
            return self.VIEW_COMPATIBILITY_MATRIX[(v2, v1)]
        if "DETAIL" in {v1, v2}:
            return 0.80
        if "UNKNOWN" in {v1, v2}:
            return 0.30
        return 0.40

    def compare_candidates(
        self,
        cand_a: ObjectCandidate,
        cand_b: ObjectCandidate,
        views_dict: dict[str, ViewEvidence] | None = None,
        view_callouts: list[dict[str, Any]] | None = None,
    ) -> EvidenceMatch:
        """
        Compara exhaustivamente dos candidatos a objeto y emite un EvidenceMatch auditable.
        """
        match_seed = f"{min(cand_a.candidate_id, cand_b.candidate_id)}::{max(cand_a.candidate_id, cand_b.candidate_id)}"
        match_id = f"match_{hashlib.sha256(match_seed.encode('utf-8')).hexdigest()[:12]}"

        evidence_for: list[ResolutionEvidence] = []
        evidence_against: list[ResolutionEvidence] = []
        rule_ids: list[str] = []

        # 1. Compatibilidad de Vista
        view_a = views_dict.get(cand_a.view_ids[0]) if (views_dict and cand_a.view_ids) else None
        view_b = views_dict.get(cand_b.view_ids[0]) if (views_dict and cand_b.view_ids) else None

        type_v_a = view_a.view_type if view_a else "UNKNOWN"
        type_v_b = view_b.view_type if view_b else "UNKNOWN"
        view_comp = self.get_view_compatibility(type_v_a, type_v_b)

        if view_comp >= 0.70:
            evidence_for.append(
                ResolutionEvidence(
                    criterion="VIEW_COMPATIBILITY",
                    description=f"Vistas complementarias {type_v_a} y {type_v_b}",
                    score=view_comp,
                    rule_id="RULE_VIEW_COMPATIBILITY_HIGH",
                )
            )
            rule_ids.append("RULE_VIEW_COMPATIBILITY_HIGH")
        else:
            evidence_against.append(
                ResolutionEvidence(
                    criterion="VIEW_COMPATIBILITY",
                    description=f"Vistas de baja complementariedad {type_v_a} y {type_v_b}",
                    score=view_comp,
                    is_supporting=False,
                    rule_id="RULE_VIEW_COMPATIBILITY_LOW",
                )
            )

        # 2. Independencia de Fuentes
        source_a = set(cand_a.source_ids)
        source_b = set(cand_b.source_ids)
        is_cross_source = len(source_a.intersection(source_b)) == 0
        source_indep_score = 0.85 if is_cross_source else 0.50

        # 3. Progresiva / Station Matching
        station_score = 0.0
        has_station_conflict = False
        station_delta = None

        if cand_a.station is not None and cand_b.station is not None:
            station_delta = abs(cand_a.station - cand_b.station)
            if station_delta <= self.station_tolerance:
                station_score = max(0.0, 1.0 - (station_delta / self.station_tolerance))
                evidence_for.append(
                    ResolutionEvidence(
                        criterion="STATION_ALIGNMENT",
                        description=f"Estaciones compatibles (delta={station_delta:.2f}m <= tol={self.station_tolerance:.2f}m)",
                        score=station_score,
                        rule_id="RULE_STATION_MATCH",
                        details={"delta": station_delta, "tolerance": self.station_tolerance},
                    )
                )
                rule_ids.append("RULE_STATION_MATCH")
            else:
                has_station_conflict = True
                evidence_against.append(
                    ResolutionEvidence(
                        criterion="STATION_CONFLICT",
                        description=f"Discrepancia en estación (delta={station_delta:.2f}m > tol={self.station_tolerance:.2f}m)",
                        score=1.0,
                        is_supporting=False,
                        rule_id="RULE_STATION_MISMATCH",
                        details={"delta": station_delta, "tolerance": self.station_tolerance},
                    )
                )
                rule_ids.append("RULE_STATION_MISMATCH")

        # 4. Compatibilidad de Labels y Textos
        label_score = 0.0
        labels_a = set(t.upper() for t in cand_a.related_texts + cand_a.labels)
        labels_b = set(t.upper() for t in cand_b.related_texts + cand_b.labels)

        # Buscar tokens coincidentes significativos (ej. P3, PILA 3, ALCANTARILLA 1)
        tokens_a = set().union(*[re.findall(r"\b[A-Z0-9_-]{2,}\b", l) for l in labels_a]) if labels_a else set()
        tokens_b = set().union(*[re.findall(r"\b[A-Z0-9_-]{2,}\b", l) for l in labels_b]) if labels_b else set()

        GENERIC_DRAWING_STOPWORDS = {
            "DE", "EL", "LA", "LOS", "LAS", "UN", "UNA", "EN", "CON", "POR", "PARA",
            "TIPO", "DETALLE", "CORTE", "SECCION", "PLANTA", "VISTA", "CAD",
            "SISTEMA", "ILUMINACION", "COLUMNA", "COLUMNAS", "FUNDACION", "FUNDACIONES",
            "OBRA", "PLANO", "PLANOS", "NOTAS", "NOTA", "DIMENSIONES", "DIMENSION",
            "MEDIDAS", "MEDIDA", "MILIMETROS", "METROS", "CENTIMETROS", "MM", "CM", "M",
            "ACERO", "HORMIGON", "CALIDAD", "ESCALA", "ESCALAS", "SUPERIOR", "INFERIOR",
            "GENERAL", "GENERALES", "PROYECTO", "RUTA", "NACIONAL", "VIALIDAD",
            "ARGENTINA", "DNV", "UNIDAD", "CONFORME", "DATOS", "ORIGINALES",
            "ISLAS", "ZONA", "PUENTE", "PUENTES", "REFERENCIA", "REFERENCIAS",
        }

        meaningful_common = {
            tok for tok in tokens_a.intersection(tokens_b)
            if tok not in GENERIC_DRAWING_STOPWORDS
        }

        has_label_conflict = False
        # Conflicto explícito de identificadores distintos (ej. PILA P3 vs PILA P4)
        id_pat = re.compile(r"\b(P\d+|PILA\s*\d+|COL\s*\d+|KM\s*\d+|PK\s*\d+)\b", re.IGNORECASE)
        ids_a = {m.group(0).upper().replace(" ", "") for l in labels_a for m in id_pat.finditer(l)}
        ids_b = {m.group(0).upper().replace(" ", "") for l in labels_b for m in id_pat.finditer(l)}

        if ids_a and ids_b and not ids_a.intersection(ids_b):
            has_label_conflict = True
            evidence_against.append(
                ResolutionEvidence(
                    criterion="LABEL_CONFLICT",
                    description=f"Identificadores contradictorios: {ids_a} vs {ids_b}",
                    score=0.90,
                    is_supporting=False,
                    rule_id="RULE_LABEL_CONTRADICTION",
                )
            )
            rule_ids.append("RULE_LABEL_CONTRADICTION")
        elif meaningful_common:
            has_instance_token = any(re.search(r"\d", tok) for tok in meaningful_common)
            score_val = 0.85 if has_instance_token else 0.40
            label_score = score_val
            evidence_for.append(
                ResolutionEvidence(
                    criterion="LABEL_MATCH",
                    description=f"Tokens de identificación compartidos: {sorted(meaningful_common)}",
                    score=score_val,
                    rule_id="RULE_LABEL_MATCH",
                )
            )
            rule_ids.append("RULE_LABEL_MATCH")

        # 5. Referencias Explícitas de Corte/Sección (A-A, B-B)
        callout_boost = 0.0
        if view_callouts and cand_a.view_ids and cand_b.view_ids:
            v_a_id = cand_a.view_ids[0]
            v_b_id = cand_b.view_ids[0]
            for c_match in view_callouts:
                if (c_match["view_a"] == v_a_id and c_match["view_b"] == v_b_id) or \
                   (c_match["view_a"] == v_b_id and c_match["view_b"] == v_a_id):
                    callout_boost = c_match["score_boost"]
                    evidence_for.append(
                        ResolutionEvidence(
                            criterion="CALLOUT_REFERENCE",
                            description=f"Referencia documental cruzada explícita ({c_match['tag']})",
                            score=callout_boost,
                            rule_id="RULE_CALLOUT_MATCH",
                        )
                    )
                    rule_ids.append("RULE_CALLOUT_MATCH")
                    break

        # 6. Compatibilidad Dimensional (ej. radio en planta vs diámetro en sección)
        dim_score, has_dim_conflict = self._check_dimensional_compatibility(cand_a, cand_b, evidence_for, evidence_against, rule_ids)

        # 7. Compatibilidad Geométrica y de Familia
        geom_score = 0.0
        if cand_a.probable_family == cand_b.probable_family and cand_a.probable_family != SemanticFamily.UNKNOWN:
            geom_score = 0.80
            evidence_for.append(
                ResolutionEvidence(
                    criterion="FAMILY_COMPATIBILITY",
                    description=f"Ambos pertenecen a la familia {cand_a.probable_family.value}",
                    score=0.80,
                    rule_id="RULE_FAMILY_MATCH",
                )
            )
            rule_ids.append("RULE_FAMILY_MATCH")
        elif cand_a.probable_family != cand_b.probable_family and \
             cand_a.probable_family != SemanticFamily.UNKNOWN and \
             cand_b.probable_family != SemanticFamily.UNKNOWN:
            evidence_against.append(
                ResolutionEvidence(
                    criterion="FAMILY_CONFLICT",
                    description=f"Familias incompatibles: {cand_a.probable_family.value} vs {cand_b.probable_family.value}",
                    score=0.75,
                    is_supporting=False,
                    rule_id="RULE_FAMILY_MISMATCH",
                )
            )
            rule_ids.append("RULE_FAMILY_MISMATCH")

        # 8. Compatibilidad Espacial (offset / centros)
        spatial_score = 0.0
        if cand_a.offset is not None and cand_b.offset is not None:
            d_offset = abs(cand_a.offset - cand_b.offset)
            if d_offset <= 1.0:
                spatial_score = max(0.0, 1.0 - (d_offset / 1.0))

        # 9. Penalizaciones
        penalties = 0.0
        has_family_conflict = False
        if cand_a.probable_family != cand_b.probable_family and \
           cand_a.probable_family != SemanticFamily.UNKNOWN and \
           cand_b.probable_family != SemanticFamily.UNKNOWN:
            has_family_conflict = True
            penalties += 0.40

        if has_station_conflict:
            penalties += 0.40
        if has_label_conflict:
            penalties += 0.50
        if has_dim_conflict:
            penalties += 0.45

        # 10. Cálculo de Final Score Ponderado Auditable
        weights = {
            "view": 0.15,
            "station": 0.25 if (cand_a.station is not None and cand_b.station is not None) else 0.0,
            "label": 0.25 if meaningful_common else 0.0,
            "dim": 0.20 if dim_score > 0 else 0.0,
            "geom": 0.15 if geom_score > 0 else 0.0,
            "callout": 0.20 if callout_boost > 0 else 0.0,
        }
        total_w = sum(weights.values()) or 1.0
        sum_scores = (
            weights["view"] * view_comp +
            weights["station"] * station_score +
            weights["label"] * label_score +
            weights["dim"] * dim_score +
            weights["geom"] * geom_score +
            weights["callout"] * (callout_boost / 0.35)
        )
        base_match_score = sum_scores / total_w
        final_score = max(0.0, min(1.0, base_match_score + callout_boost - penalties))

        # 11. Decisión de Correspondencia
        decision = MatchDecision.UNRESOLVED

        # Caso de la MISMA VISTA: dos candidatos distintos en la misma vista no son el mismo objeto
        is_same_view = (cand_a.view_ids == cand_b.view_ids and bool(cand_a.view_ids))
        if is_same_view:
            if "CIRCLE" in str(cand_a.labels) and "CIRCLE" in str(cand_b.labels):
                r_a = cand_a.spatial_extent.get("radius") if cand_a.spatial_extent else None
                r_b = cand_b.spatial_extent.get("radius") if cand_b.spatial_extent else None
                if r_a and r_b and abs(r_a - r_b) <= 0.01:
                    decision = MatchDecision.REPEATED_INSTANCE
                    rule_ids.append("RULE_REPEATED_INSTANCE_SAME_VIEW")
                else:
                    decision = MatchDecision.DIFFERENT_OBJECT
                    rule_ids.append("RULE_DIFFERENT_OBJECT_SAME_VIEW")
            else:
                decision = MatchDecision.DIFFERENT_OBJECT
                rule_ids.append("RULE_DIFFERENT_OBJECT_SAME_VIEW")

        # Caso DIFFERENT_OBJECT: Conflicto severo (etiquetas, estaciones o familias incompatibles)
        elif has_label_conflict or (has_station_conflict and station_delta and station_delta > 50.0) or has_family_conflict:
            decision = MatchDecision.DIFFERENT_OBJECT
            rule_ids.append("RULE_DIFFERENT_OBJECT_BY_CONFLICT")

        # Caso SAME_OBJECT: Alta evidencia convergente y sin conflicto de familias
        elif (
            final_score >= 0.75
            and not has_station_conflict
            and not has_label_conflict
            and not has_dim_conflict
            and not has_family_conflict
            and (station_score >= 0.70 or label_score >= 0.70 or callout_boost > 0)
        ):
            decision = MatchDecision.SAME_OBJECT
            rule_ids.append("RULE_DECISION_SAME_OBJECT")

        elif final_score >= 0.50 and not has_station_conflict and not has_label_conflict and not has_family_conflict:
            decision = MatchDecision.POSSIBLE_SAME_OBJECT
            rule_ids.append("RULE_DECISION_POSSIBLE_SAME_OBJECT")

        elif cand_a.probable_family == cand_b.probable_family and cand_a.probable_family != SemanticFamily.UNKNOWN:
            decision = MatchDecision.SYSTEM_RELATED
            rule_ids.append("RULE_DECISION_SYSTEM_RELATED")
        else:
            decision = MatchDecision.UNRESOLVED
            rule_ids.append("RULE_DECISION_UNRESOLVED")

        notes = f"Comparación entre {cand_a.candidate_id} y {cand_b.candidate_id}: decisión={decision.value}, score={final_score:.3f}"

        return EvidenceMatch(
            match_id=match_id,
            candidate_a_id=cand_a.candidate_id,
            candidate_b_id=cand_b.candidate_id,
            decision=decision,
            confidence=round(final_score, 3),
            evidence_for=evidence_for,
            evidence_against=evidence_against,
            spatial_score=round(spatial_score, 3),
            station_score=round(station_score, 3),
            label_score=round(label_score, 3),
            dimensional_score=round(dim_score, 3),
            geometric_score=round(geom_score, 3),
            view_compatibility_score=round(view_comp, 3),
            source_independence_score=round(source_indep_score, 3),
            penalties=round(penalties, 3),
            final_score=round(final_score, 3),
            rule_ids=rule_ids,
            notes=notes,
        )

    def _check_dimensional_compatibility(
        self,
        cand_a: ObjectCandidate,
        cand_b: ObjectCandidate,
        evidence_for: list[ResolutionEvidence],
        evidence_against: list[ResolutionEvidence],
        rule_ids: list[str],
    ) -> tuple[float, bool]:
        """
        Compara dimensiones documentadas o geométricas (ej. radio de círculo 0.60 m vs diámetro 1.20 m).
        """
        dim_score = 0.0
        has_conflict = False

        # Extraer radio/diámetro geométrico o paramétrico
        r_a = cand_a.spatial_extent.get("radius") if cand_a.spatial_extent else None
        r_b = cand_b.spatial_extent.get("radius") if cand_b.spatial_extent else None

        meas_a = [m["value"] for m in cand_a.parameter_candidates if m.get("candidate_type") == CandidateType.MEASUREMENT.value]
        meas_b = [m["value"] for m in cand_b.parameter_candidates if m.get("candidate_type") == CandidateType.MEASUREMENT.value]

        # Comparar si r_a (radio) es compatible con algún diámetro d_b = 2 * r_a
        val_pairs: list[tuple[float, float, str]] = []
        if r_a:
            val_pairs.append((r_a * 2.0, "DERIVED_DIAMETER_A", "GEOM_A"))
        if r_b:
            val_pairs.append((r_b * 2.0, "DERIVED_DIAMETER_B", "GEOM_B"))

        for d_derived, name_d, src_d in val_pairs:
            other_meas = meas_b if "A" in src_d else meas_a
            for m_val in other_meas:
                rel_diff = abs(d_derived - m_val) / max(m_val, 1e-4)
                if rel_diff <= self.dimension_tolerance:
                    dim_score = 0.90
                    evidence_for.append(
                        ResolutionEvidence(
                            criterion="DIMENSIONAL_COMPATIBILITY",
                            description=f"Diámetro derivado ({d_derived:.2f}m) compatible con medición documentada ({m_val:.2f}m)",
                            score=0.90,
                            rule_id="RULE_DIMENSIONAL_RADIUS_DIAMETER_MATCH",
                            details={"derived": d_derived, "measured": m_val, "diff": rel_diff},
                        )
                    )
                    rule_ids.append("RULE_DIMENSIONAL_RADIUS_DIAMETER_MATCH")
                    return dim_score, False
                elif abs(d_derived - m_val) > 0.5:
                    # Incompatibilidad dimensional flagrante (ej. 1.20m vs 2.50m)
                    has_conflict = True
                    evidence_against.append(
                        ResolutionEvidence(
                            criterion="DIMENSIONAL_CONFLICT",
                            description=f"Incompatibilidad dimensional: {d_derived:.2f}m vs {m_val:.2f}m",
                            score=0.85,
                            is_supporting=False,
                            rule_id="RULE_DIMENSIONAL_MISMATCH",
                            details={"val1": d_derived, "val2": m_val},
                        )
                    )
                    rule_ids.append("RULE_DIMENSIONAL_MISMATCH")

        return dim_score, has_conflict
