from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path
from typing import Optional, Type

from readers.dwg.base import DWGProvider
from readers.dwg.libredwg_provider import LibreDWGProvider

LOGGER = logging.getLogger("agente_modelador_3d.readers.dwg.registry")


class DWGProviderRegistry:
    """
    Registro central y selector dinámico de proveedores DWG.

    Soporta selección por:
    - Configuración explícita: DWG_PROVIDER=libredwg, DWG_PROVIDER=oda, etc.
    - Modo automático: DWG_PROVIDER=auto (descubre el mejor proveedor disponible en el entorno).

    Garantiza aislamiento: si ningún proveedor está disponible, no genera errores de import
    y deja la capacidad DWG en estado UNAVAILABLE de forma limpia.
    """

    def __init__(self) -> None:
        self._providers: dict[str, DWGProvider] = {}
        self._register_default_providers()

    def _register_default_providers(self) -> None:
        # Registrar LibreDWG Provider por defecto
        self.register_provider(LibreDWGProvider())

    def register_provider(self, provider: DWGProvider) -> None:
        key = provider.provider_id.upper()
        self._providers[key] = provider

    def get_provider(self, provider_id: str) -> Optional[DWGProvider]:
        return self._providers.get(provider_id.upper())

    def list_providers(self) -> list[str]:
        return sorted(list(self._providers.keys()))

    def get_active_provider(self, configured_preference: Optional[str] = None) -> Optional[DWGProvider]:
        """
        Resuelve el proveedor DWG según la preferencia del entorno o autodescubrimiento.
        """
        pref = configured_preference or os.getenv("DWG_PROVIDER", "auto").strip().upper()

        if pref != "AUTO" and pref in self._providers:
            provider = self._providers[pref]
            if provider.is_available():
                return provider
            LOGGER.warning("Proveedor DWG solicitado %s no está disponible en este entorno.", pref)
            return provider  # Se devuelve para permitir probe/health_check

        # Modo AUTO: buscar primer proveedor disponible
        for p_id, provider in self._providers.items():
            if provider.is_available():
                LOGGER.info("DWG Provider AUTO seleccionó: %s", provider.display_name)
                return provider

        # Si ninguno está disponible, retornar el primero registrado (ej. LibreDWG) para diagnósticos
        if self._providers:
            first_key = next(iter(self._providers))
            return self._providers[first_key]

        return None

    def health_summary(self) -> dict[str, dict]:
        return {
            p_id: prov.health_check().to_dict()
            for p_id, prov in self._providers.items()
        }


# Instancia singleton global del registry
_GLOBAL_DWG_REGISTRY: Optional[DWGProviderRegistry] = None


def get_dwg_registry() -> DWGProviderRegistry:
    global _GLOBAL_DWG_REGISTRY
    if _GLOBAL_DWG_REGISTRY is None:
        _GLOBAL_DWG_REGISTRY = DWGProviderRegistry()
    return _GLOBAL_DWG_REGISTRY
