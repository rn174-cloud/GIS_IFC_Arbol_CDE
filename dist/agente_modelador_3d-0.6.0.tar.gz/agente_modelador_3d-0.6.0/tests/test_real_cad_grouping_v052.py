"""
tests/test_real_cad_grouping_v052.py
Pruebas unitarias para v0.5.2: Real CAD Object Grouping Correction.

Cubre exhaustivamente las 12 correcciones obligatorias aprobadas:
1. test_deterministic_group_id_independent_of_entity_order
2. test_different_groups_receive_different_ids
3. test_no_grouping_across_different_regions
4. test_spatial_index_produces_same_groups_as_brute_force_reference
5. test_layer_eje_with_connected_chain_alone_does_not_assign_alignment
6. test_linear_chain_plus_station_or_explicit_text_may_produce_alignment_candidate
7. test_block_instance_is_not_exploded
8. test_shared_region_context_cannot_by_itself_promote_primitive
9. test_single_line_without_evidence_does_not_become_candidate
10. test_four_connected_lines_form_closed_contour_motif
11. test_concentric_circles_remain_neutral_motif
12. test_candidate_count_significantly_lower_than_primitive_count
13. test_singleton_and_multi_candidate_hypothesis_metrics_reported
"""
from __future__ import annotations

import math
import pytest

from core.models import (
    CandidateStatus,
    CandidateType,
    EvidenceOrigin,
    ObjectCandidate,
    ObjectHypothesis,
    SemanticFamily,
    SemanticSignal,
    SourceDocument,
    SourceReference,
    ViewEvidence,
)
from reconstruction.local_geometry_grouper import LocalGeometryGrouper
from reconstruction.object_candidate_detector import ObjectCandidateDetector
from reconstruction.object_hypothesis_resolver import ObjectHypothesisResolver


def test_deterministic_group_id_independent_of_entity_order():
    """
    5. Identidad Determinista:
    El mismo grupo con orden distinto de entidades conserva exactamente el mismo group_id.
    """
    grouper = LocalGeometryGrouper()

    # Dos listas con las mismas entidades pero en orden inverso
    ents_a = [
        {"entity_type": "LINE", "handle": "H01", "start": {"x": 0.0, "y": 0.0}, "end": {"x": 10.0, "y": 0.0}, "layer": "EJE"},
        {"entity_type": "LINE", "handle": "H02", "start": {"x": 10.0, "y": 0.0}, "end": {"x": 20.0, "y": 0.0}, "layer": "EJE"},
    ]
    ents_b = [
        {"entity_type": "LINE", "handle": "H02", "start": {"x": 10.0, "y": 0.0}, "end": {"x": 20.0, "y": 0.0}, "layer": "EJE"},
        {"entity_type": "LINE", "handle": "H01", "start": {"x": 0.0, "y": 0.0}, "end": {"x": 10.0, "y": 0.0}, "layer": "EJE"},
    ]

    doc_a = SourceDocument(path="test_a.dwg", file_type="DWG", extracted_data={"entities": ents_a})
    doc_b = SourceDocument(path="test_b.dwg", file_type="DWG", extracted_data={"entities": ents_b})

    _, groups_a, _, _ = grouper.group_cad_document(doc_a, [])
    _, groups_b, _, _ = grouper.group_cad_document(doc_b, [])

    assert len(groups_a) == 1
    assert len(groups_b) == 1
    assert groups_a[0].group_id == groups_b[0].group_id
    assert sorted(groups_a[0].member_handles) == sorted(groups_b[0].member_handles)


def test_different_groups_receive_different_ids():
    """
    5. Identidad Determinista:
    Grupos distintos reciben IDs distintos.
    """
    grouper = LocalGeometryGrouper()

    ents = [
        {"entity_type": "LINE", "handle": "H01", "start": {"x": 0.0, "y": 0.0}, "end": {"x": 10.0, "y": 0.0}, "layer": "L1"},
        {"entity_type": "LINE", "handle": "H02", "start": {"x": 10.0, "y": 0.0}, "end": {"x": 20.0, "y": 0.0}, "layer": "L1"},
        {"entity_type": "LINE", "handle": "H03", "start": {"x": 100.0, "y": 0.0}, "end": {"x": 110.0, "y": 0.0}, "layer": "L2"},
        {"entity_type": "LINE", "handle": "H04", "start": {"x": 110.0, "y": 0.0}, "end": {"x": 120.0, "y": 0.0}, "layer": "L2"},
    ]
    doc = SourceDocument(path="test.dwg", file_type="DWG", extracted_data={"entities": ents})
    _, groups, _, _ = grouper.group_cad_document(doc, [])

    assert len(groups) == 2
    assert groups[0].group_id != groups[1].group_id


def test_no_grouping_across_different_regions():
    """
    8. Region Boundaries:
    LocalGeometryGroup nunca conecta primitivas de regiones diferentes por cercanía geométrica.
    """
    grouper = LocalGeometryGrouper()

    # Dos líneas que se tocan perfectamente en (10, 0), pero pertenecen a vistas/regiones distintas
    ents = [
        {"entity_type": "LINE", "handle": "R1_01", "start": {"x": 0.0, "y": 0.0}, "end": {"x": 10.0, "y": 0.0}, "layer": "GEO"},
        {"entity_type": "LINE", "handle": "R2_01", "start": {"x": 10.0, "y": 0.0}, "end": {"x": 20.0, "y": 0.0}, "layer": "GEO"},
    ]
    views = [
        ViewEvidence(
            view_id="region_planta",
            view_type="PLAN",
            source=SourceReference(source_file="test.dwg", source_type="DWG"),
            entity_references=["R1_01"],
            bounding_box={"minx": 0, "miny": -5, "maxx": 10, "maxy": 5},
        ),
        ViewEvidence(
            view_id="region_perfil",
            view_type="PROFILE",
            source=SourceReference(source_file="test.dwg", source_type="DWG"),
            entity_references=["R2_01"],
            bounding_box={"minx": 10, "miny": -5, "maxx": 20, "maxy": 5},
        ),
    ]
    doc = SourceDocument(path="test.dwg", file_type="DWG", extracted_data={"entities": ents})
    _, groups, _, _ = grouper.group_cad_document(doc, views)

    # Cada región tiene 1 sola primitiva; como un grupo requiere >= 2 primitivas en la misma región,
    # no deben unirse cruzando la frontera de región.
    assert len(groups) == 0


def test_spatial_index_produces_same_groups_as_brute_force_reference():
    """
    4. Spatial Index / Scalability:
    Compara el resultado de STRtree contra una referencia exhaustiva O(N^2) en un fixture pequeño.
    """
    grouper = LocalGeometryGrouper()

    # 6 líneas formando 2 componentes conexos y 1 aislada
    ents = [
        # Componente 1 (cadena de 3)
        {"entity_type": "LINE", "handle": "L1", "start": {"x": 0.0, "y": 0.0}, "end": {"x": 10.0, "y": 0.0}, "layer": "A"},
        {"entity_type": "LINE", "handle": "L2", "start": {"x": 10.0, "y": 0.0}, "end": {"x": 10.0, "y": 10.0}, "layer": "A"},
        {"entity_type": "LINE", "handle": "L3", "start": {"x": 10.0, "y": 10.0}, "end": {"x": 0.0, "y": 10.0}, "layer": "A"},
        # Componente 2 (par de 2)
        {"entity_type": "LINE", "handle": "L4", "start": {"x": 50.0, "y": 50.0}, "end": {"x": 60.0, "y": 50.0}, "layer": "B"},
        {"entity_type": "LINE", "handle": "L5", "start": {"x": 60.0, "y": 50.0}, "end": {"x": 70.0, "y": 50.0}, "layer": "B"},
        # Aislada
        {"entity_type": "LINE", "handle": "L6", "start": {"x": 200.0, "y": 200.0}, "end": {"x": 210.0, "y": 200.0}, "layer": "C"},
    ]
    doc = SourceDocument(path="test.dwg", file_type="DWG", extracted_data={"entities": ents})
    prims, groups, _, stats = grouper.group_cad_document(doc, [])

    # Verificación por fuerza bruta directa
    threshold = stats["region_summaries"][0]["threshold_audit"]["final_threshold"]

    # Comprobación de componentes
    group_handles = [sorted(g.member_handles) for g in groups]
    assert sorted(["L1", "L2", "L3"]) in group_handles
    assert sorted(["L4", "L5"]) in group_handles
    assert not any("L6" in g.member_handles for g in groups)
    assert stats["spatial_queries"] == len(ents)


def test_layer_eje_with_connected_chain_alone_does_not_assign_alignment():
    """
    1. Alignment Semantics:
    LAYER "EJE" + LINEAR_CHAIN NO produce POSSIBLE_ALIGNMENT_FEATURE.
    Debe permanecer en UNKNOWN_LINEAR_FEATURE / SemanticFamily.UNKNOWN.
    """
    detector = ObjectCandidateDetector()

    # 3 líneas conectadas en layer EJE sin estación ni textos documentales
    ents = [
        {"entity_type": "LINE", "handle": "E01", "start": {"x": 0.0, "y": 0.0}, "end": {"x": 100.0, "y": 0.0}, "layer": "EJE"},
        {"entity_type": "LINE", "handle": "E02", "start": {"x": 100.0, "y": 0.0}, "end": {"x": 200.0, "y": 0.0}, "layer": "EJE"},
        {"entity_type": "LINE", "handle": "E03", "start": {"x": 200.0, "y": 0.0}, "end": {"x": 300.0, "y": 0.0}, "layer": "EJE"},
    ]
    doc = SourceDocument(path="test_eje.dwg", file_type="DWG", extracted_data={"entities": ents, "texts": []})

    candidates, signals, _ = detector.detect_candidates(
        documents=[doc],
        views=[],
        classified_measurements=[],
    )

    assert len(candidates) == 1
    cand = candidates[0]
    # Comprobar que NO es ALIGNMENT ni POSSIBLE_ALIGNMENT_FEATURE
    assert cand.probable_family != SemanticFamily.ALIGNMENT
    assert cand.probable_type != "POSSIBLE_ALIGNMENT_FEATURE"
    assert cand.probable_type == "UNKNOWN_LINEAR_FEATURE"


def test_linear_chain_plus_station_or_explicit_text_may_produce_alignment_candidate():
    """
    1. Alignment Semantics:
    LINEAR_CHAIN + evidencia semántica independiente (STATION o TEXT_ALIGNMENT_EXPLICIT)
    SÍ produce POSSIBLE_ALIGNMENT_FEATURE.
    """
    detector = ObjectCandidateDetector()

    ents = [
        {"entity_type": "LINE", "handle": "E01", "start": {"x": 0.0, "y": 0.0}, "end": {"x": 100.0, "y": 0.0}, "layer": "EJE"},
        {"entity_type": "LINE", "handle": "E02", "start": {"x": 100.0, "y": 0.0}, "end": {"x": 200.0, "y": 0.0}, "layer": "EJE"},
    ]
    # Evidencia semántica independiente: progresiva estructurada
    measurements = [
        {
            "candidate_type": CandidateType.STATION.value,
            "value": 10500.0,
            "unit": "METER",
            "view_id": "cad_modelspace",
        }
    ]
    doc = SourceDocument(path="test_eje_st.dwg", file_type="DWG", extracted_data={"entities": ents, "texts": []})

    candidates, _, _ = detector.detect_candidates(
        documents=[doc],
        views=[],
        classified_measurements=measurements,
    )

    assert len(candidates) == 1
    cand = candidates[0]
    assert cand.probable_family == SemanticFamily.ALIGNMENT
    assert cand.probable_type == "POSSIBLE_ALIGNMENT_FEATURE"
    assert "LINEAR_CHAIN_GEOMETRY" in cand.type_evidence
    assert "STATIONING_EVIDENCE" in cand.type_evidence


def test_block_instance_is_not_exploded():
    """
    7. Blocks:
    Un INSERT se conserva como instancia documental atómica y NO se explota automáticamente.
    Produce ObjectCandidate con promotion_reason='BLOCK_WITH_METADATA'.
    """
    detector = ObjectCandidateDetector()

    ents = [
        {
            "entity_type": "INSERT",
            "handle": "BLK01",
            "name": "COLUMNA_TIPO_A",
            "insert": {"x": 50.0, "y": 50.0, "z": 0.0},
            "layer": "ESTRUCTURA",
            "attributes": {"DIAMETRO": "1.20", "MATERIAL": "H30"},
        }
    ]
    doc = SourceDocument(path="test_block.dwg", file_type="DWG", extracted_data={"entities": ents})

    candidates, _, _ = detector.detect_candidates([doc], [], [])

    assert len(candidates) == 1
    cand = candidates[0]
    assert cand.promotion_reason == "BLOCK_WITH_METADATA"
    assert cand.probable_family == SemanticFamily.STRUCTURAL
    assert cand.probable_type == "POSSIBLE_COLUMN_COMPONENT"
    assert cand.member_primitive_count == 1


def test_shared_region_context_cannot_by_itself_promote_primitive():
    """
    6 & 11. Semantic Signal Scope:
    Un texto regional (SAME_REGION, scope=SHARED_REGION_CONTEXT) NO puede promover por sí mismo
    una primitiva aislada a ObjectCandidate.
    """
    detector = ObjectCandidateDetector()

    # Una sola línea sin conectividad con un texto lejano en la misma región
    ents = [
        {"entity_type": "LINE", "handle": "ISO_01", "start": {"x": 0.0, "y": 0.0}, "end": {"x": 5.0, "y": 0.0}, "layer": "0"},
    ]
    texts = [
        {"text": "REPAVIMENTACION Y CALZADA", "insert": {"x": 80.0, "y": 80.0, "z": 0.0}, "layer": "TEXTOS"},
    ]
    doc = SourceDocument(path="test_iso.dwg", file_type="DWG", extracted_data={"entities": ents, "texts": texts})

    candidates, _, _ = detector.detect_candidates([doc], [], [])

    # La línea aislada no debe ser promovida
    assert len(candidates) == 0


def test_single_line_without_evidence_does_not_become_candidate():
    """
    11. Primitiva aislada sin evidencia:
    Una sola línea huérfana NO se convierte en candidato.
    """
    detector = ObjectCandidateDetector()

    ents = [
        {"entity_type": "LINE", "handle": "LINE_LONE", "start": {"x": 0.0, "y": 0.0}, "end": {"x": 10.0, "y": 0.0}, "layer": "AUX"},
    ]
    doc = SourceDocument(path="test_lone.dwg", file_type="DWG", extracted_data={"entities": ents, "texts": []})
    candidates, _, _ = detector.detect_candidates([doc], [], [])

    assert len(candidates) == 0


def test_four_connected_lines_form_closed_contour_motif():
    """
    10. Connected components:
    Cuatro líneas formando un marco cerrado se clasifican como CLOSED_CONTOUR.
    """
    detector = ObjectCandidateDetector()

    ents = [
        {"entity_type": "LINE", "handle": "B01", "start": {"x": 0.0, "y": 0.0}, "end": {"x": 10.0, "y": 0.0}, "layer": "CALZADA"},
        {"entity_type": "LINE", "handle": "B02", "start": {"x": 10.0, "y": 0.0}, "end": {"x": 10.0, "y": 20.0}, "layer": "CALZADA"},
        {"entity_type": "LINE", "handle": "B03", "start": {"x": 10.0, "y": 20.0}, "end": {"x": 0.0, "y": 20.0}, "layer": "CALZADA"},
        {"entity_type": "LINE", "handle": "B04", "start": {"x": 0.0, "y": 20.0}, "end": {"x": 0.0, "y": 0.0}, "layer": "CALZADA"},
    ]
    doc = SourceDocument(path="test_contour.dwg", file_type="DWG", extracted_data={"entities": ents, "texts": []})
    candidates, _, _ = detector.detect_candidates([doc], [], [])

    assert len(candidates) == 1
    cand = candidates[0]
    assert cand.promotion_reason == "CONNECTED_GROUP"
    assert cand.member_primitive_count == 4
    assert "CLOSED_CONTOUR" in cand.type_evidence


def test_concentric_circles_remain_neutral_motif():
    """
    Motivos:
    Círculos concéntricos se detectan como motivo neutral con promotion_reason='GEOMETRIC_MOTIF'.
    """
    detector = ObjectCandidateDetector()

    ents = [
        {"entity_type": "CIRCLE", "handle": "C1", "center": {"x": 10.0, "y": 10.0, "z": 0.0}, "radius": 2.0, "layer": "GEOM"},
        {"entity_type": "CIRCLE", "handle": "C2", "center": {"x": 10.0, "y": 10.0, "z": 0.0}, "radius": 4.0, "layer": "GEOM"},
    ]
    doc = SourceDocument(path="test_circ.dwg", file_type="DWG", extracted_data={"entities": ents, "texts": []})
    candidates, _, _ = detector.detect_candidates([doc], [], [])

    assert len(candidates) == 1
    cand = candidates[0]
    assert cand.promotion_reason == "GEOMETRIC_MOTIF"
    assert cand.probable_type == "UNKNOWN_CIRCULAR_ASSEMBLY"
    assert cand.probable_family == SemanticFamily.UNKNOWN
    assert cand.member_primitive_count == 2


def test_candidate_count_significantly_lower_than_primitive_count():
    """
    9. Acceptance Conceptual Condition:
    ObjectCandidates << PrimitiveEvidence cuando hay muchas primitivas conectadas o aisladas.
    """
    detector = ObjectCandidateDetector()

    # 100 líneas: 2 cadenas de 10 líneas, y 80 líneas aisladas dispersas
    ents = []
    # Cadena 1: 10 líneas
    for i in range(10):
        ents.append({"entity_type": "LINE", "handle": f"C1_{i}", "start": {"x": i * 5.0, "y": 0.0}, "end": {"x": (i + 1) * 5.0, "y": 0.0}, "layer": "LINEA"})
    # Cadena 2: 10 líneas
    for i in range(10):
        ents.append({"entity_type": "LINE", "handle": f"C2_{i}", "start": {"x": i * 5.0, "y": 100.0}, "end": {"x": (i + 1) * 5.0, "y": 100.0}, "layer": "LINEA"})
    # 80 líneas aisladas separadas por 200m
    for i in range(80):
        ents.append({"entity_type": "LINE", "handle": f"ISO_{i}", "start": {"x": 1000.0 + i * 200.0, "y": 0.0}, "end": {"x": 1000.0 + i * 200.0 + 2.0, "y": 0.0}, "layer": "RUIDO"})

    doc = SourceDocument(path="test_scale.dwg", file_type="DWG", extracted_data={"entities": ents, "texts": []})
    candidates, _, _ = detector.detect_candidates([doc], [], [])

    # Las 80 aisladas no se promueven; solo las 2 cadenas conectadas se promueven
    assert len(candidates) == 2
    assert len(candidates) < len(ents) / 10


def test_singleton_and_multi_candidate_hypothesis_metrics_reported():
    """
    9. Acceptance Metrics:
    Verifica que ObjectHypothesis marque is_singleton correctamente.
    """
    resolver = ObjectHypothesisResolver()

    cand1 = ObjectCandidate(candidate_id="c1", probable_family=SemanticFamily.UNKNOWN, probable_type="T1")
    cand2 = ObjectCandidate(candidate_id="c2", probable_family=SemanticFamily.UNKNOWN, probable_type="T2")

    # Sin matches -> dos hipótesis singleton
    hypotheses, _ = resolver.resolve_hypotheses_and_drafts(
        candidates=[cand1, cand2],
        matches=[],
        views_dict={},
    )

    assert len(hypotheses) == 2
    assert all(h.is_singleton for h in hypotheses)
