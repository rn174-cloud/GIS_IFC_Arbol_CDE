"""
Pruebas unitarias para v0.5.1: Real CAD Semantic Recovery.
Verifica:
1. Dimension Derivation: ALIGNED (euclidiana) vs LINEAR/ROTATED (proyección de ejes X/Y),
   respetando status DERIVED / DOCUMENTED / UNRESOLVED, sin forzar a metros cuando INSUNITS=0.
2. Clustering Adaptativo: cálculo de umbral adaptativo multi-factor (nearest-neighbour, percentiles, drawing extent),
   sin thresholds absolutos fijos como 150 o 5.
3. Geometric Motifs: CONCENTRIC_CIRCLES como señal neutra UNKNOWN_CIRCULAR_ASSEMBLY,
   sin saltos semánticos a pilote/shaft sin evidencia independiente.
4. Region != Object: verificación de separación estricta jerárquica.
5. Ingesta Canónica: flujo de entities, texts, dimensions desde CanonicalCADDocument.
"""
import pytest
from core.models import SourceDocument, SourceReference, EvidenceStatus
from reconstruction.parameter_extractor import ParameterExtractor, CandidateType
from reconstruction.view_segmenter import ViewSegmenter
from reconstruction.object_candidate_detector import ObjectCandidateDetector


def test_dimension_derivation_linear_vs_aligned():
    """
    Verifica que ALIGNED derive euclidianamente y LINEAR proyecte sobre el eje adecuado,
    y que geometrías ambiguas resulten en UNRESOLVED sin fabricar valores.
    """
    extractor = ParameterExtractor()
    source = SourceReference(
        source_file="test_doc.dwg",
        source_type="DWG",
        coordinate_reference="CAD_UNIT",
    )

    # 1. Cota ALIGNED inequívoca: puntos oblicuos
    dim_aligned = {
        "handle": "A01",
        "dimension_type": "ALIGNED",
        "measurement": -1.0,  # no resuelto nativamente
        "definition_points": [[0.0, 0.0, 0.0], [3.0, 4.0, 0.0]],  # distancia 5.0
    }

    # 2. Cota LINEAR HORIZONTAL inequívoca
    dim_linear_h = {
        "handle": "L01",
        "dimension_type": "LINEAR",
        "measurement": -1.0,
        "definition_points": [[10.0, 5.0, 0.0], [25.0, 5.0, 0.0]],  # dx = 15.0, dy = 0
    }

    # 3. Cota LINEAR VERTICAL inequívoca
    dim_linear_v = {
        "handle": "L02",
        "dimension_type": "ROTATED",
        "measurement": -1.0,
        "definition_points": [[10.0, 5.0, 0.0], [10.0, 35.0, 0.0]],  # dx = 0, dy = 30.0
    }

    # 4. Cota ambigua (sin puntos o degenerada)
    dim_ambiguous = {
        "handle": "L03",
        "dimension_type": "LINEAR",
        "measurement": -1.0,
        "definition_points": [[5.0, 5.0, 0.0], [5.0, 5.0, 0.0]],  # distancia 0
    }

    # 5. Cota documentada nativamente
    dim_documented = {
        "handle": "D01",
        "dimension_type": "LINEAR",
        "measurement": 12.50,
        "definition_points": [[0.0, 0.0, 0.0], [12.5, 0.0, 0.0]],
    }

    results = extractor.extract_from_cad_dimensions(
        [dim_aligned, dim_linear_h, dim_linear_v, dim_ambiguous, dim_documented],
        source=source,
    )

    by_handle = {r.dimension_handle: r for r in results}

    # A01: ALIGNED -> DERIVED euclidiano
    assert "A01" in by_handle
    assert by_handle["A01"].status == EvidenceStatus.DERIVED
    assert by_handle["A01"].value == pytest.approx(5.0)
    assert by_handle["A01"].unit == "CAD_UNIT"
    assert by_handle["A01"].derivation_method == "ALIGNED_DEFINITION_POINTS_EUCLIDEAN"

    # L01: LINEAR HORIZONTAL -> DERIVED proyección X
    assert "L01" in by_handle
    assert by_handle["L01"].status == EvidenceStatus.DERIVED
    assert by_handle["L01"].value == pytest.approx(15.0)
    assert by_handle["L01"].derivation_method == "LINEAR_HORIZONTAL_AXIS_PROJECTION"

    # L02: ROTATED VERTICAL -> DERIVED proyección Y
    assert "L02" in by_handle
    assert by_handle["L02"].status == EvidenceStatus.DERIVED
    assert by_handle["L02"].value == pytest.approx(30.0)
    assert by_handle["L02"].derivation_method == "LINEAR_VERTICAL_AXIS_PROJECTION"

    # L03: Ambigua / degenerada -> no debe estar en los resultados (UNRESOLVED)
    assert "L03" not in by_handle

    # D01: Documentada
    assert "D01" in by_handle
    assert by_handle["D01"].status == EvidenceStatus.DOCUMENTED
    assert by_handle["D01"].value == pytest.approx(12.50)


def test_adaptive_clustering_threshold_computation():
    """
    Verifica que el umbral de clustering sea adaptativo, dependa de la dispersión
    y dimensiones del documento, y registre estadísticas completas sin constantes arbitrarias.
    """
    segmenter = ViewSegmenter()

    # Generar dos nubes de bounding boxes separadas
    # Nube 1: elementos de tamaño 2x2 espaciados 1 unidad entre sí
    boxes_1 = [
        {"minx": i * 3.0, "miny": 0.0, "maxx": i * 3.0 + 2.0, "maxy": 2.0}
        for i in range(10)
    ]
    # Nube 2: elementos separados a 500 unidades
    boxes_2 = [
        {"minx": 500.0 + i * 3.0, "miny": 0.0, "maxx": 500.0 + i * 3.0 + 2.0, "maxy": 2.0}
        for i in range(10)
    ]
    all_boxes = boxes_1 + boxes_2

    th, method, stats = segmenter._compute_adaptive_threshold(all_boxes)

    assert method == "ADAPTIVE_NEAREST_NEIGHBOUR_EXTENT"
    assert "drawing_extent" in stats
    assert "median_diag" in stats
    assert "p50_nn_dist" in stats
    assert "max_nn_dist" in stats
    assert stats["drawing_extent"] > 500.0
    # El umbral adaptativo debe ser menor que la separación (500 - 29 = ~470)
    assert th < 400.0

    # Clusterizar con el umbral adaptativo
    clusters = segmenter._cluster_bboxes(all_boxes, max_gap=th)
    assert len(clusters) == 2


def test_geometric_motif_neutral_assembly():
    """
    Verifica que círculos concéntricos se detecten como UNKNOWN_CIRCULAR_ASSEMBLY
    con motivo CONCENTRIC_CIRCLES y NO como pilote o shaft sin evidencia semántica independiente.
    """
    detector = ObjectCandidateDetector()

    doc = SourceDocument(
        path="test_synthetic.dwg",
        file_type="DWG",
        extracted_data={
            "entities": [
                {
                    "entity_type": "CIRCLE",
                    "handle": "C01",
                    "layer": "GEOMETRIA",
                    "center": {"x": 100.0, "y": 200.0, "z": 0.0},
                    "radius": 10.0,
                },
                {
                    "entity_type": "CIRCLE",
                    "handle": "C02",
                    "layer": "GEOMETRIA",
                    "center": {"x": 100.0, "y": 200.0, "z": 0.0},
                    "radius": 15.0,
                },
            ],
            "texts": [],
            "dimensions": [],
        },
    )

    candidates, signals, _ = detector.detect_candidates(
        documents=[doc],
        views=[],
        classified_measurements=[],
    )

    # Debe encontrar el motivo concéntrico
    motif_cands = [c for c in candidates if "UNKNOWN_CIRCULAR_ASSEMBLY" in c.probable_type]
    assert len(motif_cands) == 1
    mc = motif_cands[0]
    assert mc.probable_type == "UNKNOWN_CIRCULAR_ASSEMBLY"
    assert mc.probable_family.value == "UNKNOWN"
    assert any(s.signal_type == "GEOMETRIC_MOTIF" for s in mc.semantic_signals)
