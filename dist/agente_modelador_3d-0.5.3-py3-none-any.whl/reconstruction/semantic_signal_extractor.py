from __future__ import annotations

import math
import re
from typing import Any

from core.models import (
    CandidateType,
    EvidenceOrigin,
    ProximityLevel,
    SemanticSignal,
    SourceDocument,
    ViewEvidence,
)


class SemanticSignalExtractor:
    """
    Extractor endurecido de señales semánticas a partir de evidencia documental.

    Produce evidencias atómicas estructuradas (SemanticSignal) con:
    1. Distancia real y niveles de proximidad (VERY_NEAR, NEAR, SAME_REGION, FAR).
    2. Agrupamiento por origen (signal_group) para evitar doble conteo.
    3. Señales negativas cuando existe contradicción o incompatibilidad.
    4. Auditoría geométrica de bounding boxes y umbrales de distancia.
    """

    # Diccionario general y neutral de patrones léxicos para layers / nombres
    LAYER_FAMILY_PATTERNS = {
        "STRUCTURAL": [
            r"ESTRUCT", r"SUBESTRUCT", r"PILOT", r"PILA", r"ESTRIB", r"COLUMN",
            r"VIGA", r"TABLERO", r"LOSA", r"SUPERESTRUCT", r"APOYO", r"CABEZAL"
        ],
        "PAVEMENT": [
            r"PAVIMENT", r"CALZADA", r"ASFALT", r"CONCRETO", r"BASE", r"SUBBASE",
            r"RODADURA", r"BANQUINA", r"CORONA"
        ],
        "DRAINAGE": [
            r"DRENAJE", r"ALCANTARILL", r"CUNETA", r"SUMIDER", r"CANAL", r"COLECTOR",
            r"SEWER", r"CULVERT", r"DESAGUE"
        ],
        "EARTHWORKS": [
            r"TERRAPLEN", r"DESMONTE", r"TALUD", r"SUELO", r"COMPACT", r"MOV_SUELO",
            r"EXCAVACION", r"CURVA_NIVEL"
        ],
        "ROAD_SAFETY": [
            r"DEFENSA", r"GUARDARRAIL", r"BARANDA", r"BARRERA", r"SAFETY", r"SENAL"
        ],
        "ALIGNMENT": [
            r"TRAZA", r"PROGRESIV", r"ALINEAMIENT", r"ALIGNMENT", r"CENTRO"
        ],
        "UTILITIES": [
            r"DUCTO", r"GAS", r"ELECTR", r"FIBRA", r"AGUA", r"CANERIA", r"PIPE"
        ],
    }

    @staticmethod
    def compute_bbox(entity: dict[str, Any]) -> dict[str, float] | None:
        """
        Calcula el bounding box 2D de una entidad gráfica.
        """
        ent_type = entity.get("entity_type", "")

        if ent_type == "LINE":
            s = entity.get("start", {})
            e = entity.get("end", {})
            if "x" in s and "x" in e:
                return {
                    "minx": min(s["x"], e["x"]),
                    "miny": min(s["y"], e["y"]),
                    "maxx": max(s["x"], e["x"]),
                    "maxy": max(s["y"], e["y"]),
                }

        elif ent_type == "CIRCLE":
            c = entity.get("center", {})
            r = float(entity.get("radius", 0.0))
            if "x" in c and "y" in c:
                return {
                    "minx": c["x"] - r,
                    "miny": c["y"] - r,
                    "maxx": c["x"] + r,
                    "maxy": c["y"] + r,
                }

        elif ent_type in {"TEXT", "MTEXT", "INSERT"}:
            ins = entity.get("insert", {})
            if "x" in ins and "y" in ins:
                # Si tiene height, estimar caja aproximada
                h = float(entity.get("height", entity.get("char_height", 2.5)))
                text_len = len(str(entity.get("text", "")))
                w = max(h, text_len * h * 0.6)
                return {
                    "minx": ins["x"],
                    "miny": ins["y"],
                    "maxx": ins["x"] + w,
                    "maxy": ins["y"] + h,
                }

        elif ent_type in {"LWPOLYLINE", "POLYLINE"}:
            pts = entity.get("points", [])
            if pts:
                xs = [p["x"] for p in pts if "x" in p]
                ys = [p["y"] for p in pts if "y" in p]
                if xs and ys:
                    return {
                        "minx": min(xs),
                        "miny": min(ys),
                        "maxx": max(xs),
                        "maxy": max(ys),
                    }

        elif "bbox" in entity and isinstance(entity["bbox"], dict):
            return entity["bbox"]

        return None

    @staticmethod
    def bbox_distance(b1: dict[str, float], b2: dict[str, float]) -> float:
        """
        Calcula la distancia euclidiana mínima entre dos bounding boxes rectangulares.
        Si se intersectan o tocan, la distancia es 0.0.
        """
        dx = max(0.0, max(b1["minx"], b2["minx"]) - min(b1["maxx"], b2["maxx"]))
        dy = max(0.0, max(b1["miny"], b2["miny"]) - min(b1["maxy"], b2["maxy"]))
        return math.hypot(dx, dy)

    @classmethod
    def evaluate_proximity(
        cls,
        ent_bbox: dict[str, float] | None,
        target_bbox: dict[str, float] | None,
        threshold_very_near: float = 15.0,
        threshold_near: float = 50.0,
        threshold_region: float = 200.0,
    ) -> tuple[float | None, ProximityLevel, str]:
        """
        Evalúa la proximidad física entre dos bounding boxes con umbrales rigurosos.
        """
        if not ent_bbox or not target_bbox:
            return None, ProximityLevel.FAR, "MISSING_BBOX"

        dist = cls.bbox_distance(ent_bbox, target_bbox)

        if dist <= threshold_very_near:
            return dist, ProximityLevel.VERY_NEAR, "EUCLIDEAN_BBOX_MIN_DISTANCE"
        elif dist <= threshold_near:
            return dist, ProximityLevel.NEAR, "EUCLIDEAN_BBOX_MIN_DISTANCE"
        elif dist <= threshold_region:
            return dist, ProximityLevel.SAME_REGION, "EUCLIDEAN_BBOX_MIN_DISTANCE"
        else:
            return dist, ProximityLevel.FAR, "EUCLIDEAN_BBOX_MIN_DISTANCE"

    def extract_signals_for_entity(
        self,
        entity: dict[str, Any],
        source_id: str,
        view_id: str | None = None,
        candidate_text_entities: list[dict[str, Any]] | None = None,
        nearby_station: float | None = None,
        station_distance: float | None = None,
        candidate_dimension_entities: list[dict[str, Any]] | None = None,
    ) -> list[SemanticSignal]:
        """
        Extrae y normaliza señales semánticas atómicas para una entidad CAD o primitiva individual.
        Evalúa distancias reales y bounding boxes.
        """
        signals: list[SemanticSignal] = []
        ent_ref = str(entity.get("handle", ""))
        layer = str(entity.get("layer", ""))
        ent_type = str(entity.get("entity_type", "")).upper()
        ent_bbox = self.compute_bbox(entity)

        # 1. Señales de Layer (signal_group: CAD_LAYER)
        if layer:
            signals.append(
                SemanticSignal(
                    signal_type="LAYER_NAME",
                    value=layer,
                    source_id=source_id,
                    entity_reference=ent_ref,
                    view_id=view_id,
                    confidence=0.30,
                    weight=0.20,
                    signal_group=EvidenceOrigin.CAD_LAYER,
                    scope="LOCAL_TO_PRIMITIVE",
                    entity_bbox=ent_bbox,
                    notes=f"Entidad en layer {layer}",
                )
            )

            # Clasificación léxica de layer hacia familias generales
            # IMPORTANTE: pertenece al mismo signal_group CAD_LAYER para evitar doble conteo
            layer_upper = layer.upper()
            has_hint = False
            for family, patterns in self.LAYER_FAMILY_PATTERNS.items():
                if any(re.search(pat, layer_upper) for pat in patterns):
                    signals.append(
                        SemanticSignal(
                            signal_type="LAYER_FAMILY_HINT",
                            value=family,
                            source_id=source_id,
                            entity_reference=ent_ref,
                            view_id=view_id,
                            confidence=0.50,
                            weight=0.20,
                            signal_group=EvidenceOrigin.CAD_LAYER,
                            scope="LOCAL_TO_PRIMITIVE",
                            entity_bbox=ent_bbox,
                            notes=f"Layer {layer} sugiere familia {family}",
                        )
                    )
                    has_hint = True
                    break

            # v0.5.2: Token 'EJE' no asigna pertenencia directa a SemanticFamily.ALIGNMENT
            # Solo emite LAYER_SEMANTIC_HINT("EJE") como señal complementaria
            if not has_hint and "EJE" in layer_upper:
                signals.append(
                    SemanticSignal(
                        signal_type="LAYER_SEMANTIC_HINT",
                        value="EJE",
                        source_id=source_id,
                        entity_reference=ent_ref,
                        view_id=view_id,
                        confidence=0.35,
                        weight=0.15,
                        signal_group=EvidenceOrigin.CAD_LAYER,
                        scope="LOCAL_TO_PRIMITIVE",
                        entity_bbox=ent_bbox,
                        notes="Layer contiene token EJE (hint complementario, no familia semántica)",
                    )
                )

        # 2. Señales de Block Name / Insert (signal_group: CAD_BLOCK)
        if ent_type == "INSERT":
            block_name = str(entity.get("name", ""))
            signals.append(
                SemanticSignal(
                    signal_type="BLOCK_NAME",
                    value=block_name,
                    source_id=source_id,
                    entity_reference=ent_ref,
                    view_id=view_id,
                    confidence=0.45,
                    weight=0.25,
                    signal_group=EvidenceOrigin.CAD_BLOCK,
                    entity_bbox=ent_bbox,
                    notes=f"Instancia de bloque {block_name}",
                )
            )
            attribs = entity.get("attributes", {})
            if attribs:
                signals.append(
                    SemanticSignal(
                        signal_type="BLOCK_ATTRIBUTES",
                        value=attribs,
                        source_id=source_id,
                        entity_reference=ent_ref,
                        view_id=view_id,
                        confidence=0.60,
                        weight=0.20,
                        signal_group=EvidenceOrigin.CAD_BLOCK,
                        entity_bbox=ent_bbox,
                        notes=f"Atributos de bloque definidos: {list(attribs.keys())}",
                    )
                )

        # 3. Señales de Geometría Básica (signal_group: GEOMETRIC)
        if ent_type == "CIRCLE":
            radius = entity.get("radius")
            signals.append(
                SemanticSignal(
                    signal_type="CIRCULAR_GEOMETRY",
                    value={"radius": radius},
                    source_id=source_id,
                    entity_reference=ent_ref,
                    view_id=view_id,
                    confidence=0.40,
                    weight=0.15,
                    signal_group=EvidenceOrigin.GEOMETRIC,
                    entity_bbox=ent_bbox,
                    notes=f"Geometría circular radio={radius}",
                )
            )
        elif ent_type in {"LWPOLYLINE", "POLYLINE"}:
            is_closed = entity.get("closed", False)
            if is_closed:
                signals.append(
                    SemanticSignal(
                        signal_type="CLOSED_PROFILE",
                        value={"closed": True, "vertex_count": len(entity.get("points", []))},
                        source_id=source_id,
                        entity_reference=ent_ref,
                        view_id=view_id,
                        confidence=0.35,
                        weight=0.15,
                        signal_group=EvidenceOrigin.GEOMETRIC,
                        entity_bbox=ent_bbox,
                        notes="Polilínea cerrada / contorno superficial",
                    )
                )
            else:
                signals.append(
                    SemanticSignal(
                        signal_type="LINEAR_GEOMETRY",
                        value={"closed": False, "vertex_count": len(entity.get("points", []))},
                        source_id=source_id,
                        entity_reference=ent_ref,
                        view_id=view_id,
                        confidence=0.30,
                        weight=0.15,
                        signal_group=EvidenceOrigin.GEOMETRIC,
                        entity_bbox=ent_bbox,
                        notes="Polilínea abierta / trayectoria lineal",
                    )
                )
        elif ent_type == "LINE":
            signals.append(
                SemanticSignal(
                    signal_type="LINEAR_GEOMETRY",
                    value="SEGMENT",
                    source_id=source_id,
                    entity_reference=ent_ref,
                    view_id=view_id,
                    confidence=0.20,
                    weight=0.10,
                    signal_group=EvidenceOrigin.GEOMETRIC,
                    entity_bbox=ent_bbox,
                    notes="Segmento de línea recta 2D",
                )
            )

        # 4. Textos Próximos con Proximidad Espacial Real (signal_group: TEXTUAL)
        if candidate_text_entities:
            for txt_ent in candidate_text_entities:
                text_str = str(txt_ent.get("text", "")).strip()
                if not text_str:
                    continue

                txt_bbox = self.compute_bbox(txt_ent)
                dist, prox_level, method = self.evaluate_proximity(ent_bbox, txt_bbox)

                # Si es FAR (> 200m o umbral), no genera señal positiva de TEXT_NEARBY
                if prox_level == ProximityLevel.FAR:
                    continue

                # Ponderación según nivel de proximidad real
                is_informative = any(
                    kw in text_str.upper()
                    for kw in ["PILA", "PILOTE", "COLUMNA", "VIGA", "CALZADA", "PAVIMENTO", "EJE", "DIAMETRO", "ANCHO"]
                )

                if prox_level == ProximityLevel.VERY_NEAR:
                    conf = 0.80 if is_informative else 0.50
                    weight = 0.30 if is_informative else 0.20
                    sig_type = "TEXT_VERY_NEAR"
                    sig_scope = "LOCAL_TO_PRIMITIVE"
                elif prox_level == ProximityLevel.NEAR:
                    conf = 0.65 if is_informative else 0.40
                    weight = 0.20 if is_informative else 0.15
                    sig_type = "TEXT_NEARBY"
                    sig_scope = "LOCAL_TO_PRIMITIVE"
                else:  # SAME_REGION
                    conf = 0.30 if is_informative else 0.15
                    weight = 0.05  # Reducido sensiblemente (<= 0.05) para contexto regional compartido
                    sig_type = "TEXT_SAME_REGION"
                    sig_scope = "SHARED_REGION_CONTEXT"

                # Detección de evidencia negativa por contradicción textual explícita
                # Ejemplo: Si la entidad es CIRCLE pero el texto cercano dice 'PERFIL LONGITUDINAL TERRENO NATURAL'
                is_neg = False
                if ent_type == "CIRCLE" and any(k in text_str.upper() for k in ["PERFIL", "LONGITUDINAL", "TERRENO", "COTAS"]):
                    is_neg = True
                    conf = 0.70
                    weight = 0.25
                    sig_type = "TEXT_CONTRADICTS_TYPE"
                    sig_scope = "LOCAL_TO_PRIMITIVE"

                signals.append(
                    SemanticSignal(
                        signal_type=sig_type,
                        value=text_str,
                        source_id=source_id,
                        entity_reference=ent_ref,
                        view_id=view_id,
                        confidence=conf,
                        weight=weight,
                        signal_group=EvidenceOrigin.NEGATIVE if is_neg else EvidenceOrigin.TEXTUAL,
                        is_negative=is_neg,
                        scope=sig_scope,
                        real_distance=dist,
                        proximity_level=prox_level,
                        coordinate_system="VIEW_LOCAL_CAD",
                        entity_bbox=ent_bbox,
                        target_bbox=txt_bbox,
                        distance_threshold=50.0,
                        distance_method=method,
                        notes=f"Texto a distancia {dist:.2f}m ({prox_level.value}): {text_str[:40]!r}" if dist is not None else f"Texto en región: {text_str[:40]!r}",
                    )
                )

        # 5. Station Próxima con Distancia Real (signal_group: STATIONING)
        if nearby_station is not None:
            prox_level = ProximityLevel.NEAR
            if station_distance is not None:
                if station_distance <= 15.0:
                    prox_level = ProximityLevel.VERY_NEAR
                elif station_distance <= 50.0:
                    prox_level = ProximityLevel.NEAR
                elif station_distance <= 200.0:
                    prox_level = ProximityLevel.SAME_REGION
                else:
                    prox_level = ProximityLevel.FAR

            if prox_level != ProximityLevel.FAR:
                s_weight = 0.15 if prox_level in {ProximityLevel.VERY_NEAR, ProximityLevel.NEAR} else 0.05
                signals.append(
                    SemanticSignal(
                        signal_type="STATION_NEARBY",
                        value=nearby_station,
                        source_id=source_id,
                        entity_reference=ent_ref,
                        view_id=view_id,
                        confidence=0.75,
                        weight=s_weight,
                        signal_group=EvidenceOrigin.STATIONING,
                        real_distance=station_distance,
                        proximity_level=prox_level,
                        coordinate_system="VIEW_LOCAL_CAD",
                        entity_bbox=ent_bbox,
                        distance_threshold=50.0,
                        distance_method="STATION_ALIGNMENT_DISTANCE",
                        notes=f"Progresiva {nearby_station:.2f} m ({prox_level.value})",
                    )
                )

        # 6. Cotas / Dimensiones Próximas (signal_group: DIMENSIONAL)
        if candidate_dimension_entities:
            for dim_meas in candidate_dimension_entities:
                dim_pts = dim_meas.get("derivation_inputs") or {}
                if not isinstance(dim_pts, dict):
                    continue
                p1 = dim_pts.get("p1")
                p2 = dim_pts.get("p2")
                if not p1 or not p2:
                    continue

                dim_bbox = {
                    "minx": min(p1[0], p2[0]),
                    "miny": min(p1[1], p2[1]),
                    "maxx": max(p1[0], p2[0]),
                    "maxy": max(p1[1], p2[1]),
                }

                dist, prox_level, method = self.evaluate_proximity(ent_bbox, dim_bbox)
                if prox_level in {ProximityLevel.VERY_NEAR, ProximityLevel.NEAR}:
                    val = dim_meas.get("value")
                    h = dim_meas.get("dimension_handle")
                    status_str = dim_meas.get("status", "DERIVED")

                    # Si los puntos de la cota abarcan la extensión de la entidad
                    is_spanning = False
                    if ent_bbox:
                        if (dim_bbox["minx"] <= ent_bbox["minx"] + 0.1 and dim_bbox["maxx"] >= ent_bbox["maxx"] - 0.1) or \
                           (dim_bbox["miny"] <= ent_bbox["miny"] + 0.1 and dim_bbox["maxy"] >= ent_bbox["maxy"] - 0.1):
                            is_spanning = True

                    sig_name = "DIMENSION_SPANS_ENTITY" if is_spanning else "DIMENSION_NEAR_ENTITY"
                    signals.append(
                        SemanticSignal(
                            signal_type=sig_name,
                            value={"value": val, "unit": dim_meas.get("unit"), "handle": h, "status": status_str},
                            source_id=source_id,
                            entity_reference=ent_ref,
                            view_id=view_id,
                            confidence=0.80 if is_spanning else 0.65,
                            weight=0.25 if is_spanning else 0.15,
                            signal_group=EvidenceOrigin.DIMENSIONAL,
                            real_distance=dist,
                            proximity_level=prox_level,
                            coordinate_system="VIEW_LOCAL_CAD",
                            entity_bbox=ent_bbox,
                            target_bbox=dim_bbox,
                            distance_threshold=25.0,
                            distance_method=method,
                            notes=f"Cota {h} ({status_str}) a {dist:.2f}m: valor={val} {dim_meas.get('unit')}",
                        )
                    )

        return signals

    def extract_signals_from_view(
        self,
        view: ViewEvidence,
        source_document: SourceDocument,
        classified_measurements: list[dict[str, Any]] | None = None,
    ) -> list[SemanticSignal]:
        """
        Extrae señales globales y contextuales a nivel de vista.
        """
        signals: list[SemanticSignal] = []
        src_id = source_document.source_id or "src_unknown"

        # Señal de tipo de vista (signal_group: MULTIVIEW / SPATIAL)
        if view.view_type != "UNKNOWN":
            signals.append(
                SemanticSignal(
                    signal_type="VIEW_TYPE",
                    value=view.view_type,
                    source_id=src_id,
                    view_id=view.view_id,
                    confidence=view.confidence or 0.60,
                    weight=0.15,
                    signal_group=EvidenceOrigin.MULTIVIEW,
                    notes=f"Evidencia ubicada en vista {view.view_type}",
                )
            )

        # Señal de bounding box (signal_group: SPATIAL)
        if view.bounding_box:
            signals.append(
                SemanticSignal(
                    signal_type="SPATIAL_CLUSTER",
                    value=view.bounding_box,
                    source_id=src_id,
                    view_id=view.view_id,
                    confidence=0.70,
                    weight=0.05,
                    signal_group=EvidenceOrigin.SPATIAL,
                    scope="SHARED_REGION_CONTEXT",
                    notes=f"Región espacial ({view.detection_method})",
                )
            )

        # Señales de cotas / dimensiones (signal_group: DIMENSIONAL)
        if classified_measurements:
            for meas in classified_measurements:
                if meas.get("view_id") == view.view_id:
                    cand_type = meas.get("candidate_type")
                    if cand_type == CandidateType.MEASUREMENT.value:
                        signals.append(
                            SemanticSignal(
                                signal_type="DIMENSION_NEARBY",
                                value={"value": meas.get("value"), "unit": meas.get("unit"), "raw": meas.get("raw_text")},
                                source_id=src_id,
                                view_id=view.view_id,
                                confidence=0.70,
                                weight=0.05,
                                signal_group=EvidenceOrigin.DIMENSIONAL,
                                scope="SHARED_REGION_CONTEXT",
                                proximity_level=ProximityLevel.SAME_REGION,
                                notes=f"Cota en región de vista: {meas.get('raw_text')}",
                            )
                        )
                    elif cand_type == CandidateType.STATION.value:
                        signals.append(
                            SemanticSignal(
                                signal_type="STATION_NEARBY",
                                value=meas.get("value"),
                                source_id=src_id,
                                view_id=view.view_id,
                                confidence=0.80,
                                weight=0.05,
                                signal_group=EvidenceOrigin.STATIONING,
                                scope="SHARED_REGION_CONTEXT",
                                proximity_level=ProximityLevel.SAME_REGION,
                                notes=f"Progresiva en región de vista: {meas.get('raw_text')}",
                            )
                        )

        return signals
