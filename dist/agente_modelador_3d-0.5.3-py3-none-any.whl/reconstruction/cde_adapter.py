"""
reconstruction/cde_adapter.py
Adapter / Bridge entre el Agente Modelador 3D y el CDE de RN174.
Implementa el Processor Output Contract V1 para PROCESSOR_CAD.

Responsabilidades:
1. Recibir los resultados de ReconstructionPipeline.run().
2. Mapear CanonicalCADDocument -> processing_artifact.
3. Mapear PrimitiveEvidence y derivados -> document_evidence.
4. Mapear GeometricMotif -> document_evidence (DERIVED).
5. Mapear ObjectCandidate y ObjectHypothesis -> object_hypothesis.
6. Construir hypothesis_evidence_links con support_type y peso.
7. Generar un payload conforme al Processor Output Contract.
"""
from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional


class CADModelerCDEAdapter:
    """
    Transforma salidas del Modelador 3D (v0.5.2) al Processor Output Contract de RN174 CDE.
    NO altera la lógica interna de modelado ni fuerza entidades IFC.
    """

    def __init__(
        self,
        file_registry_id: str,
        source_sha256: str,
        processor_id: str = "PROCESSOR_CAD",
        processor_version: str = "0.5.2",
        requested_operation: str = "CAD_SEMANTIC_RECONSTRUCTION",
        execution_mode: str = "CLI"
    ):
        self.file_registry_id = file_registry_id
        self.source_sha256 = source_sha256
        self.processor_id = processor_id
        self.processor_version = processor_version
        self.requested_operation = requested_operation
        self.execution_mode = execution_mode

    def build_processor_payload(
        self,
        pipeline_result: Dict[str, Any],
        output_dir: Path,
        processing_job_id: Optional[str] = None
    ) -> Dict[str, Any]:
        job_id = processing_job_id or str(uuid.uuid4())
        
        # 1. Recuperar resúmenes
        grouping_summary = pipeline_result.get("grouping_summary", {})
        candidates_summary = pipeline_result.get("object_candidates_summary", {})
        multiview_summary = pipeline_result.get("multiview_resolution_summary", {})
        geom_summary = pipeline_result.get("geometry_summary", {})
        
        total_canonical_entities = grouping_summary.get("canonical_entities", 0)
        total_primitives = grouping_summary.get("primitive_evidence", 0)
        total_groups = grouping_summary.get("local_geometry_groups", 0)
        total_motifs = grouping_summary.get("geometric_motifs", 0)
        total_candidates = grouping_summary.get("object_candidates", 0)
        total_hypotheses = multiview_summary.get("total_hypotheses", 0)
        built_count = geom_summary.get("built_count", 0)
        ifc_count = 0 # No se crea IFC en esta fase
        
        # 2. Determinar estado semántico del job
        # 0 BUILT / 0 IFC NO es FAILED; es COMPLETED_INSUFFICIENT_EVIDENCE
        if built_count == 0:
            job_status = "COMPLETED_INSUFFICIENT_EVIDENCE"
            warning_msg = (
                "El procesamiento CAD completó exitosamente la extracción semántica y el descubrimiento "
                "de candidatos e hipótesis, pero la documentación dimensional/geométrica fue insuficiente "
                "para consolidar sólidos volumétricos o exportar entidades IFC conformes a obra."
            )
            warnings = [warning_msg]
        else:
            job_status = "COMPLETED"
            warnings = []

        processing_summary = {
            "canonical_entities": total_canonical_entities,
            "primitive_evidence_count": total_primitives,
            "local_geometry_group_count": total_groups,
            "geometric_motif_count": total_motifs,
            "object_candidate_count": total_candidates,
            "object_hypothesis_count": total_hypotheses,
            "built_count": built_count,
            "ifc_count": ifc_count,
            "grouping_metrics": grouping_summary.get("metrics_by_source", {}),
            "promotion_reasons": grouping_summary.get("promotion_reasons", {}),
            "data_gaps_identified": [
                "ELEVACION_COTA",
                "SECCION_TRANSVERSAL_COMPLETA"
            ]
        }

        # 3. Mapeo de Artifacts
        artifacts: List[Dict[str, Any]] = []
        canonical_artifact_id = str(uuid.uuid4())
        
        ev_dir = output_dir / "evidence"
        ev_files = list(ev_dir.glob("*.json"))
        canonical_file_path = str(ev_files[0]) if ev_files else str(output_dir / "evidence" / "canonical_cad.json")
        
        artifacts.append({
            "artifact_id": canonical_artifact_id,
            "artifact_type": "CANONICAL_CAD_DOCUMENT",
            "artifact_format": "JSON",
            "artifact_name": Path(canonical_file_path).name,
            "artifact_sha256": None,
            "artifact_size_bytes": Path(canonical_file_path).stat().st_size if Path(canonical_file_path).exists() else 0,
            "storage_type": "LOCAL_FILESYSTEM",
            "storage_location": str(canonical_file_path),
            "relation_to_source": "NORMALIZED_FROM",
            "metadata": {
                "entity_count": total_canonical_entities,
                "provider": "GNU LibreDWG External CLI Provider"
            }
        })

        sem_dir = output_dir / "semantic"
        if (sem_dir / "object_hypotheses.json").exists():
            artifacts.append({
                "artifact_id": str(uuid.uuid4()),
                "artifact_type": "SEMANTIC_HYPOTHESIS_PACKAGE",
                "artifact_format": "JSON",
                "artifact_name": "object_hypotheses.json",
                "storage_type": "LOCAL_FILESYSTEM",
                "storage_location": str(sem_dir / "object_hypotheses.json"),
                "relation_to_source": "DERIVED_FROM",
                "metadata": {"hypothesis_count": total_hypotheses}
            })

        # 4. Mapeo de Evidencias (PrimitiveEvidence, Motifs, etc.)
        evidence_list: List[Dict[str, Any]] = []
        evidence_relations: List[Dict[str, Any]] = []
        
        cand_file = sem_dir / "object_candidates.json"
        candidates_data = []
        if cand_file.exists():
            with open(cand_file, "r", encoding="utf-8") as f:
                candidates_data = json.load(f)

        cand_evidence_map: Dict[str, str] = {}

        for c in candidates_data:
            c_id = c.get("candidate_id")
            prem_reason = c.get("promotion_reason", "UNKNOWN")
            signals = c.get("semantic_signals", [])
            primary_entity = c.get("primary_entity") or {}
            
            ev_id = str(uuid.uuid4())
            cand_evidence_map[c_id] = ev_id
            
            # Extraer handles de los signals geométricos
            handles = []
            if primary_entity.get("handle"):
                handles.append(primary_entity.get("handle"))
            for s in signals:
                if s.get("signal_type") == "GEOMETRIC_MOTIF" and s.get("entity_reference"):
                    handles.extend(s.get("entity_reference").split(","))
            
            handle_str = ",".join(list(dict.fromkeys(handles))) if handles else c.get("candidate_id")

            # Localizador documental detallado
            source_loc = {
                "source_id": c.get("source_id"),
                "handle": handle_str,
                "layer": primary_entity.get("layer") or c.get("probable_family") or "0",
                "space": "MODELSPACE",
                "promotion_reason": prem_reason,
                "member_primitive_count": c.get("member_primitive_count", 1)
            }
            
            text_signals = [s.get("value") for s in signals if s.get("signal_group") == "TEXTUAL" and s.get("value")]
            src_text = " | ".join(text_signals[:3]) if text_signals else None

            if prem_reason == "GEOMETRIC_MOTIF":
                ev_type = "CAD_PRIMITIVE"
                ev_subtype = "GEOMETRIC_MOTIF"
                ev_status = "DERIVED"
                derivation_method = "MOTIF_DETECTION"
                derivation_rule = c.get("type_rule_id")
            elif prem_reason == "CONNECTED_GROUP":
                ev_type = "CAD_PRIMITIVE"
                ev_subtype = "LOCAL_GEOMETRY_GROUP"
                ev_status = "DERIVED"
                derivation_method = "SPATIAL_CONNECTIVITY"
                derivation_rule = "ADAPTIVE_LOCAL_STATS"
            else:
                ev_type = "CAD_PRIMITIVE"
                ev_subtype = "METADATA_BLOCK"
                ev_status = "SOURCE"
                derivation_method = "DIRECT_EXTRACTION"
                derivation_rule = None

            evidence_list.append({
                "evidence_id": ev_id,
                "file_registry_id": self.file_registry_id,
                "artifact_id": canonical_artifact_id,
                "evidence_type": ev_type,
                "evidence_subtype": ev_subtype,
                "source_locator": source_loc,
                "source_text": src_text,
                "numeric_value": None,
                "numeric_unit": None,
                "evidence_status": ev_status,
                "confidence": round(float(c.get("final_confidence", 0.70)), 3),
                "derivation_method": derivation_method,
                "derivation_rule": derivation_rule,
                "review_status": "UNREVIEWED"
            })

        # 5. Mapeo de Object Hypotheses y Links
        hypotheses_list: List[Dict[str, Any]] = []
        links_list: List[Dict[str, Any]] = []
        
        hyp_file = sem_dir / "object_hypotheses.json"
        hypotheses_data = []
        if hyp_file.exists():
            with open(hyp_file, "r", encoding="utf-8") as f:
                hypotheses_data = json.load(f)

        for h in hypotheses_data:
            raw_h_id = h.get("hypothesis_id")
            h_uuid = str(uuid.uuid4())
            
            prob_family = h.get("probable_family", "INFRAESTRUCTURA_VIAL")
            prob_type = h.get("probable_type", "ELEMENTO_PEAJE")
            conf = round(float(h.get("confidence", 0.70)), 3)
            
            h_status = "SUPPORTED" if conf >= 0.75 else "CANDIDATE"
            
            hypotheses_list.append({
                "hypothesis_id": h_uuid,
                "hypothesis_type": prob_type,
                "object_class": prob_family,
                "object_subclass": h.get("resolution_status"),
                "status": h_status,
                "confidence": conf,
                "canonical_name": f"{prob_type} - {raw_h_id}",
                "description": h.get("notes") or f"Hipótesis consolidada por {self.processor_id}",
                "spatial_context": {
                    "original_modeler_id": raw_h_id,
                    "spatial_reference": h.get("spatial_reference", {}),
                    "data_gaps": h.get("data_gaps", []),
                    "unresolved_questions": h.get("unresolved_questions", [])
                },
                "linked_aim_asset_id": None,
                "created_by": "PROCESSOR"
            })

            for cand_id in h.get("member_candidate_ids", []):
                ev_linked_id = cand_evidence_map.get(cand_id)
                if ev_linked_id:
                    links_list.append({
                        "hypothesis_id": h_uuid,
                        "evidence_id": ev_linked_id,
                        "support_type": "SUPPORTS",
                        "weight": conf
                    })

        payload = {
            "processing_job": {
                "processing_job_id": job_id,
                "file_registry_id": self.file_registry_id,
                "processor_id": self.processor_id,
                "processor_version": self.processor_version,
                "requested_operation": self.requested_operation,
                "execution_mode": self.execution_mode,
                "status": job_status,
                "input_sha256": self.source_sha256,
                "processing_parameters": {
                    "mode": pipeline_result.get("mode", "AUDIT"),
                    "project_name": pipeline_result.get("project_name")
                },
                "processing_summary": processing_summary,
                "warning_count": len(warnings),
                "error_count": 0,
                "error_code": None,
                "error_message": None
            },
            "artifacts": artifacts,
            "evidence": evidence_list,
            "evidence_relations": evidence_relations,
            "object_hypotheses": hypotheses_list,
            "hypothesis_evidence_links": links_list,
            "warnings": warnings,
            "errors": []
        }

        return payload
