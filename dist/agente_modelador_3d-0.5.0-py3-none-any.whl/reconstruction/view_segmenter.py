from __future__ import annotations

import math
from typing import Any

from core.models import (
    SourceDocument,
    SourceReference,
    ViewEvidence,
)


class ViewSegmenter:
    """
    Segmentador espacial de vistas dentro de un plano CAD o PDF.

    Responsabilidad:
    Detectar regiones gráficas discretas dentro del plano para evitar que
    todas las entidades del archivo se asignen indiscriminadamente a todas las vistas.

    Principios:
    1. Proximidad espacial entre textos, cotas y geometría.
    2. Agrupamiento por bounding boxes y distancia.
    3. Títulos de vista próximos a una región gráfica.
    4. Conservar referencias a entidades en lugar de duplicar geometría pesada.
    5. Si no puede segmentarse de manera fiable: view_type=UNKNOWN, detection_method=UNRESOLVED.
    """

    def segment_document(
        self,
        document: SourceDocument,
        lexical_views: list[ViewEvidence],
    ) -> list[ViewEvidence]:
        """
        Segmenta espacialmente el documento combinando evidencia léxica y geométrica.
        """
        if document.file_type in {"DXF", "DWG"}:
            return self._segment_cad(document, lexical_views)

        if document.file_type == "PDF":
            return self._segment_pdf(document, lexical_views)

        return lexical_views

    def _segment_cad(
        self,
        document: SourceDocument,
        lexical_views: list[ViewEvidence],
    ) -> list[ViewEvidence]:
        """
        Segmenta un archivo CAD agrupando entidades por cercanía espacial o por título.
        """
        entities = document.extracted_data.get("entities", [])
        texts = document.extracted_data.get("texts", [])

        if not entities:
            return lexical_views

        # Calcular bounding boxes de entidades que tienen coordenadas
        entity_boxes: list[tuple[dict[str, Any], dict[str, float]]] = []
        for entity in entities:
            box = self._compute_cad_entity_bbox(entity)
            if box:
                entity_boxes.append((entity, box))

        if not entity_boxes:
            return lexical_views

        # Si hay títulos léxicos de vista específicos identificados, asociamos clusters espaciales
        # Si no hay clusters dispersos, generamos una vista con el bounding box global
        clusters = self._cluster_bboxes([b for _, b in entity_boxes], max_gap=150.0)

        # Si solo hay 1 cluster o no se puede separar limpiamente:
        if len(clusters) <= 1:
            global_box = self._merge_bboxes([b for _, b in entity_boxes])
            segmented_views: list[ViewEvidence] = []
            
            # Asignar a cada vista léxica su bounding box y entity_references (handles)
            all_handles = [
                str(e.get("handle")) for e in entities if e.get("handle")
            ]
            
            for v in lexical_views:
                v.bounding_box = global_box
                v.detection_method = "GLOBAL_CAD_BOUNDS"
                v.entity_references = all_handles
                # Para evitar duplicar modelspace pesado, dejamos el resumen liviano
                v.geometry = {
                    "bbox": global_box,
                    "entity_count": len(entities),
                }
                segmented_views.append(v)
            return segmented_views

        # Si hay múltiples clusters espaciales discernibles:
        segmented_views = []
        for cluster_idx, cluster_box in enumerate(clusters):
            # Identificar entidades dentro de este cluster
            contained_entities = []
            contained_handles = []
            contained_texts = []

            for ent, box in entity_boxes:
                if self._box_inside_or_intersects(box, cluster_box):
                    contained_entities.append(ent)
                    if ent.get("handle"):
                        contained_handles.append(str(ent["handle"]))
                    if ent.get("entity_type") in {"TEXT", "MTEXT"} and ent.get("text"):
                        contained_texts.append(str(ent["text"]))

            # Determinar tipo de vista a partir de los textos contenidos en la región
            cluster_text_str = " ".join(contained_texts).upper()
            assigned_type = "UNKNOWN"
            conf = 0.40

            if any(k in cluster_text_str for k in ["PLANTA", "PLAN"]):
                assigned_type = "PLAN"
                conf = 0.70
            elif any(k in cluster_text_str for k in ["SECCION", "SECCIÓN", "CORTE", "SECTION"]):
                assigned_type = "SECTION"
                conf = 0.70
            elif any(k in cluster_text_str for k in ["PERFIL", "PROFILE"]):
                assigned_type = "PROFILE"
                conf = 0.70
            elif any(k in cluster_text_str for k in ["DETALLE", "DETAIL"]):
                assigned_type = "DETAIL"
                conf = 0.70

            view_id = f"{document.path.name}:region:{cluster_idx}:{assigned_type}"

            view = ViewEvidence(
                view_id=view_id,
                view_type=assigned_type,
                source=SourceReference(
                    source_file=str(document.path),
                    source_type=document.file_type,
                    view=assigned_type,
                ),
                bounding_box=cluster_box,
                detection_method="SPATIAL_CLUSTER_BBOX",
                geometry={
                    "bbox": cluster_box,
                    "entity_count": len(contained_entities),
                },
                entity_references=contained_handles,
                texts=contained_texts,
                confidence=conf,
            )
            segmented_views.append(view)

        return segmented_views

    def _segment_pdf(
        self,
        document: SourceDocument,
        lexical_views: list[ViewEvidence],
    ) -> list[ViewEvidence]:
        """
        Segmenta páginas PDF asociando bounding boxes de página y regiones vectoriales.
        """
        pages = document.extracted_data.get("pages", [])
        if not pages:
            return lexical_views

        segmented_views: list[ViewEvidence] = []

        for page in pages:
            pn = page.get("page_number", 1)
            pw = page.get("width", 0.0)
            ph = page.get("height", 0.0)
            page_bbox = {"minx": 0.0, "miny": 0.0, "maxx": float(pw), "maxy": float(ph)}

            # Buscar la vista léxica correspondiente a esta página si existe
            matching_lex = [
                v for v in lexical_views
                if v.source.sheet == str(pn)
            ]

            v_type = matching_lex[0].view_type if matching_lex else "UNKNOWN"
            conf = matching_lex[0].confidence if matching_lex else 0.20

            # Guardar referencia liviana (evitar clonar 4500 primitivas en cada vista)
            drawings_count = len(page.get("drawings", []))

            view_id = f"{document.path.name}:page:{pn}:{v_type}"
            view = ViewEvidence(
                view_id=view_id,
                view_type=v_type,
                source=SourceReference(
                    source_file=str(document.path),
                    source_type="PDF",
                    sheet=str(pn),
                    view=v_type,
                ),
                bounding_box=page_bbox,
                detection_method="PAGE_BOUNDS_AND_VECTORS",
                geometry={
                    "page_number": pn,
                    "page_width": pw,
                    "page_height": ph,
                    "drawings_count": drawings_count,
                },
                texts=[
                    w.get("text", "")
                    for w in page.get("words", [])
                    if w.get("text")
                ],
                confidence=conf,
            )
            segmented_views.append(view)

        return segmented_views

    def _compute_cad_entity_bbox(self, entity: dict[str, Any]) -> dict[str, float] | None:
        """Calcula bounding box 2D de una entidad CAD."""
        etype = entity.get("entity_type")

        if etype == "LINE":
            s, e = entity.get("start", {}), entity.get("end", {})
            return {
                "minx": min(s.get("x", 0.0), e.get("x", 0.0)),
                "miny": min(s.get("y", 0.0), e.get("y", 0.0)),
                "maxx": max(s.get("x", 0.0), e.get("x", 0.0)),
                "maxy": max(s.get("y", 0.0), e.get("y", 0.0)),
            }

        if etype in {"LWPOLYLINE", "POLYLINE"}:
            pts = entity.get("points", [])
            if not pts:
                return None
            xs = [p.get("x", 0.0) for p in pts]
            ys = [p.get("y", 0.0) for p in pts]
            return {
                "minx": min(xs),
                "miny": min(ys),
                "maxx": max(xs),
                "maxy": max(ys),
            }

        if etype in {"CIRCLE", "ARC"}:
            c = entity.get("center", {})
            r = entity.get("radius", 0.0)
            cx, cy = c.get("x", 0.0), c.get("y", 0.0)
            return {
                "minx": cx - r,
                "miny": cy - r,
                "maxx": cx + r,
                "maxy": cy + r,
            }

        if etype in {"TEXT", "MTEXT", "INSERT", "POINT"}:
            loc = entity.get("insert") or entity.get("location") or {}
            x, y = loc.get("x", 0.0), loc.get("y", 0.0)
            return {
                "minx": x,
                "miny": y,
                "maxx": x,
                "maxy": y,
            }

        return None

    def _merge_bboxes(self, boxes: list[dict[str, float]]) -> dict[str, float]:
        if not boxes:
            return {"minx": 0.0, "miny": 0.0, "maxx": 0.0, "maxy": 0.0}
        return {
            "minx": min(b["minx"] for b in boxes),
            "miny": min(b["miny"] for b in boxes),
            "maxx": max(b["maxx"] for b in boxes),
            "maxy": max(b["maxy"] for b in boxes),
        }

    def _cluster_bboxes(
        self,
        boxes: list[dict[str, float]],
        max_gap: float = 150.0,
    ) -> list[dict[str, float]]:
        """
        Agrupa cajas que estén a una distancia menor a max_gap.
        """
        if not boxes:
            return []

        clusters: list[list[dict[str, float]]] = []

        for b in boxes:
            assigned = False
            for c in clusters:
                merged = self._merge_bboxes(c)
                # Distancia entre merged y b
                dx = max(0.0, max(merged["minx"] - b["maxx"], b["minx"] - merged["maxx"]))
                dy = max(0.0, max(merged["miny"] - b["maxy"], b["miny"] - merged["maxy"]))
                dist = math.sqrt(dx * dx + dy * dy)
                if dist <= max_gap:
                    c.append(b)
                    assigned = True
                    break
            if not assigned:
                clusters.append([b])

        return [self._merge_bboxes(c) for c in clusters]

    def _box_inside_or_intersects(
        self,
        inner: dict[str, float],
        outer: dict[str, float],
        tol: float = 1.0,
    ) -> bool:
        return not (
            inner["maxx"] < outer["minx"] - tol
            or inner["minx"] > outer["maxx"] + tol
            or inner["maxy"] < outer["miny"] - tol
            or inner["miny"] > outer["maxy"] + tol
        )
