from __future__ import annotations

import hashlib
from typing import Any
from core.models import (
    DataGap,
    EvidenceStatus,
    GeometryRecipe,
    ParameterValue,
    QualityConfidenceLevel,
    RecipeType,
    ReconstructedObject,
)
from reconstruction.geometry_parameter_resolver import GeometryParameterResolver
from reconstruction.local_frame_resolver import LocalFrameResolver


class GeometricRecipeResolver:
    """
    Infiere y formula la receta geométrica 3D paramétrica (GeometryRecipe) exclusivamente
    a partir de evidencias paramétricas y vistas resueltas.
    
    REGLA:
    Prohibido inventar dimensiones no documentadas (alturas, espesores, radios o profundidades).
    Si falta una dimensión crítica requerida por la receta, la receta se marca con
    unresolved_parameters y se genera un DataGap explícito.
    """

    def __init__(self, param_resolver: GeometryParameterResolver | None = None) -> None:
        self.param_resolver = param_resolver or GeometryParameterResolver(mode="STRICT")

    def resolve_recipe(
        self,
        obj: ReconstructedObject,
    ) -> tuple[GeometryRecipe, list[DataGap]]:
        """
        Deduce la receta geométrica para un ReconstructedObject.
        """
        data_gaps: list[DataGap] = []

        # 1. Evaluar elegibilidad de parámetros
        eligible_params, evaluations = self.param_resolver.filter_eligible_parameters(
            parameters=obj.parameters,
            conflicts=obj.conflicts,
        )

        # 2. LocalFrame del objeto
        local_frame = LocalFrameResolver.resolve_local_frame(obj)
        frame_dict = LocalFrameResolver.frame_to_dict(local_frame)

        # 3. Detectar indicios de forma a partir de vistas, tipo o nombres de parámetros
        # Extraer parámetros normalizados
        param_names = set(eligible_params.keys())
        all_param_names = set(obj.parameters.keys())

        # Buscar dimensiones típicas
        radius = self._extract_param_value(eligible_params, ["RADIO", "RADIUS", "R"])
        diameter = self._extract_param_value(eligible_params, ["DIAMETRO", "DIAMETER", "DIAM"])
        if radius is None and diameter is not None:
            radius = diameter / 2.0

        width = self._extract_param_value(eligible_params, ["ANCHO", "WIDTH", "BASE", "B"])
        length = self._extract_param_value(eligible_params, ["LONGITUD", "LENGTH", "LARGO", "L"])
        height = self._extract_param_value(eligible_params, ["ALTURA", "HEIGHT", "ALTO", "H", "PROFUNDIDAD", "DEPTH"])
        thickness = self._extract_param_value(eligible_params, ["ESPESOR", "THICKNESS", "E"])

        recipe_type = RecipeType.UNKNOWN
        required_params: list[str] = []
        source_params: dict[str, Any] = {}
        unresolved: list[str] = []
        profile_def: dict[str, Any] = {}

        # Determinar si es extrusión circular
        if radius is not None or diameter is not None:
            recipe_type = RecipeType.CIRCULAR_EXTRUSION
            required_params = ["RADIO", "ALTURA"]
            source_params["RADIO"] = radius

            if height is not None:
                source_params["ALTURA"] = height
            elif length is not None:
                source_params["ALTURA"] = length
            else:
                unresolved.append("ALTURA")
                data_gaps.append(
                    DataGap(
                        object_id=obj.object_id,
                        parameter="ALTURA",
                        description=f"Extrusión circular requiere altura/longitud documentada para el objeto {obj.object_id}",
                        criticality="HIGH",
                    )
                )

            profile_def = {
                "shape": "CIRCLE",
                "radius": radius,
            }

        # Determinar si es extrusión rectangular / prismática
        elif width is not None or (thickness is not None and length is not None):
            recipe_type = RecipeType.RECTANGULAR_EXTRUSION
            required_params = ["ANCHO", "LONGITUD", "ESPESOR"]

            if width is not None:
                source_params["ANCHO"] = width
            else:
                unresolved.append("ANCHO")
                data_gaps.append(DataGap(object_id=obj.object_id, parameter="ANCHO", description="Falta ancho documentado", criticality="HIGH"))

            if length is not None:
                source_params["LONGITUD"] = length
            elif height is not None and thickness is not None:
                source_params["LONGITUD"] = height
            else:
                unresolved.append("LONGITUD")
                data_gaps.append(DataGap(object_id=obj.object_id, parameter="LONGITUD", description="Falta longitud documentada", criticality="HIGH"))

            if thickness is not None:
                source_params["ESPESOR"] = thickness
            elif height is not None and length is not None:
                source_params["ESPESOR"] = height
            else:
                unresolved.append("ESPESOR")
                data_gaps.append(DataGap(object_id=obj.object_id, parameter="ESPESOR", description="Falta espesor documentado", criticality="HIGH"))

            profile_def = {
                "shape": "RECTANGLE",
                "width": source_params.get("ANCHO"),
                "height": source_params.get("ESPESOR"),
            }

        else:
            # No hay indicios suficientes
            recipe_type = RecipeType.UNKNOWN
            unresolved.append("GEOMETRIC_PROFILE")
            data_gaps.append(
                DataGap(
                    object_id=obj.object_id,
                    parameter="GEOMETRIC_PROFILE",
                    description=f"Sin parámetros suficientes para formular receta 3D en {obj.object_id}",
                    criticality="HIGH",
                )
            )

        # Determinar evidence_status y confianza de la receta
        if unresolved:
            geom_conf = QualityConfidenceLevel.NOT_EVALUATED
            ev_status = EvidenceStatus.UNKNOWN
        else:
            # Verificar estados de los parámetros utilizados
            statuses = [
                obj.parameters[p].status
                for p in required_params
                if p in obj.parameters
            ]
            if not statuses:
                ev_status = EvidenceStatus.UNKNOWN
                geom_conf = QualityConfidenceLevel.NOT_EVALUATED
            elif all(s == EvidenceStatus.DOCUMENTED for s in statuses):
                ev_status = EvidenceStatus.DOCUMENTED
                geom_conf = QualityConfidenceLevel.HIGH
            elif all(s in {EvidenceStatus.DOCUMENTED, EvidenceStatus.DERIVED, EvidenceStatus.INTERPOLATED} for s in statuses):
                ev_status = EvidenceStatus.DERIVED
                geom_conf = QualityConfidenceLevel.HIGH
            elif any(s in {EvidenceStatus.INFERRED, EvidenceStatus.PROVISIONAL} for s in statuses):
                ev_status = EvidenceStatus.INFERRED
                geom_conf = QualityConfidenceLevel.LOW
            else:
                ev_status = EvidenceStatus.UNKNOWN
                geom_conf = QualityConfidenceLevel.LOW

        recipe_id = f"recipe_{hashlib.sha256((obj.object_id + recipe_type.value).encode('utf-8')).hexdigest()[:8]}"

        recipe = GeometryRecipe(
            recipe_id=recipe_id,
            object_id=obj.object_id,
            recipe_type=recipe_type,
            required_parameters=required_params,
            source_parameters=source_params,
            local_frame=frame_dict,
            profile_definition=profile_def,
            evidence_status=ev_status,
            geometry_confidence=geom_conf,
            unresolved_parameters=unresolved,
            validation_rules=["RULE_DIMENSION_VERIFICATION", "RULE_FRAME_ORTHONORMALITY"],
            notes=f"Receta {recipe_type.value} para objeto {obj.object_id}",
        )

        return recipe, data_gaps

    def _extract_param_value(
        self,
        params: dict[str, ParameterValue],
        synonyms: list[str],
    ) -> float | None:
        """
        Busca un valor numérico entre una lista de nombres o sinónimos.
        Garantiza comparación de palabras completas para evitar que una letra
        como 'R' coincida erróneamente con 'PROGRESIVA_EJE'.
        """
        import re
        syn_patterns = [rf"(^|_){re.escape(syn.upper())}(_|$)" for syn in synonyms]

        for syn_pat in syn_patterns:
            for name, p in params.items():
                uname = name.upper()
                if re.search(syn_pat, uname):
                    if isinstance(p.value, (int, float)):
                        return float(p.value)
        return None
