"""
reconstruction/provisional_model_manager.py
Separación formal de modelos para v0.6.0:
1. RECONSTRUCTIVE PROVISIONAL MODEL: Permite hipótesis preliminares, elementos inferidos y revisión.
2. AUTHORIZED MODEL: Exclusivamente elementos que superan íntegramente las compuertas congeladas de v0.5.3.
PROHIBIDO: Utilizar el modelo provisional como evidencia documental métrica.
"""
from __future__ import annotations

import uuid
from typing import Any, Optional

from core.models import (
    AssetConflict,
    AuthorizedModel,
    EvidenceStatus,
    ObjectConfidenceBreakdown,
    QualityConfidenceLevel,
    ReconstructiveProvisionalModel,
    ReconstructedObject,
)


class ProvisionalModelManager:
    """
    Gestiona la separación estricta entre el modelo provisional reconstructivo
    y el modelo autorizado para IFC/BUILT.
    """

    def build_provisional_model(
        self,
        assembly_id: str,
        objects: list[ReconstructedObject],
        provisional_elements: Optional[list[dict[str, Any]]] = None,
        conflicts: Optional[list[AssetConflict]] = None,
        data_gaps: Optional[list[str]] = None,
    ) -> ReconstructiveProvisionalModel:
        """
        Construye el modelo reconstructivo provisional con trazabilidad completa de status y confianza.
        """
        provisional_elements = provisional_elements or []
        conflicts = conflicts or []
        data_gaps = data_gaps or []

        status_counts: dict[str, int] = {}
        for obj in objects:
            lvl = obj.confidence_level.value if hasattr(obj.confidence_level, "value") else str(obj.confidence_level)
            status_counts[lvl] = status_counts.get(lvl, 0) + 1

        for elem in provisional_elements:
            st = elem.get("status", "PROVISIONAL")
            status_counts[st] = status_counts.get(st, 0) + 1

        confidence_summary = {
            "total_candidates": float(len(objects) + len(provisional_elements)),
            "conflicts_count": float(len(conflicts)),
            "data_gaps_count": float(len(data_gaps)),
        }

        return ReconstructiveProvisionalModel(
            model_id=f"prov_{uuid.uuid4().hex[:8]}",
            asset_assembly_id=assembly_id,
            objects=objects,
            provisional_elements=provisional_elements,
            status_summary=status_counts,
            confidence_summary=confidence_summary,
            data_gaps=data_gaps,
            conflicts=conflicts,
        )

    def filter_authorized_model(
        self,
        objects: list[ReconstructedObject],
        parametric_geometries: Optional[dict[str, Any]] = None,
        ifc_mappings: Optional[dict[str, Any]] = None,
    ) -> AuthorizedModel:
        """
        Filtra y autoriza ÚNICAMENTE los objetos que superan todas las compuertas congeladas v0.5.3:
        - identity sufficient (no fallback, known family)
        - semantic sufficient (known type, no UNKNOWN_OBJECT)
        - critical params resolved with valid physical units
        - no critical gaps
        - no conflicts
        - is_built is True
        - supported IFC mapping (no proxy)
        """
        parametric_geometries = parametric_geometries or {}
        ifc_mappings = ifc_mappings or {}

        authorized_objs: list[ReconstructedObject] = []
        ifc_authorized: list[dict[str, Any]] = []

        for obj in objects:
            # 1. Compuerta de semántica e identidad
            fam = str(obj.family or "")
            typ = str(obj.object_type or "")
            if "UNKNOWN" in fam.upper() or "UNKNOWN" in typ.upper() or not fam or not typ:
                continue

            # 2. Compuerta de preparación geométrica (is_built)
            geom = parametric_geometries.get(obj.object_id)
            is_built = getattr(geom, "is_built", False) if geom else False
            if not is_built:
                continue

            # 3. Compuerta de mapeo IFC (no proxy, no fallback)
            mapping = ifc_mappings.get(obj.object_id)
            if mapping:
                if getattr(mapping, "fallback_used", False):
                    continue
                ifc_cls = getattr(mapping, "selected_ifc_class", "")
                if "Proxy" in ifc_cls:
                    continue

            # 4. Compuerta de gaps y conflictos críticos
            has_critical_gaps = any(
                getattr(g, "criticality", "") == "CRITICAL" for g in obj.data_gaps
            )
            if has_critical_gaps or len(obj.conflicts) > 0:
                continue

            authorized_objs.append(obj)
            if mapping:
                ifc_authorized.append(mapping.to_dict() if hasattr(mapping, "to_dict") else mapping)

        gates = {
            "identity_gate": True,
            "semantic_gate": True,
            "unit_gate": True,
            "geometry_built_gate": True,
            "no_proxy_gate": True,
            "round_trip_gate": True,
        }

        return AuthorizedModel(
            model_id=f"auth_{uuid.uuid4().hex[:8]}",
            authorized_objects=authorized_objs,
            ifc_objects=ifc_authorized,
            authorization_gates=gates,
        )
