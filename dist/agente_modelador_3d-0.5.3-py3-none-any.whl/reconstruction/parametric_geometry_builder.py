from __future__ import annotations

import hashlib
import math
from typing import Any
from core.geometry_kernel import (
    LocalFrame,
    Point3D,
    Vector3D,
    add_vector,
)
from core.models import (
    DataGap,
    DocumentConflict,
    GeometryRecipe,
    ParametricGeometry,
    QualityConfidenceLevel,
    RecipeType,
    ReconstructedObject,
    SemanticFamily,
    UnitResolutionStatus,
)


class ParametricGeometryBuilder:
    """
    Motor de generación paramétrica de sólidos 3D trazables.
    
    Responsabilidad:
    - Evaluar la compuerta integral BUILT AUTHORIZATION GATE (Criterios A a J).
    - Prohibir terminantemente la autorización de BUILT ante identidad insuficiente,
      semántica UNKNOWN, DataGaps críticos, unidades físicas no resueltas o conflictos.
    - Construir representaciones paramétricas cerradas (vértices, caras, bounding box, volumen)
      únicamente para candidatos formalmente elegibles.
    """

    def build_geometry(
        self,
        obj: ReconstructedObject,
        recipe: GeometryRecipe,
        gaps: list[DataGap] | None = None,
    ) -> ParametricGeometry:
        """
        Construye el sólido paramétrico a partir de la receta y valida su completitud.
        """
        geom_id = f"geom_{hashlib.sha256((obj.object_id + recipe.recipe_id).encode('utf-8')).hexdigest()[:8]}"

        def make_failure(reason: str, extra_conflicts=None, extra_gaps=None) -> ParametricGeometry:
            return ParametricGeometry(
                geometry_id=geom_id,
                object_id=obj.object_id,
                recipe_id=recipe.recipe_id,
                geometry_type=recipe.recipe_type,
                is_built=False,
                build_failure_reason=reason,
                conflicts=extra_conflicts or [],
                data_gaps=extra_gaps or [],
                geometry_confidence=QualityConfidenceLevel.NOT_EVALUATED,
            )

        # -------------------------------------------------------------
        # BUILT AUTHORIZATION GATE (Criterios A a I)
        # -------------------------------------------------------------
        # Criterio G: Sin conflictos documentales críticos sin resolver
        if obj.conflicts:
            unresolved_conflicts = [c for c in obj.conflicts if c.resolution != "RESOLVED"]
            if unresolved_conflicts:
                return make_failure("DOCUMENT_CONFLICT_UNRESOLVED", extra_conflicts=[c.to_dict() for c in unresolved_conflicts])

        # Criterio E: Parámetros requeridos por la receta resueltos
        if recipe.unresolved_parameters:
            return make_failure(f"MISSING_REQUIRED_PARAMETERS: {', '.join(recipe.unresolved_parameters)}", extra_gaps=[g.to_dict() for g in (gaps or [])])

        # Criterio A: Identidad suficiente (LOW bloquea BUILT)
        if obj.confidence_breakdown and obj.confidence_breakdown.identity_confidence == QualityConfidenceLevel.LOW:
            return make_failure("INSUFFICIENT_IDENTITY")

        # Criterio B: Semántica suficiente (LOW bloquea BUILT)
        if obj.confidence_breakdown and obj.confidence_breakdown.semantic_confidence == QualityConfidenceLevel.LOW:
            return make_failure("INSUFFICIENT_SEMANTICS")

        # Criterio C: object_type != UNKNOWN_OBJECT
        type_str = str(obj.object_type or "").upper().strip()
        if type_str in {"UNKNOWN_OBJECT", "UNKNOWN"} or type_str.startswith("UNKNOWN_"):
            return make_failure("INSUFFICIENT_SEMANTICS: UNKNOWN_OBJECT")

        # Criterio D: family != UNKNOWN
        fam_str = str(obj.family or "").upper().strip()
        if fam_str in {"UNKNOWN", SemanticFamily.UNKNOWN.value}:
            return make_failure("INSUFFICIENT_SEMANTICS: UNKNOWN_FAMILY")

        # Criterio H: Sin DataGap crítico
        all_gaps = (obj.data_gaps or []) + (gaps or [])
        critical_gaps = [
            g for g in all_gaps
            if getattr(g, "gap_category", "") in {"CRITICAL_FOR_IDENTITY", "CRITICAL_FOR_SEMANTICS", "CRITICAL_FOR_GEOMETRY"}
            or getattr(g, "criticality", "") == "HIGH"
        ]
        if critical_gaps:
            return make_failure(f"CRITICAL_DATA_GAP: {critical_gaps[0].parameter}", extra_gaps=[g.to_dict() for g in all_gaps])

        # Criterio F: Unidades resueltas para parámetros geométricos críticos
        for req_p in recipe.required_parameters:
            p_obj = obj.parameters.get(req_p)
            if not p_obj and req_p == "RADIO":
                p_obj = obj.parameters.get("DIAMETRO")
            elif not p_obj and req_p == "ALTURA":
                p_obj = obj.parameters.get("LONGITUD")
            elif not p_obj and req_p == "LONGITUD":
                p_obj = obj.parameters.get("ALTURA")

            if not p_obj or p_obj.value is None:
                return make_failure(f"MISSING_REQUIRED_PARAMETERS: {req_p}")

            u_status = getattr(p_obj, "unit_resolution_status", None)
            if (
                p_obj.unit == "CAD_UNIT"
                or u_status in {UnitResolutionStatus.UNIT_UNRESOLVED, UnitResolutionStatus.UNIT_SCALE_HYPOTHESIS}
            ):
                return make_failure(f"UNIT_UNRESOLVED: {req_p}")

        # Criterio I: Tipo de receta geométrica soportada
        if recipe.recipe_type == RecipeType.RECTANGULAR_EXTRUSION:
            return self._build_rectangular_extrusion(obj, recipe, geom_id)
        elif recipe.recipe_type == RecipeType.CIRCULAR_EXTRUSION:
            return self._build_circular_extrusion(obj, recipe, geom_id)
        else:
            return make_failure(f"UNSUPPORTED_OR_UNKNOWN_RECIPE_TYPE: {recipe.recipe_type.value}")

    def _build_rectangular_extrusion(
        self,
        obj: ReconstructedObject,
        recipe: GeometryRecipe,
        geom_id: str,
    ) -> ParametricGeometry:
        """
        Construye un prisma rectangular 3D paramétrico a partir de ancho, espesor/alto y longitud.
        """
        w = float(recipe.source_parameters.get("ANCHO", 0.0))
        h = float(recipe.source_parameters.get("ESPESOR", 0.0) or recipe.source_parameters.get("ALTURA", 0.0))
        length = float(recipe.source_parameters.get("LONGITUD", 0.0))

        if w <= 0.0 or h <= 0.0 or length <= 0.0:
            return ParametricGeometry(
                geometry_id=geom_id,
                object_id=obj.object_id,
                recipe_id=recipe.recipe_id,
                geometry_type=recipe.recipe_type,
                is_built=False,
                build_failure_reason="INVALID_DIMENSIONS_ZERO_OR_NEGATIVE",
                geometry_confidence=QualityConfidenceLevel.NOT_EVALUATED,
            )

        # Marco local
        lf_dict = recipe.local_frame or {}
        orig = lf_dict.get("origin", (0.0, 0.0, 0.0))
        p_orig = Point3D(orig[0], orig[1], orig[2])

        # Vértices del prisma rectangular centrado transversalmente [-w/2, w/2], [0, h], [0, length]
        # o alineado al sistema local
        hw = w / 2.0
        # 8 vértices en coordenadas locales transformadas al origen
        # Base inicial (u=0)
        v0 = [p_orig.x, p_orig.y - hw, p_orig.z]
        v1 = [p_orig.x, p_orig.y + hw, p_orig.z]
        v2 = [p_orig.x, p_orig.y + hw, p_orig.z + h]
        v3 = [p_orig.x, p_orig.y - hw, p_orig.z + h]
        # Base final (extruida a lo largo de X longitud)
        v4 = [p_orig.x + length, p_orig.y - hw, p_orig.z]
        v5 = [p_orig.x + length, p_orig.y + hw, p_orig.z]
        v6 = [p_orig.x + length, p_orig.y + hw, p_orig.z + h]
        v7 = [p_orig.x + length, p_orig.y - hw, p_orig.z + h]

        vertices = [v0, v1, v2, v3, v4, v5, v6, v7]

        # 6 caras cuadrangulares
        faces = [
            [0, 3, 2, 1],  # Tapa inicio
            [4, 5, 6, 7],  # Tapa fin
            [0, 1, 5, 4],  # Cara inferior
            [2, 3, 7, 6],  # Cara superior
            [0, 4, 7, 3],  # Cara lateral izquierda
            [1, 2, 6, 5],  # Cara lateral derecha
        ]

        vol = round(w * h * length, 4)
        area = round(2 * (w * h + w * length + h * length), 4)

        all_x = [v[0] for v in vertices]
        all_y = [v[1] for v in vertices]
        all_z = [v[2] for v in vertices]

        bbox = {
            "minx": min(all_x),
            "maxx": max(all_x),
            "miny": min(all_y),
            "maxy": max(all_y),
            "minz": min(all_z),
            "maxz": max(all_z),
        }

        return ParametricGeometry(
            geometry_id=geom_id,
            object_id=obj.object_id,
            recipe_id=recipe.recipe_id,
            geometry_type=recipe.recipe_type,
            parameters={"ANCHO": w, "ESPESOR": h, "LONGITUD": length},
            local_frame=recipe.local_frame,
            vertices=vertices,
            faces=faces,
            bounding_box=bbox,
            volume=vol,
            surface_area=area,
            source_traceability=[{"source": s} for s in obj.source_documents],
            geometry_confidence=recipe.geometry_confidence,
            is_built=True,
        )

    def _build_circular_extrusion(
        self,
        obj: ReconstructedObject,
        recipe: GeometryRecipe,
        geom_id: str,
        num_segments: int = 16,
    ) -> ParametricGeometry:
        """
        Construye un cilindro paramétrico a partir de radio y altura (longitud).
        """
        r = float(recipe.source_parameters.get("RADIO", 0.0))
        h = float(recipe.source_parameters.get("ALTURA", 0.0))

        if r <= 0.0 or h <= 0.0:
            return ParametricGeometry(
                geometry_id=geom_id,
                object_id=obj.object_id,
                recipe_id=recipe.recipe_id,
                geometry_type=recipe.recipe_type,
                is_built=False,
                build_failure_reason="INVALID_DIMENSIONS_ZERO_OR_NEGATIVE",
                geometry_confidence=QualityConfidenceLevel.NOT_EVALUATED,
            )

        lf_dict = recipe.local_frame or {}
        orig = lf_dict.get("origin", (0.0, 0.0, 0.0))
        p_orig = Point3D(orig[0], orig[1], orig[2])

        # Vértices de la base inferior y superior
        # Extrusión a lo largo del eje Z del local frame
        vertices: list[list[float]] = []
        for i in range(num_segments):
            theta = 2.0 * math.pi * i / num_segments
            vx = p_orig.x + r * math.cos(theta)
            vy = p_orig.y + r * math.sin(theta)
            vz = p_orig.z
            vertices.append([round(vx, 4), round(vy, 4), round(vz, 4)])

        for i in range(num_segments):
            theta = 2.0 * math.pi * i / num_segments
            vx = p_orig.x + r * math.cos(theta)
            vy = p_orig.y + r * math.sin(theta)
            vz = p_orig.z + h
            vertices.append([round(vx, 4), round(vy, 4), round(vz, 4)])

        # Caras laterales
        faces: list[list[int]] = []
        for i in range(num_segments):
            next_i = (i + 1) % num_segments
            faces.append([i, next_i, next_i + num_segments, i + num_segments])

        # Tapas circulares aproximadas por polígonos
        faces.append(list(range(num_segments - 1, -1, -1)))
        faces.append(list(range(num_segments, 2 * num_segments)))

        vol = round(math.pi * (r ** 2) * h, 4)
        area = round(2.0 * math.pi * r * h + 2.0 * math.pi * (r ** 2), 4)

        all_x = [v[0] for v in vertices]
        all_y = [v[1] for v in vertices]
        all_z = [v[2] for v in vertices]

        bbox = {
            "minx": min(all_x),
            "maxx": max(all_x),
            "miny": min(all_y),
            "maxy": max(all_y),
            "minz": min(all_z),
            "maxz": max(all_z),
        }

        return ParametricGeometry(
            geometry_id=geom_id,
            object_id=obj.object_id,
            recipe_id=recipe.recipe_id,
            geometry_type=recipe.recipe_type,
            parameters={"RADIO": r, "ALTURA": h},
            local_frame=recipe.local_frame,
            vertices=vertices,
            faces=faces,
            bounding_box=bbox,
            volume=vol,
            surface_area=area,
            source_traceability=[{"source": s} for s in obj.source_documents],
            geometry_confidence=recipe.geometry_confidence,
            is_built=True,
        )
