"""
Motor de reconstrucción documental y geométrica.

Esta capa transforma evidencia extraída de las fuentes en:

- vistas;
- parámetros;
- relaciones;
- objetos reconstruidos;
- definiciones geométricas.

Regla fundamental:

2D -> SIGNIFICADO -> OBJETO -> PARAMETROS
-> RELACIONES -> 3D -> IFC 4.3

Nunca:

LINEA 2D -> SOLIDO ARBITRARIO
"""

from reconstruction.view_classifier import ViewClassifier
from reconstruction.view_segmenter import ViewSegmenter
from reconstruction.parameter_extractor import ParameterExtractor
from reconstruction.semantic_signal_extractor import SemanticSignalExtractor
from reconstruction.object_candidate_detector import (
    ObjectCandidateDetector,
    compute_candidate_confidence,
)
from reconstruction.reference_resolver import ReferenceResolver
from reconstruction.multiview_matcher import MultiViewMatcher
from reconstruction.object_hypothesis_resolver import ObjectHypothesisResolver
from reconstruction.multiview_solver import MultiViewSolver
from reconstruction.object_reconstructor import ObjectReconstructor

__all__ = [
    "ViewClassifier",
    "ViewSegmenter",
    "ParameterExtractor",
    "SemanticSignalExtractor",
    "ObjectCandidateDetector",
    "compute_candidate_confidence",
    "ReferenceResolver",
    "MultiViewMatcher",
    "ObjectHypothesisResolver",
    "MultiViewSolver",
    "ObjectReconstructor",
]

