from __future__ import annotations

import json
from pathlib import Path
import ifcopenshell
import pytest

from core.geometry_kernel import LocalFrame, Point3D, Vector3D
from core.models import (
    DocumentConflict,
    EvidenceStatus,
    GeometryRecipe,
    ObjectConfidenceBreakdown,
    ParameterValue,
    ParametricGeometry,
    QualityConfidenceLevel,
    RecipeType,
    ReconstructedObject,
    SemanticFamily,
    SourceReference,
)
from ifc.authoring_pipeline import IFCAuthoringPipeline
from ifc.guid_registry import IFCGuidRegistry
from ifc.semantic_mapper import IFCSemanticMapper
from ifc.validator import IFCValidator


# ==============================================================================
# TESTS OBLIGATORIOS FASE v0.4
# ==============================================================================

def test_1_schema_is_ifc4x3(tmp_path):
    """
    1. El schema del modelo creado es estrictamente IFC4X3 / IFC4X3_ADD2.
    """
    pipeline = IFCAuthoringPipeline(
        project_name="Test Project",
        guid_registry_path=tmp_path / "guids.json",
    )
    model, _ = pipeline.author_ifc_model([])
    assert model.schema.startswith("IFC4X3")


def test_2_ifc_project_created_correctly(tmp_path):
    """
    2. IfcProject creado correctamente con nombre y unidades métricas.
    """
    pipeline = IFCAuthoringPipeline(
        project_name="RN174 Road Infrastructure",
        guid_registry_path=tmp_path / "guids.json",
    )
    model, report = pipeline.author_ifc_model([])
    projects = model.by_type("IfcProject")
    assert len(projects) == 1
    assert projects[0].Name == "RN174 Road Infrastructure"


def test_3_facility_created_correctly(tmp_path):
    """
    3. Facility creada correctamente en la jerarquía IfcProject -> IfcSite -> IfcFacility/IfcRoad.
    """
    pipeline = IFCAuthoringPipeline(
        project_name="Test Project",
        facility_name="Ruta Nacional 174",
        facility_class="IfcRoad",
        guid_registry_path=tmp_path / "guids.json",
    )
    model, _ = pipeline.author_ifc_model([])
    roads = model.by_type("IfcRoad")
    assert len(roads) == 1
    assert roads[0].Name == "Ruta Nacional 174"

    # Verificar agregación
    site = model.by_type("IfcSite")[0]
    assert site.IsDecomposedBy[0].RelatedObjects[0] == roads[0]


def test_4_rectangular_extrusion_preserves_dimensions(tmp_path):
    """
    4. Rectangular extrusion conserva 7.30 x 50.00 x 0.20 en IfcRectangleProfileDef y Depth.
    """
    obj = ReconstructedObject(
        object_id="obj_slab_ctrl",
        family="PAVEMENT",
        object_type="CALZADA",
        parameters={
            "ANCHO": ParameterValue(name="ANCHO", value=7.30, status=EvidenceStatus.DOCUMENTED),
            "LONGITUD": ParameterValue(name="LONGITUD", value=50.0, status=EvidenceStatus.DOCUMENTED),
            "ESPESOR": ParameterValue(name="ESPESOR", value=0.20, status=EvidenceStatus.DOCUMENTED),
        },
    )
    obj.is_built = True
    geom = ParametricGeometry(
        geometry_id="g_slab",
        object_id=obj.object_id,
        recipe_id="r_slab",
        geometry_type=RecipeType.RECTANGULAR_EXTRUSION,
        parameters={"ANCHO": 7.30, "ESPESOR": 0.20, "LONGITUD": 50.0},
        geometry_confidence=QualityConfidenceLevel.VERIFIED,
        is_built=True,
    )

    pipeline = IFCAuthoringPipeline(
        project_name="Test Rect",
        guid_registry_path=tmp_path / "guids.json",
    )
    model, report = pipeline.author_ifc_model([(obj, geom)])

    solid = model.by_type("IfcExtrudedAreaSolid")[0]
    profile = solid.SweptArea
    assert profile.is_a("IfcRectangleProfileDef")
    assert profile.XDim == 7.30
    assert profile.YDim == 0.20
    assert solid.Depth == 50.00


def test_5_circular_extrusion_preserves_radius_and_height(tmp_path):
    """
    5. Circular extrusion conserva radio y altura (IfcCircleProfileDef + Depth).
    """
    obj = ReconstructedObject(
        object_id="obj_col_ctrl",
        family="STRUCTURAL",
        object_type="PILOTE",
        parameters={
            "RADIO": ParameterValue(name="RADIO", value=0.60, status=EvidenceStatus.DOCUMENTED),
            "ALTURA": ParameterValue(name="ALTURA", value=15.0, status=EvidenceStatus.DOCUMENTED),
        },
    )
    obj.is_built = True
    geom = ParametricGeometry(
        geometry_id="g_col",
        object_id=obj.object_id,
        recipe_id="r_col",
        geometry_type=RecipeType.CIRCULAR_EXTRUSION,
        parameters={"RADIO": 0.60, "ALTURA": 15.0},
        geometry_confidence=QualityConfidenceLevel.VERIFIED,
        is_built=True,
    )

    pipeline = IFCAuthoringPipeline(
        project_name="Test Circ",
        guid_registry_path=tmp_path / "guids.json",
    )
    model, _ = pipeline.author_ifc_model([(obj, geom)])

    solid = model.by_type("IfcExtrudedAreaSolid")[0]
    profile = solid.SweptArea
    assert profile.is_a("IfcCircleProfileDef")
    assert profile.Radius == 0.60
    assert solid.Depth == 15.0


def test_6_global_ids_valid_and_unique(tmp_path):
    """
    6. GlobalIds generados son conformes al estándar IFC y unívocos.
    """
    obj1 = ReconstructedObject(object_id="obj_1", family="PAVEMENT", object_type="CALZADA")
    obj1.is_built = True
    geom1 = ParametricGeometry(geometry_id="g1", object_id="obj_1", recipe_id="r1", geometry_type=RecipeType.RECTANGULAR_EXTRUSION, parameters={"ANCHO": 1.0, "ESPESOR": 1.0, "LONGITUD": 1.0}, geometry_confidence=QualityConfidenceLevel.HIGH, is_built=True)

    obj2 = ReconstructedObject(object_id="obj_2", family="STRUCTURAL", object_type="PILA")
    obj2.is_built = True
    geom2 = ParametricGeometry(geometry_id="g2", object_id="obj_2", recipe_id="r2", geometry_type=RecipeType.RECTANGULAR_EXTRUSION, parameters={"ANCHO": 1.0, "ESPESOR": 1.0, "LONGITUD": 1.0}, geometry_confidence=QualityConfidenceLevel.HIGH, is_built=True)

    pipeline = IFCAuthoringPipeline(project_name="Test GUIDs", guid_registry_path=tmp_path / "guids.json")
    model, _ = pipeline.author_ifc_model([(obj1, geom1), (obj2, geom2)])

    guids = [e.GlobalId for e in model if hasattr(e, "GlobalId") and e.GlobalId]
    assert len(guids) == len(set(guids))
    for g in guids:
        assert len(g) == 22


def test_7_same_object_id_preserves_global_id_on_update(tmp_path):
    """
    7. Mismo object_id conserva su GlobalId ante un update o reejecución.
    """
    reg_path = tmp_path / "guids.json"
    registry = IFCGuidRegistry(reg_path)
    guid_initial = registry.get_or_create_guid("obj_asset_100")

    # Segunda ejecución con nueva instancia del registro
    registry_second = IFCGuidRegistry(reg_path)
    guid_updated = registry_second.get_or_create_guid("obj_asset_100")

    assert guid_initial == guid_updated


def test_8_distinct_object_ids_get_distinct_global_ids(tmp_path):
    """
    8. Objetos distintos obtienen GlobalIds distintos.
    """
    registry = IFCGuidRegistry(tmp_path / "guids.json")
    g1 = registry.get_or_create_guid("obj_A")
    g2 = registry.get_or_create_guid("obj_B")
    assert g1 != g2


def test_9_pset_source_traceability_exists(tmp_path):
    """
    9. Pset_SourceTraceability existe en el producto IFC.
    """
    obj = ReconstructedObject(object_id="obj_trace", family="PAVEMENT", object_type="CALZADA", source_documents=["plano_1.dxf", "plano_2.dxf"])
    obj.is_built = True
    geom = ParametricGeometry(geometry_id="g_tr", object_id="obj_trace", recipe_id="r_tr", geometry_type=RecipeType.RECTANGULAR_EXTRUSION, parameters={"ANCHO": 1.0, "ESPESOR": 1.0, "LONGITUD": 1.0}, geometry_confidence=QualityConfidenceLevel.HIGH, is_built=True)

    pipeline = IFCAuthoringPipeline(project_name="Test Pset", guid_registry_path=tmp_path / "guids.json")
    model, _ = pipeline.author_ifc_model([(obj, geom)])

    psets = model.by_type("IfcPropertySet")
    trace_psets = [p for p in psets if p.Name == "Pset_SourceTraceability"]
    assert len(trace_psets) == 1
    props = {prop.Name: prop.NominalValue.wrappedValue for prop in trace_psets[0].HasProperties}
    assert props["SourceId"] == "obj_trace"
    assert "plano_1.dxf" in props["SourceFiles"]


def test_10_pset_reconstructed_parameters_exists(tmp_path):
    """
    10. Pset_ReconstructedParameters existe y conserva valores y unidades.
    """
    obj = ReconstructedObject(
        object_id="obj_p_pset",
        family="PAVEMENT",
        object_type="CALZADA",
        parameters={
            "ANCHO": ParameterValue(name="ANCHO", value=7.30, unit="m", status=EvidenceStatus.DOCUMENTED),
        },
    )
    obj.is_built = True
    geom = ParametricGeometry(geometry_id="g_p", object_id="obj_p_pset", recipe_id="r_p", geometry_type=RecipeType.RECTANGULAR_EXTRUSION, parameters={"ANCHO": 7.3, "ESPESOR": 0.2, "LONGITUD": 10.0}, geometry_confidence=QualityConfidenceLevel.HIGH, is_built=True)

    pipeline = IFCAuthoringPipeline(project_name="Test Pset Param", guid_registry_path=tmp_path / "guids.json")
    model, _ = pipeline.author_ifc_model([(obj, geom)])

    psets = [p for p in model.by_type("IfcPropertySet") if p.Name == "Pset_ReconstructedParameters"]
    assert len(psets) == 1
    props = {prop.Name: prop.NominalValue.wrappedValue for prop in psets[0].HasProperties}
    assert props["ANCHO"] == 7.30
    assert props["ANCHO_Unit"] == "m"
    assert props["ANCHO_Status"] == "DOCUMENTED"


def test_11_pset_reconstruction_quality_exists(tmp_path):
    """
    11. Pset_ReconstructionQuality existe con desglose completo de confianza.
    """
    cb = ObjectConfidenceBreakdown(
        identity_confidence=QualityConfidenceLevel.HIGH,
        semantic_confidence=QualityConfidenceLevel.HIGH,
        parameter_confidence=QualityConfidenceLevel.HIGH,
        geometry_confidence=QualityConfidenceLevel.VERIFIED,
    )
    obj = ReconstructedObject(object_id="obj_q", family="PAVEMENT", object_type="CALZADA", confidence_breakdown=cb)
    obj.is_built = True
    geom = ParametricGeometry(geometry_id="g_q", object_id="obj_q", recipe_id="r_q", geometry_type=RecipeType.RECTANGULAR_EXTRUSION, parameters={"ANCHO": 1.0, "ESPESOR": 1.0, "LONGITUD": 1.0}, geometry_confidence=QualityConfidenceLevel.VERIFIED, is_built=True)

    pipeline = IFCAuthoringPipeline(project_name="Test Pset Quality", guid_registry_path=tmp_path / "guids.json")
    model, _ = pipeline.author_ifc_model([(obj, geom)])

    psets = [p for p in model.by_type("IfcPropertySet") if p.Name == "Pset_ReconstructionQuality"]
    assert len(psets) == 1
    props = {prop.Name: prop.NominalValue.wrappedValue for prop in psets[0].HasProperties}
    assert props["GeometryConfidence"] == "VERIFIED"
    assert props["GeometryValidationStatus"] == "VERIFIED"


def test_12_unknown_geometry_does_not_generate_ifc_product(tmp_path):
    """
    12. UNKNOWN geometry o receta vacía no genera producto IFC.
    """
    obj = ReconstructedObject(object_id="obj_unk", family="UNKNOWN")
    geom = ParametricGeometry(
        geometry_id="g_unk",
        object_id="obj_unk",
        recipe_id="r_unk",
        geometry_type=RecipeType.UNKNOWN,
        is_built=False,
        build_failure_reason="NO_DIMENSIONS",
    )
    pipeline = IFCAuthoringPipeline(project_name="Test Unk", guid_registry_path=tmp_path / "guids.json")
    model, report = pipeline.author_ifc_model([(obj, geom)])

    assert report["authorized_products_count"] == 0
    assert report["not_authorized_count"] == 1
    assert "GEOMETRY_NOT_BUILT" in report["not_authorized"][0]["reason"]


def test_13_not_built_does_not_generate_ifc_product(tmp_path):
    """
    13. NOT_BUILT no genera producto físico IFC.
    """
    obj = ReconstructedObject(object_id="obj_nb", family="STRUCTURAL", object_type="PILOTE")
    geom = ParametricGeometry(
        geometry_id="g_nb",
        object_id="obj_nb",
        recipe_id="r_nb",
        geometry_type=RecipeType.CIRCULAR_EXTRUSION,
        is_built=False,
        build_failure_reason="MISSING_REQUIRED_PARAMETERS: ALTURA",
    )
    pipeline = IFCAuthoringPipeline(project_name="Test NB", guid_registry_path=tmp_path / "guids.json")
    model, report = pipeline.author_ifc_model([(obj, geom)])

    assert len(report["authorized_products"]) == 0
    assert report["not_authorized_count"] == 1


def test_14_critical_document_conflict_blocks_ifc(tmp_path):
    """
    14. DOCUMENT_CONFLICT crítico bloquea la creación del producto IFC.
    """
    conflict = DocumentConflict(
        object_id="obj_conf",
        parameter="ANCHO",
        source_a=SourceReference(source_file="a.dxf"),
        value_a=7.30,
        source_b=SourceReference(source_file="b.dxf"),
        value_b=6.00,
        resolution="UNRESOLVED",
    )
    obj = ReconstructedObject(object_id="obj_conf", family="PAVEMENT", object_type="CALZADA", conflicts=[conflict])
    obj.is_built = True
    geom = ParametricGeometry(geometry_id="g_cf", object_id="obj_conf", recipe_id="r_cf", geometry_type=RecipeType.RECTANGULAR_EXTRUSION, parameters={"ANCHO": 7.3, "ESPESOR": 0.2, "LONGITUD": 10.0}, geometry_confidence=QualityConfidenceLevel.HIGH, is_built=True)

    pipeline = IFCAuthoringPipeline(project_name="Test Conf", guid_registry_path=tmp_path / "guids.json")
    model, report = pipeline.author_ifc_model([(obj, geom)])

    assert report["authorized_products_count"] == 0
    assert report["not_authorized"][0]["reason"] == "CRITICAL_DOCUMENT_CONFLICT_ACTIVE"


def test_15_proxy_not_used_when_specific_class_resolved(tmp_path):
    """
    15. IfcBuildingElementProxy NO se utiliza cuando existe clase específica resuelta.
    """
    obj = ReconstructedObject(object_id="obj_slab", family="PAVEMENT", object_type="CALZADA")
    obj.is_built = True
    geom = ParametricGeometry(geometry_id="g_sl", object_id="obj_slab", recipe_id="r_sl", geometry_type=RecipeType.RECTANGULAR_EXTRUSION, parameters={"ANCHO": 7.3, "ESPESOR": 0.2, "LONGITUD": 10.0}, geometry_confidence=QualityConfidenceLevel.HIGH, is_built=True)

    pipeline = IFCAuthoringPipeline(project_name="Test Class", guid_registry_path=tmp_path / "guids.json")
    model, report = pipeline.author_ifc_model([(obj, geom)])

    assert len(model.by_type("IfcBuildingElementProxy")) == 0
    slabs = model.by_type("IfcSlab")
    assert len(slabs) == 1
    assert slabs[0].PredefinedType == "PAVING"


def test_16_unknown_crs_does_not_invent_epsg(tmp_path):
    """
    16. CRS desconocido no genera entidades IfcProjectedCRS inventadas.
    """
    pipeline = IFCAuthoringPipeline(project_name="Test Local CRS", guid_registry_path=tmp_path / "guids.json")
    model, _ = pipeline.author_ifc_model([], crs_info=None)

    assert len(model.by_type("IfcProjectedCRS")) == 0
    assert len(model.by_type("IfcMapConversion")) == 0


def test_17_units_preserved(tmp_path):
    """
    17. Unidades del proyecto se configuran y preservan como METERS.
    """
    pipeline = IFCAuthoringPipeline(project_name="Test Units", guid_registry_path=tmp_path / "guids.json")
    model, _ = pipeline.author_ifc_model([])

    units = model.by_type("IfcSIUnit")
    length_units = [u for u in units if u.UnitType == "LENGTHUNIT"]
    assert len(length_units) >= 1
    assert length_units[0].Name == "METRE"


def test_18_ifc_round_trip_preserves_dimensions(tmp_path):
    """
    18. IFC round-trip: abrir el modelo generado y comprobar que las dimensiones extraídas coinciden.
    """
    obj = ReconstructedObject(
        object_id="obj_rt_dims",
        family="PAVEMENT",
        object_type="CALZADA",
        parameters={
            "ANCHO": ParameterValue(name="ANCHO", value=7.30, status=EvidenceStatus.DOCUMENTED),
            "LONGITUD": ParameterValue(name="LONGITUD", value=50.0, status=EvidenceStatus.DOCUMENTED),
            "ESPESOR": ParameterValue(name="ESPESOR", value=0.20, status=EvidenceStatus.DOCUMENTED),
        },
    )
    obj.is_built = True
    geom = ParametricGeometry(
        geometry_id="g_rt",
        object_id="obj_rt_dims",
        recipe_id="r_rt",
        geometry_type=RecipeType.RECTANGULAR_EXTRUSION,
        parameters={"ANCHO": 7.30, "ESPESOR": 0.20, "LONGITUD": 50.0},
        geometry_confidence=QualityConfidenceLevel.VERIFIED,
        is_built=True,
    )

    ifc_path = tmp_path / "roundtrip.ifc"
    pipeline = IFCAuthoringPipeline(project_name="Test RT Dims", guid_registry_path=tmp_path / "guids.json")
    model, _ = pipeline.author_ifc_model([(obj, geom)])
    model.write(str(ifc_path))

    # Reabrir el archivo IFC con ifcopenshell
    opened_model = ifcopenshell.open(str(ifc_path))
    solid = opened_model.by_type("IfcExtrudedAreaSolid")[0]
    profile = solid.SweptArea

    assert profile.XDim == 7.30
    assert profile.YDim == 0.20
    assert solid.Depth == 50.00


def test_19_ifc_round_trip_preserves_placement(tmp_path):
    """
    19. IFC round-trip: el placement del producto conserva la posición especificada.
    """
    frame_data = {
        "origin": [12345.67, 3.5, 15.0],
        "longitudinal": [1.0, 0.0, 0.0],
        "transverse": [0.0, 1.0, 0.0],
        "vertical": [0.0, 0.0, 1.0],
    }
    obj = ReconstructedObject(object_id="obj_placed", family="STRUCTURAL", object_type="PILA")
    obj.is_built = True
    geom = ParametricGeometry(
        geometry_id="g_pl",
        object_id="obj_placed",
        recipe_id="r_pl",
        geometry_type=RecipeType.CIRCULAR_EXTRUSION,
        parameters={"RADIO": 0.5, "ALTURA": 6.0},
        local_frame=frame_data,
        geometry_confidence=QualityConfidenceLevel.VERIFIED,
        is_built=True,
    )

    ifc_path = tmp_path / "placement_rt.ifc"
    pipeline = IFCAuthoringPipeline(project_name="Test RT Place", guid_registry_path=tmp_path / "guids.json")
    model, _ = pipeline.author_ifc_model([(obj, geom)])
    model.write(str(ifc_path))

    opened = ifcopenshell.open(str(ifc_path))
    product = opened.by_type("IfcColumn")[0]
    local_placement = product.ObjectPlacement
    coords = local_placement.RelativePlacement.Location.Coordinates

    assert coords[0] == 12345.67
    assert coords[1] == 3.5
    assert coords[2] == 15.0


def test_20_all_tests_pass(tmp_path):
    """
    20. Comprobación general de validez con IFCValidator en un modelo completo.
    """
    pipeline = IFCAuthoringPipeline(project_name="Complete Valid Model", guid_registry_path=tmp_path / "guids.json")
    model, report = pipeline.author_ifc_model([])
    validator = IFCValidator()
    val_report = validator.validate_model(model)

    assert val_report["is_valid"] is True
    assert len(val_report["errors"]) == 0
