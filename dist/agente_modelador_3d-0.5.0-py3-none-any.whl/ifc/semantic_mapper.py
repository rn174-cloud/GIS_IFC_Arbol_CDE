from __future__ import annotations

from typing import Any, Optional
from core.models import (
    IFCMappingDecision,
    ReconstructedObject,
    SemanticFamily,
)


class IFCSemanticMapper:
    """
    Motor de asignación semántica de clases y predefined_types IFC 4.3.
    
    Responsabilidad:
    Resolver la correspondencia auditable entre ReconstructedObject y la taxonomía IFC 4.3.
    
    REGLA FUNDAMENTAL:
    No decidir la clase IFC por la forma geométrica (ej. CIRCULAR_EXTRUSION != IfcPile).
    Priorizar clases específicas IFC4X3 sobre proxies.
    IfcBuildingElementProxy solo se considera si no existe clase específica y la evidencia es indeterminada.
    """

    # Mapeo auditable de familias y tipos a clases IFC 4.3
    RULES: list[dict[str, Any]] = [
        # Pavimentos e infraestructura vial
        {
            "rule_id": "RULE_PAVEMENT_SLAB",
            "match_family": SemanticFamily.PAVEMENT.value,
            "match_types": ["CALZADA", "PAVIMENTO", "PAVEMENT", "CARRIAGEWAY", "SURFACE_BOUNDARY"],
            "ifc_class": "IfcSlab",
            "predefined_type": "PAVING",
            "confidence": 0.95,
        },
        # Estructuras: Pilotes
        {
            "rule_id": "RULE_STRUCTURAL_PILE",
            "match_family": SemanticFamily.STRUCTURAL.value,
            "match_types": ["PILOTE", "PILE", "PILOTE_HORMIGON", "FOUNDATION_PILE"],
            "ifc_class": "IfcPile",
            "predefined_type": "DRIVEN",
            "confidence": 0.95,
        },
        # Estructuras: Columnas / Pilas
        {
            "rule_id": "RULE_STRUCTURAL_COLUMN",
            "match_family": SemanticFamily.STRUCTURAL.value,
            "match_types": ["COLUMNA", "PILA", "COLUMN", "PIER", "POSSIBLE_COLUMN_COMPONENT", "POSSIBLE_FOUNDATION_MEMBER"],
            "ifc_class": "IfcColumn",
            "predefined_type": "PIERSTEM",
            "confidence": 0.90,
        },
        # Estructuras: Vigas
        {
            "rule_id": "RULE_STRUCTURAL_BEAM",
            "match_family": SemanticFamily.STRUCTURAL.value,
            "match_types": ["VIGA", "BEAM", "GIRDER", "DINTELL"],
            "ifc_class": "IfcBeam",
            "predefined_type": "GIRDER",
            "confidence": 0.95,
        },
        # Estructuras: Zapatas
        {
            "rule_id": "RULE_STRUCTURAL_FOOTING",
            "match_family": SemanticFamily.STRUCTURAL.value,
            "match_types": ["ZAPATA", "FOOTING", "CABEZAL"],
            "ifc_class": "IfcFooting",
            "predefined_type": "PAD_FOOTING",
            "confidence": 0.95,
        },
        # Drenaje
        {
            "rule_id": "RULE_DRAINAGE_DISTRIBUTION",
            "match_family": SemanticFamily.DRAINAGE.value,
            "match_types": ["ALCANTARILLA", "CULVERT", "SUMIDERO", "CANAL", "DESAGUE"],
            "ifc_class": "IfcDistributionFlowElement",
            "predefined_type": "NOTDEFINED",
            "confidence": 0.90,
        },
        # Seguridad vial: Defensas / Barandas
        {
            "rule_id": "RULE_ROAD_SAFETY_RAILING",
            "match_family": SemanticFamily.ROAD_SAFETY.value,
            "match_types": ["DEFENSA", "BARANDA", "GUARDRAIL", "RAILING"],
            "ifc_class": "IfcRailing",
            "predefined_type": "GUARDRAIL",
            "confidence": 0.95,
        },
        # Señalización
        {
            "rule_id": "RULE_SIGNAGE_SIGN",
            "match_family": SemanticFamily.SIGNAGE.value,
            "match_types": ["SENAL", "SIGN", "CARTEL"],
            "ifc_class": "IfcSign",
            "predefined_type": "NOTDEFINED",
            "confidence": 0.95,
        },
        # Iluminación
        {
            "rule_id": "RULE_LIGHTING_FIXTURE",
            "match_family": SemanticFamily.LIGHTING.value,
            "match_types": ["LUMINARIA", "LIGHT", "LIGHT_FIXTURE", "COLUMNA_ALUMBRADO"],
            "ifc_class": "IfcLightFixture",
            "predefined_type": "SECURITYLIGHTING",
            "confidence": 0.90,
        },
        # Movimiento de suelos
        {
            "rule_id": "RULE_EARTHWORKS_ELEMENT",
            "match_family": SemanticFamily.EARTHWORKS.value,
            "match_types": ["TERRAPLEN", "EMBANKMENT", "EARTHWORKS"],
            "ifc_class": "IfcEarthworksElement",
            "predefined_type": "EMBANKMENT",
            "confidence": 0.90,
        },
    ]

    def resolve_mapping(self, obj: ReconstructedObject) -> IFCMappingDecision:
        """
        Deduce la clase IFC 4.3 a partir de la familia y tipo del ReconstructedObject.
        """
        # Si ya posee ifc_class explícita y no es proxy, respetarla
        if obj.ifc_class and "Proxy" not in obj.ifc_class:
            return IFCMappingDecision(
                object_id=obj.object_id,
                requested_family=str(obj.family),
                probable_type=str(obj.object_type),
                selected_ifc_class=obj.ifc_class,
                selected_predefined_type=obj.ifc_predefined_type,
                mapping_confidence=1.0,
                rule_id="RULE_PREDEFINED_EXPLICIT",
                supporting_evidence=["Objeto con clase IFC explícita asignada."],
                fallback_used=False,
            )

        fam_str = str(obj.family or "").upper()
        type_str = str(obj.object_type or "").upper()

        # Evaluar reglas
        for r in self.RULES:
            if r["match_family"] == fam_str:
                for t in r["match_types"]:
                    if t in type_str or type_str in t:
                        return IFCMappingDecision(
                            object_id=obj.object_id,
                            requested_family=fam_str,
                            probable_type=type_str,
                            selected_ifc_class=r["ifc_class"],
                            selected_predefined_type=r["predefined_type"],
                            mapping_confidence=r["confidence"],
                            rule_id=r["rule_id"],
                            supporting_evidence=[f"Concordancia familia {fam_str} y tipo {type_str} con regla {r['rule_id']}"],
                            fallback_used=False,
                        )

        # Si no hubo coincidencia exacta pero la familia es conocida, asignar clase genérica de la familia
        if fam_str == SemanticFamily.PAVEMENT.value:
            return IFCMappingDecision(
                object_id=obj.object_id,
                requested_family=fam_str,
                probable_type=type_str,
                selected_ifc_class="IfcSlab",
                selected_predefined_type="PAVING",
                mapping_confidence=0.80,
                rule_id="RULE_FAMILY_DEFAULT_SLAB",
                supporting_evidence=["Familia PAVEMENT asignada a IfcSlab/PAVING."],
                fallback_used=False,
            )
        elif fam_str == SemanticFamily.STRUCTURAL.value:
            return IFCMappingDecision(
                object_id=obj.object_id,
                requested_family=fam_str,
                probable_type=type_str,
                selected_ifc_class="IfcMember",
                selected_predefined_type="STRUCTURALPART",
                mapping_confidence=0.75,
                rule_id="RULE_FAMILY_DEFAULT_MEMBER",
                supporting_evidence=["Familia STRUCTURAL asignada a IfcMember."],
                fallback_used=False,
            )

        # Fallback de último recurso: IfcBuildingElementProxy
        return IFCMappingDecision(
            object_id=obj.object_id,
            requested_family=fam_str,
            probable_type=type_str,
            selected_ifc_class="IfcBuildingElementProxy",
            selected_predefined_type="NOTDEFINED",
            mapping_confidence=0.40,
            rule_id="RULE_FALLBACK_PROXY",
            supporting_evidence=["Sin coincidencia semántica específica disponible."],
            fallback_used=True,
            notes="Clase asignada por fallback; requiere resolución semántica previa.",
        )
