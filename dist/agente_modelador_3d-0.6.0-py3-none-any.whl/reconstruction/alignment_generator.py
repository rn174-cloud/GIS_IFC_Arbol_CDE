"""
reconstruction/alignment_generator.py
Generador genérico consciente de alineamiento (Alignment-Aware Generation) para v0.6.0.
Calcula puntos, tangentes, normales y marcos locales a partir de progresivas/estaciones (station/measure).
REGLA ESTRICTA: NO asume periodicidad ni inventa espaciados; requiere status explícito (DOCUMENTED/DERIVED/INFERRED).
"""
from __future__ import annotations

import math
from typing import Any, Callable, Optional

from core.models import EvidenceStatus


class AlignmentFrame:
    """
    Marco de coordenadas local derivado del eje vial/ferroviario en una progresiva/estación dada.
    """
    def __init__(
        self,
        station: float,
        point: tuple[float, float, float],
        tangent: tuple[float, float, float],
        normal: tuple[float, float, float],
        binormal: tuple[float, float, float],
        evidence_status: EvidenceStatus = EvidenceStatus.DOCUMENTED,
    ):
        self.station = station
        self.point = point
        self.tangent = tangent
        self.normal = normal
        self.binormal = binormal
        self.evidence_status = evidence_status

    def to_dict(self) -> dict[str, Any]:
        return {
            "station": self.station,
            "origin": list(self.point),
            "tangent": list(self.tangent),
            "normal": list(self.normal),
            "binormal": list(self.binormal),
            "evidence_status": self.evidence_status.value if hasattr(self.evidence_status, "value") else str(self.evidence_status),
        }

    def compute_offset_point(
        self,
        lateral_offset: float,
        vertical_offset: float,
    ) -> tuple[float, float, float]:
        """
        Calcula un punto tridimensional desplazado transversal y verticalmente del eje.
        P = P_eje + lateral * normal + vertical * binormal
        """
        px = self.point[0] + lateral_offset * self.normal[0] + vertical_offset * self.binormal[0]
        py = self.point[1] + lateral_offset * self.normal[1] + vertical_offset * self.binormal[1]
        pz = self.point[2] + lateral_offset * self.normal[2] + vertical_offset * self.binormal[2]
        return (px, py, pz)


class AlignmentAwareGenerator:
    """
    Servicio genérico para resolver posicionamiento y marcos locales sobre alineamientos gobernados.
    """

    def __init__(
        self,
        lrs_evaluator: Optional[Callable[[float], tuple[tuple[float, float, float], tuple[float, float, float]]]] = None,
    ):
        """
        lrs_evaluator: función opcional (station) -> (point(x,y,z), tangent(tx,ty,tz))
        proporcionada por el servicio LRS gobernado del entorno.
        """
        self.lrs_evaluator = lrs_evaluator

    def resolve_frame_at_station(
        self,
        station: float,
        status: EvidenceStatus = EvidenceStatus.DOCUMENTED,
    ) -> AlignmentFrame:
        """
        Calcula el marco ortonormal local a partir de la progresiva/estación.
        """
        if self.lrs_evaluator:
            pt, tang = self.lrs_evaluator(station)
        else:
            # Línea de referencia canónica genérica por defecto (X=station, Y=0, Z=0)
            pt = (station, 0.0, 0.0)
            tang = (1.0, 0.0, 0.0)

        # Normalizar tangente
        t_len = math.sqrt(tang[0] ** 2 + tang[1] ** 2 + tang[2] ** 2)
        if t_len > 1e-9:
            tang = (tang[0] / t_len, tang[1] / t_len, tang[2] / t_len)
        else:
            tang = (1.0, 0.0, 0.0)

        # Normal transversal (en el plano XY horizontal por defecto)
        normal = (-tang[1], tang[0], 0.0)
        n_len = math.sqrt(normal[0] ** 2 + normal[1] ** 2 + normal[2] ** 2)
        if n_len > 1e-9:
            normal = (normal[0] / n_len, normal[1] / n_len, normal[2] / n_len)
        else:
            normal = (0.0, 1.0, 0.0)

        # Binormal vertical Z = Tangente x Normal
        binormal = (
            tang[1] * normal[2] - tang[2] * normal[1],
            tang[2] * normal[0] - tang[0] * normal[2],
            tang[0] * normal[1] - tang[1] * normal[0],
        )

        return AlignmentFrame(
            station=station,
            point=pt,
            tangent=tang,
            normal=normal,
            binormal=binormal,
            evidence_status=status,
        )

    def generate_alignment_array(
        self,
        stations: Optional[list[float]] = None,
        start_station: Optional[float] = None,
        end_station: Optional[float] = None,
        spacing: Optional[float] = None,
        lateral_offset: float = 0.0,
        vertical_offset: float = 0.0,
        evidence_status: EvidenceStatus = EvidenceStatus.DOCUMENTED,
    ) -> list[dict[str, Any]]:
        """
        Genera colocaciones a lo largo del alineamiento.
        REGLA ESTRICTA: NO inventa espaciados. Si no se suministran estaciones explícitas
        ni espaciado gobernado, devuelve lista vacía y no extrapola.
        """
        resolved_stations: list[float] = []

        if stations is not None and len(stations) > 0:
            resolved_stations = sorted(stations)
        elif start_station is not None and end_station is not None and spacing is not None and spacing > 0:
            # Espaciado paramétrico gobernado
            cur = start_station
            while cur <= end_station + 1e-6:
                resolved_stations.append(round(cur, 3))
                cur += spacing
        else:
            # Sin estaciones documentadas ni espaciado gobernado, NO inventar
            return []

        placements: list[dict[str, Any]] = []
        for st in resolved_stations:
            frame = self.resolve_frame_at_station(st, status=evidence_status)
            pos = frame.compute_offset_point(lateral_offset, vertical_offset)
            placements.append({
                "station": st,
                "placement_point": list(pos),
                "local_frame": frame.to_dict(),
                "evidence_status": evidence_status.value if hasattr(evidence_status, "value") else str(evidence_status),
            })

        return placements
