from __future__ import annotations

import pytest
from core.geometry_kernel import LocalFrame, Point3D, Vector3D
from core.models import (
    CandidateStatus,
    DocumentConflict,
    EvidenceStatus,
    GeometryRecipe,
    ObjectCandidate,
    ObjectConfidenceBreakdown,
    ParameterEligibilityStatus,
    ParameterValue,
    ParametricGeometry,
    QualityConfidenceLevel,
    RecipeType,
    ReconstructedObject,
    SemanticFamily,
    SourceReference,
)
from reconstruction.geometric_recipe_resolver import GeometricRecipeResolver
from reconstruction.geometry_parameter_resolver import GeometryParameterResolver
from reconstruction.geometry_validator import GeometryValidator
from reconstruction.local_frame_resolver import LocalFrameResolver
from reconstruction.parametric_geometry_builder import ParametricGeometryBuilder


# ==============================================================================
# TESTS OBLIGATORIOS FASE v0.3
# ==============================================================================

def test_1_rectangular_extrusion_with_documented_dimensions():
    """
    1. Rectangular extrusion con dimensiones documentadas (ancho, longitud, espesor).
    """
    obj = ReconstructedObject(
        object_id="obj_slab_1",
        family="PAVEMENT",
        parameters={
            "ANCHO": ParameterValue(name="ANCHO", value=7.30, status=EvidenceStatus.DOCUMENTED),
            "LONGITUD": ParameterValue(name="LONGITUD", value=50.0, status=EvidenceStatus.DOCUMENTED),
            "ESPESOR": ParameterValue(name="ESPESOR", value=0.20, status=EvidenceStatus.DOCUMENTED),
        },
    )
    resolver = GeometricRecipeResolver()
    recipe, gaps = resolver.resolve_recipe(obj)

    assert recipe.recipe_type == RecipeType.RECTANGULAR_EXTRUSION
    assert len(recipe.unresolved_parameters) == 0
    assert len(gaps) == 0
    assert recipe.geometry_confidence == QualityConfidenceLevel.HIGH

    builder = ParametricGeometryBuilder()
    geom = builder.build_geometry(obj=obj, recipe=recipe, gaps=gaps)

    assert geom.is_built is True
    assert geom.volume == round(7.30 * 50.0 * 0.20, 4)
    assert len(geom.vertices) == 8
    assert len(geom.faces) == 6


def test_2_circular_extrusion_with_documented_radius_and_length():
    """
    2. Circular extrusion con radio + longitud documentados.
    """
    obj = ReconstructedObject(
        object_id="obj_pile_1",
        family="STRUCTURAL",
        parameters={
            "RADIO": ParameterValue(name="RADIO", value=0.60, status=EvidenceStatus.DOCUMENTED),
            "ALTURA": ParameterValue(name="ALTURA", value=12.0, status=EvidenceStatus.DOCUMENTED),
        },
    )
    resolver = GeometricRecipeResolver()
    recipe, gaps = resolver.resolve_recipe(obj)

    assert recipe.recipe_type == RecipeType.CIRCULAR_EXTRUSION
    assert len(recipe.unresolved_parameters) == 0
    assert recipe.geometry_confidence == QualityConfidenceLevel.HIGH

    builder = ParametricGeometryBuilder()
    geom = builder.build_geometry(obj=obj, recipe=recipe, gaps=gaps)

    assert geom.is_built is True
    assert geom.parameters["RADIO"] == 0.60
    assert geom.parameters["ALTURA"] == 12.0
    assert geom.volume > 0.0


def test_3_documented_radius_without_depth_yields_not_built():
    """
    3. Radio documentado sin profundidad/altura -> NOT_BUILT y se genera DATA_GAP.
    """
    obj = ReconstructedObject(
        object_id="obj_pile_incomplete",
        family="STRUCTURAL",
        parameters={
            "RADIO": ParameterValue(name="RADIO", value=0.60, status=EvidenceStatus.DOCUMENTED),
        },
    )
    resolver = GeometricRecipeResolver()
    recipe, gaps = resolver.resolve_recipe(obj)

    assert recipe.recipe_type == RecipeType.CIRCULAR_EXTRUSION
    assert "ALTURA" in recipe.unresolved_parameters
    assert len(gaps) == 1
    assert gaps[0].parameter == "ALTURA"

    builder = ParametricGeometryBuilder()
    geom = builder.build_geometry(obj=obj, recipe=recipe, gaps=gaps)

    assert geom.is_built is False
    assert "MISSING_REQUIRED_PARAMETERS" in (geom.build_failure_reason or "")
    assert geom.geometry_confidence == QualityConfidenceLevel.NOT_EVALUATED


def test_4_unknown_parameter_blocks_verified_geometry():
    """
    4. Parámetro UNKNOWN bloquea geometría VERIFIED (es rechazado por ParameterEligibility).
    """
    param_resolver = GeometryParameterResolver(mode="STRICT")
    status = param_resolver.evaluate_parameter(
        ParameterValue(name="ESPESOR", value=None, status=EvidenceStatus.UNKNOWN)
    )
    assert status == ParameterEligibilityStatus.REJECTED_UNKNOWN

    obj = ReconstructedObject(
        object_id="obj_unknown_test",
        parameters={
            "ANCHO": ParameterValue(name="ANCHO", value=7.30, status=EvidenceStatus.DOCUMENTED),
            "LONGITUD": ParameterValue(name="LONGITUD", value=20.0, status=EvidenceStatus.DOCUMENTED),
            "ESPESOR": ParameterValue(name="ESPESOR", value=None, status=EvidenceStatus.UNKNOWN),
        },
    )
    resolver = GeometricRecipeResolver(param_resolver=param_resolver)
    recipe, gaps = resolver.resolve_recipe(obj)

    # El parámetro UNKNOWN no entra a eligible_params, por ende queda no resuelto
    assert "ESPESOR" in recipe.unresolved_parameters

    builder = ParametricGeometryBuilder()
    geom = builder.build_geometry(obj=obj, recipe=recipe, gaps=gaps)
    assert geom.is_built is False


def test_5_inferred_parameter_only_allowed_in_preliminary_mode():
    """
    5. Parámetro INFERRED solo se permite en modo PRELIMINARY (rechazado en STRICT).
    """
    param = ParameterValue(name="ALTURA", value=8.5, status=EvidenceStatus.INFERRED)

    strict_resolver = GeometryParameterResolver(mode="STRICT")
    assert strict_resolver.evaluate_parameter(param) == ParameterEligibilityStatus.REJECTED_INFERRED

    prelim_resolver = GeometryParameterResolver(mode="PRELIMINARY")
    eligible, _ = prelim_resolver.filter_eligible_parameters({"ALTURA": param})
    assert "ALTURA" in eligible


def test_6_document_conflict_blocks_geometry():
    """
    6. DOCUMENT_CONFLICT bloquea la construcción de geometría.
    """
    conflict = DocumentConflict(
        object_id="obj_conflicted",
        parameter="ANCHO",
        source_a=SourceReference(source_file="f1.dxf"),
        value_a=7.30,
        source_b=SourceReference(source_file="f2.dxf"),
        value_b=6.00,
        resolution="UNRESOLVED",
    )
    obj = ReconstructedObject(
        object_id="obj_conflicted",
        parameters={
            "ANCHO": ParameterValue(name="ANCHO", value=7.30, status=EvidenceStatus.DOCUMENTED),
            "LONGITUD": ParameterValue(name="LONGITUD", value=10.0, status=EvidenceStatus.DOCUMENTED),
            "ESPESOR": ParameterValue(name="ESPESOR", value=0.30, status=EvidenceStatus.DOCUMENTED),
        },
        conflicts=[conflict],
    )

    resolver = GeometricRecipeResolver()
    recipe, gaps = resolver.resolve_recipe(obj)

    builder = ParametricGeometryBuilder()
    geom = builder.build_geometry(obj=obj, recipe=recipe, gaps=gaps)

    assert geom.is_built is False
    assert geom.build_failure_reason == "DOCUMENT_CONFLICT_UNRESOLVED"


def test_7_geometry_confidence_remains_not_evaluated_if_not_built():
    """
    7. geometry_confidence permanece NOT_EVALUATED si no se construye.
    """
    obj = ReconstructedObject(
        object_id="obj_empty",
        parameters={},
    )
    resolver = GeometricRecipeResolver()
    recipe, gaps = resolver.resolve_recipe(obj)
    builder = ParametricGeometryBuilder()
    geom = builder.build_geometry(obj=obj, recipe=recipe, gaps=gaps)

    assert geom.is_built is False
    assert geom.geometry_confidence == QualityConfidenceLevel.NOT_EVALUATED


def test_8_geometry_confidence_high_if_critical_parameters_sufficient():
    """
    8. geometry_confidence HIGH si parámetros críticos son suficientes y documentados.
    """
    obj = ReconstructedObject(
        object_id="obj_solid_ok",
        parameters={
            "RADIO": ParameterValue(name="RADIO", value=0.50, status=EvidenceStatus.DOCUMENTED),
            "ALTURA": ParameterValue(name="ALTURA", value=10.0, status=EvidenceStatus.DOCUMENTED),
        },
    )
    resolver = GeometricRecipeResolver()
    recipe, gaps = resolver.resolve_recipe(obj)
    builder = ParametricGeometryBuilder()
    geom = builder.build_geometry(obj=obj, recipe=recipe, gaps=gaps)

    assert geom.is_built is True
    assert geom.geometry_confidence == QualityConfidenceLevel.HIGH


def test_9_verified_only_after_validation():
    """
    9. VERIFIED solo tras superar validación geométrica contra fuentes.
    """
    obj = ReconstructedObject(
        object_id="obj_to_verify",
        parameters={
            "RADIO": ParameterValue(name="RADIO", value=0.50, status=EvidenceStatus.DOCUMENTED),
            "ALTURA": ParameterValue(name="ALTURA", value=10.0, status=EvidenceStatus.DOCUMENTED),
        },
    )
    resolver = GeometricRecipeResolver()
    recipe, gaps = resolver.resolve_recipe(obj)
    builder = ParametricGeometryBuilder()
    geom = builder.build_geometry(obj=obj, recipe=recipe, gaps=gaps)

    validator = GeometryValidator(default_tolerance=0.005)
    val_results, final_conf = validator.validate_geometry(obj=obj, geom=geom)

    assert final_conf == QualityConfidenceLevel.VERIFIED
    assert len(val_results) > 0
    assert all(r["status"] == "PASS" for r in val_results)


def test_10_round_trip_dimensional_reproduces_measurements():
    """
    10. Round-trip dimensional reproduce las cotas con diferencia cero.
    """
    obj = ReconstructedObject(
        object_id="obj_roundtrip",
        parameters={
            "ANCHO": ParameterValue(name="ANCHO", value=7.30, status=EvidenceStatus.DOCUMENTED),
            "LONGITUD": ParameterValue(name="LONGITUD", value=100.0, status=EvidenceStatus.DOCUMENTED),
            "ESPESOR": ParameterValue(name="ESPESOR", value=0.25, status=EvidenceStatus.DOCUMENTED),
        },
    )
    resolver = GeometricRecipeResolver()
    recipe, gaps = resolver.resolve_recipe(obj)
    builder = ParametricGeometryBuilder()
    geom = builder.build_geometry(obj=obj, recipe=recipe, gaps=gaps)

    validator = GeometryValidator()
    val_results, _ = validator.validate_geometry(obj=obj, geom=geom)

    width_res = next(r for r in val_results if r["parameter"] == "ANCHO")
    assert width_res["difference"] == 0.0
    assert width_res["status"] == "PASS"


def test_11_local_frame_respects_orientation():
    """
    11. Local frame respeta la orientación especificada.
    """
    obj = ReconstructedObject(object_id="obj_col", family="STRUCTURAL")
    frame = LocalFrameResolver.resolve_local_frame(obj, tangent_vector=Vector3D(0.0, 1.0, 0.0))

    assert frame.longitudinal == Vector3D(0.0, 1.0, 0.0)
    assert frame.vertical == Vector3D(0.0, 0.0, 1.0)
    assert frame.transverse == Vector3D(-1.0, 0.0, 0.0)


def test_12_station_only_positions_never_creates_objects():
    """
    12. Station solo posiciona el local frame, nunca crea objetos por sí misma.
    """
    obj = ReconstructedObject(
        object_id="obj_at_station",
        spatial_reference={"station": 12345.67, "offset": 3.5, "elevation": 15.0},
    )
    frame = LocalFrameResolver.resolve_local_frame(obj)

    assert frame.origin.x == 12345.67
    assert frame.origin.y == 3.5
    assert frame.origin.z == 15.0


def test_13_two_repeated_instances_generate_two_distinct_geometries():
    """
    13. Dos repeated instances generan dos geometrías distintas e independientes.
    """
    obj_1 = ReconstructedObject(
        object_id="obj_col_1",
        spatial_reference={"station": 100.0, "offset": -2.0},
        parameters={
            "RADIO": ParameterValue(name="RADIO", value=0.40, status=EvidenceStatus.DOCUMENTED),
            "ALTURA": ParameterValue(name="ALTURA", value=6.0, status=EvidenceStatus.DOCUMENTED),
        },
    )
    obj_2 = ReconstructedObject(
        object_id="obj_col_2",
        spatial_reference={"station": 100.0, "offset": 2.0},
        parameters={
            "RADIO": ParameterValue(name="RADIO", value=0.40, status=EvidenceStatus.DOCUMENTED),
            "ALTURA": ParameterValue(name="ALTURA", value=6.0, status=EvidenceStatus.DOCUMENTED),
        },
    )
    resolver = GeometricRecipeResolver()
    r1, _ = resolver.resolve_recipe(obj_1)
    r2, _ = resolver.resolve_recipe(obj_2)

    builder = ParametricGeometryBuilder()
    g1 = builder.build_geometry(obj=obj_1, recipe=r1)
    g2 = builder.build_geometry(obj=obj_2, recipe=r2)

    assert g1.geometry_id != g2.geometry_id
    assert g1.bounding_box != g2.bounding_box


def test_14_same_parameters_produce_deterministic_geometry():
    """
    14. Mismos parámetros producen geometría idéntica y determinista.
    """
    obj_a = ReconstructedObject(
        object_id="obj_det_1",
        parameters={
            "RADIO": ParameterValue(name="RADIO", value=0.50, status=EvidenceStatus.DOCUMENTED),
            "ALTURA": ParameterValue(name="ALTURA", value=8.0, status=EvidenceStatus.DOCUMENTED),
        },
    )
    resolver = GeometricRecipeResolver()
    r_a, _ = resolver.resolve_recipe(obj_a)

    builder = ParametricGeometryBuilder()
    geom_a1 = builder.build_geometry(obj=obj_a, recipe=r_a)
    geom_a2 = builder.build_geometry(obj=obj_a, recipe=r_a)

    assert geom_a1.volume == geom_a2.volume
    assert geom_a1.vertices == geom_a2.vertices
    assert geom_a1.bounding_box == geom_a2.bounding_box
