from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Optional

from core.models import (
    SourceDocument,
    UnitResolutionStatus,
)


@dataclass
class UnitResolutionRecord:
    """
    Registro auditable de resolución de unidad para una dimensión o valor técnico.
    Preserva raw_value, raw_unit, resolved_value, resolved_unit, conversion_factor,
    unit_evidence y unit_resolution_status.
    """
    raw_value: float
    raw_unit: Optional[str]
    resolved_value: Optional[float]
    resolved_unit: Optional[str]
    conversion_factor: Optional[float]
    unit_evidence: Optional[str]
    scale_evidence: Optional[str]
    candidate_scale_factor: Optional[float]
    unit_resolution_status: UnitResolutionStatus
    is_primary_evidence: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "raw_value": self.raw_value,
            "raw_unit": self.raw_unit,
            "resolved_value": self.resolved_value,
            "resolved_unit": self.resolved_unit,
            "conversion_factor": self.conversion_factor,
            "unit_evidence": self.unit_evidence,
            "scale_evidence": self.scale_evidence,
            "candidate_scale_factor": self.candidate_scale_factor,
            "unit_resolution_status": self.unit_resolution_status.value,
            "is_primary_evidence": self.is_primary_evidence,
        }


class UnitResolver:
    """
    Resolutor estricto y conservador de unidades y escalas para el Agente Modelador 3D v0.5.3.

    PRINCIPIOS OBLIGATORIOS:
    1. Un ratio de 1000 entre cotas o dimensiones (ej. 4.0 vs 4000.0) genera ÚNICAMENTE
       UNIT_SCALE_HYPOTHESIS si no existe evidencia documental independiente.
    2. La escala gráfica / viewport (1:10, 1:25, 1:50) es ÚNICAMENTE evidencia secundaria;
       NO constituye por sí sola evidencia suficiente de unidad física.
    3. Para resolver una unidad a mm/m/cm se exige evidencia primaria documental:
       - Notas del plano (drawing notes, ej. 'DIMENSIONES EN MILIMETROS', 'DIMENSIONES EN METROS');
       - Sufijos/prefijos explícitos de cota ('4000 mm', '4.0 m');
       - INSUNITS de cabecera CAD (4 = mm, 6 = m, 1 = pulgadas);
       - Metadatos de estilo de cota (DIMLFAC, DIMSCALE) o metadatos de bloque inequívocos;
       - Metadatos CDE / gobernanza documental del activo.
    4. Preservar siempre raw_value, raw_unit, resolved_value, resolved_unit, conversion_factor,
       unit_evidence y unit_resolution_status.
    5. Normalización interna a metros (SI) únicamente una vez demostrada documentalmente la unidad.
    """

    NOTE_MM_PATTERN = re.compile(
        r"(?:DIMENSIONES|COTAS|MEDIDAS)\s+EN\s+MIL[IÍ]METROS|DIMENSIONS?\s+IN\s+MILL?IMET[ER]S?|\bMIL[IÍ]METROS\b",
        re.IGNORECASE,
    )
    NOTE_M_PATTERN = re.compile(
        r"(?:DIMENSIONES|COTAS|MEDIDAS)\s+EN\s+METROS|DIMENSIONS?\s+IN\s+MET[ER]S?|\bMETROS\b",
        re.IGNORECASE,
    )
    NOTE_CM_PATTERN = re.compile(
        r"(?:DIMENSIONES|COTAS|MEDIDAS)\s+EN\s+CENT[IÍ]METROS|\bCENT[IÍ]METROS\b",
        re.IGNORECASE,
    )
    EXPLICIT_SUFFIX_PATTERN = re.compile(
        r"(?P<val>[-+]?\d+(?:[.,]\d+)?)\s*(?P<unit>mm|cm|m|km)\b",
        re.IGNORECASE,
    )

    GRAPHIC_SCALE_PATTERN = re.compile(
        r"\b(?:ESC(?:ALA)?\.?)\s*1\s*:\s*(?P<denom>\d+)",
        re.IGNORECASE,
    )

    def __init__(self, canonical_unit: str = "m") -> None:
        self.canonical_unit = canonical_unit

    def detect_document_unit_evidence(self, document: SourceDocument) -> dict[str, Any]:
        """
        Inspecciona un SourceDocument en búsqueda de evidencia primaria y secundaria de unidades.
        """
        extracted = document.extracted_data or {}
        texts = extracted.get("texts", [])
        raw_text_list = [t.get("text", "") for t in texts if isinstance(t, dict)]
        header = extracted.get("header", {})

        primary_evidence: list[str] = []
        secondary_evidence: list[str] = []
        dominant_unit: Optional[str] = None

        # 1. Inspeccionar INSUNITS en cabecera CAD (Evidencia Primaria)
        insunits = header.get("INSUNITS") or header.get("$INSUNITS")
        if insunits is not None:
            try:
                iu = int(insunits)
                if iu == 4:
                    primary_evidence.append(f"INSUNITS=4 (Millimeters)")
                    dominant_unit = dominant_unit or "mm"
                elif iu == 6:
                    primary_evidence.append(f"INSUNITS=6 (Meters)")
                    dominant_unit = dominant_unit or "m"
                elif iu == 5:
                    primary_evidence.append(f"INSUNITS=5 (Centimeters)")
                    dominant_unit = dominant_unit or "cm"
            except (ValueError, TypeError):
                pass

        # 2. Inspeccionar notas de texto en el plano (Evidencia Primaria)
        for t in raw_text_list:
            if self.NOTE_MM_PATTERN.search(t):
                primary_evidence.append(f"DRAWING_NOTE: {t.strip()[:100]}")
                dominant_unit = dominant_unit or "mm"
            elif self.NOTE_M_PATTERN.search(t):
                primary_evidence.append(f"DRAWING_NOTE: {t.strip()[:100]}")
                dominant_unit = dominant_unit or "m"
            elif self.NOTE_CM_PATTERN.search(t):
                primary_evidence.append(f"DRAWING_NOTE: {t.strip()[:100]}")
                dominant_unit = dominant_unit or "cm"

        # 3. Inspeccionar metadatos explícitos del documento (Evidencia Primaria)
        if document.units:
            u_norm = document.units.strip().lower()
            if u_norm in {"m", "meter", "meters", "metro", "metros"}:
                primary_evidence.append(f"DOCUMENT_METADATA: {document.units}")
                dominant_unit = dominant_unit or "m"
            elif u_norm in {"mm", "millimeter", "millimeters", "milimetro", "milimetros"}:
                primary_evidence.append(f"DOCUMENT_METADATA: {document.units}")
                dominant_unit = dominant_unit or "mm"

        # 4. Inspeccionar escalas gráficas (Evidencia Secundaria ÚNICAMENTE)
        for t in raw_text_list:
            m_scale = self.GRAPHIC_SCALE_PATTERN.search(t)
            if m_scale:
                secondary_evidence.append(f"GRAPHIC_SCALE_VIEWPORT: {m_scale.group(0)}")

        return {
            "dominant_unit": dominant_unit,
            "primary_evidence": primary_evidence,
            "secondary_evidence": secondary_evidence,
            "has_primary": len(primary_evidence) > 0,
        }

    def resolve_measurement_unit(
        self,
        raw_value: float,
        declared_unit: Optional[str] = None,
        raw_text: Optional[str] = None,
        doc_evidence: Optional[dict[str, Any]] = None,
        comparison_value: Optional[float] = None,
    ) -> UnitResolutionRecord:
        """
        Resuelve la unidad de una medición preservando trazabilidad completa.
        """
        # 1. Verificar si el texto local declara unidad explícita (Evidencia Primaria)
        local_unit = declared_unit
        explicit_evidence: Optional[str] = None

        if raw_text:
            m_suf = self.EXPLICIT_SUFFIX_PATTERN.search(raw_text)
            if m_suf:
                local_unit = m_suf.group("unit").lower()
                explicit_evidence = f"EXPLICIT_TEXT_SUFFIX: {m_suf.group(0)}"

        if not explicit_evidence and declared_unit:
            u_norm = str(declared_unit).lower().strip()
            if u_norm in {"m", "meter", "meters", "metro", "metros", "mm", "millimeter", "millimeters", "milimetro", "milimetros", "cm", "centimeter", "centimeters"}:
                local_unit = u_norm
                explicit_evidence = f"DECLARED_MEASUREMENT_UNIT: {declared_unit}"

        doc_unit = doc_evidence.get("dominant_unit") if doc_evidence else None
        doc_prim = doc_evidence.get("primary_evidence", []) if doc_evidence else []
        doc_sec = doc_evidence.get("secondary_evidence", []) if doc_evidence else []

        # Determinar si existe relación 1000 con otro valor
        ratio_1000 = False
        candidate_scale: Optional[float] = None
        if comparison_value is not None and comparison_value > 0 and raw_value > 0:
            ratio = raw_value / comparison_value
            inv_ratio = comparison_value / raw_value
            if 950 <= ratio <= 1050:
                ratio_1000 = True
                candidate_scale = 1000.0
            elif 950 <= inv_ratio <= 1050:
                ratio_1000 = True
                candidate_scale = 0.001

        # CASO A: Evidencia local explícita primaria
        if explicit_evidence and local_unit:
            canonical_val, factor = self._convert_to_canonical(raw_value, local_unit)
            return UnitResolutionRecord(
                raw_value=raw_value,
                raw_unit=local_unit,
                resolved_value=canonical_val,
                resolved_unit=self.canonical_unit,
                conversion_factor=factor,
                unit_evidence=explicit_evidence,
                scale_evidence=None,
                candidate_scale_factor=candidate_scale,
                unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED,
                is_primary_evidence=True,
            )

        # CASO B: Evidencia primaria a nivel de plano (ej. NOTA: DIMENSIONES EN MILIMETROS)
        if doc_prim and doc_unit:
            primary_str = " | ".join(doc_prim[:3])
            # Si el valor numérico es coherente con la unidad documental
            canonical_val, factor = self._convert_to_canonical(raw_value, doc_unit)
            return UnitResolutionRecord(
                raw_value=raw_value,
                raw_unit=doc_unit,
                resolved_value=canonical_val,
                resolved_unit=self.canonical_unit,
                conversion_factor=factor,
                unit_evidence=f"DOCUMENT_PRIMARY: {primary_str}",
                scale_evidence=doc_sec[0] if doc_sec else None,
                candidate_scale_factor=candidate_scale,
                unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED,
                is_primary_evidence=True,
            )

        # CASO C: Ratio 1000 detectado pero SIN evidencia primaria de unidad
        if ratio_1000:
            # Solo escala secundaria o ninguna evidencia: UNIT_SCALE_HYPOTHESIS
            sec_str = doc_sec[0] if doc_sec else "RATIO_1000_WITHOUT_PRIMARY_EVIDENCE"
            return UnitResolutionRecord(
                raw_value=raw_value,
                raw_unit=local_unit,
                resolved_value=None,  # No se normaliza hasta demostrar documentalmente
                resolved_unit=None,
                conversion_factor=None,
                unit_evidence=None,
                scale_evidence=f"SCALE_HYPOTHESIS_ONLY: {sec_str}",
                candidate_scale_factor=candidate_scale,
                unit_resolution_status=UnitResolutionStatus.UNIT_SCALE_HYPOTHESIS,
                is_primary_evidence=False,
            )

        # CASO D: Sin evidencia de unidad
        return UnitResolutionRecord(
            raw_value=raw_value,
            raw_unit=local_unit,
            resolved_value=None,
            resolved_unit=None,
            conversion_factor=None,
            unit_evidence=None,
            scale_evidence=doc_sec[0] if doc_sec else None,
            candidate_scale_factor=None,
            unit_resolution_status=UnitResolutionStatus.UNIT_UNRESOLVED,
            is_primary_evidence=False,
        )

    def normalize_between_documented_units(
        self,
        rec_a: UnitResolutionRecord,
        rec_b: UnitResolutionRecord,
        tolerance: float = 0.02,
    ) -> tuple[bool, Optional[float], Optional[str]]:
        """
        Compara dos registros de unidad. Si ambos están demostrados documentalmente,
        evalúa compatibilidad en base canónica (m) sin generar conflicto espurio.
        """
        # Si alguno está en UNIT_SCALE_HYPOTHESIS o UNIT_UNRESOLVED, no puede normalizarse con certeza
        if (
            rec_a.unit_resolution_status not in {UnitResolutionStatus.UNIT_DOCUMENTED, UnitResolutionStatus.UNIT_DERIVED}
            or rec_b.unit_resolution_status not in {UnitResolutionStatus.UNIT_DOCUMENTED, UnitResolutionStatus.UNIT_DERIVED}
        ):
            return False, None, "UNRESOLVED_UNIT_EVIDENCE"

        val_a = rec_a.resolved_value
        val_b = rec_b.resolved_value

        if val_a is None or val_b is None:
            return False, None, "MISSING_CANONICAL_VALUE"

        diff = abs(val_a - val_b)
        if diff <= tolerance:
            mean_val = round((val_a + val_b) / 2.0, 4)
            return True, mean_val, "NORMALIZED_DOCUMENTED_UNITS_COMPATIBLE"
        else:
            return False, None, f"DOCUMENTED_VALUES_DISCREPANT: {val_a} vs {val_b}"

    def _convert_to_canonical(self, value: float, unit: str) -> tuple[float, float]:
        u = unit.lower().strip()
        if u == "mm":
            return round(value * 0.001, 6), 0.001
        elif u == "cm":
            return round(value * 0.01, 6), 0.01
        elif u == "m":
            return round(value, 6), 1.0
        elif u == "km":
            return round(value * 1000.0, 6), 1000.0
        return value, 1.0
