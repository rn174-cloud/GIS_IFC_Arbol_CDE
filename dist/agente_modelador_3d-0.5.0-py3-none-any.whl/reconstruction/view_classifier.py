from __future__ import annotations

import re
from typing import Any

from core.models import (
    SourceDocument,
    SourceReference,
    ViewEvidence,
)


class ViewClassifier:
    """
    Clasificador inicial de vistas documentales.

    Reconoce indicios de:

    - planta;
    - perfil longitudinal;
    - sección;
    - elevación;
    - detalle;
    - esquema;
    - tabla.

    IMPORTANTE:
    la clasificación es evidencia preliminar.
    No implica que el contenido haya sido interpretado
    correctamente todavía.
    """

    VIEW_PATTERNS = {
        "PLAN": (
            r"\bPLANTA\b",
            r"\bPLAN\b",
            r"\bPLANTA GENERAL\b",
        ),
        "PROFILE": (
            r"\bPERFIL\b",
            r"\bPERFIL LONGITUDINAL\b",
            r"\bLONGITUDINAL PROFILE\b",
        ),
        "SECTION": (
            r"\bSECCION\b",
            r"\bSECCIÓN\b",
            r"\bCORTE\b",
            r"\bSECTION\b",
        ),
        "ELEVATION": (
            r"\bELEVACION\b",
            r"\bELEVACIÓN\b",
            r"\bALZADO\b",
            r"\bELEVATION\b",
        ),
        "DETAIL": (
            r"\bDETALLE\b",
            r"\bDETAIL\b",
        ),
        "SCHEMATIC": (
            r"\bESQUEMA\b",
            r"\bSCHEMATIC\b",
        ),
        "TABLE": (
            r"\bTABLA\b",
            r"\bCUADRO\b",
            r"\bPLANILLA\b",
            r"\bTABLE\b",
            r"\bSCHEDULE\b",
        ),
    }

    def classify_document(
        self,
        document: SourceDocument,
    ) -> list[ViewEvidence]:
        """
        Clasifica vistas potenciales dentro de una fuente.
        """

        if document.file_type == "PDF":
            return self._classify_pdf(
                document
            )

        if document.file_type in {
            "DXF",
            "DWG",
        }:
            return self._classify_cad(
                document
            )

        return []

    def _classify_pdf(
        self,
        document: SourceDocument,
    ) -> list[ViewEvidence]:

        views: list[ViewEvidence] = []

        pages = (
            document.extracted_data.get(
                "pages",
                [],
            )
        )

        for page in pages:

            text = str(
                page.get(
                    "text",
                    "",
                )
            )

            detected = self.classify_text(
                text
            )

            if not detected:
                detected = [
                    (
                        "UNKNOWN",
                        0.20,
                    )
                ]

            for view_type, confidence in detected:

                page_number = page.get(
                    "page_number"
                )

                views.append(
                    ViewEvidence(
                        view_id=(
                            f"{document.path.name}"
                            f":page:{page_number}"
                            f":{view_type}"
                        ),
                        view_type=view_type,
                        source=SourceReference(
                            source_file=str(
                                document.path
                            ),
                            source_type="PDF",
                            sheet=str(
                                page_number
                            ),
                            view=view_type,
                        ),
                        geometry={
                            "page_width": page.get(
                                "width"
                            ),
                            "page_height": page.get(
                                "height"
                            ),
                            "drawings": page.get(
                                "drawings",
                                [],
                            ),
                        },
                        texts=[
                            word.get(
                                "text",
                                "",
                            )
                            for word
                            in page.get(
                                "words",
                                [],
                            )
                            if word.get(
                                "text"
                            )
                        ],
                        confidence=confidence,
                    )
                )

        return views

    def _classify_cad(
        self,
        document: SourceDocument,
    ) -> list[ViewEvidence]:

        entities = (
            document.extracted_data.get(
                "entities",
                [],
            )
        )

        texts = [
            str(
                entity.get(
                    "text",
                    "",
                )
            )
            for entity in entities
            if entity.get(
                "entity_type"
            )
            in {
                "TEXT",
                "MTEXT",
            }
        ]

        combined_text = "\n".join(
            texts
        )

        detected = self.classify_text(
            combined_text
        )

        if not detected:
            detected = [
                (
                    "UNKNOWN",
                    0.20,
                )
            ]

        views: list[ViewEvidence] = []

        for index, (
            view_type,
            confidence,
        ) in enumerate(detected):

            views.append(
                ViewEvidence(
                    view_id=(
                        f"{document.path.name}"
                        f":cad:{index}"
                        f":{view_type}"
                    ),
                    view_type=view_type,
                    source=SourceReference(
                        source_file=str(
                            document.path
                        ),
                        source_type=(
                            document.file_type
                        ),
                        view=view_type,
                    ),
                    geometry={
                        "entities": entities,
                    },
                    texts=texts,
                    confidence=confidence,
                )
            )

        return views

    def classify_text(
        self,
        text: str,
    ) -> list[
        tuple[str, float]
    ]:
        """
        Clasificación léxica inicial.

        Devuelve múltiples candidatos si el documento
        contiene varias clases de vista.
        """

        normalized = (
            text.upper()
        )

        results: list[
            tuple[str, float]
        ] = []

        for view_type, patterns in (
            self.VIEW_PATTERNS.items()
        ):

            matches = 0

            for pattern in patterns:
                matches += len(
                    re.findall(
                        pattern,
                        normalized,
                        flags=re.IGNORECASE,
                    )
                )

            if matches:
                confidence = min(
                    0.55
                    + matches * 0.10,
                    0.95,
                )

                results.append(
                    (
                        view_type,
                        confidence,
                    )
                )

        return sorted(
            results,
            key=lambda item: item[1],
            reverse=True,
        )
