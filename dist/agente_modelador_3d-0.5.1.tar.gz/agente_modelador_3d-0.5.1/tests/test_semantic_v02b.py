import json
from pathlib import Path
import pytest

from core.config import AgentConfig
from core.models import (
    CandidateStatus,
    CandidateType,
    EvidenceMatch,
    MatchDecision,
    ObjectCandidate,
    ResolutionEvidence,
    SemanticFamily,
    SourceReference,
    ViewEvidence,
)
from reconstruction.multiview_matcher import MultiViewMatcher
from reconstruction.object_hypothesis_resolver import ObjectHypothesisResolver
from reconstruction.pipeline import ReconstructionPipeline
from reconstruction.reference_resolver import ReferenceResolver


def test_same_station_same_label_complementary_views_produces_same_object():
    """
    Test 1: Misma station + mismo label + vistas complementarias (PLAN ↔ SECTION) produce SAME_OBJECT.
    """
    matcher = MultiViewMatcher(station_tolerance=5.0)

    view_plan = ViewEvidence(view_id="v_plan", view_type="PLAN", source=SourceReference(source_file="f.dxf"))
    view_sec = ViewEvidence(view_id="v_sec", view_type="SECTION", source=SourceReference(source_file="f.dxf"))
    views_dict = {"v_plan": view_plan, "v_sec": view_sec}

    cand_plan = ObjectCandidate(
        candidate_id="cand_p3_plan",
        probable_family=SemanticFamily.STRUCTURAL,
        probable_type="POSSIBLE_FOUNDATION_MEMBER",
        station=12345.0,
        labels=["PILA P3"],
        related_texts=["PILA P3"],
        view_ids=["v_plan"],
        source_ids=["src_1"],
    )

    cand_sec = ObjectCandidate(
        candidate_id="cand_p3_sec",
        probable_family=SemanticFamily.STRUCTURAL,
        probable_type="POSSIBLE_FOUNDATION_MEMBER",
        station=12345.0,
        labels=["SECCION PILA P3"],
        related_texts=["SECCION PILA P3"],
        view_ids=["v_sec"],
        source_ids=["src_1"],
    )

    match = matcher.compare_candidates(cand_plan, cand_sec, views_dict=views_dict)

    assert match.decision == MatchDecision.SAME_OBJECT
    assert match.confidence >= 0.75
    assert match.station_score >= 0.90
    assert match.label_score >= 0.80


def test_same_station_different_labels_does_not_produce_same_object():
    """
    Test 2: Misma station + labels contradictorios (PILA P3 vs PILA P4) NO produce SAME_OBJECT.
    Produce DIFFERENT_OBJECT por contradicción explícita.
    """
    matcher = MultiViewMatcher(station_tolerance=5.0)

    cand_p3 = ObjectCandidate(
        candidate_id="cand_p3",
        probable_family=SemanticFamily.STRUCTURAL,
        station=12345.0,
        labels=["PILA P3"],
        related_texts=["PILA P3"],
        view_ids=["v1"],
        source_ids=["src_1"],
    )

    cand_p4 = ObjectCandidate(
        candidate_id="cand_p4",
        probable_family=SemanticFamily.STRUCTURAL,
        station=12345.0,
        labels=["PILA P4"],
        related_texts=["PILA P4"],
        view_ids=["v2"],
        source_ids=["src_1"],
    )

    match = matcher.compare_candidates(cand_p3, cand_p4)

    assert match.decision == MatchDecision.DIFFERENT_OBJECT
    assert any(e.criterion == "LABEL_CONFLICT" for e in match.evidence_against)
    assert match.penalties >= 0.40


def test_same_radius_circles_in_same_view_conserves_repeated_instance():
    """
    Test 3: Mismo radio en dos círculos separados en la misma vista conserva REPEATED_INSTANCE.
    """
    matcher = MultiViewMatcher()

    cand_c1 = ObjectCandidate(
        candidate_id="cand_c1",
        probable_family=SemanticFamily.STRUCTURAL,
        spatial_extent={"center": {"x": 100.0, "y": 0.0, "z": -5.0}, "radius": 1.2},
        labels=["CAD_CIRCLE_31"],
        view_ids=["v_modelspace"],
        source_ids=["src_1"],
    )

    cand_c2 = ObjectCandidate(
        candidate_id="cand_c2",
        probable_family=SemanticFamily.STRUCTURAL,
        spatial_extent={"center": {"x": 200.0, "y": 0.0, "z": -5.0}, "radius": 1.2},
        labels=["CAD_CIRCLE_32"],
        view_ids=["v_modelspace"],
        source_ids=["src_1"],
    )

    match = matcher.compare_candidates(cand_c1, cand_c2)

    assert match.decision == MatchDecision.REPEATED_INSTANCE
    assert "RULE_REPEATED_INSTANCE_SAME_VIEW" in match.rule_ids


def test_radius_and_diameter_dimensional_compatibility():
    """
    Test 4: PLAN circle radius 0.60 m + SECTION diameter 1.20 m son dimensionalmente compatibles.
    """
    matcher = MultiViewMatcher()

    cand_plan = ObjectCandidate(
        candidate_id="cand_plan_r",
        probable_family=SemanticFamily.STRUCTURAL,
        spatial_extent={"center": {"x": 10.0, "y": 10.0, "z": 0.0}, "radius": 0.60},
        parameter_candidates=[],
        view_ids=["v_plan"],
        source_ids=["src_1"],
    )

    cand_sec = ObjectCandidate(
        candidate_id="cand_sec_d",
        probable_family=SemanticFamily.STRUCTURAL,
        parameter_candidates=[
            {"candidate_type": CandidateType.MEASUREMENT.value, "value": 1.20, "unit": "m", "raw_text": "DIAMETRO=1.20 m"}
        ],
        view_ids=["v_sec"],
        source_ids=["src_1"],
    )

    match = matcher.compare_candidates(cand_plan, cand_sec)

    assert match.dimensional_score >= 0.85
    assert any(e.criterion == "DIMENSIONAL_COMPATIBILITY" for e in match.evidence_for)


def test_dimensional_mismatch_generates_conflict():
    """
    Test 5: Diámetro 1.20 m vs 2.50 m genera incompatibilidad dimensional y penalización.
    """
    matcher = MultiViewMatcher()

    cand_a = ObjectCandidate(
        candidate_id="cand_a",
        probable_family=SemanticFamily.STRUCTURAL,
        spatial_extent={"radius": 0.60},  # derived diameter = 1.20 m
        parameter_candidates=[],
        view_ids=["v1"],
        source_ids=["src_1"],
    )

    cand_b = ObjectCandidate(
        candidate_id="cand_b",
        probable_family=SemanticFamily.STRUCTURAL,
        parameter_candidates=[
            {"candidate_type": CandidateType.MEASUREMENT.value, "value": 2.50, "unit": "m", "raw_text": "DIAMETRO=2.50 m"}
        ],
        view_ids=["v2"],
        source_ids=["src_1"],
    )

    match = matcher.compare_candidates(cand_a, cand_b)

    assert any(e.criterion == "DIMENSIONAL_CONFLICT" for e in match.evidence_against)
    assert match.penalties >= 0.40


def test_callout_reference_boosts_matching_score():
    """
    Test 6: Referencia SECCION A-A ↔ CORTE A-A eleva el score de matching.
    """
    ref_resolver = ReferenceResolver()
    v1 = ViewEvidence(view_id="v1", view_type="PLAN", source=SourceReference(source_file="a.dxf"), texts=["VER CORTE A-A"])
    v2 = ViewEvidence(view_id="v2", view_type="SECTION", source=SourceReference(source_file="a.dxf"), texts=["SECCION A-A"])

    callouts = ref_resolver.find_view_callout_matches([v1, v2])
    assert len(callouts) == 1
    assert callouts[0]["tag"] == "SECTION_A-A"

    matcher = MultiViewMatcher()
    cand1 = ObjectCandidate(candidate_id="c1", probable_family=SemanticFamily.STRUCTURAL, view_ids=["v1"], source_ids=["src_1"])
    cand2 = ObjectCandidate(candidate_id="c2", probable_family=SemanticFamily.STRUCTURAL, view_ids=["v2"], source_ids=["src_1"])

    match = matcher.compare_candidates(cand1, cand2, views_dict={"v1": v1, "v2": v2}, view_callouts=callouts)
    assert any(e.criterion == "CALLOUT_REFERENCE" for e in match.evidence_for)


def test_different_object_blocks_merge_and_repeated_instance_conserves_objects():
    """
    Test 7 y 8: DIFFERENT_OBJECT bloquea merge; REPEATED_INSTANCE conserva objetos separados.
    """
    resolver = ObjectHypothesisResolver()

    c1 = ObjectCandidate(candidate_id="c1", probable_family=SemanticFamily.STRUCTURAL, probable_type="POSSIBLE_COLUMN_COMPONENT")
    c2 = ObjectCandidate(candidate_id="c2", probable_family=SemanticFamily.STRUCTURAL, probable_type="POSSIBLE_COLUMN_COMPONENT")

    # Match de tipo REPEATED_INSTANCE (no SAME_OBJECT)
    match = EvidenceMatch(
        match_id="m1",
        candidate_a_id="c1",
        candidate_b_id="c2",
        decision=MatchDecision.REPEATED_INSTANCE,
        confidence=0.75,
    )

    hyps, drafts = resolver.resolve_hypotheses_and_drafts([c1, c2], [match])

    # No deben fusionarse en 1 hipótesis de 2 miembros: deben conservar 2 hipótesis distintas
    assert len(hyps) == 2
    for h in hyps:
        assert len(h.member_candidate_ids) == 1


def test_document_conflict_generated_for_divergent_documented_values():
    """
    Test 9: DOCUMENT_CONFLICT se genera ante valores documentados incompatibles en una hipótesis consolidada.
    """
    resolver = ObjectHypothesisResolver()

    c1 = ObjectCandidate(
        candidate_id="c1",
        probable_family=SemanticFamily.PAVEMENT,
        probable_type="POSSIBLE_SURFACE_BOUNDARY",
        parameter_candidates=[
            {"candidate_type": CandidateType.MEASUREMENT.value, "raw_text": "ANCHO=7.30 m", "value": 7.30, "unit": "m", "source": {"source_file": "f1.dxf", "view_type": "PLAN"}}
        ],
        status=CandidateStatus.PARTIALLY_RESOLVED,
    )

    c2 = ObjectCandidate(
        candidate_id="c2",
        probable_family=SemanticFamily.PAVEMENT,
        probable_type="POSSIBLE_SURFACE_BOUNDARY",
        parameter_candidates=[
            {"candidate_type": CandidateType.MEASUREMENT.value, "raw_text": "ANCHO=10.50 m", "value": 10.50, "unit": "m", "source": {"source_file": "f2.dxf", "view_type": "SECTION"}}
        ],
        status=CandidateStatus.PARTIALLY_RESOLVED,
    )

    match = EvidenceMatch(
        match_id="m_same",
        candidate_a_id="c1",
        candidate_b_id="c2",
        decision=MatchDecision.SAME_OBJECT,
        confidence=0.85,
    )

    hyps, drafts = resolver.resolve_hypotheses_and_drafts([c1, c2], [match])

    assert len(drafts) == 1
    draft = drafts[0]
    assert len(draft.conflicts) == 1
    conflict = draft.conflicts[0]
    assert conflict.parameter == "ANCHO"
    assert conflict.value_a == 7.30
    assert conflict.value_b == 10.50


def test_deterministic_object_id_and_empty_geometry_and_no_ifc(tmp_path):
    """
    Test 10, 11 y 12: object_id es determinista, geometry_definition sigue vacía y no se crea geometría IFC.
    """
    id1 = ObjectHypothesisResolver.generate_deterministic_object_id(SemanticFamily.STRUCTURAL, 12345.0, "PILA P3", ["c1", "c2"])
    id2 = ObjectHypothesisResolver.generate_deterministic_object_id(SemanticFamily.STRUCTURAL, 12345.0, "PILA P3", ["c2", "c1"])

    assert id1 == id2
    assert id1.startswith("obj_STRU_PK12345_")

    # Ejecutar pipeline real
    dxf_sample = Path("scratch/test_infrastructure_sample.dxf").resolve()
    config = AgentConfig(output_dir=tmp_path)
    pipeline = ReconstructionPipeline(config=config, project_name="Test_v02B")

    result = pipeline.run([dxf_sample])

    # No se crea IFC
    assert result["model_generation"]["performed"] is False

    # Verificar que los reconstructed objects tienen geometry_definition VACÍA
    semantic_dir = tmp_path / "semantic"
    with (semantic_dir / "reconstructed_objects.json").open("r", encoding="utf-8") as f:
        reconstructed = json.load(f)

    assert len(reconstructed) > 0
    for robj in reconstructed:
        assert robj["geometry_definition"] == {}
        assert robj["ifc_class"] is None
