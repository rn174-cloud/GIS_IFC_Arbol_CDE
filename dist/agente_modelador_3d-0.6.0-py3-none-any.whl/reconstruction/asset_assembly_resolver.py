"""
reconstruction/asset_assembly_resolver.py
Capa genérica AssetAssemblyResolver para v0.6.0.
Construye la AssetAssemblyHypothesis que representa el conjunto construido antes de la geometría fina.
"""
from __future__ import annotations

import uuid
from typing import Any, Optional

from core.models import (
    AssetAssemblyHypothesis,
    AssetContext,
    DocumentRole,
    EvidenceStatus,
    FacilityType,
    SourceDocument,
    VisualContextAssessment,
)


class AssetAssemblyResolver:
    """
    Formula hipótesis de ensamblaje macro combinando el contexto del activo,
    la evaluación visual multimodal y los roles de documentos disponibles.
    """

    def resolve_assembly_hypothesis(
        self,
        asset_context: AssetContext,
        visual_assessment: Optional[VisualContextAssessment] = None,
        documents: Optional[list[SourceDocument]] = None,
        document_roles: Optional[dict[str, DocumentRole]] = None,
    ) -> AssetAssemblyHypothesis:
        """
        Crea una AssetAssemblyHypothesis estructurada y trazable.
        """
        documents = documents or []
        document_roles = document_roles or {}

        assembly_id = f"asm_{uuid.uuid4().hex[:10]}"
        fac_type = asset_context.facility_or_asset_type

        # 1. Heredar o refinar sistemas y componentes según contexto y visual assessment
        systems = list(asset_context.system_contexts)
        subsystems = list(asset_context.subsystem_contexts)
        expected_components = list(asset_context.visible_or_documented_components)

        if visual_assessment:
            for sys in visual_assessment.possible_systems:
                if sys not in systems:
                    systems.append(sys)
            for comp in visual_assessment.possible_components:
                if comp not in expected_components:
                    expected_components.append(comp)

        # 2. Relaciones esperadas entre sistemas de acuerdo a la tipología del activo
        possible_relations = self._derive_expected_system_relations(fac_type)

        # 3. Espacialización inicial
        spatial_regions = self._derive_spatial_regions(asset_context, visual_assessment)

        # 4. Auditoría de fuentes
        doc_paths = [str(d.path) for d in documents]
        visual_sources = []
        if visual_assessment and visual_assessment.visible_features:
            visual_sources.append("MULTIMODAL_VISUAL_SET")

        # 5. Identificar preguntas no resueltas y gaps de información
        unresolved_questions: list[str] = []
        data_gaps: list[str] = []
        contradictions: list[str] = []

        # Verificar si disponemos de documentos de disposición general vs detalles
        has_general_arrangement = any(
            role in [DocumentRole.GENERAL_ARRANGEMENT, DocumentRole.PLAN, DocumentRole.AS_BUILT]
            for role in document_roles.values()
        )
        has_typology_detail = any(
            role in [DocumentRole.DETAIL, DocumentRole.SECTION]
            for role in document_roles.values()
        )
        has_inventory_or_schedule = any(
            role in [DocumentRole.INVENTORY, DocumentRole.SCHEDULE, DocumentRole.GIS_SOURCE]
            for role in document_roles.values()
        )

        if not has_general_arrangement and not has_inventory_or_schedule:
            unresolved_questions.append(
                "Missing authoritative source for general layout, cardinality and component placement."
            )
            data_gaps.append("GENERAL_ARRANGEMENT_OR_INVENTORY_ABSENT")

        if not has_typology_detail:
            unresolved_questions.append(
                "Missing detailed section or fabrication drawing defining cross-sectional dimensions."
            )
            data_gaps.append("TYPOLOGY_CROSS_SECTION_DETAIL_ABSENT")

        if visual_assessment:
            unresolved_questions.extend(visual_assessment.unresolved_questions[:4])

        # 6. Evaluar status y confidence de la hipótesis de ensamblaje
        if has_general_arrangement and has_typology_detail:
            status = EvidenceStatus.DOCUMENTED
            confidence = 0.85
        elif has_general_arrangement or has_inventory_or_schedule:
            status = EvidenceStatus.DERIVED
            confidence = 0.70
        elif asset_context.evidence_status == EvidenceStatus.DOCUMENTED:
            status = EvidenceStatus.DERIVED
            confidence = 0.65
        else:
            status = EvidenceStatus.INFERRED
            confidence = 0.45

        return AssetAssemblyHypothesis(
            assembly_id=assembly_id,
            asset_context=asset_context.asset_context,
            facility_type=fac_type,
            systems=systems,
            subsystems=subsystems,
            expected_component_types=expected_components,
            possible_relations=possible_relations,
            spatial_regions=spatial_regions,
            source_documents=doc_paths,
            visual_sources=visual_sources,
            evidence_status=status,
            confidence=confidence,
            unresolved_questions=unresolved_questions,
            data_gaps=data_gaps,
            contradictions=contradictions,
        )

    def _derive_expected_system_relations(self, facility_type: str) -> list[dict[str, Any]]:
        """
        Retorna relaciones topológicas y funcionales arquetípicas del tipo de activo.
        """
        if facility_type == FacilityType.BRIDGE.value:
            return [
                {"source": "SUPERSTRUCTURE", "relation": "SUPPORTED_BY", "target": "SUBSTRUCTURE"},
                {"source": "SUBSTRUCTURE", "relation": "SUPPORTED_BY", "target": "FOUNDATIONS"},
                {"source": "ROADWAY", "relation": "LOCATED_ON", "target": "SUPERSTRUCTURE"},
                {"source": "SAFETY_AND_EQUIPMENT", "relation": "LOCATED_ON", "target": "SUPERSTRUCTURE"},
            ]
        elif facility_type == FacilityType.TOLL_PLAZA.value:
            return [
                {"source": "CONTROL_CABINS", "relation": "LOCATED_ON", "target": "ISLANDS"},
                {"source": "CANOPY_STRUCTURE", "relation": "SUPPORTS", "target": "ROOF_FRAME"},
                {"source": "TOLL_LANES", "relation": "CONTAINS", "target": "ISLANDS"},
            ]
        elif facility_type == FacilityType.LIGHTING_SYSTEM.value:
            return [
                {"source": "LUMINAIRES", "relation": "LOCATED_ON", "target": "SUPPORT_STRUCTURES"},
                {"source": "SUPPORT_STRUCTURES", "relation": "SUPPORTED_BY", "target": "FOUNDATIONS"},
                {"source": "ELECTRICAL_CIRCUITS", "relation": "FEEDS", "target": "LUMINAIRES"},
            ]
        elif facility_type == FacilityType.DRAINAGE_SYSTEM.value:
            return [
                {"source": "INLETS_AND_CHAMBERS", "relation": "FEEDS", "target": "CONVEYANCE_NETWORK"},
                {"source": "CONVEYANCE_NETWORK", "relation": "DRAINS_TO", "target": "OUTFALLS"},
            ]
        elif facility_type == FacilityType.ROAD_CORRIDOR.value:
            return [
                {"source": "SAFETY_BARRIERS", "relation": "LOCATED_ON", "target": "PAVEMENT_STRUCTURE"},
                {"source": "SIGNAGE_AND_MARKING", "relation": "LOCATED_ON", "target": "PAVEMENT_STRUCTURE"},
                {"source": "PAVEMENT_STRUCTURE", "relation": "DRAINS_TO", "target": "DRAINAGE"},
            ]
        elif facility_type == FacilityType.INDUSTRIAL_FACILITY.value:
            return [
                {"source": "PROCESS_EQUIPMENT", "relation": "LOCATED_IN", "target": "STRUCTURAL_FRAME"},
                {"source": "STRUCTURAL_FRAME", "relation": "SUPPORTED_BY", "target": "FOUNDATION_SLAB"},
                {"source": "PIPING", "relation": "CONNECTED_TO", "target": "PROCESS_EQUIPMENT"},
            ]
        else:
            return [
                {"source": "SECONDARY_SYSTEMS", "relation": "SUPPORTED_BY", "target": "PRIMARY_STRUCTURE"},
                {"source": "PRIMARY_STRUCTURE", "relation": "SUPPORTED_BY", "target": "FOUNDATION"},
            ]

    def _derive_spatial_regions(
        self, asset_context: AssetContext, visual_assessment: Optional[VisualContextAssessment]
    ) -> list[dict[str, Any]]:
        """
        Define regiones espaciales primarias para contextualizar búsqueda geométrica.
        """
        fac = asset_context.facility_or_asset_type
        if fac == FacilityType.BRIDGE.value:
            return [
                {"region_name": "REGION_SUPERSTRUCTURE", "elevation_band": "ABOVE_GRADE", "scope": "DECK_AND_GIRDERS"},
                {"region_name": "REGION_SUBSTRUCTURE", "elevation_band": "GRADE_TO_DECK", "scope": "PIERS_AND_ABUTMENTS"},
                {"region_name": "REGION_FOUNDATION", "elevation_band": "BELOW_GRADE", "scope": "PILES_AND_FOOTINGS"},
            ]
        elif fac == FacilityType.TOLL_PLAZA.value:
            return [
                {"region_name": "REGION_CANOPY_OVERHEAD", "elevation_band": "OVERHEAD", "scope": "ROOF_TRUSSES_AND_LIGHTING"},
                {"region_name": "REGION_PLAZA_SURFACE", "elevation_band": "SURFACE", "scope": "ISLANDS_AND_CABINS"},
            ]
        elif fac == FacilityType.LIGHTING_SYSTEM.value:
            return [
                {"region_name": "REGION_POLE_MAST", "elevation_band": "ELEVATED", "scope": "LUMINAIRE_AND_BRACKET"},
                {"region_name": "REGION_BASE_FOUNDATION", "elevation_band": "GROUND_LEVEL", "scope": "ANCHOR_BOLTS_AND_BASE"},
            ]
        else:
            return [
                {"region_name": "REGION_PRIMARY_SUPERSTRUCTURE", "elevation_band": "UPPER", "scope": "MAIN_FRAME"},
                {"region_name": "REGION_PRIMARY_SUBSTRUCTURE", "elevation_band": "LOWER", "scope": "SUBGRADE_BASE"},
            ]
