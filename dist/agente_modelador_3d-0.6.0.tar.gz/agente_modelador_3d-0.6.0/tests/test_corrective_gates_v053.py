"""
tests/test_corrective_gates_v053.py
Batería de 13 tests correctivos obligatorios para compuertas v0.5.3.
"""
from __future__ import annotations

from pathlib import Path
import pytest

from core.models import (
    CandidateStatus,
    CandidateType,
    ConsolidatedParameter,
    DataGap,
    DocumentConflict,
    EvidenceStatus,
    GeometryRecipe,
    ObjectCandidate,
    ObjectConfidenceBreakdown,
    ObjectHypothesis,
    ParameterBindingCandidate,
    ParameterValue,
    ParametricGeometry,
    QualityConfidenceLevel,
    RecipeType,
    ReconstructedObject,
    SemanticFamily,
    SourceReference,
    UnitResolutionStatus,
)
from ifc.authoring_pipeline import IFCAuthoringPipeline
from ifc.semantic_mapper import IFCSemanticMapper
from reconstruction.geometry_validator import GeometryValidator
from reconstruction.multidocument_synthesizer import MultidocumentSynthesizer
from reconstruction.parametric_geometry_builder import ParametricGeometryBuilder
from reconstruction.unit_resolver import UnitResolver


def test_1_cad_unit_cannot_silently_become_metre():
    """1. CAD_UNIT cannot silently become metre; unresolved CAD_UNIT yields conversion_factor=None."""
    resolver = UnitResolver()
    rec = resolver.resolve_measurement_unit(
        raw_value=12.5,
        declared_unit="CAD_UNIT",
        raw_text="12.5",
        doc_evidence={"dominant_unit": None, "primary_evidence": [], "secondary_evidence": []},
    )

    assert rec.unit_resolution_status == UnitResolutionStatus.UNIT_UNRESOLVED
    assert rec.resolved_value is None
    assert rec.resolved_unit is None
    assert rec.conversion_factor is None
    assert rec.raw_value == 12.5
    assert rec.raw_unit == "CAD_UNIT"


def test_2_unresolved_critical_unit_blocks_built():
    """2. Unresolved critical parameter unit blocks BUILT."""
    builder = ParametricGeometryBuilder()

    obj = ReconstructedObject(
        object_id="obj_valid_type_01",
        name="COLUMNA_01",
        object_type="COLUMNA",
        family=SemanticFamily.STRUCTURAL.value,
        confidence_breakdown=ObjectConfidenceBreakdown(
            identity_confidence=QualityConfidenceLevel.HIGH,
            semantic_confidence=QualityConfidenceLevel.HIGH,
            parameter_confidence=QualityConfidenceLevel.MEDIUM,
            geometry_confidence=QualityConfidenceLevel.NOT_EVALUATED,
        ),
    )
    # Parámetro con unidad física no resuelta
    p_diam = ParameterValue(
        name="DIAMETRO",
        value=1.0,
        unit="CAD_UNIT",
        status=EvidenceStatus.DOCUMENTED,
    )
    p_diam.unit_resolution_status = UnitResolutionStatus.UNIT_UNRESOLVED  # type: ignore[attr-defined]
    obj.add_parameter(p_diam)

    p_alt = ParameterValue(
        name="ALTURA",
        value=10.0,
        unit="m",
        status=EvidenceStatus.DOCUMENTED,
    )
    p_alt.unit_resolution_status = UnitResolutionStatus.UNIT_DOCUMENTED  # type: ignore[attr-defined]
    obj.add_parameter(p_alt)

    recipe = GeometryRecipe(
        recipe_id="recipe_col",
        object_id=obj.object_id,
        recipe_type=RecipeType.CIRCULAR_EXTRUSION,
        required_parameters=["RADIO", "ALTURA"],
        source_parameters={"RADIO": 0.5, "ALTURA": 10.0},
    )

    geom = builder.build_geometry(obj=obj, recipe=recipe)
    assert not geom.is_built
    assert "UNIT_UNRESOLVED" in (geom.build_failure_reason or "")


def test_3_unknown_object_blocks_built():
    """3. UNKNOWN_OBJECT blocks BUILT."""
    builder = ParametricGeometryBuilder()

    obj = ReconstructedObject(
        object_id="obj_unkn_01",
        name="UNKNOWN_OBJECT_01",
        object_type="UNKNOWN_OBJECT",
        family=SemanticFamily.STRUCTURAL.value,
        confidence_breakdown=ObjectConfidenceBreakdown(
            identity_confidence=QualityConfidenceLevel.HIGH,
            semantic_confidence=QualityConfidenceLevel.HIGH,
        ),
    )
    recipe = GeometryRecipe(
        recipe_id="rec_01",
        object_id=obj.object_id,
        recipe_type=RecipeType.CIRCULAR_EXTRUSION,
        required_parameters=["RADIO", "ALTURA"],
    )

    geom = builder.build_geometry(obj=obj, recipe=recipe)
    assert not geom.is_built
    assert "INSUFFICIENT_SEMANTICS: UNKNOWN_OBJECT" in (geom.build_failure_reason or "")


def test_4_unknown_family_blocks_built():
    """4. UNKNOWN family blocks BUILT."""
    builder = ParametricGeometryBuilder()

    obj = ReconstructedObject(
        object_id="obj_unkn_fam",
        name="COLUMN_01",
        object_type="COLUMNA",
        family="UNKNOWN",
        confidence_breakdown=ObjectConfidenceBreakdown(
            identity_confidence=QualityConfidenceLevel.HIGH,
            semantic_confidence=QualityConfidenceLevel.HIGH,
        ),
    )
    recipe = GeometryRecipe(
        recipe_id="rec_02",
        object_id=obj.object_id,
        recipe_type=RecipeType.CIRCULAR_EXTRUSION,
        required_parameters=["RADIO", "ALTURA"],
    )

    geom = builder.build_geometry(obj=obj, recipe=recipe)
    assert not geom.is_built
    assert "INSUFFICIENT_SEMANTICS: UNKNOWN_FAMILY" in (geom.build_failure_reason or "")


def test_5_low_identity_blocks_built():
    """5. LOW / insufficient identity blocks BUILT."""
    builder = ParametricGeometryBuilder()

    obj = ReconstructedObject(
        object_id="obj_low_id",
        name="COLUMNA_01",
        object_type="COLUMNA",
        family=SemanticFamily.STRUCTURAL.value,
        confidence_breakdown=ObjectConfidenceBreakdown(
            identity_confidence=QualityConfidenceLevel.LOW,
            semantic_confidence=QualityConfidenceLevel.HIGH,
        ),
    )
    recipe = GeometryRecipe(
        recipe_id="rec_03",
        object_id=obj.object_id,
        recipe_type=RecipeType.CIRCULAR_EXTRUSION,
        required_parameters=["RADIO", "ALTURA"],
    )

    geom = builder.build_geometry(obj=obj, recipe=recipe)
    assert not geom.is_built
    assert "INSUFFICIENT_IDENTITY" in (geom.build_failure_reason or "")


def test_6_insufficient_semantic_resolution_blocks_built():
    """6. Insufficient semantic resolution blocks BUILT."""
    builder = ParametricGeometryBuilder()

    obj = ReconstructedObject(
        object_id="obj_low_sem",
        name="COLUMNA_01",
        object_type="COLUMNA",
        family=SemanticFamily.STRUCTURAL.value,
        confidence_breakdown=ObjectConfidenceBreakdown(
            identity_confidence=QualityConfidenceLevel.HIGH,
            semantic_confidence=QualityConfidenceLevel.LOW,
        ),
    )
    recipe = GeometryRecipe(
        recipe_id="rec_04",
        object_id=obj.object_id,
        recipe_type=RecipeType.CIRCULAR_EXTRUSION,
        required_parameters=["RADIO", "ALTURA"],
    )

    geom = builder.build_geometry(obj=obj, recipe=recipe)
    assert not geom.is_built
    assert "INSUFFICIENT_SEMANTICS" in (geom.build_failure_reason or "")


def test_7_critical_datagap_blocks_built():
    """7. Critical DataGap blocks BUILT."""
    builder = ParametricGeometryBuilder()

    obj = ReconstructedObject(
        object_id="obj_with_gap",
        name="COLUMNA_01",
        object_type="COLUMNA",
        family=SemanticFamily.STRUCTURAL.value,
        confidence_breakdown=ObjectConfidenceBreakdown(
            identity_confidence=QualityConfidenceLevel.HIGH,
            semantic_confidence=QualityConfidenceLevel.HIGH,
        ),
    )
    obj.data_gaps.append(
        DataGap(
            object_id=obj.object_id,
            parameter="ALTURA",
            description="Falta cota de altura de columna",
            criticality="HIGH",
            gap_category="CRITICAL_FOR_GEOMETRY",
        )
    )
    recipe = GeometryRecipe(
        recipe_id="rec_05",
        object_id=obj.object_id,
        recipe_type=RecipeType.CIRCULAR_EXTRUSION,
        required_parameters=["RADIO", "ALTURA"],
    )

    geom = builder.build_geometry(obj=obj, recipe=recipe)
    assert not geom.is_built
    assert "CRITICAL_DATA_GAP" in (geom.build_failure_reason or "")


def test_8_different_documents_cannot_merge_critical_parameters_without_same_object():
    """8. Different documents cannot merge critical parameters without SAME_OBJECT."""
    synthesizer = MultidocumentSynthesizer()

    hyp = ObjectHypothesis(
        hypothesis_id="hyp_multi_no_same",
        source_ids=["doc_a.dwg", "doc_b.dwg"],
        identity_gate_status="MULTIDOCUMENT_SYNTHESIS_NOT_AUTHORIZED",
    )

    b_a = ParameterBindingCandidate(
        parameter_name="ALTURA",
        binding_method="EXPLICIT_TEXT_HEIGHT",
        raw_value=10.0,
        raw_unit="m",
        resolved_value=10.0,
        resolved_unit="m",
        conversion_factor=1.0,
        unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED,
        source_id="doc_a.dwg",
    )
    b_b = ParameterBindingCandidate(
        parameter_name="DIAMETRO",
        binding_method="EXPLICIT_TEXT_DIAMETER",
        raw_value=1.2,
        raw_unit="m",
        resolved_value=1.2,
        resolved_unit="m",
        conversion_factor=1.0,
        unit_resolution_status=UnitResolutionStatus.UNIT_DOCUMENTED,
        source_id="doc_b.dwg",
    )

    consolidated, conflicts, readiness = synthesizer.synthesize_parameters_for_hypothesis(
        hypothesis=hyp,
        binding_candidates=[b_a, b_b],
    )

    # El parámetro del documento secundario doc_b.dwg no debe haberse fusionado
    assert "ALTURA" in consolidated
    assert "DIAMETRO" not in consolidated
    assert not readiness.is_ready_for_built


def test_9_ifcbuildingelementproxy_fallback_rejected_for_reconstructed_physical_asset():
    """9. IfcBuildingElementProxy fallback is rejected for reconstructed physical asset."""
    mapper = IFCSemanticMapper()

    obj = ReconstructedObject(
        object_id="obj_unknown_asset",
        name="UNKNOWN_01",
        object_type="UNKNOWN_OBJECT",
        family="UNKNOWN",
    )

    decision = mapper.resolve_mapping(obj)

    assert decision.selected_ifc_class != "IfcBuildingElementProxy"
    assert decision.rule_id == "SEMANTIC_MAPPING_NOT_SUPPORTED"
    assert decision.fallback_used is True
    assert decision.mapping_confidence == 0.0


def test_10_ifc_authoring_rejects_fallback_used_mapping(tmp_path):
    """10. IFC authoring rejects fallback_used mapping."""
    authoring = IFCAuthoringPipeline(
        project_name="Test_Gate",
        guid_registry_path=tmp_path / "guid_reg.json",
    )

    obj = ReconstructedObject(
        object_id="obj_proxy_attempt",
        name="UNKNOWN_OBJ",
        object_type="UNKNOWN_OBJECT",
        family="UNKNOWN",
    )
    geom = ParametricGeometry(
        geometry_id="geom_01",
        object_id=obj.object_id,
        recipe_id="rec_01",
        geometry_type=RecipeType.CIRCULAR_EXTRUSION,
        parameters={"RADIO": 0.5, "ALTURA": 5.0},
        is_built=True,
        geometry_confidence=QualityConfidenceLevel.VERIFIED,
    )

    model, report = authoring.author_ifc_model([(obj, geom)])

    assert report["authorized_products_count"] == 0
    assert report["not_authorized_count"] == 1
    assert "IFC_NOT_AUTHORIZED" in report["not_authorized"][0]["reason"]


def test_11_cylindrical_round_trip_validates_diametro_against_2_radio():
    """11. Cylindrical round-trip validates DIAMETRO against 2*RADIO."""
    validator = GeometryValidator(default_tolerance=0.005)

    obj = ReconstructedObject(
        object_id="obj_col_cyl",
        name="COLUMNA_01",
        object_type="COLUMNA",
        family=SemanticFamily.STRUCTURAL.value,
    )
    # Objeto documenta DIAMETRO = 1.0 m y ALTURA = 10.0 m
    obj.add_parameter(ParameterValue(name="DIAMETRO", value=1.0, unit="m", status=EvidenceStatus.DOCUMENTED))
    obj.add_parameter(ParameterValue(name="ALTURA", value=10.0, unit="m", status=EvidenceStatus.DOCUMENTED))

    # Geometría generada por receta usa RADIO = 0.5 m y ALTURA = 10.0 m
    geom = ParametricGeometry(
        geometry_id="geom_cyl",
        object_id=obj.object_id,
        recipe_id="rec_cyl",
        geometry_type=RecipeType.CIRCULAR_EXTRUSION,
        parameters={"RADIO": 0.5, "ALTURA": 10.0},
        bounding_box={"minx": -0.5, "maxx": 0.5, "miny": -0.5, "maxy": 0.5, "minz": 0.0, "maxz": 10.0},
        is_built=True,
        geometry_confidence=QualityConfidenceLevel.HIGH,
    )

    results, final_conf = validator.validate_geometry(obj=obj, geom=geom)

    assert final_conf == QualityConfidenceLevel.VERIFIED
    radio_check = next((r for r in results if r.get("derived_expected_parameter") == "RADIO"), None)
    assert radio_check is not None
    assert radio_check["source_parameter"] == "DIAMETRO"
    assert radio_check["expected"] == 0.5
    assert radio_check["actual"] == 0.5
    assert radio_check["status"] == "PASS"


def test_12_missing_critical_round_trip_parameter_yields_round_trip_incomplete():
    """12. Missing critical round-trip parameter yields ROUND_TRIP_INCOMPLETE and not VERIFIED."""
    validator = GeometryValidator(default_tolerance=0.005)

    obj = ReconstructedObject(
        object_id="obj_missing_param",
        name="COLUMNA_01",
        object_type="COLUMNA",
        family=SemanticFamily.STRUCTURAL.value,
    )
    # Objeto solo documenta ALTURA pero no documenta ni RADIO ni DIAMETRO
    obj.add_parameter(ParameterValue(name="ALTURA", value=10.0, unit="m", status=EvidenceStatus.DOCUMENTED))

    # Geometría tiene RADIO inventado/generado
    geom = ParametricGeometry(
        geometry_id="geom_incomplete",
        object_id=obj.object_id,
        recipe_id="rec_cyl",
        geometry_type=RecipeType.CIRCULAR_EXTRUSION,
        parameters={"RADIO": 0.5, "ALTURA": 10.0},
        bounding_box={"minx": -0.5, "maxx": 0.5, "miny": -0.5, "maxy": 0.5, "minz": 0.0, "maxz": 10.0},
        is_built=True,
        geometry_confidence=QualityConfidenceLevel.HIGH,
    )

    results, final_conf = validator.validate_geometry(obj=obj, geom=geom)

    assert final_conf != QualityConfidenceLevel.VERIFIED
    assert not geom.is_built
    assert geom.build_failure_reason == "ROUND_TRIP_INCOMPLETE"
    radio_check = next((r for r in results if r.get("derived_expected_parameter") == "RADIO"), None)
    assert radio_check is not None
    assert radio_check["status"] == "FAIL"
    assert "ROUND_TRIP_INCOMPLETE" in radio_check.get("reason", "")


def test_13_geometry_verified_alone_cannot_authorize_built():
    """13. Geometry VERIFIED alone cannot authorize BUILT when identity or semantics fail."""
    builder = ParametricGeometryBuilder()

    # Objeto con geometría que matemáticamente compilaría pero con identidad LOW y semántica UNKNOWN
    obj = ReconstructedObject(
        object_id="obj_verified_geom_only",
        name="UNKNOWN_01",
        object_type="UNKNOWN_OBJECT",
        family="UNKNOWN",
        confidence_breakdown=ObjectConfidenceBreakdown(
            identity_confidence=QualityConfidenceLevel.LOW,
            semantic_confidence=QualityConfidenceLevel.LOW,
            geometry_confidence=QualityConfidenceLevel.VERIFIED,
        ),
    )
    recipe = GeometryRecipe(
        recipe_id="rec_fake",
        object_id=obj.object_id,
        recipe_type=RecipeType.CIRCULAR_EXTRUSION,
        required_parameters=["RADIO", "ALTURA"],
        source_parameters={"RADIO": 0.5, "ALTURA": 10.0},
    )

    geom = builder.build_geometry(obj=obj, recipe=recipe)

    assert not geom.is_built
    assert geom.build_failure_reason in {
        "INSUFFICIENT_IDENTITY",
        "INSUFFICIENT_SEMANTICS",
        "INSUFFICIENT_SEMANTICS: UNKNOWN_OBJECT",
        "INSUFFICIENT_SEMANTICS: UNKNOWN_FAMILY",
    }
