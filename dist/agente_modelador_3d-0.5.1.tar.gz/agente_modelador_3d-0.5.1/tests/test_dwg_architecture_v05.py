import os
import tempfile
from pathlib import Path
import pytest
import ezdxf

from core.canonical_cad import (
    CanonicalCADBlock,
    CanonicalCADBlockReference,
    CanonicalCADDimension,
    CanonicalCADDocument,
    CanonicalCADEntity,
    CanonicalCADLayer,
    CanonicalCADLayout,
    CanonicalCADText,
    CanonicalCADViewport,
    CanonicalCADXRef,
    CanonicalIngestionStrategy,
    CanonicalSpaceType,
    CanonicalUnitStatus,
    CanonicalXRefStatus,
)
from readers.dwg.base import (
    CapabilityStatus,
    DWGProvider,
    ProviderCapabilities,
    ProviderHealth,
)
from readers.dwg.libredwg_provider import LibreDWGProvider
from readers.dwg.registry import DWGProviderRegistry, get_dwg_registry
from readers.dwg_reader import DWGReader
from readers.dxf_reader import DXFReader


# ==============================================================================
# 1. CANONICAL CAD MODEL TESTS (FIXTURES TEST_FIXTURE_ONLY)
# ==============================================================================

@pytest.fixture
def test_fixture_dxf(tmp_path: Path) -> Path:
    """Fixture CAD mínima genérica y neutral (TEST_FIXTURE_ONLY)."""
    dxf_path = tmp_path / "fixture_sample_TEST_FIXTURE_ONLY.dxf"
    doc = ezdxf.new("R2010")
    msp = doc.modelspace()

    # Modelspace entity with handle and layer
    msp.add_line((0, 0), (100, 0), dxfattribs={"layer": "TEST_BEAM_LAYER"})
    msp.add_circle((50, 50), 25, dxfattribs={"layer": "TEST_PIER_LAYER"})
    msp.add_text("STATION_100", dxfattribs={"layer": "TEST_TEXT_LAYER"}).set_placement((10, 20))

    # Block definition and instance
    blk = doc.blocks.new(name="TEST_FOOTING_BLOCK")
    blk.add_line((0, 0), (10, 10))
    msp.add_blockref("TEST_FOOTING_BLOCK", (200, 300))

    doc.header["$INSUNITS"] = 6  # Meters

    doc.saveas(dxf_path)
    return dxf_path


def test_canonical_model_contract_preservation(test_fixture_dxf: Path):
    """Test 1: DXF produce el contrato canónico esperado con metadatos neutrales."""
    reader = DXFReader()
    canonical = reader.read_canonical(test_fixture_dxf)

    assert isinstance(canonical, CanonicalCADDocument)
    assert canonical.source_format == "DXF"
    assert canonical.provider == "EZDXF"
    assert canonical.source_path.name == test_fixture_dxf.name
    assert canonical.units == "m"
    assert canonical.unit_status == CanonicalUnitStatus.DOCUMENTED


def test_canonical_handle_and_layer_preserved(test_fixture_dxf: Path):
    """Test 2 & 3: Los handles y capas originales se preservan en CanonicalCADEntity."""
    reader = DXFReader()
    canonical = reader.read_canonical(test_fixture_dxf)

    assert len(canonical.entities) >= 3
    for ent in canonical.entities:
        assert ent.handle is not None
        assert ent.layer is not None
        assert ent.entity_id.startswith(canonical.source_id)

    layers = set(canonical.layers.keys())
    assert "TEST_BEAM_LAYER" in layers
    assert "TEST_PIER_LAYER" in layers


def test_canonical_block_definition_and_instance_separated(test_fixture_dxf: Path):
    """Test 4: Las definiciones de bloques y sus instancias permanecen estrictamente separadas."""
    reader = DXFReader()
    canonical = reader.read_canonical(test_fixture_dxf)

    assert "TEST_FOOTING_BLOCK" in canonical.blocks
    block_def = canonical.blocks["TEST_FOOTING_BLOCK"]
    assert block_def.name == "TEST_FOOTING_BLOCK"

    # Verificar que el bloque no se explotó automáticamente en entidades básicas
    entities_in_msp = [e for e in canonical.entities if e.space == CanonicalSpaceType.MODELSPACE]
    assert any(e.entity_type == "INSERT" for e in entities_in_msp)


def test_canonical_text_preserved(test_fixture_dxf: Path):
    """Test 6: El texto y sus coordenadas de inserción se conservan en CanonicalCADText."""
    reader = DXFReader()
    canonical = reader.read_canonical(test_fixture_dxf)

    texts = [t for t in canonical.texts if t.text == "STATION_100"]
    assert len(texts) == 1
    assert texts[0].layer == "TEST_TEXT_LAYER"
    assert texts[0].insertion_point[0] == 10.0
    assert texts[0].insertion_point[1] == 20.0


def test_canonical_dimension_supported_contract():
    """Test 7: CanonicalCADDimension registra cotas con soporte estructurado."""
    dim = CanonicalCADDimension(
        handle="A12F",
        layer="COTAS",
        dimension_type="ALIGNED",
        measurement=25.4,
        text_override="25.40 m",
        definition_points=[(0, 0, 0), (25.4, 0, 0)],
        status="SUPPORTED",
    )
    d_dict = dim.to_dict()
    assert d_dict["measurement"] == 25.4
    assert d_dict["status"] == "SUPPORTED"
    assert d_dict["text_override"] == "25.40 m"


def test_canonical_modelspace_and_paperspace_separated(tmp_path: Path):
    """Test 8 & 9: Modelspace y paperspace no se mezclan automáticamente."""
    dxf_path = tmp_path / "fixture_spaces_TEST_FIXTURE_ONLY.dxf"
    doc = ezdxf.new("R2010")
    msp = doc.modelspace()
    msp.add_line((0, 0), (10, 0), dxfattribs={"layer": "MODEL_LINE"})

    psp = doc.layout("Layout1")
    psp.add_circle((0, 0), 5, dxfattribs={"layer": "PAPER_CIRCLE"})

    doc.saveas(dxf_path)

    reader = DXFReader()
    canonical = reader.read_canonical(dxf_path)

    msp_ents = canonical.modelspace_entities
    psp_ents = canonical.paperspace_entities

    assert any(e.layer == "MODEL_LINE" for e in msp_ents)
    assert not any(e.layer == "PAPER_CIRCLE" for e in msp_ents)
    assert any(e.layer == "PAPER_CIRCLE" for e in psp_ents)


def test_canonical_unknown_units_not_converted(tmp_path: Path):
    """Test 10: Unidades no documentadas (UNKNOWN) no se convierten silenciosamente a metros."""
    dxf_path = tmp_path / "fixture_nounits_TEST_FIXTURE_ONLY.dxf"
    doc = ezdxf.new("R2010")
    doc.modelspace().add_line((0, 0), (10, 0))
    # INSUNITS 0 = Unspecified / Unknown units
    doc.header["$INSUNITS"] = 0
    doc.saveas(dxf_path)

    reader = DXFReader()
    canonical = reader.read_canonical(dxf_path)

    assert canonical.units is None
    assert canonical.unit_status == CanonicalUnitStatus.UNKNOWN


def test_canonical_crs_not_invented(test_fixture_dxf: Path):
    """Test 11: Si la fuente no documenta CRS, permanece en None sin inventar EPSG."""
    reader = DXFReader()
    canonical = reader.read_canonical(test_fixture_dxf)
    assert canonical.crs_if_documented is None


def test_canonical_unsupported_entities_not_silently_dropped():
    """Test 12: Entidades no soportadas se auditan explícitamente en unsupported_entities."""
    doc = CanonicalCADDocument(
        source_id="test_src_01",
        source_path=Path("dummy_TEST_FIXTURE_ONLY.dwg"),
        source_format="DWG",
        unsupported_entities=[
            {"handle": "UNSUP1", "raw_type": "PROPRIETARY_PROXY_ENTITY", "reason": "No mesh available"}
        ],
    )
    assert len(doc.unsupported_entities) == 1
    assert doc.unsupported_entities[0]["raw_type"] == "PROPRIETARY_PROXY_ENTITY"


def test_canonical_source_id_and_intermediate_isolation(tmp_path: Path):
    """Test 13 & 14: source_id y source_path corresponden al archivo primario, nunca al intermediario."""
    dwg_fake_path = tmp_path / "primary_source_TEST_FIXTURE_ONLY.dwg"
    dwg_fake_path.write_bytes(b"AC1032FAKEBINARYHEADER" + b"\x00" * 100)

    provider = LibreDWGProvider()
    inspect_info = provider.inspect(dwg_fake_path)

    assert inspect_info["filename"] == "primary_source_TEST_FIXTURE_ONLY.dwg"
    assert inspect_info["dwg_version"] == "AC1032"
    assert inspect_info["source_id"].startswith("src_")


# ==============================================================================
# 2. DWG PROVIDER ARCHITECTURE & ISOLATION TESTS
# ==============================================================================

def test_provider_unavailable_handling(tmp_path: Path):
    """Test 15: Proveedor ausente no genera import error y reporta estado UNAVAILABLE de forma limpia."""
    # Configurar provider apuntando a ejecutables inexistentes
    provider = LibreDWGProvider(
        executable_path=str(tmp_path / "non_existent_dwgread.exe"),
        converter_path=str(tmp_path / "non_existent_dwg2dxf.exe"),
    )

    assert provider.is_available() is False
    assert provider.probe() is False

    health = provider.health_check()
    assert health.is_operational is False
    assert "not available" in health.notes.lower()


def test_dwg_reader_raises_when_unavailable_without_breaking_imports(tmp_path: Path):
    """DWGReader falla limpiamente con mensaje diagnóstico sin romper imports."""
    dwg_path = tmp_path / "test_sample_TEST_FIXTURE_ONLY.dwg"
    dwg_path.write_bytes(b"AC1027DUMMY")

    reader = DWGReader()
    # Si LibreDWG no está en PATH y no hay DWG_TO_DXF_COMMAND:
    if not reader.dwg_registry.get_active_provider().is_available():
        with pytest.raises(RuntimeError) as exc_info:
            reader.read(dwg_path)
        assert "UNAVAILABLE" in str(exc_info.value) or "conversor" in str(exc_info.value)


def test_provider_registry_auto_selection():
    """El registro selecciona dinámicamente y expone la matriz de capabilities."""
    registry = DWGProviderRegistry()
    active = registry.get_active_provider()
    assert active is not None
    assert active.provider_id == "LIBREDWG"

    caps = active.get_capabilities()
    assert isinstance(caps, ProviderCapabilities)
    assert hasattr(caps, "layers")
    assert hasattr(caps, "modelspace")


def test_temp_directory_cleanup(tmp_path: Path):
    """La ingesta con intermediarios limpia los temporales a menos que KEEP_DWG_INTERMEDIATES esté activo."""
    provider = LibreDWGProvider(keep_intermediates=False)
    assert provider.keep_intermediates is False
