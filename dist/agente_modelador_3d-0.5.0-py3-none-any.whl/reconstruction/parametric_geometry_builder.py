from __future__ import annotations

import hashlib
import math
from typing import Any
from core.geometry_kernel import (
    LocalFrame,
    Point3D,
    Vector3D,
    add_vector,
)
from core.models import (
    DataGap,
    DocumentConflict,
    GeometryRecipe,
    ParametricGeometry,
    QualityConfidenceLevel,
    RecipeType,
    ReconstructedObject,
)


class ParametricGeometryBuilder:
    """
    Motor de generación paramétrica de sólidos 3D trazables.
    
    Responsabilidad:
    - Construir representaciones paramétricas cerradas (vértices, caras, bounding box, volumen).
    - Evaluar si un ReconstructedObject reúne las condiciones necesarias.
    - REGLA: Si faltan dimensiones o hay conflicto documental crítico, devolver NOT_BUILT
      con causa explícita. NUNCA inventar dimensiones faltantes.
    """

    def build_geometry(
        self,
        obj: ReconstructedObject,
        recipe: GeometryRecipe,
        gaps: list[DataGap] | None = None,
    ) -> ParametricGeometry:
        """
        Construye el sólido paramétrico a partir de la receta y valida su completitud.
        """
        geom_id = f"geom_{hashlib.sha256((obj.object_id + recipe.recipe_id).encode('utf-8')).hexdigest()[:8]}"

        # 1. Verificar si existen conflictos no resueltos
        if obj.conflicts:
            unresolved_conflicts = [c for c in obj.conflicts if c.resolution != "RESOLVED"]
            if unresolved_conflicts:
                return ParametricGeometry(
                    geometry_id=geom_id,
                    object_id=obj.object_id,
                    recipe_id=recipe.recipe_id,
                    geometry_type=recipe.recipe_type,
                    is_built=False,
                    build_failure_reason="DOCUMENT_CONFLICT_UNRESOLVED",
                    conflicts=[c.to_dict() for c in unresolved_conflicts],
                    geometry_confidence=QualityConfidenceLevel.NOT_EVALUATED,
                )

        # 2. Verificar parámetros no resueltos en la receta
        if recipe.unresolved_parameters:
            return ParametricGeometry(
                geometry_id=geom_id,
                object_id=obj.object_id,
                recipe_id=recipe.recipe_id,
                geometry_type=recipe.recipe_type,
                is_built=False,
                build_failure_reason=f"MISSING_REQUIRED_PARAMETERS: {', '.join(recipe.unresolved_parameters)}",
                data_gaps=[g.to_dict() for g in (gaps or [])],
                geometry_confidence=QualityConfidenceLevel.NOT_EVALUATED,
            )

        # 3. Construir según el tipo de receta
        if recipe.recipe_type == RecipeType.RECTANGULAR_EXTRUSION:
            return self._build_rectangular_extrusion(obj, recipe, geom_id)
        elif recipe.recipe_type == RecipeType.CIRCULAR_EXTRUSION:
            return self._build_circular_extrusion(obj, recipe, geom_id)
        else:
            return ParametricGeometry(
                geometry_id=geom_id,
                object_id=obj.object_id,
                recipe_id=recipe.recipe_id,
                geometry_type=recipe.recipe_type,
                is_built=False,
                build_failure_reason=f"UNSUPPORTED_OR_UNKNOWN_RECIPE_TYPE: {recipe.recipe_type.value}",
                geometry_confidence=QualityConfidenceLevel.NOT_EVALUATED,
            )

    def _build_rectangular_extrusion(
        self,
        obj: ReconstructedObject,
        recipe: GeometryRecipe,
        geom_id: str,
    ) -> ParametricGeometry:
        """
        Construye un prisma rectangular 3D paramétrico a partir de ancho, espesor/alto y longitud.
        """
        w = float(recipe.source_parameters.get("ANCHO", 0.0))
        h = float(recipe.source_parameters.get("ESPESOR", 0.0) or recipe.source_parameters.get("ALTURA", 0.0))
        length = float(recipe.source_parameters.get("LONGITUD", 0.0))

        if w <= 0.0 or h <= 0.0 or length <= 0.0:
            return ParametricGeometry(
                geometry_id=geom_id,
                object_id=obj.object_id,
                recipe_id=recipe.recipe_id,
                geometry_type=recipe.recipe_type,
                is_built=False,
                build_failure_reason="INVALID_DIMENSIONS_ZERO_OR_NEGATIVE",
                geometry_confidence=QualityConfidenceLevel.NOT_EVALUATED,
            )

        # Marco local
        lf_dict = recipe.local_frame or {}
        orig = lf_dict.get("origin", (0.0, 0.0, 0.0))
        p_orig = Point3D(orig[0], orig[1], orig[2])

        # Vértices del prisma rectangular centrado transversalmente [-w/2, w/2], [0, h], [0, length]
        # o alineado al sistema local
        hw = w / 2.0
        # 8 vértices en coordenadas locales transformadas al origen
        # Base inicial (u=0)
        v0 = [p_orig.x, p_orig.y - hw, p_orig.z]
        v1 = [p_orig.x, p_orig.y + hw, p_orig.z]
        v2 = [p_orig.x, p_orig.y + hw, p_orig.z + h]
        v3 = [p_orig.x, p_orig.y - hw, p_orig.z + h]
        # Base final (extruida a lo largo de X longitud)
        v4 = [p_orig.x + length, p_orig.y - hw, p_orig.z]
        v5 = [p_orig.x + length, p_orig.y + hw, p_orig.z]
        v6 = [p_orig.x + length, p_orig.y + hw, p_orig.z + h]
        v7 = [p_orig.x + length, p_orig.y - hw, p_orig.z + h]

        vertices = [v0, v1, v2, v3, v4, v5, v6, v7]

        # 6 caras cuadrangulares
        faces = [
            [0, 3, 2, 1],  # Tapa inicio
            [4, 5, 6, 7],  # Tapa fin
            [0, 1, 5, 4],  # Cara inferior
            [2, 3, 7, 6],  # Cara superior
            [0, 4, 7, 3],  # Cara lateral izquierda
            [1, 2, 6, 5],  # Cara lateral derecha
        ]

        vol = round(w * h * length, 4)
        area = round(2 * (w * h + w * length + h * length), 4)

        all_x = [v[0] for v in vertices]
        all_y = [v[1] for v in vertices]
        all_z = [v[2] for v in vertices]

        bbox = {
            "minx": min(all_x),
            "maxx": max(all_x),
            "miny": min(all_y),
            "maxy": max(all_y),
            "minz": min(all_z),
            "maxz": max(all_z),
        }

        return ParametricGeometry(
            geometry_id=geom_id,
            object_id=obj.object_id,
            recipe_id=recipe.recipe_id,
            geometry_type=recipe.recipe_type,
            parameters={"ANCHO": w, "ESPESOR": h, "LONGITUD": length},
            local_frame=recipe.local_frame,
            vertices=vertices,
            faces=faces,
            bounding_box=bbox,
            volume=vol,
            surface_area=area,
            source_traceability=[{"source": s} for s in obj.source_documents],
            geometry_confidence=recipe.geometry_confidence,
            is_built=True,
        )

    def _build_circular_extrusion(
        self,
        obj: ReconstructedObject,
        recipe: GeometryRecipe,
        geom_id: str,
        num_segments: int = 16,
    ) -> ParametricGeometry:
        """
        Construye un cilindro paramétrico a partir de radio y altura (longitud).
        """
        r = float(recipe.source_parameters.get("RADIO", 0.0))
        h = float(recipe.source_parameters.get("ALTURA", 0.0))

        if r <= 0.0 or h <= 0.0:
            return ParametricGeometry(
                geometry_id=geom_id,
                object_id=obj.object_id,
                recipe_id=recipe.recipe_id,
                geometry_type=recipe.recipe_type,
                is_built=False,
                build_failure_reason="INVALID_DIMENSIONS_ZERO_OR_NEGATIVE",
                geometry_confidence=QualityConfidenceLevel.NOT_EVALUATED,
            )

        lf_dict = recipe.local_frame or {}
        orig = lf_dict.get("origin", (0.0, 0.0, 0.0))
        p_orig = Point3D(orig[0], orig[1], orig[2])

        # Vértices de la base inferior y superior
        # Extrusión a lo largo del eje Z del local frame
        vertices: list[list[float]] = []
        for i in range(num_segments):
            theta = 2.0 * math.pi * i / num_segments
            vx = p_orig.x + r * math.cos(theta)
            vy = p_orig.y + r * math.sin(theta)
            vz = p_orig.z
            vertices.append([round(vx, 4), round(vy, 4), round(vz, 4)])

        for i in range(num_segments):
            theta = 2.0 * math.pi * i / num_segments
            vx = p_orig.x + r * math.cos(theta)
            vy = p_orig.y + r * math.sin(theta)
            vz = p_orig.z + h
            vertices.append([round(vx, 4), round(vy, 4), round(vz, 4)])

        # Caras laterales
        faces: list[list[int]] = []
        for i in range(num_segments):
            next_i = (i + 1) % num_segments
            faces.append([i, next_i, next_i + num_segments, i + num_segments])

        # Tapas circulares aproximadas por polígonos
        faces.append(list(range(num_segments - 1, -1, -1)))
        faces.append(list(range(num_segments, 2 * num_segments)))

        vol = round(math.pi * (r ** 2) * h, 4)
        area = round(2.0 * math.pi * r * h + 2.0 * math.pi * (r ** 2), 4)

        all_x = [v[0] for v in vertices]
        all_y = [v[1] for v in vertices]
        all_z = [v[2] for v in vertices]

        bbox = {
            "minx": min(all_x),
            "maxx": max(all_x),
            "miny": min(all_y),
            "maxy": max(all_y),
            "minz": min(all_z),
            "maxz": max(all_z),
        }

        return ParametricGeometry(
            geometry_id=geom_id,
            object_id=obj.object_id,
            recipe_id=recipe.recipe_id,
            geometry_type=recipe.recipe_type,
            parameters={"RADIO": r, "ALTURA": h},
            local_frame=recipe.local_frame,
            vertices=vertices,
            faces=faces,
            bounding_box=bbox,
            volume=vol,
            surface_area=area,
            source_traceability=[{"source": s} for s in obj.source_documents],
            geometry_confidence=recipe.geometry_confidence,
            is_built=True,
        )
